################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgAsDensityModelPluginAtmFluxLagsConfig", "AgAsDensityModelPluginSample", "AgAsDensityModelResult", "AgAsDensityModelResultEval", 
"AgAsDensityModelResultRegister", "AgAsDragModelPluginSample", "AgAsDragModelResult", "AgAsDragModelResultEval", "AgAsDragModelResultRegister", 
"AgAsEOMFuncPluginRegisterHandler", "AgAsEOMFuncPluginSetIndicesHandler", "AgAsEOMFuncPluginStateVector", "AgAsHpopPluginResult", 
"AgAsHpopPluginResultEval", "AgAsHpopPluginResultPostEval", "AgAsHpopPluginSampleEngine", "AgAsLightReflectionPluginSample", 
"AgAsLightReflectionResult", "AgAsLightReflectionResultEval", "AgAsLightReflectionResultRegister", "AgEAccelType", "AgEAsDensityModelErrorCodes", 
"AgEAsDragModelErrorCodes", "AgEAsEOMFuncPluginErrorCodes", "AgEAsEOMFuncPluginEventTypes", "AgEAsEOMFuncPluginInputStateValues", 
"AgEAsEOMFuncPluginOutputStateValues", "AgEAsHpopPluginErrorCodes", "AgEAsHpopPluginEventIndicators", "AgEAsLightReflectionErrorCodes", 
"AgEForceModelType", "AgEOMFuncHPOPPluginResult", "AgEOMFuncHPOPPluginResultEval", "AgEOMFuncHPOPPluginResultPostEval", 
"IAgAsDensityModelPlugin", "IAgAsDensityModelPluginAtmFluxLags", "IAgAsDensityModelPluginAtmFluxLagsConfig", "IAgAsDensityModelPluginExtended", 
"IAgAsDensityModelPluginSample", "IAgAsDensityModelResult", "IAgAsDensityModelResultEval", "IAgAsDensityModelResultRegister", 
"IAgAsDragModelPlugin", "IAgAsDragModelPlugin2", "IAgAsDragModelPluginSample", "IAgAsDragModelResult", "IAgAsDragModelResultEval", 
"IAgAsDragModelResultRegister", "IAgAsEOMFuncPlugin", "IAgAsEOMFuncPluginRegisterHandler", "IAgAsEOMFuncPluginSetIndicesHandler", 
"IAgAsEOMFuncPluginStateVector", "IAgAsHpopPlugin", "IAgAsHpopPluginResult", "IAgAsHpopPluginResultEval", "IAgAsHpopPluginResultPostEval", 
"IAgAsHpopPluginSampleEngine", "IAgAsLightReflectionPlugin", "IAgAsLightReflectionPlugin2", "IAgAsLightReflectionPluginSample", 
"IAgAsLightReflectionResult", "IAgAsLightReflectionResultEval", "IAgAsLightReflectionResultRegister"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.attrautomation import *
from ..plugins.utplugin import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEForceModelType(IntEnum):
    """Enumeration of force model contributors"""
   
    eGravityModel = 0
    """Gravity."""
    eSolidTidesModel = 1
    """Solid tides."""
    eOceanTidesModel = 2
    """Ocean Tides."""
    eDragModel = 3
    """Atmospheric drag."""
    eSRPModel = 4
    """Solar radiation pressure."""
    eThirdBodyModel = 5
    """Third bodies."""
    eGenRelativityModel = 6
    """General relativity effects."""
    eAlbedoModel = 7
    """Albedo (solar radiation reflected from central body)."""
    eThermalRadiationPressureModel = 8
    """Thermal radiation pressure from central body."""
    eDensityModel = 9
    """Atmospheric Density."""

AgEForceModelType.eGravityModel.__doc__ = "Gravity."
AgEForceModelType.eSolidTidesModel.__doc__ = "Solid tides."
AgEForceModelType.eOceanTidesModel.__doc__ = "Ocean Tides."
AgEForceModelType.eDragModel.__doc__ = "Atmospheric drag."
AgEForceModelType.eSRPModel.__doc__ = "Solar radiation pressure."
AgEForceModelType.eThirdBodyModel.__doc__ = "Third bodies."
AgEForceModelType.eGenRelativityModel.__doc__ = "General relativity effects."
AgEForceModelType.eAlbedoModel.__doc__ = "Albedo (solar radiation reflected from central body)."
AgEForceModelType.eThermalRadiationPressureModel.__doc__ = "Thermal radiation pressure from central body."
AgEForceModelType.eDensityModel.__doc__ = "Atmospheric Density."

agcls.AgTypeNameMap["AgEForceModelType"] = AgEForceModelType

class AgEAsHpopPluginErrorCodes(IntEnum):
    """Enumeration of AgAsHpopPlugin General Error Codes"""
   
    eHpopPluginErrorInternalFailure = (((1 << 31) | (4 << 16)) | 0x101)
    """Hpop Plugin: An internal failure occurred."""
    eHpopPluginErrorNotConfigured = (((1 << 31) | (4 << 16)) | 0x102)
    """Hpop Plugin: Not configured properly."""
    eHpopPluginErrorSRPIsOff = (((1 << 31) | (4 << 16)) | 0x103)
    """Hpop Plugin: SRP is turned off."""
    eHpopPluginErrorDragIsOff = (((1 << 31) | (4 << 16)) | 0x104)
    """Hpop Plugin: Drag is turned off."""
    eHpopPluginErrorGravityFieldUndefined = (((1 << 31) | (4 << 16)) | 0x105)
    """Hpop Plugin: Gravity field is undefined."""
    eHpopPluginErrorForceModelTypeNotFound = (((1 << 31) | (4 << 16)) | 0x106)
    """Hpop Plugin: Force Model Type was not found."""
    eHpopPluginErrorInvalidSquareRoot = (((1 << 31) | (4 << 16)) | 0x107)
    """Hpop Plugin: The Square Root of an invalid value occurred."""
    eHpopPluginErrorTemperatureUnavailable = (((1 << 31) | (4 << 16)) | 0x108)
    """Hpop Plugin: Density model does not provide temperature."""
    eHpopPluginErrorPressureUnavailable = (((1 << 31) | (4 << 16)) | 0x109)
    """Hpop Plugin: Density model does not provide pressure."""
    eHpopPluginErrorInvalidAccelerationType = (((1 << 31) | (4 << 16)) | 0x10A)
    """Hpop Plugin: The acceleration type provided as input was invalid. Valid values range from 0 to 10."""
    eHpopPluginErrorRadiationPressureIsOff = (((1 << 31) | (4 << 16)) | 0x10B)
    """Hpop Plugin: Both albedo and thermal radiation pressure accelerations are off."""
    eHpopPluginErrorNoFuel = (((1 << 31) | (4 << 16)) | 0x10C)
    """Hpop Plugin: Fuel mass is not available in HPOP."""
    eHpopPluginErrorNotUsingFluxFile = (((1 << 31) | (4 << 16)) | 0x10D)
    """Hpop Plugin: Not using a flux file."""
    eHpopPluginErrorSetTotalMassInvalid = (((1 << 31) | (4 << 16)) | 0x10E)
    """Hpop Plugin: Can't set total mass in Astrogator.  Set dry mass or fuel mass."""

AgEAsHpopPluginErrorCodes.eHpopPluginErrorInternalFailure.__doc__ = "Hpop Plugin: An internal failure occurred."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorNotConfigured.__doc__ = "Hpop Plugin: Not configured properly."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorSRPIsOff.__doc__ = "Hpop Plugin: SRP is turned off."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorDragIsOff.__doc__ = "Hpop Plugin: Drag is turned off."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorGravityFieldUndefined.__doc__ = "Hpop Plugin: Gravity field is undefined."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorForceModelTypeNotFound.__doc__ = "Hpop Plugin: Force Model Type was not found."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorInvalidSquareRoot.__doc__ = "Hpop Plugin: The Square Root of an invalid value occurred."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorTemperatureUnavailable.__doc__ = "Hpop Plugin: Density model does not provide temperature."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorPressureUnavailable.__doc__ = "Hpop Plugin: Density model does not provide pressure."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorInvalidAccelerationType.__doc__ = "Hpop Plugin: The acceleration type provided as input was invalid. Valid values range from 0 to 10."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorRadiationPressureIsOff.__doc__ = "Hpop Plugin: Both albedo and thermal radiation pressure accelerations are off."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorNoFuel.__doc__ = "Hpop Plugin: Fuel mass is not available in HPOP."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorNotUsingFluxFile.__doc__ = "Hpop Plugin: Not using a flux file."
AgEAsHpopPluginErrorCodes.eHpopPluginErrorSetTotalMassInvalid.__doc__ = "Hpop Plugin: Can't set total mass in Astrogator.  Set dry mass or fuel mass."

agcls.AgTypeNameMap["AgEAsHpopPluginErrorCodes"] = AgEAsHpopPluginErrorCodes

class AgEAsHpopPluginEventIndicators(IntEnum):
    """Enumeration of AgAsHpopPlugin Event Indicators"""
   
    eHpopPluginEventIndicatorsStopPropagation = 0
    """Stops propagation."""
    eHpopPluginEventIndicatorsStopSegment = 1
    """Ends current segment."""
    eHpopPluginEventIndicatorsMarkDiscontinuity = 2
    """Marks a discontinuity."""

AgEAsHpopPluginEventIndicators.eHpopPluginEventIndicatorsStopPropagation.__doc__ = "Stops propagation."
AgEAsHpopPluginEventIndicators.eHpopPluginEventIndicatorsStopSegment.__doc__ = "Ends current segment."
AgEAsHpopPluginEventIndicators.eHpopPluginEventIndicatorsMarkDiscontinuity.__doc__ = "Marks a discontinuity."

agcls.AgTypeNameMap["AgEAsHpopPluginEventIndicators"] = AgEAsHpopPluginEventIndicators

class AgEAccelType(IntEnum):
    """Enumeration of contributions to the total force model acceleration"""
   
    eTotalAccel = 0
    """Total acceleration."""
    eTwoBodyAccel = 1
    """Two body contribution."""
    eGravityAccel = 2
    """Contribution of the total gravity field."""
    ePerturbedGravityAccel = 3
    """Contribution of the total gravity field minus the two body contribution."""
    eSolidTidesAccel = 4
    """Contribution of solid tides.  Will be zero if the force model is not set to consider this effect."""
    eOceanTidesAccel = 5
    """Contribution of ocean tides.  Will be zero if the force model is not set to consider this effect."""
    eDragAccel = 6
    """Contribution of atmospheric drag.  Will be zero if the force model is not set to consider this effect."""
    eSRPAccel = 7
    """Contribution of solar radiation pressure.  Will be zero if the force model is not set to consider this effect."""
    eThirdBodyAccel = 8
    """Contribution of all third bodies.  Will be zero if the force model is not considering any third body forces."""
    eGenRelativityAccel = 9
    """Contribution of general relativity effects.  Will be zero if the force model is not set to consider this effect."""
    eAddedAccel = 10
    """Contribution of any additional acceleration, say by a plugin."""
    eAlbedoAccel = 11
    """Contribution of albedo (reflected solar radiation pressure)."""
    eThermalRadiationPressureAccel = 12
    """Contribution of thermal radiation pressure."""

AgEAccelType.eTotalAccel.__doc__ = "Total acceleration."
AgEAccelType.eTwoBodyAccel.__doc__ = "Two body contribution."
AgEAccelType.eGravityAccel.__doc__ = "Contribution of the total gravity field."
AgEAccelType.ePerturbedGravityAccel.__doc__ = "Contribution of the total gravity field minus the two body contribution."
AgEAccelType.eSolidTidesAccel.__doc__ = "Contribution of solid tides.  Will be zero if the force model is not set to consider this effect."
AgEAccelType.eOceanTidesAccel.__doc__ = "Contribution of ocean tides.  Will be zero if the force model is not set to consider this effect."
AgEAccelType.eDragAccel.__doc__ = "Contribution of atmospheric drag.  Will be zero if the force model is not set to consider this effect."
AgEAccelType.eSRPAccel.__doc__ = "Contribution of solar radiation pressure.  Will be zero if the force model is not set to consider this effect."
AgEAccelType.eThirdBodyAccel.__doc__ = "Contribution of all third bodies.  Will be zero if the force model is not considering any third body forces."
AgEAccelType.eGenRelativityAccel.__doc__ = "Contribution of general relativity effects.  Will be zero if the force model is not set to consider this effect."
AgEAccelType.eAddedAccel.__doc__ = "Contribution of any additional acceleration, say by a plugin."
AgEAccelType.eAlbedoAccel.__doc__ = "Contribution of albedo (reflected solar radiation pressure)."
AgEAccelType.eThermalRadiationPressureAccel.__doc__ = "Contribution of thermal radiation pressure."

agcls.AgTypeNameMap["AgEAccelType"] = AgEAccelType

class AgEAsLightReflectionErrorCodes(IntEnum):
    """Enumeration of AgAsLightReflectionPlugin General Error Codes"""
   
    eLightReflectionErrorInternalFailure = (((1 << 31) | (4 << 16)) | 0x101)
    """LightReflection Plugin: An internal failure occurred."""
    eLightReflectionErrorNotConfigured = (((1 << 31) | (4 << 16)) | 0x102)
    """LightReflection Plugin: Not configured properly."""
    eLightReflectionErrorTransformFailure = (((1 << 31) | (4 << 16)) | 0x103)
    """LightReflection Plugin: Cannot transform vector from requested frame to specified frame."""
    eLightReflectionErrorSetReflectanceFailure = (((1 << 31) | (4 << 16)) | 0x104)
    """LightReflection Plugin: Cannot set reflectance."""
    eLightReflectionErrorSetReflectancePartialsFailure = (((1 << 31) | (4 << 16)) | 0x105)
    """LightReflection Plugin: Cannot set reflectance partials."""
    eLightReflectionErrorParameterIndexOutOfRange = (((1 << 31) | (4 << 16)) | 0x106)
    """LightReflection Plugin: The index number for the parameter is out of range."""
    eLightReflectionErrorParameterPartialsFailure = (((1 << 31) | (4 << 16)) | 0x107)
    """LightReflection Plugin:  Cannot set parameter partials."""
    eLightReflectionErrorPluginInputNotReal = (((1 << 31) | (4 << 16)) | 0x108)
    """LightReflection Plugin: Input value is not a real number.  Check for divide by zero."""
    eLightReflectionErrorParameterNotFound = (((1 << 31) | (4 << 16)) | 0x109)
    """LightReflection Plugin: The parameter cannot be found."""

AgEAsLightReflectionErrorCodes.eLightReflectionErrorInternalFailure.__doc__ = "LightReflection Plugin: An internal failure occurred."
AgEAsLightReflectionErrorCodes.eLightReflectionErrorNotConfigured.__doc__ = "LightReflection Plugin: Not configured properly."
AgEAsLightReflectionErrorCodes.eLightReflectionErrorTransformFailure.__doc__ = "LightReflection Plugin: Cannot transform vector from requested frame to specified frame."
AgEAsLightReflectionErrorCodes.eLightReflectionErrorSetReflectanceFailure.__doc__ = "LightReflection Plugin: Cannot set reflectance."
AgEAsLightReflectionErrorCodes.eLightReflectionErrorSetReflectancePartialsFailure.__doc__ = "LightReflection Plugin: Cannot set reflectance partials."
AgEAsLightReflectionErrorCodes.eLightReflectionErrorParameterIndexOutOfRange.__doc__ = "LightReflection Plugin: The index number for the parameter is out of range."
AgEAsLightReflectionErrorCodes.eLightReflectionErrorParameterPartialsFailure.__doc__ = "LightReflection Plugin:  Cannot set parameter partials."
AgEAsLightReflectionErrorCodes.eLightReflectionErrorPluginInputNotReal.__doc__ = "LightReflection Plugin: Input value is not a real number.  Check for divide by zero."
AgEAsLightReflectionErrorCodes.eLightReflectionErrorParameterNotFound.__doc__ = "LightReflection Plugin: The parameter cannot be found."

agcls.AgTypeNameMap["AgEAsLightReflectionErrorCodes"] = AgEAsLightReflectionErrorCodes

class AgEAsDragModelErrorCodes(IntEnum):
    """Enumeration of AgAsDragModelPlugin General Error Codes"""
   
    eDragModelErrorInternalFailure = (((1 << 31) | (4 << 16)) | 0x101)
    """DragModel Plugin: An internal failure occurred."""
    eDragModelErrorNotConfigured = (((1 << 31) | (4 << 16)) | 0x102)
    """DragModel Plugin: Not configured properly."""
    eDragModelErrorTransformFailure = (((1 << 31) | (4 << 16)) | 0x103)
    """DragModel Plugin: Cannot transform vector from requested frame to specified frame."""
    eDragModelErrorSetReflectanceFailure = (((1 << 31) | (4 << 16)) | 0x104)
    """DragModel Plugin: Cannot set reflectance."""
    eDragModelErrorSetReflectancePartialsFailure = (((1 << 31) | (4 << 16)) | 0x105)
    """DragModel Plugin: Cannot set reflectance partials."""
    eDragModelErrorParameterIndexOutOfRange = (((1 << 31) | (4 << 16)) | 0x106)
    """DragModel Plugin: The index number for the parameter is out of range."""
    eDragModelErrorParameterPartialsFailure = (((1 << 31) | (4 << 16)) | 0x107)
    """DragModel Plugin:  Cannot set parameter partials."""
    eDragModelErrorInputNotReal = (((1 << 31) | (4 << 16)) | 0x108)
    """DensityModel Plugin: Input value is not a real number.  Check for divide by zero."""
    eDragModelErrorParameterNotFound = (((1 << 31) | (4 << 16)) | 0x109)
    """DragModel Plugin: The parameter cannot be found."""

AgEAsDragModelErrorCodes.eDragModelErrorInternalFailure.__doc__ = "DragModel Plugin: An internal failure occurred."
AgEAsDragModelErrorCodes.eDragModelErrorNotConfigured.__doc__ = "DragModel Plugin: Not configured properly."
AgEAsDragModelErrorCodes.eDragModelErrorTransformFailure.__doc__ = "DragModel Plugin: Cannot transform vector from requested frame to specified frame."
AgEAsDragModelErrorCodes.eDragModelErrorSetReflectanceFailure.__doc__ = "DragModel Plugin: Cannot set reflectance."
AgEAsDragModelErrorCodes.eDragModelErrorSetReflectancePartialsFailure.__doc__ = "DragModel Plugin: Cannot set reflectance partials."
AgEAsDragModelErrorCodes.eDragModelErrorParameterIndexOutOfRange.__doc__ = "DragModel Plugin: The index number for the parameter is out of range."
AgEAsDragModelErrorCodes.eDragModelErrorParameterPartialsFailure.__doc__ = "DragModel Plugin:  Cannot set parameter partials."
AgEAsDragModelErrorCodes.eDragModelErrorInputNotReal.__doc__ = "DensityModel Plugin: Input value is not a real number.  Check for divide by zero."
AgEAsDragModelErrorCodes.eDragModelErrorParameterNotFound.__doc__ = "DragModel Plugin: The parameter cannot be found."

agcls.AgTypeNameMap["AgEAsDragModelErrorCodes"] = AgEAsDragModelErrorCodes

class AgEAsEOMFuncPluginErrorCodes(IntEnum):
    """Enumeration of AgAsEOMFuncPlugin General Error Codes"""
   
    eEOMFuncPluginErrorInternalFailure = (((1 << 31) | (4 << 16)) | 0x101)
    """EOMFunc Plugin: An internal failure occurred."""
    eEOMFuncPluginErrorNotConfigured = (((1 << 31) | (4 << 16)) | 0x102)
    """EOMFunc Plugin: Not configured properly."""
    eEOMFuncPluginErrorIndexOutOfRange = (((1 << 31) | (4 << 16)) | 0x103)
    """EOMFunc Plugin: Index out of valid range."""
    eEOMFuncPluginErrorInputNotRegistered = (((1 << 31) | (4 << 16)) | 0x104)
    """EOMFunc Plugin: Variable not registered as input."""
    eEOMFuncPluginErrorParamOutputNotRegistered = (((1 << 31) | (4 << 16)) | 0x105)
    """EOMFunc Plugin: Variable not registered as parameter output."""
    eEOMFuncPluginErrorDerivOutputNotRegistered = (((1 << 31) | (4 << 16)) | 0x106)
    """EOMFunc Plugin: Variable not registered as derivative output."""
    eEOMFuncPluginErrorInvalidStateVariable = (((1 << 31) | (4 << 16)) | 0x107)
    """EOMFunc Plugin: Invalid state variable."""
    eEOMFuncPluginErrorInvalidEventType = (((1 << 31) | (4 << 16)) | 0x108)
    """EOMFunc Plugin: Invalid event type."""
    eEOMFuncPluginErrorInputNotReal = (((1 << 31) | (4 << 16)) | 0x109)
    """EOMFunc Plugin: Input value is not a real number.  Check for divide by zero."""

AgEAsEOMFuncPluginErrorCodes.eEOMFuncPluginErrorInternalFailure.__doc__ = "EOMFunc Plugin: An internal failure occurred."
AgEAsEOMFuncPluginErrorCodes.eEOMFuncPluginErrorNotConfigured.__doc__ = "EOMFunc Plugin: Not configured properly."
AgEAsEOMFuncPluginErrorCodes.eEOMFuncPluginErrorIndexOutOfRange.__doc__ = "EOMFunc Plugin: Index out of valid range."
AgEAsEOMFuncPluginErrorCodes.eEOMFuncPluginErrorInputNotRegistered.__doc__ = "EOMFunc Plugin: Variable not registered as input."
AgEAsEOMFuncPluginErrorCodes.eEOMFuncPluginErrorParamOutputNotRegistered.__doc__ = "EOMFunc Plugin: Variable not registered as parameter output."
AgEAsEOMFuncPluginErrorCodes.eEOMFuncPluginErrorDerivOutputNotRegistered.__doc__ = "EOMFunc Plugin: Variable not registered as derivative output."
AgEAsEOMFuncPluginErrorCodes.eEOMFuncPluginErrorInvalidStateVariable.__doc__ = "EOMFunc Plugin: Invalid state variable."
AgEAsEOMFuncPluginErrorCodes.eEOMFuncPluginErrorInvalidEventType.__doc__ = "EOMFunc Plugin: Invalid event type."
AgEAsEOMFuncPluginErrorCodes.eEOMFuncPluginErrorInputNotReal.__doc__ = "EOMFunc Plugin: Input value is not a real number.  Check for divide by zero."

agcls.AgTypeNameMap["AgEAsEOMFuncPluginErrorCodes"] = AgEAsEOMFuncPluginErrorCodes

class AgEAsEOMFuncPluginInputStateValues(IntEnum):
    """Enumeration of state vector input values"""
   
    eEOMFuncPluginInputStateValuesPosX = 0
    """X-component of position (inertial)."""
    eEOMFuncPluginInputStateValuesPosY = 1
    """Y-component of position (inertial)."""
    eEOMFuncPluginInputStateValuesPosZ = 2
    """Z-component of position (inertial)."""
    eEOMFuncPluginInputStateValuesVelX = 3
    """X-component of velocity (inertial)."""
    eEOMFuncPluginInputStateValuesVelY = 4
    """Y-component of velocity (inertial)."""
    eEOMFuncPluginInputStateValuesVelZ = 5
    """Z-component of velocity (inertial)."""
    eEOMFuncPluginInputStateValuesPosCBFX = 6
    """X-component of position (fixed)."""
    eEOMFuncPluginInputStateValuesPosCBFY = 7
    """Y-component of position (fixed)"""
    eEOMFuncPluginInputStateValuesPosCBFZ = 8
    """Z-component of position (fixed)"""
    eEOMFuncPluginInputStateValuesVelCBFX = 9
    """X-component of velocity (fixed)"""
    eEOMFuncPluginInputStateValuesVelCBFY = 10
    """Y-component of velocity (fixed)"""
    eEOMFuncPluginInputStateValuesVelCBFZ = 11
    """Z-component of velocity (fixed)"""
    eEOMFuncPluginInputStateValuesCBIVelInCBFX = 12
    """X-component of inertial velocity expressed in fixed frame"""
    eEOMFuncPluginInputStateValuesCBIVelInCBFY = 13
    """Y-component of inertial velocity expressed in fixed frame"""
    eEOMFuncPluginInputStateValuesCBIVelInCBFZ = 14
    """Z-component of inertial velocity expressed in fixed frame"""
    eEOMFuncPluginInputStateValuesQuat1 = 15
    """Quaternion1"""
    eEOMFuncPluginInputStateValuesQuat2 = 16
    """Quaternion2"""
    eEOMFuncPluginInputStateValuesQuat3 = 17
    """Quaternion3"""
    eEOMFuncPluginInputStateValuesQuat4 = 18
    """Quaternion4"""
    eEOMFuncPluginInputStateValuesCBIToCBF00 = 19
    """0,0 entry of CBI to CBF rotation matrix"""
    eEOMFuncPluginInputStateValuesCBIToCBF01 = 20
    """0,1 entry of CBI to CBF rotation matrix"""
    eEOMFuncPluginInputStateValuesCBIToCBF02 = 21
    """0,2 entry of CBI to CBF rotation matrix"""
    eEOMFuncPluginInputStateValuesCBIToCBF10 = 22
    """1,0 entry of CBI to CBF rotation matrix"""
    eEOMFuncPluginInputStateValuesCBIToCBF11 = 23
    """1,1 entry of CBI to CBF rotation matrix"""
    eEOMFuncPluginInputStateValuesCBIToCBF12 = 24
    """1,2 entry of CBI to CBF rotation matrix"""
    eEOMFuncPluginInputStateValuesCBIToCBF20 = 25
    """2,0 entry of CBI to CBF rotation matrix"""
    eEOMFuncPluginInputStateValuesCBIToCBF21 = 26
    """2,1 entry of CBI to CBF rotation matrix"""
    eEOMFuncPluginInputStateValuesCBIToCBF22 = 27
    """2,2 entry of CBI to CBF rotation matrix"""
    eEOMFuncPluginInputStateValuesAngVelCBFX = 28
    """X-component of angular velocity in fixed frame"""
    eEOMFuncPluginInputStateValuesAngVelCBFY = 29
    """Y-component of angular velocity in fixed frame"""
    eEOMFuncPluginInputStateValuesAngVelCBFZ = 30
    """Z-component of angular velocity in fixed frame"""
    eEOMFuncPluginInputStateValuesAltitude = 31
    """Altitude"""
    eEOMFuncPluginInputStateValuesLatitude = 32
    """Latitude"""
    eEOMFuncPluginInputStateValuesLongitude = 33
    """Longitude"""
    eEOMFuncPluginInputStateValuesTotalMass = 34
    """Total mass."""
    eEOMFuncPluginInputStateValuesDryMass = 35
    """Dry mass."""
    eEOMFuncPluginInputStateValuesFuelMass = 36
    """Fuel mass."""
    eEOMFuncPluginInputStateValuesCd = 37
    """Drag coefficient (Cd)."""
    eEOMFuncPluginInputStateValuesDragArea = 38
    """Drag area."""
    eEOMFuncPluginInputStateValuesAtmosphericDensity = 39
    """Atmospheric density"""
    eEOMFuncPluginInputStateValuesAtmosphericAltitude = 40
    """Atmospheric altitude"""
    eEOMFuncPluginInputStateValuesCr = 41
    """SRP coefficient (Cr)."""
    eEOMFuncPluginInputStateValuesSRPArea = 42
    """SRP area."""
    eEOMFuncPluginInputStateValuesKr1 = 43
    """Kr1 parameter of GPS SRP models"""
    eEOMFuncPluginInputStateValuesKr2 = 44
    """Kr2 parameter of GPS SRP models"""
    eEOMFuncPluginInputStateValuesApparentToTrueCbSunPosCBFX = 45
    """ApparentToTrueCbSunPosCBFX"""
    eEOMFuncPluginInputStateValuesApparentToTrueCbSunPosCBFY = 46
    """ApparentToTrueCbSunPosCBFY"""
    eEOMFuncPluginInputStateValuesApparentToTrueCbSunPosCBFZ = 47
    """ApparentToTrueCbSunPosCBFZ"""
    eEOMFuncPluginInputStateValuesApparentToTrueCbSatPosCBFX = 48
    """ApparentToTrueCbSatPosCBFX"""
    eEOMFuncPluginInputStateValuesApparentToTrueCbSatPosCBFY = 49
    """ApparentToTrueCbSatPosCBFY"""
    eEOMFuncPluginInputStateValuesApparentToTrueCbSatPosCBFZ = 50
    """ApparentToTrueCbSatPosCBFZ"""
    eEOMFuncPluginInputStateValuesApparentToTrueCbSatToSunCBIPosX = 51
    """ApparentToTrueCbSatToSunCBIPosX"""
    eEOMFuncPluginInputStateValuesApparentToTrueCbSatToSunCBIPosY = 52
    """ApparentToTrueCbSatToSunCBIPosY"""
    eEOMFuncPluginInputStateValuesApparentToTrueCbSatToSunCBIPosZ = 53
    """ApparentToTrueCbSatToSunCBIPosZ"""
    eEOMFuncPluginInputStateValuesApparentSunPosCBFX = 54
    """ApparentSunPosCBFX"""
    eEOMFuncPluginInputStateValuesApparentSunPosCBFY = 55
    """ApparentSunPosCBFY"""
    eEOMFuncPluginInputStateValuesApparentSunPosCBFZ = 56
    """ApparentSunPosCBFZ"""
    eEOMFuncPluginInputStateValuesApparentSatPosCBFX = 57
    """ApparentSatPosCBFX"""
    eEOMFuncPluginInputStateValuesApparentSatPosCBFY = 58
    """ApparentSatPosCBFY"""
    eEOMFuncPluginInputStateValuesApparentSatPosCBFZ = 59
    """ApparentSatPosCBFZ"""
    eEOMFuncPluginInputStateValuesApparentSatToSunCBIPosX = 60
    """ApparentSatToSunCBIPosX"""
    eEOMFuncPluginInputStateValuesApparentSatToSunCBIPosY = 61
    """ApparentSatToSunCBIPosY"""
    eEOMFuncPluginInputStateValuesApparentSatToSunCBIPosZ = 62
    """ApparentSatToSunCBIPosZ"""
    eEOMFuncPluginInputStateValuesTrueSunPosCBFX = 63
    """TrueSunPosCBFX"""
    eEOMFuncPluginInputStateValuesTrueSunPosCBFY = 64
    """TrueSunPosCBFY"""
    eEOMFuncPluginInputStateValuesTrueSunPosCBFZ = 65
    """TrueSunPosCBFZ"""
    eEOMFuncPluginInputStateValuesTrueSatPosCBFX = 66
    """TrueSatPosCBFX"""
    eEOMFuncPluginInputStateValuesTrueSatPosCBFY = 67
    """TrueSatPosCBFY"""
    eEOMFuncPluginInputStateValuesTrueSatPosCBFZ = 68
    """TrueSatPosCBFZ"""
    eEOMFuncPluginInputStateValuesTrueSatToSunCBIPosX = 69
    """TrueSatToSunCBIPosX"""
    eEOMFuncPluginInputStateValuesTrueSatToSunCBIPosY = 70
    """TrueSatToSunCBIPosY"""
    eEOMFuncPluginInputStateValuesTrueSatToSunCBIPosZ = 71
    """TrueSatToSunCBIPosZ"""
    eEOMFuncPluginInputStateValuesSolarIntensity = 72
    """Solar intensity"""
    eEOMFuncPluginInputStateValuesRadPressureCoefficient = 73
    """Radiation pressure coefficient."""
    eEOMFuncPluginInputStateValuesRadPressureArea = 74
    """Radiation pressure area."""
    eEOMFuncPluginInputStateValuesMassFlowRate = 75
    """Mass flow rate."""
    eEOMFuncPluginInputStateValuesTankPressure = 76
    """Tank pressure."""
    eEOMFuncPluginInputStateValuesTankTemperature = 77
    """Tank temperature."""
    eEOMFuncPluginInputStateValuesFuelDensity = 78
    """Fuel density."""
    eEOMFuncPluginInputStateValuesThrustX = 79
    """x-component of thrust"""
    eEOMFuncPluginInputStateValuesThrustY = 80
    """y-component of thrust."""
    eEOMFuncPluginInputStateValuesThrustZ = 81
    """z-component of thrust."""
    eEOMFuncPluginInputStateValuesDeltaV = 82
    """Delta-V (integrated)."""
    eEOMFuncPluginInputStateValuesGravityAccelX = 83
    """GravityAccelX"""
    eEOMFuncPluginInputStateValuesGravityAccelY = 84
    """GravityAccelY"""
    eEOMFuncPluginInputStateValuesGravityAccelZ = 85
    """GravityAccelZ"""
    eEOMFuncPluginInputStateValuesTwoBodyAccelX = 86
    """TwoBodyAccelX"""
    eEOMFuncPluginInputStateValuesTwoBodyAccelY = 87
    """TwoBodyAccelY"""
    eEOMFuncPluginInputStateValuesTwoBodyAccelZ = 88
    """TwoBodyAccelZ"""
    eEOMFuncPluginInputStateValuesGravityPertAccelX = 89
    """GravityPertAccelX"""
    eEOMFuncPluginInputStateValuesGravityPertAccelY = 90
    """GravityPertAccelY"""
    eEOMFuncPluginInputStateValuesGravityPertAccelZ = 91
    """GravityPertAccelZ"""
    eEOMFuncPluginInputStateValuesSolidTidesAccelX = 92
    """SolidTidesAccelX"""
    eEOMFuncPluginInputStateValuesSolidTidesAccelY = 93
    """SolidTidesAccelY"""
    eEOMFuncPluginInputStateValuesSolidTidesAccelZ = 94
    """SolidTidesAccelZ"""
    eEOMFuncPluginInputStateValuesOceanTidesAccelX = 95
    """OceanTidesAccelX"""
    eEOMFuncPluginInputStateValuesOceanTidesAccelY = 96
    """OceanTidesAccelY"""
    eEOMFuncPluginInputStateValuesOceanTidesAccelZ = 97
    """OceanTidesAccelZ"""
    eEOMFuncPluginInputStateValuesDragAccelX = 98
    """DragAccelX"""
    eEOMFuncPluginInputStateValuesDragAccelY = 99
    """DragAccelY"""
    eEOMFuncPluginInputStateValuesDragAccelZ = 100
    """DragAccelZ"""
    eEOMFuncPluginInputStateValuesThirdBodyAccelX = 101
    """ThirdBodyAccelX"""
    eEOMFuncPluginInputStateValuesThirdBodyAccelY = 102
    """ThirdBodyAccelY"""
    eEOMFuncPluginInputStateValuesThirdBodyAccelZ = 103
    """ThirdBodyAccelZ"""
    eEOMFuncPluginInputStateValuesSRPAccelX = 104
    """SRPAccelX"""
    eEOMFuncPluginInputStateValuesSRPAccelY = 105
    """SRPAccelY"""
    eEOMFuncPluginInputStateValuesSRPAccelZ = 106
    """SRPAccelZ"""
    eEOMFuncPluginInputStateValuesNoShadowSRPAccelX = 107
    """X-component of SRP acceleration without accounting for shadow"""
    eEOMFuncPluginInputStateValuesNoShadowSRPAccelY = 108
    """Y-component of SRP acceleration without accounting for shadow"""
    eEOMFuncPluginInputStateValuesNoShadowSRPAccelZ = 109
    """Z-component of SRP acceleration without accounting for shadow"""
    eEOMFuncPluginInputStateValuesGenRelAccelX = 110
    """GenRelAccelX"""
    eEOMFuncPluginInputStateValuesGenRelAccelY = 111
    """GenRelAccelY"""
    eEOMFuncPluginInputStateValuesGenRelAccelZ = 112
    """GenRelAccelZ"""
    eEOMFuncPluginInputStateValuesAlbedoAccelX = 113
    """AlbedoAccelX"""
    eEOMFuncPluginInputStateValuesAlbedoAccelY = 114
    """AlbedoAccelY"""
    eEOMFuncPluginInputStateValuesAlbedoAccelZ = 115
    """AlbedoAccelZ"""
    eEOMFuncPluginInputStateValuesThermalPressureAccelX = 116
    """ThermalPressureAccelX"""
    eEOMFuncPluginInputStateValuesThermalPressureAccelY = 117
    """ThermalPressureAccelY"""
    eEOMFuncPluginInputStateValuesThermalPressureAccelZ = 118
    """ThermalPressureAccelZ"""
    eEOMFuncPluginInputStateValuesAddedAccelX = 119
    """X-component of acceleration added by plugins"""
    eEOMFuncPluginInputStateValuesAddedAccelY = 120
    """Y-component of acceleration added by plugins"""
    eEOMFuncPluginInputStateValuesAddedAccelZ = 121
    """Z-component of acceleration added by plugins"""
    eEOMFuncPluginInputStateValuesStateTransPosXPosX = 122
    """StateTransPosXPosX"""
    eEOMFuncPluginInputStateValuesStateTransPosXPosY = 123
    """StateTransPosXPosY"""
    eEOMFuncPluginInputStateValuesStateTransPosXPosZ = 124
    """StateTransPosXPosZ"""
    eEOMFuncPluginInputStateValuesStateTransPosXVelX = 125
    """StateTransPosXVelX"""
    eEOMFuncPluginInputStateValuesStateTransPosXVelY = 126
    """StateTransPosXVelY"""
    eEOMFuncPluginInputStateValuesStateTransPosXVelZ = 127
    """StateTransPosXVelZ"""
    eEOMFuncPluginInputStateValuesStateTransPosYPosX = 128
    """StateTransPosYPosX"""
    eEOMFuncPluginInputStateValuesStateTransPosYPosY = 129
    """StateTransPosYPosY"""
    eEOMFuncPluginInputStateValuesStateTransPosYPosZ = 130
    """StateTransPosYPosZ"""
    eEOMFuncPluginInputStateValuesStateTransPosYVelX = 131
    """StateTransPosYVelX"""
    eEOMFuncPluginInputStateValuesStateTransPosYVelY = 132
    """StateTransPosYVelY"""
    eEOMFuncPluginInputStateValuesStateTransPosYVelZ = 133
    """StateTransPosYVelZ"""
    eEOMFuncPluginInputStateValuesStateTransPosZPosX = 134
    """StateTransPosZPosX"""
    eEOMFuncPluginInputStateValuesStateTransPosZPosY = 135
    """StateTransPosZPosY"""
    eEOMFuncPluginInputStateValuesStateTransPosZPosZ = 136
    """StateTransPosZPosZ"""
    eEOMFuncPluginInputStateValuesStateTransPosZVelX = 137
    """StateTransPosZVelX"""
    eEOMFuncPluginInputStateValuesStateTransPosZVelY = 138
    """StateTransPosZVelY"""
    eEOMFuncPluginInputStateValuesStateTransPosZVelZ = 139
    """StateTransPosZVelZ"""
    eEOMFuncPluginInputStateValuesStateTransVelXPosX = 140
    """StateTransVelXPosX"""
    eEOMFuncPluginInputStateValuesStateTransVelXPosY = 141
    """StateTransVelXPosY"""
    eEOMFuncPluginInputStateValuesStateTransVelXPosZ = 142
    """StateTransVelXPosZ"""
    eEOMFuncPluginInputStateValuesStateTransVelXVelX = 143
    """StateTransVelXVelX"""
    eEOMFuncPluginInputStateValuesStateTransVelXVelY = 144
    """StateTransVelXVelY"""
    eEOMFuncPluginInputStateValuesStateTransVelXVelZ = 145
    """StateTransVelXVelZ"""
    eEOMFuncPluginInputStateValuesStateTransVelYPosX = 146
    """StateTransVelYPosX"""
    eEOMFuncPluginInputStateValuesStateTransVelYPosY = 147
    """StateTransVelYPosY"""
    eEOMFuncPluginInputStateValuesStateTransVelYPosZ = 148
    """StateTransVelYPosZ"""
    eEOMFuncPluginInputStateValuesStateTransVelYVelX = 149
    """StateTransVelYVelX"""
    eEOMFuncPluginInputStateValuesStateTransVelYVelY = 150
    """StateTransVelYVelY"""
    eEOMFuncPluginInputStateValuesStateTransVelYVelZ = 151
    """StateTransVelYVelZ"""
    eEOMFuncPluginInputStateValuesStateTransVelZPosX = 152
    """StateTransVelZPosX"""
    eEOMFuncPluginInputStateValuesStateTransVelZPosY = 153
    """StateTransVelZPosY"""
    eEOMFuncPluginInputStateValuesStateTransVelZPosZ = 154
    """StateTransVelZPosZ"""
    eEOMFuncPluginInputStateValuesStateTransVelZVelX = 155
    """StateTransVelZVelX"""
    eEOMFuncPluginInputStateValuesStateTransVelZVelY = 156
    """StateTransVelZVelY"""
    eEOMFuncPluginInputStateValuesStateTransVelZVelZ = 157
    """StateTransVelZVelZ"""

AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesPosX.__doc__ = "X-component of position (inertial)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesPosY.__doc__ = "Y-component of position (inertial)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesPosZ.__doc__ = "Z-component of position (inertial)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesVelX.__doc__ = "X-component of velocity (inertial)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesVelY.__doc__ = "Y-component of velocity (inertial)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesVelZ.__doc__ = "Z-component of velocity (inertial)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesPosCBFX.__doc__ = "X-component of position (fixed)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesPosCBFY.__doc__ = "Y-component of position (fixed)"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesPosCBFZ.__doc__ = "Z-component of position (fixed)"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesVelCBFX.__doc__ = "X-component of velocity (fixed)"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesVelCBFY.__doc__ = "Y-component of velocity (fixed)"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesVelCBFZ.__doc__ = "Z-component of velocity (fixed)"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIVelInCBFX.__doc__ = "X-component of inertial velocity expressed in fixed frame"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIVelInCBFY.__doc__ = "Y-component of inertial velocity expressed in fixed frame"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIVelInCBFZ.__doc__ = "Z-component of inertial velocity expressed in fixed frame"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesQuat1.__doc__ = "Quaternion1"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesQuat2.__doc__ = "Quaternion2"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesQuat3.__doc__ = "Quaternion3"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesQuat4.__doc__ = "Quaternion4"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIToCBF00.__doc__ = "0,0 entry of CBI to CBF rotation matrix"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIToCBF01.__doc__ = "0,1 entry of CBI to CBF rotation matrix"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIToCBF02.__doc__ = "0,2 entry of CBI to CBF rotation matrix"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIToCBF10.__doc__ = "1,0 entry of CBI to CBF rotation matrix"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIToCBF11.__doc__ = "1,1 entry of CBI to CBF rotation matrix"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIToCBF12.__doc__ = "1,2 entry of CBI to CBF rotation matrix"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIToCBF20.__doc__ = "2,0 entry of CBI to CBF rotation matrix"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIToCBF21.__doc__ = "2,1 entry of CBI to CBF rotation matrix"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCBIToCBF22.__doc__ = "2,2 entry of CBI to CBF rotation matrix"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAngVelCBFX.__doc__ = "X-component of angular velocity in fixed frame"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAngVelCBFY.__doc__ = "Y-component of angular velocity in fixed frame"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAngVelCBFZ.__doc__ = "Z-component of angular velocity in fixed frame"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAltitude.__doc__ = "Altitude"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesLatitude.__doc__ = "Latitude"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesLongitude.__doc__ = "Longitude"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTotalMass.__doc__ = "Total mass."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesDryMass.__doc__ = "Dry mass."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesFuelMass.__doc__ = "Fuel mass."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCd.__doc__ = "Drag coefficient (Cd)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesDragArea.__doc__ = "Drag area."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAtmosphericDensity.__doc__ = "Atmospheric density"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAtmosphericAltitude.__doc__ = "Atmospheric altitude"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesCr.__doc__ = "SRP coefficient (Cr)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesSRPArea.__doc__ = "SRP area."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesKr1.__doc__ = "Kr1 parameter of GPS SRP models"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesKr2.__doc__ = "Kr2 parameter of GPS SRP models"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentToTrueCbSunPosCBFX.__doc__ = "ApparentToTrueCbSunPosCBFX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentToTrueCbSunPosCBFY.__doc__ = "ApparentToTrueCbSunPosCBFY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentToTrueCbSunPosCBFZ.__doc__ = "ApparentToTrueCbSunPosCBFZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentToTrueCbSatPosCBFX.__doc__ = "ApparentToTrueCbSatPosCBFX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentToTrueCbSatPosCBFY.__doc__ = "ApparentToTrueCbSatPosCBFY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentToTrueCbSatPosCBFZ.__doc__ = "ApparentToTrueCbSatPosCBFZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentToTrueCbSatToSunCBIPosX.__doc__ = "ApparentToTrueCbSatToSunCBIPosX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentToTrueCbSatToSunCBIPosY.__doc__ = "ApparentToTrueCbSatToSunCBIPosY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentToTrueCbSatToSunCBIPosZ.__doc__ = "ApparentToTrueCbSatToSunCBIPosZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentSunPosCBFX.__doc__ = "ApparentSunPosCBFX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentSunPosCBFY.__doc__ = "ApparentSunPosCBFY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentSunPosCBFZ.__doc__ = "ApparentSunPosCBFZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentSatPosCBFX.__doc__ = "ApparentSatPosCBFX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentSatPosCBFY.__doc__ = "ApparentSatPosCBFY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentSatPosCBFZ.__doc__ = "ApparentSatPosCBFZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentSatToSunCBIPosX.__doc__ = "ApparentSatToSunCBIPosX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentSatToSunCBIPosY.__doc__ = "ApparentSatToSunCBIPosY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesApparentSatToSunCBIPosZ.__doc__ = "ApparentSatToSunCBIPosZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTrueSunPosCBFX.__doc__ = "TrueSunPosCBFX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTrueSunPosCBFY.__doc__ = "TrueSunPosCBFY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTrueSunPosCBFZ.__doc__ = "TrueSunPosCBFZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTrueSatPosCBFX.__doc__ = "TrueSatPosCBFX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTrueSatPosCBFY.__doc__ = "TrueSatPosCBFY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTrueSatPosCBFZ.__doc__ = "TrueSatPosCBFZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTrueSatToSunCBIPosX.__doc__ = "TrueSatToSunCBIPosX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTrueSatToSunCBIPosY.__doc__ = "TrueSatToSunCBIPosY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTrueSatToSunCBIPosZ.__doc__ = "TrueSatToSunCBIPosZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesSolarIntensity.__doc__ = "Solar intensity"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesRadPressureCoefficient.__doc__ = "Radiation pressure coefficient."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesRadPressureArea.__doc__ = "Radiation pressure area."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesMassFlowRate.__doc__ = "Mass flow rate."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTankPressure.__doc__ = "Tank pressure."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTankTemperature.__doc__ = "Tank temperature."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesFuelDensity.__doc__ = "Fuel density."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesThrustX.__doc__ = "x-component of thrust"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesThrustY.__doc__ = "y-component of thrust."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesThrustZ.__doc__ = "z-component of thrust."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesDeltaV.__doc__ = "Delta-V (integrated)."
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesGravityAccelX.__doc__ = "GravityAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesGravityAccelY.__doc__ = "GravityAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesGravityAccelZ.__doc__ = "GravityAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTwoBodyAccelX.__doc__ = "TwoBodyAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTwoBodyAccelY.__doc__ = "TwoBodyAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesTwoBodyAccelZ.__doc__ = "TwoBodyAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesGravityPertAccelX.__doc__ = "GravityPertAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesGravityPertAccelY.__doc__ = "GravityPertAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesGravityPertAccelZ.__doc__ = "GravityPertAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesSolidTidesAccelX.__doc__ = "SolidTidesAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesSolidTidesAccelY.__doc__ = "SolidTidesAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesSolidTidesAccelZ.__doc__ = "SolidTidesAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesOceanTidesAccelX.__doc__ = "OceanTidesAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesOceanTidesAccelY.__doc__ = "OceanTidesAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesOceanTidesAccelZ.__doc__ = "OceanTidesAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesDragAccelX.__doc__ = "DragAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesDragAccelY.__doc__ = "DragAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesDragAccelZ.__doc__ = "DragAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesThirdBodyAccelX.__doc__ = "ThirdBodyAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesThirdBodyAccelY.__doc__ = "ThirdBodyAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesThirdBodyAccelZ.__doc__ = "ThirdBodyAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesSRPAccelX.__doc__ = "SRPAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesSRPAccelY.__doc__ = "SRPAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesSRPAccelZ.__doc__ = "SRPAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesNoShadowSRPAccelX.__doc__ = "X-component of SRP acceleration without accounting for shadow"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesNoShadowSRPAccelY.__doc__ = "Y-component of SRP acceleration without accounting for shadow"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesNoShadowSRPAccelZ.__doc__ = "Z-component of SRP acceleration without accounting for shadow"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesGenRelAccelX.__doc__ = "GenRelAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesGenRelAccelY.__doc__ = "GenRelAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesGenRelAccelZ.__doc__ = "GenRelAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAlbedoAccelX.__doc__ = "AlbedoAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAlbedoAccelY.__doc__ = "AlbedoAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAlbedoAccelZ.__doc__ = "AlbedoAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesThermalPressureAccelX.__doc__ = "ThermalPressureAccelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesThermalPressureAccelY.__doc__ = "ThermalPressureAccelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesThermalPressureAccelZ.__doc__ = "ThermalPressureAccelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAddedAccelX.__doc__ = "X-component of acceleration added by plugins"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAddedAccelY.__doc__ = "Y-component of acceleration added by plugins"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesAddedAccelZ.__doc__ = "Z-component of acceleration added by plugins"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosXPosX.__doc__ = "StateTransPosXPosX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosXPosY.__doc__ = "StateTransPosXPosY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosXPosZ.__doc__ = "StateTransPosXPosZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosXVelX.__doc__ = "StateTransPosXVelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosXVelY.__doc__ = "StateTransPosXVelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosXVelZ.__doc__ = "StateTransPosXVelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosYPosX.__doc__ = "StateTransPosYPosX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosYPosY.__doc__ = "StateTransPosYPosY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosYPosZ.__doc__ = "StateTransPosYPosZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosYVelX.__doc__ = "StateTransPosYVelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosYVelY.__doc__ = "StateTransPosYVelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosYVelZ.__doc__ = "StateTransPosYVelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosZPosX.__doc__ = "StateTransPosZPosX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosZPosY.__doc__ = "StateTransPosZPosY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosZPosZ.__doc__ = "StateTransPosZPosZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosZVelX.__doc__ = "StateTransPosZVelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosZVelY.__doc__ = "StateTransPosZVelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransPosZVelZ.__doc__ = "StateTransPosZVelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelXPosX.__doc__ = "StateTransVelXPosX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelXPosY.__doc__ = "StateTransVelXPosY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelXPosZ.__doc__ = "StateTransVelXPosZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelXVelX.__doc__ = "StateTransVelXVelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelXVelY.__doc__ = "StateTransVelXVelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelXVelZ.__doc__ = "StateTransVelXVelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelYPosX.__doc__ = "StateTransVelYPosX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelYPosY.__doc__ = "StateTransVelYPosY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelYPosZ.__doc__ = "StateTransVelYPosZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelYVelX.__doc__ = "StateTransVelYVelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelYVelY.__doc__ = "StateTransVelYVelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelYVelZ.__doc__ = "StateTransVelYVelZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelZPosX.__doc__ = "StateTransVelZPosX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelZPosY.__doc__ = "StateTransVelZPosY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelZPosZ.__doc__ = "StateTransVelZPosZ"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelZVelX.__doc__ = "StateTransVelZVelX"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelZVelY.__doc__ = "StateTransVelZVelY"
AgEAsEOMFuncPluginInputStateValues.eEOMFuncPluginInputStateValuesStateTransVelZVelZ.__doc__ = "StateTransVelZVelZ"

agcls.AgTypeNameMap["AgEAsEOMFuncPluginInputStateValues"] = AgEAsEOMFuncPluginInputStateValues

class AgEAsEOMFuncPluginOutputStateValues(IntEnum):
    """Enumeration of state vector output values"""
   
    eEOMFuncPluginOutputStateValuesDryMass = 0
    """Dry mass."""
    eEOMFuncPluginOutputStateValuesFuelMass = 1
    """Fuel mass."""
    eEOMFuncPluginOutputStateValuesCd = 2
    """Drag coefficient (Cd)."""
    eEOMFuncPluginOutputStateValuesDragArea = 3
    """Drag area."""
    eEOMFuncPluginOutputStateValuesAtmosphericDensity = 4
    """Atmospheric density"""
    eEOMFuncPluginOutputStateValuesAtmosphericAltitude = 5
    """Atmospheric altitude"""
    eEOMFuncPluginOutputStateValuesCr = 6
    """SRP coefficient (Cr)."""
    eEOMFuncPluginOutputStateValuesSRPArea = 7
    """SRP area."""
    eEOMFuncPluginOutputStateValuesKr1 = 8
    """Kr1 parameter of GPS SRP models"""
    eEOMFuncPluginOutputStateValuesKr2 = 9
    """Kr2 parameter of GPS SRP models"""
    eEOMFuncPluginOutputStateValuesSolarIntensity = 10
    """Solar intensity"""
    eEOMFuncPluginOutputStateValuesRadPressureCoefficient = 11
    """Radiation pressure coefficient."""
    eEOMFuncPluginOutputStateValuesRadPressureArea = 12
    """Radiation pressure area."""

AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesDryMass.__doc__ = "Dry mass."
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesFuelMass.__doc__ = "Fuel mass."
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesCd.__doc__ = "Drag coefficient (Cd)."
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesDragArea.__doc__ = "Drag area."
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesAtmosphericDensity.__doc__ = "Atmospheric density"
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesAtmosphericAltitude.__doc__ = "Atmospheric altitude"
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesCr.__doc__ = "SRP coefficient (Cr)."
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesSRPArea.__doc__ = "SRP area."
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesKr1.__doc__ = "Kr1 parameter of GPS SRP models"
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesKr2.__doc__ = "Kr2 parameter of GPS SRP models"
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesSolarIntensity.__doc__ = "Solar intensity"
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesRadPressureCoefficient.__doc__ = "Radiation pressure coefficient."
AgEAsEOMFuncPluginOutputStateValues.eEOMFuncPluginOutputStateValuesRadPressureArea.__doc__ = "Radiation pressure area."

agcls.AgTypeNameMap["AgEAsEOMFuncPluginOutputStateValues"] = AgEAsEOMFuncPluginOutputStateValues

class AgEAsEOMFuncPluginEventTypes(IntEnum):
    """Enumeration of event types"""
   
    eEOMFuncPluginEventTypesPrePropagate = 0
    """Pre-propagate"""
    eEOMFuncPluginEventTypesPreNextStep = 1
    """Pre-next step"""
    eEOMFuncPluginEventTypesEvaluate = 2
    """Evaluate"""
    eEOMFuncPluginEventTypesPostPropagate = 3
    """Post-propagate"""

AgEAsEOMFuncPluginEventTypes.eEOMFuncPluginEventTypesPrePropagate.__doc__ = "Pre-propagate"
AgEAsEOMFuncPluginEventTypes.eEOMFuncPluginEventTypesPreNextStep.__doc__ = "Pre-next step"
AgEAsEOMFuncPluginEventTypes.eEOMFuncPluginEventTypesEvaluate.__doc__ = "Evaluate"
AgEAsEOMFuncPluginEventTypes.eEOMFuncPluginEventTypesPostPropagate.__doc__ = "Post-propagate"

agcls.AgTypeNameMap["AgEAsEOMFuncPluginEventTypes"] = AgEAsEOMFuncPluginEventTypes

class AgEAsDensityModelErrorCodes(IntEnum):
    """Enumeration of AgAsDensityModelPlugin General Error Codes"""
   
    eDensityModelPluginInternalFailure = (((1 << 31) | (4 << 16)) | 0x101)
    """DensityModel Plugin: An internal failure occurred."""
    eDensityModelPluginNotConfigured = (((1 << 31) | (4 << 16)) | 0x102)
    """DensityModel Plugin: Not configured properly."""
    eDensityModelPluginSetDensityFailure = (((1 << 31) | (4 << 16)) | 0x103)
    """DensityModel Plugin: Cannot set density."""
    eDensityModelPluginSetTemperatureFailure = (((1 << 31) | (4 << 16)) | 0x104)
    """DensityModel Plugin: Cannot set temperature."""
    eDensityModelPluginSetPressureFailure = (((1 << 31) | (4 << 16)) | 0x105)
    """DensityModel Plugin: Cannot set pressure."""
    eDensityModelPluginParameterIndexOutOfRange = (((1 << 31) | (4 << 16)) | 0x106)
    """DensityModel Plugin: The index number for the parameter is out of range."""
    eDensityModelPluginInputNotReal = (((1 << 31) | (4 << 16)) | 0x107)
    """DensityModel Plugin: Input value is not a real number.  Check for divide by zero."""
    eDensityModelPluginNotUsingFluxFile = (((1 << 31) | (4 << 16)) | 0x108)
    """DensityModel Plugin: Not using a flux file."""
    eDensityModelPluginNullData = (((1 << 31) | (4 << 16)) | 0x109)
    """DensityModel Plugin: Data file or some indices null."""
    eDensityModelPluginParameterNotFound = (((1 << 31) | (4 << 16)) | 0x10A)
    """DensityModel Plugin: The parameter cannot be found."""

AgEAsDensityModelErrorCodes.eDensityModelPluginInternalFailure.__doc__ = "DensityModel Plugin: An internal failure occurred."
AgEAsDensityModelErrorCodes.eDensityModelPluginNotConfigured.__doc__ = "DensityModel Plugin: Not configured properly."
AgEAsDensityModelErrorCodes.eDensityModelPluginSetDensityFailure.__doc__ = "DensityModel Plugin: Cannot set density."
AgEAsDensityModelErrorCodes.eDensityModelPluginSetTemperatureFailure.__doc__ = "DensityModel Plugin: Cannot set temperature."
AgEAsDensityModelErrorCodes.eDensityModelPluginSetPressureFailure.__doc__ = "DensityModel Plugin: Cannot set pressure."
AgEAsDensityModelErrorCodes.eDensityModelPluginParameterIndexOutOfRange.__doc__ = "DensityModel Plugin: The index number for the parameter is out of range."
AgEAsDensityModelErrorCodes.eDensityModelPluginInputNotReal.__doc__ = "DensityModel Plugin: Input value is not a real number.  Check for divide by zero."
AgEAsDensityModelErrorCodes.eDensityModelPluginNotUsingFluxFile.__doc__ = "DensityModel Plugin: Not using a flux file."
AgEAsDensityModelErrorCodes.eDensityModelPluginNullData.__doc__ = "DensityModel Plugin: Data file or some indices null."
AgEAsDensityModelErrorCodes.eDensityModelPluginParameterNotFound.__doc__ = "DensityModel Plugin: The parameter cannot be found."

agcls.AgTypeNameMap["AgEAsDensityModelErrorCodes"] = AgEAsDensityModelErrorCodes


class IAgAsHpopPluginResult(object):
    """HPOP plugin interface used to get/set force model settings. Supports the IAgEpoch interface."""

    _num_methods = 52
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Mu_method_offset = 1
    _PosVel_method_offset = 2
    _get_Cd_method_offset = 3
    _set_Cd_method_offset = 4
    _get_Cr_method_offset = 5
    _set_Cr_method_offset = 6
    _get_DragArea_method_offset = 7
    _set_DragArea_method_offset = 8
    _get_SRPArea_method_offset = 9
    _set_SRPArea_method_offset = 10
    _get_TimeSinceRefEpoch_method_offset = 11
    _SetAtmFluxLags_method_offset = 12
    _DayCount_method_offset = 13
    _SunPosition_method_offset = 14
    _TransformVector_method_offset = 15
    _get_Altitude_method_offset = 16
    _LatLonAlt_method_offset = 17
    _Trace_method_offset = 18
    _get_LightSpeed_method_offset = 19
    _get_SolarFlux_method_offset = 20
    _get_CbName_method_offset = 21
    _PosVel_Array_method_offset = 22
    _DayCount_Array_method_offset = 23
    _SunPosition_Array_method_offset = 24
    _TransformVector_Array_method_offset = 25
    _LatLonAlt_Array_method_offset = 26
    _CurrentAtmFlux_method_offset = 27
    _CurrentAtmFlux_Array_method_offset = 28
    _AtmFlux_method_offset = 29
    _AtmFlux_Array_method_offset = 30
    _AtmFluxLags_method_offset = 31
    _AtmFluxLags_Array_method_offset = 32
    _IsForceModelOn_method_offset = 33
    _ForceModelName_method_offset = 34
    _get_RadPressureCoefficient_method_offset = 35
    _set_RadPressureCoefficient_method_offset = 36
    _get_RadPressureArea_method_offset = 37
    _set_RadPressureArea_method_offset = 38
    _get_DryMass_method_offset = 39
    _set_DryMass_method_offset = 40
    _get_FuelMass_method_offset = 41
    _set_FuelMass_method_offset = 42
    _get_TotalMass_method_offset = 43
    _StopPropagation_method_offset = 44
    _IndicateEvent_method_offset = 45
    _SetMaxStep_method_offset = 46
    _DateElements_method_offset = 47
    _DateElements_Array_method_offset = 48
    _DateString_method_offset = 49
    _RefEpochElements_method_offset = 50
    _RefEpochElements_Array_method_offset = 51
    _RefEpochString_method_offset = 52
    _metadata = {
        "iid_data" : (4663189866946898891, 18025843431723388857),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsHpopPluginResult."""
        initialize_from_source_object(self, sourceObject, IAgAsHpopPluginResult)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsHpopPluginResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsHpopPluginResult, None)
    
    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_Mu_metadata)

    _get_Cd_metadata = { "offset" : _get_Cd_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cd(self) -> float:
        """Drag Coefficient. Can only be set if Drag is on."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_Cd_metadata)

    _set_Cd_metadata = { "offset" : _set_Cd_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Cd.setter
    def Cd(self, newCd:float) -> None:
        """Drag Coefficient. Can only be set if Drag is on."""
        return self._intf.set_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._set_Cd_metadata, newCd)

    _get_Cr_metadata = { "offset" : _get_Cr_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cr(self) -> float:
        """SRP Coefficient. Can only be set if SRP is on."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_Cr_metadata)

    _set_Cr_metadata = { "offset" : _set_Cr_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Cr.setter
    def Cr(self, newCr:float) -> None:
        """SRP Coefficient. Can only be set if SRP is on."""
        return self._intf.set_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._set_Cr_metadata, newCr)

    _get_DragArea_metadata = { "offset" : _get_DragArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DragArea(self) -> float:
        """Drag Area in meters^2. Can only be set if Drag is on."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_DragArea_metadata)

    _set_DragArea_metadata = { "offset" : _set_DragArea_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @DragArea.setter
    def DragArea(self, newDragArea:float) -> None:
        """Drag Area in meters^2. Can only be set if Drag is on."""
        return self._intf.set_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._set_DragArea_metadata, newDragArea)

    _get_SRPArea_metadata = { "offset" : _get_SRPArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SRPArea(self) -> float:
        """SRP Area in meters^2. Can only be set if SRP is on."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_SRPArea_metadata)

    _set_SRPArea_metadata = { "offset" : _set_SRPArea_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @SRPArea.setter
    def SRPArea(self, newSRPArea:float) -> None:
        """SRP Area in meters^2. Can only be set if SRP is on."""
        return self._intf.set_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._set_SRPArea_metadata, newSRPArea)

    _get_TimeSinceRefEpoch_metadata = { "offset" : _get_TimeSinceRefEpoch_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TimeSinceRefEpoch(self) -> float:
        """Current epoch expressed in seconds since reference epoch."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_TimeSinceRefEpoch_metadata)

    _SetAtmFluxLags_metadata = { "offset" : _SetAtmFluxLags_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetAtmFluxLags(self, f10p7Lag:float, geoFluxLag:float) -> None:
        """Sets the lag times (in secs) used when evaluating the density flux values (F10.7 / Avg F10.7, ap / kp)."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._SetAtmFluxLags_metadata, f10p7Lag, geoFluxLag)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude in meters."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_Altitude_metadata)

    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._Trace_metadata, numCalls)

    _get_LightSpeed_metadata = { "offset" : _get_LightSpeed_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LightSpeed(self) -> float:
        """Speed of light in meters/second."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_LightSpeed_metadata)

    _get_SolarFlux_metadata = { "offset" : _get_SolarFlux_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SolarFlux(self) -> float:
        """Current solar flux in watts/meter^2. Available only if SRP is on."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_SolarFlux_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_CbName_metadata)

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) in the requested frame returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._PosVel_Array_metadata, frame, OutArg())

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._DayCount_Array_metadata, scale, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun in meters wrt the current satellite position, in the requested frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude (radians), detic longitude (radians), and altitude(meters) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._LatLonAlt_Array_metadata, OutArg())

    _CurrentAtmFlux_Array_metadata = { "offset" : _CurrentAtmFlux_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def CurrentAtmFlux_Array(self) -> list:
        """Flux values used by the density model, evaluated at the current time, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._CurrentAtmFlux_Array_metadata, OutArg())

    _AtmFlux_Array_metadata = { "offset" : _AtmFlux_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def AtmFlux_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Flux values used by density models, evaluated at the requested time, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp. No time lags are incorporated."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._AtmFlux_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _AtmFluxLags_Array_metadata = { "offset" : _AtmFluxLags_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def AtmFluxLags_Array(self) -> list:
        """The lag times (in secs), relative to the current epoch, at which the density flux values are evaluated, returned as an array of F10.7 lag, geo flux lag."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._AtmFluxLags_Array_metadata, OutArg())

    _IsForceModelOn_metadata = { "offset" : _IsForceModelOn_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEForceModelType), agmarshall.VARIANT_BOOL_arg,) }
    def IsForceModelOn(self, type:"AgEForceModelType") -> bool:
        """Indicates whether a particular force model contributor is being considered."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._IsForceModelOn_metadata, type, OutArg())

    _ForceModelName_metadata = { "offset" : _ForceModelName_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEForceModelType), agmarshall.BSTR_arg,) }
    def ForceModelName(self, type:"AgEForceModelType") -> str:
        """A translation of the enumerated type into a string."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._ForceModelName_metadata, type, OutArg())

    _get_RadPressureCoefficient_metadata = { "offset" : _get_RadPressureCoefficient_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RadPressureCoefficient(self) -> float:
        """Radiation pressure coefficient, used by albedo and thermal radiation pressure. Can only be set if albedo or thermal radiation pressure is on."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_RadPressureCoefficient_metadata)

    _set_RadPressureCoefficient_metadata = { "offset" : _set_RadPressureCoefficient_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RadPressureCoefficient.setter
    def RadPressureCoefficient(self, newCoef:float) -> None:
        """Radiation pressure coefficient, used by albedo and thermal radiation pressure. Can only be set if albedo or thermal radiation pressure is on."""
        return self._intf.set_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._set_RadPressureCoefficient_metadata, newCoef)

    _get_RadPressureArea_metadata = { "offset" : _get_RadPressureArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RadPressureArea(self) -> float:
        """Radiation pressure area in meters^2, used by albedo and thermal radiation pressure. Can only be set if albedo or thermal radiation pressure is on."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_RadPressureArea_metadata)

    _set_RadPressureArea_metadata = { "offset" : _set_RadPressureArea_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RadPressureArea.setter
    def RadPressureArea(self, newArea:float) -> None:
        """Radiation pressure area in meters^2, used by albedo and thermal radiation pressure. Can only be set if albedo or thermal radiation pressure is on."""
        return self._intf.set_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._set_RadPressureArea_metadata, newArea)

    _get_DryMass_metadata = { "offset" : _get_DryMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DryMass(self) -> float:
        """Dry Mass in kilograms."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_DryMass_metadata)

    _set_DryMass_metadata = { "offset" : _set_DryMass_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @DryMass.setter
    def DryMass(self, newDryMass:float) -> None:
        """Dry Mass in kilograms."""
        return self._intf.set_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._set_DryMass_metadata, newDryMass)

    _get_FuelMass_metadata = { "offset" : _get_FuelMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def FuelMass(self) -> float:
        """Fuel Mass in kilograms."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_FuelMass_metadata)

    _set_FuelMass_metadata = { "offset" : _set_FuelMass_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @FuelMass.setter
    def FuelMass(self, newFuelMass:float) -> None:
        """Fuel Mass in kilograms."""
        return self._intf.set_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._set_FuelMass_metadata, newFuelMass)

    _get_TotalMass_metadata = { "offset" : _get_TotalMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TotalMass(self) -> float:
        """Total Mass in kilograms."""
        return self._intf.get_property(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._get_TotalMass_metadata)

    _StopPropagation_metadata = { "offset" : _StopPropagation_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def StopPropagation(self) -> None:
        """Stops propagation.  For fatal errors."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._StopPropagation_metadata, )

    _IndicateEvent_metadata = { "offset" : _IndicateEvent_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsHpopPluginEventIndicators),) }
    def IndicateEvent(self, eventIndicator:"AgEAsHpopPluginEventIndicators") -> None:
        """Marks an event to the propagator."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._IndicateEvent_metadata, eventIndicator)

    _SetMaxStep_metadata = { "offset" : _SetMaxStep_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetMaxStep(self, maxStep:float) -> None:
        """Sets the maximum step size in seconds for the propagator."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._SetMaxStep_metadata, maxStep)

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._DateString_metadata, dateAbbrv, OutArg())

    _RefEpochElements_Array_metadata = { "offset" : _RefEpochElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def RefEpochElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Reference epoch expressed in requested time scale in day count and date formats as the array: WholeDays, SecsIntoDay, Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._RefEpochElements_Array_metadata, scale, OutArg())

    _RefEpochString_metadata = { "offset" : _RefEpochString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def RefEpochString(self, dateAbbrv:str) -> str:
        """Reference epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsHpopPluginResult._metadata, IAgAsHpopPluginResult._RefEpochString_metadata, dateAbbrv, OutArg())

    _property_names[Mu] = "Mu"
    _property_names[Cd] = "Cd"
    _property_names[Cr] = "Cr"
    _property_names[DragArea] = "DragArea"
    _property_names[SRPArea] = "SRPArea"
    _property_names[TimeSinceRefEpoch] = "TimeSinceRefEpoch"
    _property_names[Altitude] = "Altitude"
    _property_names[LightSpeed] = "LightSpeed"
    _property_names[SolarFlux] = "SolarFlux"
    _property_names[CbName] = "CbName"
    _property_names[RadPressureCoefficient] = "RadPressureCoefficient"
    _property_names[RadPressureArea] = "RadPressureArea"
    _property_names[DryMass] = "DryMass"
    _property_names[FuelMass] = "FuelMass"
    _property_names[TotalMass] = "TotalMass"


agcls.AgClassCatalog.add_catalog_entry((4663189866946898891, 18025843431723388857), IAgAsHpopPluginResult)
agcls.AgTypeNameMap["IAgAsHpopPluginResult"] = IAgAsHpopPluginResult

class IAgAsHpopPluginResultEval(object):
    """HPOP plugin interface used to get/set force model settings during the computation of a step. Supports the IAgEpoch interface."""

    _num_methods = 56
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Mu_method_offset = 1
    _PosVel_method_offset = 2
    _get_Cd_method_offset = 3
    _set_Cd_method_offset = 4
    _get_Cr_method_offset = 5
    _set_Cr_method_offset = 6
    _get_DragArea_method_offset = 7
    _set_DragArea_method_offset = 8
    _get_SRPArea_method_offset = 9
    _set_SRPArea_method_offset = 10
    _get_TimeSinceRefEpoch_method_offset = 11
    _SetAtmFluxLags_method_offset = 12
    _DayCount_method_offset = 13
    _SunPosition_method_offset = 14
    _TransformVector_method_offset = 15
    _get_Altitude_method_offset = 16
    _LatLonAlt_method_offset = 17
    _get_DragAltitude_method_offset = 18
    _get_AtmTemperature_method_offset = 19
    _get_AtmPressure_method_offset = 20
    _get_Density_method_offset = 21
    _set_Density_method_offset = 22
    _get_SolarIntensity_method_offset = 23
    _set_SolarIntensity_method_offset = 24
    _AddAcceleration_method_offset = 25
    _Trace_method_offset = 26
    _get_LightSpeed_method_offset = 27
    _get_SolarFlux_method_offset = 28
    _get_CbName_method_offset = 29
    _PosVel_Array_method_offset = 30
    _DayCount_Array_method_offset = 31
    _SunPosition_Array_method_offset = 32
    _TransformVector_Array_method_offset = 33
    _LatLonAlt_Array_method_offset = 34
    _CurrentAtmFlux_method_offset = 35
    _CurrentAtmFlux_Array_method_offset = 36
    _AtmFlux_method_offset = 37
    _AtmFlux_Array_method_offset = 38
    _AtmFluxLags_method_offset = 39
    _AtmFluxLags_Array_method_offset = 40
    _IsForceModelOn_method_offset = 41
    _ForceModelName_method_offset = 42
    _get_RadPressureCoefficient_method_offset = 43
    _set_RadPressureCoefficient_method_offset = 44
    _get_RadPressureArea_method_offset = 45
    _set_RadPressureArea_method_offset = 46
    _get_DryMass_method_offset = 47
    _get_FuelMass_method_offset = 48
    _get_TotalMass_method_offset = 49
    _StopPropagation_method_offset = 50
    _DateElements_method_offset = 51
    _DateElements_Array_method_offset = 52
    _DateString_method_offset = 53
    _RefEpochElements_method_offset = 54
    _RefEpochElements_Array_method_offset = 55
    _RefEpochString_method_offset = 56
    _metadata = {
        "iid_data" : (5270983415286004854, 3695161675954238876),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsHpopPluginResultEval."""
        initialize_from_source_object(self, sourceObject, IAgAsHpopPluginResultEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsHpopPluginResultEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsHpopPluginResultEval, None)
    
    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_Mu_metadata)

    _get_Cd_metadata = { "offset" : _get_Cd_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cd(self) -> float:
        """Drag Coefficient. Can only be set if Drag is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_Cd_metadata)

    _set_Cd_metadata = { "offset" : _set_Cd_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Cd.setter
    def Cd(self, newCd:float) -> None:
        """Drag Coefficient. Can only be set if Drag is on."""
        return self._intf.set_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._set_Cd_metadata, newCd)

    _get_Cr_metadata = { "offset" : _get_Cr_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cr(self) -> float:
        """SRP Coefficient. Can only be set if SRP is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_Cr_metadata)

    _set_Cr_metadata = { "offset" : _set_Cr_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Cr.setter
    def Cr(self, newCr:float) -> None:
        """SRP Coefficient. Can only be set if SRP is on."""
        return self._intf.set_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._set_Cr_metadata, newCr)

    _get_DragArea_metadata = { "offset" : _get_DragArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DragArea(self) -> float:
        """Drag Area in meters^2. Can only be set if Drag is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_DragArea_metadata)

    _set_DragArea_metadata = { "offset" : _set_DragArea_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @DragArea.setter
    def DragArea(self, newDragArea:float) -> None:
        """Drag Area in meters^2. Can only be set if Drag is on."""
        return self._intf.set_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._set_DragArea_metadata, newDragArea)

    _get_SRPArea_metadata = { "offset" : _get_SRPArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SRPArea(self) -> float:
        """SRP Area in meters^2. Can only be set if SRP is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_SRPArea_metadata)

    _set_SRPArea_metadata = { "offset" : _set_SRPArea_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @SRPArea.setter
    def SRPArea(self, newSRPArea:float) -> None:
        """SRP Area in meters^2. Can only be set if SRP is on."""
        return self._intf.set_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._set_SRPArea_metadata, newSRPArea)

    _get_TimeSinceRefEpoch_metadata = { "offset" : _get_TimeSinceRefEpoch_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TimeSinceRefEpoch(self) -> float:
        """Current epoch expressed in seconds since reference epoch."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_TimeSinceRefEpoch_metadata)

    _SetAtmFluxLags_metadata = { "offset" : _SetAtmFluxLags_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetAtmFluxLags(self, f10p7Lag:float, geoFluxLag:float) -> None:
        """Sets the lag times (in secs) used when evaluating the density flux values (F10.7 / Avg F10.7, ap / kp)."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._SetAtmFluxLags_metadata, f10p7Lag, geoFluxLag)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude in meters."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_Altitude_metadata)

    _get_DragAltitude_metadata = { "offset" : _get_DragAltitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DragAltitude(self) -> float:
        """Current altitude in meters used by density model. Available only if Drag is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_DragAltitude_metadata)

    _get_AtmTemperature_metadata = { "offset" : _get_AtmTemperature_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AtmTemperature(self) -> float:
        """Current atmospheric temperature in Kelvin. Available only if Drag is on and the density model can provide this data."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_AtmTemperature_metadata)

    _get_AtmPressure_metadata = { "offset" : _get_AtmPressure_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AtmPressure(self) -> float:
        """Current atmospheric pressure in Pascals. Available only if Drag is on and the density model can provide this data."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_AtmPressure_metadata)

    _get_Density_metadata = { "offset" : _get_Density_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Density(self) -> float:
        """Current density in kilograms/meter^3. Available only if Drag is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_Density_metadata)

    _set_Density_metadata = { "offset" : _set_Density_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Density.setter
    def Density(self, newDensity:float) -> None:
        """Current density in kilograms/meter^3. Available only if Drag is on."""
        return self._intf.set_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._set_Density_metadata, newDensity)

    _get_SolarIntensity_metadata = { "offset" : _get_SolarIntensity_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SolarIntensity(self) -> float:
        """Current solar intensity. Available only if SRP is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_SolarIntensity_metadata)

    _set_SolarIntensity_metadata = { "offset" : _set_SolarIntensity_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @SolarIntensity.setter
    def SolarIntensity(self, newSolarIntensity:float) -> None:
        """Current solar intensity. Available only if SRP is on."""
        return self._intf.set_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._set_SolarIntensity_metadata, newSolarIntensity)

    _AddAcceleration_metadata = { "offset" : _AddAcceleration_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AddAcceleration(self, frame:"AgEUtFrame", x:float, y:float, z:float) -> None:
        """Add the acceleration in meters/second^2 in the given frame to the force model."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._AddAcceleration_metadata, frame, x, y, z)

    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._Trace_metadata, numCalls)

    _get_LightSpeed_metadata = { "offset" : _get_LightSpeed_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LightSpeed(self) -> float:
        """Speed of light in meters/second."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_LightSpeed_metadata)

    _get_SolarFlux_metadata = { "offset" : _get_SolarFlux_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SolarFlux(self) -> float:
        """Current solar flux in watts/meter^2. Available only if SRP is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_SolarFlux_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_CbName_metadata)

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) in the requested frame returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._PosVel_Array_metadata, frame, OutArg())

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._DayCount_Array_metadata, scale, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun in meters wrt the current satellite position, in the requested frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude (radians), detic longitude (radians), and altitude (meters) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._LatLonAlt_Array_metadata, OutArg())

    _CurrentAtmFlux_Array_metadata = { "offset" : _CurrentAtmFlux_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def CurrentAtmFlux_Array(self) -> list:
        """Flux values used by the density model, evaluated at the current time, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._CurrentAtmFlux_Array_metadata, OutArg())

    _AtmFlux_Array_metadata = { "offset" : _AtmFlux_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def AtmFlux_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Flux values used by density models, evaluated at the requested time, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp. No time lags are incorporated."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._AtmFlux_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _AtmFluxLags_Array_metadata = { "offset" : _AtmFluxLags_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def AtmFluxLags_Array(self) -> list:
        """The lag times (in secs), relative to the current epoch, at which the density flux values are evaluated, returned as an array of F10.7 lag, geo flux lag."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._AtmFluxLags_Array_metadata, OutArg())

    _IsForceModelOn_metadata = { "offset" : _IsForceModelOn_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEForceModelType), agmarshall.VARIANT_BOOL_arg,) }
    def IsForceModelOn(self, type:"AgEForceModelType") -> bool:
        """Indicates whether a particular force model contributor is being considered."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._IsForceModelOn_metadata, type, OutArg())

    _ForceModelName_metadata = { "offset" : _ForceModelName_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEForceModelType), agmarshall.BSTR_arg,) }
    def ForceModelName(self, type:"AgEForceModelType") -> str:
        """A translation of the enumerated type into a string."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._ForceModelName_metadata, type, OutArg())

    _get_RadPressureCoefficient_metadata = { "offset" : _get_RadPressureCoefficient_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RadPressureCoefficient(self) -> float:
        """Radiation pressure coefficient, used by albedo and thermal radiation pressure. Can only be set if albedo or thermal radiation pressure is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_RadPressureCoefficient_metadata)

    _set_RadPressureCoefficient_metadata = { "offset" : _set_RadPressureCoefficient_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RadPressureCoefficient.setter
    def RadPressureCoefficient(self, newCoef:float) -> None:
        """Radiation pressure coefficient, used by albedo and thermal radiation pressure. Can only be set if albedo or thermal radiation pressure is on."""
        return self._intf.set_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._set_RadPressureCoefficient_metadata, newCoef)

    _get_RadPressureArea_metadata = { "offset" : _get_RadPressureArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RadPressureArea(self) -> float:
        """Radiation pressure area in meters^2, used by albedo and thermal radiation pressure. Can only be set if albedo or thermal radiation pressure is on."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_RadPressureArea_metadata)

    _set_RadPressureArea_metadata = { "offset" : _set_RadPressureArea_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @RadPressureArea.setter
    def RadPressureArea(self, newArea:float) -> None:
        """Radiation pressure area in meters^2, used by albedo and thermal radiation pressure. Can only be set if albedo or thermal radiation pressure is on."""
        return self._intf.set_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._set_RadPressureArea_metadata, newArea)

    _get_DryMass_metadata = { "offset" : _get_DryMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DryMass(self) -> float:
        """Dry Mass in kilograms."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_DryMass_metadata)

    _get_FuelMass_metadata = { "offset" : _get_FuelMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def FuelMass(self) -> float:
        """Fuel Mass in kilograms."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_FuelMass_metadata)

    _get_TotalMass_metadata = { "offset" : _get_TotalMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TotalMass(self) -> float:
        """Total Mass in kilograms."""
        return self._intf.get_property(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._get_TotalMass_metadata)

    _StopPropagation_metadata = { "offset" : _StopPropagation_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def StopPropagation(self) -> None:
        """Stops propagation.  For fatal errors."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._StopPropagation_metadata, )

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._DateString_metadata, dateAbbrv, OutArg())

    _RefEpochElements_Array_metadata = { "offset" : _RefEpochElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def RefEpochElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Reference epoch expressed in requested time scale in day count and date formats as the array: WholeDays, SecsIntoDay, Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._RefEpochElements_Array_metadata, scale, OutArg())

    _RefEpochString_metadata = { "offset" : _RefEpochString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def RefEpochString(self, dateAbbrv:str) -> str:
        """Reference epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsHpopPluginResultEval._metadata, IAgAsHpopPluginResultEval._RefEpochString_metadata, dateAbbrv, OutArg())

    _property_names[Mu] = "Mu"
    _property_names[Cd] = "Cd"
    _property_names[Cr] = "Cr"
    _property_names[DragArea] = "DragArea"
    _property_names[SRPArea] = "SRPArea"
    _property_names[TimeSinceRefEpoch] = "TimeSinceRefEpoch"
    _property_names[Altitude] = "Altitude"
    _property_names[DragAltitude] = "DragAltitude"
    _property_names[AtmTemperature] = "AtmTemperature"
    _property_names[AtmPressure] = "AtmPressure"
    _property_names[Density] = "Density"
    _property_names[SolarIntensity] = "SolarIntensity"
    _property_names[LightSpeed] = "LightSpeed"
    _property_names[SolarFlux] = "SolarFlux"
    _property_names[CbName] = "CbName"
    _property_names[RadPressureCoefficient] = "RadPressureCoefficient"
    _property_names[RadPressureArea] = "RadPressureArea"
    _property_names[DryMass] = "DryMass"
    _property_names[FuelMass] = "FuelMass"
    _property_names[TotalMass] = "TotalMass"


agcls.AgClassCatalog.add_catalog_entry((5270983415286004854, 3695161675954238876), IAgAsHpopPluginResultEval)
agcls.AgTypeNameMap["IAgAsHpopPluginResultEval"] = IAgAsHpopPluginResultEval

class IAgAsHpopPluginResultPostEval(object):
    """HPOP plugin interface used to get/set force model settings. Supports the IAgEpoch interface."""

    _num_methods = 50
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Mu_method_offset = 1
    _PosVel_method_offset = 2
    _get_Cd_method_offset = 3
    _get_Cr_method_offset = 4
    _get_DragArea_method_offset = 5
    _get_SRPArea_method_offset = 6
    _get_TimeSinceRefEpoch_method_offset = 7
    _AccelName_method_offset = 8
    _DayCount_method_offset = 9
    _SunPosition_method_offset = 10
    _TransformVector_method_offset = 11
    _get_Altitude_method_offset = 12
    _LatLonAlt_method_offset = 13
    _Trace_method_offset = 14
    _get_LightSpeed_method_offset = 15
    _get_SolarFlux_method_offset = 16
    _get_CbName_method_offset = 17
    _PosVel_Array_method_offset = 18
    _DayCount_Array_method_offset = 19
    _SunPosition_Array_method_offset = 20
    _TransformVector_Array_method_offset = 21
    _LatLonAlt_Array_method_offset = 22
    _CurrentAtmFlux_method_offset = 23
    _CurrentAtmFlux_Array_method_offset = 24
    _AtmFlux_method_offset = 25
    _AtmFlux_Array_method_offset = 26
    _AtmFluxLags_method_offset = 27
    _AtmFluxLags_Array_method_offset = 28
    _get_DragAltitude_method_offset = 29
    _get_AtmTemperature_method_offset = 30
    _get_AtmPressure_method_offset = 31
    _get_Density_method_offset = 32
    _get_SolarIntensity_method_offset = 33
    _AddAcceleration_method_offset = 34
    _GetAcceleration_method_offset = 35
    _GetAcceleration_Array_method_offset = 36
    _IsForceModelOn_method_offset = 37
    _ForceModelName_method_offset = 38
    _get_RadPressureCoefficient_method_offset = 39
    _get_RadPressureArea_method_offset = 40
    _get_DryMass_method_offset = 41
    _get_FuelMass_method_offset = 42
    _get_TotalMass_method_offset = 43
    _StopPropagation_method_offset = 44
    _DateElements_method_offset = 45
    _DateElements_Array_method_offset = 46
    _DateString_method_offset = 47
    _RefEpochElements_method_offset = 48
    _RefEpochElements_Array_method_offset = 49
    _RefEpochString_method_offset = 50
    _metadata = {
        "iid_data" : (4713609509660096624, 15696697752893265310),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsHpopPluginResultPostEval."""
        initialize_from_source_object(self, sourceObject, IAgAsHpopPluginResultPostEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsHpopPluginResultPostEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsHpopPluginResultPostEval, None)
    
    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_Mu_metadata)

    _get_Cd_metadata = { "offset" : _get_Cd_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cd(self) -> float:
        """Drag Coefficient."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_Cd_metadata)

    _get_Cr_metadata = { "offset" : _get_Cr_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cr(self) -> float:
        """SRP Coefficient."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_Cr_metadata)

    _get_DragArea_metadata = { "offset" : _get_DragArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DragArea(self) -> float:
        """Drag Area in meters^2."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_DragArea_metadata)

    _get_SRPArea_metadata = { "offset" : _get_SRPArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SRPArea(self) -> float:
        """SRP Area in meters^2."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_SRPArea_metadata)

    _get_TimeSinceRefEpoch_metadata = { "offset" : _get_TimeSinceRefEpoch_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TimeSinceRefEpoch(self) -> float:
        """Current epoch expressed in seconds since reference epoch."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_TimeSinceRefEpoch_metadata)

    _AccelName_metadata = { "offset" : _AccelName_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccelType), agmarshall.BSTR_arg,) }
    def AccelName(self, type:"AgEAccelType") -> str:
        """A translation of the enumerated type into a string."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._AccelName_metadata, type, OutArg())

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude in meters."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_Altitude_metadata)

    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._Trace_metadata, numCalls)

    _get_LightSpeed_metadata = { "offset" : _get_LightSpeed_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LightSpeed(self) -> float:
        """Speed of light in meters/second."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_LightSpeed_metadata)

    _get_SolarFlux_metadata = { "offset" : _get_SolarFlux_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SolarFlux(self) -> float:
        """Current solar flux in watts/meter^2. Available only if SRP is on."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_SolarFlux_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_CbName_metadata)

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) in the requested frame returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._PosVel_Array_metadata, frame, OutArg())

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._DayCount_Array_metadata, scale, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun in meters wrt the current satellite position, in the requested frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude (radians), detic longitude (radians), and altitude (meters) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._LatLonAlt_Array_metadata, OutArg())

    _CurrentAtmFlux_Array_metadata = { "offset" : _CurrentAtmFlux_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def CurrentAtmFlux_Array(self) -> list:
        """Flux values used by the density model, evaluated at the current time, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._CurrentAtmFlux_Array_metadata, OutArg())

    _AtmFlux_Array_metadata = { "offset" : _AtmFlux_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def AtmFlux_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Flux values used by density models, evaluated at the requested time, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp. No time lags are incorporated."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._AtmFlux_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _AtmFluxLags_Array_metadata = { "offset" : _AtmFluxLags_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def AtmFluxLags_Array(self) -> list:
        """The lag times (in secs), relative to the current epoch, at which the density flux values are evaluated, returned as an array of F10.7 lag, geo flux lag."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._AtmFluxLags_Array_metadata, OutArg())

    _get_DragAltitude_metadata = { "offset" : _get_DragAltitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DragAltitude(self) -> float:
        """Current altitude in meters used by density model. Available only if Drag is on."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_DragAltitude_metadata)

    _get_AtmTemperature_metadata = { "offset" : _get_AtmTemperature_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AtmTemperature(self) -> float:
        """Current atmospheric temperature in Kelvin. Available only if Drag is on and the density model can provide this data."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_AtmTemperature_metadata)

    _get_AtmPressure_metadata = { "offset" : _get_AtmPressure_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AtmPressure(self) -> float:
        """Current atmospheric pressure in Pascals. Available only if Drag is on and the density model can provide this data."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_AtmPressure_metadata)

    _get_Density_metadata = { "offset" : _get_Density_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Density(self) -> float:
        """Current density in kilograms/meter^3. Available only if Drag is on."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_Density_metadata)

    _get_SolarIntensity_metadata = { "offset" : _get_SolarIntensity_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SolarIntensity(self) -> float:
        """Current solar intensity. Available only if SRP is on."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_SolarIntensity_metadata)

    _AddAcceleration_metadata = { "offset" : _AddAcceleration_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AddAcceleration(self, frame:"AgEUtFrame", x:float, y:float, z:float) -> None:
        """Add the acceleration in meters/second^2 in the given frame to the force model."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._AddAcceleration_metadata, frame, x, y, z)

    _GetAcceleration_Array_metadata = { "offset" : _GetAcceleration_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccelType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def GetAcceleration_Array(self, type:"AgEAccelType", frame:"AgEUtFrame") -> list:
        """The acceleration in meters/second^2 contribution of the indicated Type, returned as cartesian components in the specified frame as the array X, Y, Z."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._GetAcceleration_Array_metadata, type, frame, OutArg())

    _IsForceModelOn_metadata = { "offset" : _IsForceModelOn_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEForceModelType), agmarshall.VARIANT_BOOL_arg,) }
    def IsForceModelOn(self, type:"AgEForceModelType") -> bool:
        """Indicates whether a particular force model contributor is being considered."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._IsForceModelOn_metadata, type, OutArg())

    _ForceModelName_metadata = { "offset" : _ForceModelName_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEForceModelType), agmarshall.BSTR_arg,) }
    def ForceModelName(self, type:"AgEForceModelType") -> str:
        """A translation of the enumerated type into a string."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._ForceModelName_metadata, type, OutArg())

    _get_RadPressureCoefficient_metadata = { "offset" : _get_RadPressureCoefficient_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RadPressureCoefficient(self) -> float:
        """Radiation pressure coefficient, used by albedo and thermal radiation pressure."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_RadPressureCoefficient_metadata)

    _get_RadPressureArea_metadata = { "offset" : _get_RadPressureArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RadPressureArea(self) -> float:
        """Radiation pressure area in meters^2, used by albedo and thermal radiation pressure."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_RadPressureArea_metadata)

    _get_DryMass_metadata = { "offset" : _get_DryMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DryMass(self) -> float:
        """Dry Mass in kilograms."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_DryMass_metadata)

    _get_FuelMass_metadata = { "offset" : _get_FuelMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def FuelMass(self) -> float:
        """Fuel Mass in kilograms."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_FuelMass_metadata)

    _get_TotalMass_metadata = { "offset" : _get_TotalMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TotalMass(self) -> float:
        """Total Mass in kilograms."""
        return self._intf.get_property(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._get_TotalMass_metadata)

    _StopPropagation_metadata = { "offset" : _StopPropagation_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def StopPropagation(self) -> None:
        """Stops propagation.  For fatal errors."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._StopPropagation_metadata, )

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._DateString_metadata, dateAbbrv, OutArg())

    _RefEpochElements_Array_metadata = { "offset" : _RefEpochElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def RefEpochElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Reference epoch expressed in requested time scale in day count and date formats as the array: WholeDays, SecsIntoDay, Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._RefEpochElements_Array_metadata, scale, OutArg())

    _RefEpochString_metadata = { "offset" : _RefEpochString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def RefEpochString(self, dateAbbrv:str) -> str:
        """Reference epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsHpopPluginResultPostEval._metadata, IAgAsHpopPluginResultPostEval._RefEpochString_metadata, dateAbbrv, OutArg())

    _property_names[Mu] = "Mu"
    _property_names[Cd] = "Cd"
    _property_names[Cr] = "Cr"
    _property_names[DragArea] = "DragArea"
    _property_names[SRPArea] = "SRPArea"
    _property_names[TimeSinceRefEpoch] = "TimeSinceRefEpoch"
    _property_names[Altitude] = "Altitude"
    _property_names[LightSpeed] = "LightSpeed"
    _property_names[SolarFlux] = "SolarFlux"
    _property_names[CbName] = "CbName"
    _property_names[DragAltitude] = "DragAltitude"
    _property_names[AtmTemperature] = "AtmTemperature"
    _property_names[AtmPressure] = "AtmPressure"
    _property_names[Density] = "Density"
    _property_names[SolarIntensity] = "SolarIntensity"
    _property_names[RadPressureCoefficient] = "RadPressureCoefficient"
    _property_names[RadPressureArea] = "RadPressureArea"
    _property_names[DryMass] = "DryMass"
    _property_names[FuelMass] = "FuelMass"
    _property_names[TotalMass] = "TotalMass"


agcls.AgClassCatalog.add_catalog_entry((4713609509660096624, 15696697752893265310), IAgAsHpopPluginResultPostEval)
agcls.AgTypeNameMap["IAgAsHpopPluginResultPostEval"] = IAgAsHpopPluginResultPostEval

class IAgAsHpopPluginSampleEngine(object):
    """HPOP sample plugin"""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Accel_method_offset = 1
    _set_Accel_method_offset = 2
    _get_ReportFrequency_method_offset = 3
    _set_ReportFrequency_method_offset = 4
    _get_DebugMode_method_offset = 5
    _set_DebugMode_method_offset = 6
    _metadata = {
        "iid_data" : (5050861332357911069, 7515621309956218022),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsHpopPluginSampleEngine."""
        initialize_from_source_object(self, sourceObject, IAgAsHpopPluginSampleEngine)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsHpopPluginSampleEngine)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsHpopPluginSampleEngine, None)
    
    _get_Accel_metadata = { "offset" : _get_Accel_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Accel(self) -> float:
        """Thrust acceleration value, in m/sec^2."""
        return self._intf.get_property(IAgAsHpopPluginSampleEngine._metadata, IAgAsHpopPluginSampleEngine._get_Accel_metadata)

    _set_Accel_metadata = { "offset" : _set_Accel_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Accel.setter
    def Accel(self, newAccel:float) -> None:
        """Thrust acceleration value, in m/sec^2."""
        return self._intf.set_property(IAgAsHpopPluginSampleEngine._metadata, IAgAsHpopPluginSampleEngine._set_Accel_metadata, newAccel)

    _get_ReportFrequency_metadata = { "offset" : _get_ReportFrequency_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ReportFrequency(self) -> int:
        """Frequency of output of debug messages, in number of integration steps."""
        return self._intf.get_property(IAgAsHpopPluginSampleEngine._metadata, IAgAsHpopPluginSampleEngine._get_ReportFrequency_metadata)

    _set_ReportFrequency_metadata = { "offset" : _set_ReportFrequency_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @ReportFrequency.setter
    def ReportFrequency(self, newFreq:int) -> None:
        """Frequency of output of debug messages, in number of integration steps."""
        return self._intf.set_property(IAgAsHpopPluginSampleEngine._metadata, IAgAsHpopPluginSampleEngine._set_ReportFrequency_metadata, newFreq)

    _get_DebugMode_metadata = { "offset" : _get_DebugMode_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def DebugMode(self) -> bool:
        """Flag to turn debug mode on/off. When on, messages are reported to message viewer at the ReportFrequency."""
        return self._intf.get_property(IAgAsHpopPluginSampleEngine._metadata, IAgAsHpopPluginSampleEngine._get_DebugMode_metadata)

    _set_DebugMode_metadata = { "offset" : _set_DebugMode_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @DebugMode.setter
    def DebugMode(self, newDebugMode:bool) -> None:
        """Flag to turn debug mode on/off. When on, messages are reported to message viewer at the ReportFrequency."""
        return self._intf.set_property(IAgAsHpopPluginSampleEngine._metadata, IAgAsHpopPluginSampleEngine._set_DebugMode_metadata, newDebugMode)

    _property_names[Accel] = "Accel"
    _property_names[ReportFrequency] = "ReportFrequency"
    _property_names[DebugMode] = "DebugMode"


agcls.AgClassCatalog.add_catalog_entry((5050861332357911069, 7515621309956218022), IAgAsHpopPluginSampleEngine)
agcls.AgTypeNameMap["IAgAsHpopPluginSampleEngine"] = IAgAsHpopPluginSampleEngine

class IAgAsLightReflectionResultRegister(object):
    """LightReflection plugin interface used to register parameters that may be estimated."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _RegisterParameter_method_offset = 1
    _Message_method_offset = 2
    _get_InstallDirectory_method_offset = 3
    _get_ConfigDirectory_method_offset = 4
    _RegisterUserInput_method_offset = 5
    _RegisterUserParameterOutput_method_offset = 6
    _metadata = {
        "iid_data" : (5642882557537992386, 4007395195679940225),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsLightReflectionResultRegister."""
        initialize_from_source_object(self, sourceObject, IAgAsLightReflectionResultRegister)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsLightReflectionResultRegister)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsLightReflectionResultRegister, None)
    
    _RegisterParameter_metadata = { "offset" : _RegisterParameter_method_offset,
            "arg_types" : (agcom.BSTR, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.BSTR, POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def RegisterParameter(self, name:str, defaultValue:float, minValue:float, maxValue:float, dimension:str) -> int:
        """Registers a parameter of the computation that may be estimated. Returns an index identifier of the parameter used by other interfaces."""
        return self._intf.invoke(IAgAsLightReflectionResultRegister._metadata, IAgAsLightReflectionResultRegister._RegisterParameter_metadata, name, defaultValue, minValue, maxValue, dimension, OutArg())

    _Message_metadata = { "offset" : _Message_method_offset,
            "arg_types" : (agcom.LONG, agcom.BSTR,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtLogMsgType), agmarshall.BSTR_arg,) }
    def Message(self, msgType:"AgEUtLogMsgType", message:str) -> None:
        """Send a message to the message viewer."""
        return self._intf.invoke(IAgAsLightReflectionResultRegister._metadata, IAgAsLightReflectionResultRegister._Message_metadata, msgType, message)

    _get_InstallDirectory_metadata = { "offset" : _get_InstallDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def InstallDirectory(self) -> str:
        """The directory path of the installation of the application."""
        return self._intf.get_property(IAgAsLightReflectionResultRegister._metadata, IAgAsLightReflectionResultRegister._get_InstallDirectory_metadata)

    _get_ConfigDirectory_metadata = { "offset" : _get_ConfigDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ConfigDirectory(self) -> str:
        """The directory path of the user configuration area."""
        return self._intf.get_property(IAgAsLightReflectionResultRegister._metadata, IAgAsLightReflectionResultRegister._get_ConfigDirectory_metadata)

    _RegisterUserInput_metadata = { "offset" : _RegisterUserInput_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def RegisterUserInput(self, userValue:str) -> int:
        """Registers as input to the plugin a user value in the state vector."""
        return self._intf.invoke(IAgAsLightReflectionResultRegister._metadata, IAgAsLightReflectionResultRegister._RegisterUserInput_metadata, userValue, OutArg())

    _RegisterUserParameterOutput_metadata = { "offset" : _RegisterUserParameterOutput_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def RegisterUserParameterOutput(self, userValue:str) -> int:
        """Registers a user value in the state vector as a parameter output of the plugin."""
        return self._intf.invoke(IAgAsLightReflectionResultRegister._metadata, IAgAsLightReflectionResultRegister._RegisterUserParameterOutput_metadata, userValue, OutArg())

    _property_names[InstallDirectory] = "InstallDirectory"
    _property_names[ConfigDirectory] = "ConfigDirectory"


agcls.AgClassCatalog.add_catalog_entry((5642882557537992386, 4007395195679940225), IAgAsLightReflectionResultRegister)
agcls.AgTypeNameMap["IAgAsLightReflectionResultRegister"] = IAgAsLightReflectionResultRegister

class IAgAsLightReflectionResult(object):
    """LightReflection plugin interface used to get/set settings. Supports the IAgEpoch interface."""

    _num_methods = 31
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _get_Mu_method_offset = 2
    _get_CbName_method_offset = 3
    _get_LightSpeed_method_offset = 4
    _get_SolarIntensity_method_offset = 5
    _get_SolarFlux_method_offset = 6
    _DayCount_method_offset = 7
    _DayCount_Array_method_offset = 8
    _get_TotalMass_method_offset = 9
    _get_Altitude_method_offset = 10
    _PosVel_method_offset = 11
    _PosVel_Array_method_offset = 12
    _LatLonAlt_method_offset = 13
    _LatLonAlt_Array_method_offset = 14
    _SunPosition_method_offset = 15
    _SunPosition_Array_method_offset = 16
    _TransformVector_method_offset = 17
    _TransformVector_Array_method_offset = 18
    _IncidentDirection_method_offset = 19
    _IncidentDirection_Array_method_offset = 20
    _TransformVectorToBody_method_offset = 21
    _TransformVectorToBody_Array_method_offset = 22
    _TransformVectorFromBody_method_offset = 23
    _TransformVectorFromBody_Array_method_offset = 24
    _IncidentDirectionInBody_method_offset = 25
    _IncidentDirectionInBody_Array_method_offset = 26
    _DateElements_method_offset = 27
    _DateElements_Array_method_offset = 28
    _DateString_method_offset = 29
    _GetInputValue_method_offset = 30
    _SetParameterOutputValue_method_offset = 31
    _metadata = {
        "iid_data" : (4623001660734949206, 10971601212790303660),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsLightReflectionResult."""
        initialize_from_source_object(self, sourceObject, IAgAsLightReflectionResult)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsLightReflectionResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsLightReflectionResult, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._Trace_metadata, numCalls)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._get_Mu_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._get_CbName_metadata)

    _get_LightSpeed_metadata = { "offset" : _get_LightSpeed_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LightSpeed(self) -> float:
        """Speed of light in meters/second."""
        return self._intf.get_property(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._get_LightSpeed_metadata)

    _get_SolarIntensity_metadata = { "offset" : _get_SolarIntensity_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SolarIntensity(self) -> float:
        """Current solar intensity. Available only if SRP is on."""
        return self._intf.get_property(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._get_SolarIntensity_metadata)

    _get_SolarFlux_metadata = { "offset" : _get_SolarFlux_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SolarFlux(self) -> float:
        """Current solar flux in watts/meter^2. Available only if SRP is on."""
        return self._intf.get_property(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._get_SolarFlux_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._DayCount_Array_metadata, scale, OutArg())

    _get_TotalMass_metadata = { "offset" : _get_TotalMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TotalMass(self) -> float:
        """Total Mass in kilograms."""
        return self._intf.get_property(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._get_TotalMass_metadata)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude in meters."""
        return self._intf.get_property(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._get_Altitude_metadata)

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) in the requested frame returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._PosVel_Array_metadata, frame, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude (radians), detic longitude (radians), and altitude(meters) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._LatLonAlt_Array_metadata, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun in meters wrt the current satellite position, in the requested frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _IncidentDirection_Array_metadata = { "offset" : _IncidentDirection_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirection_Array(self, frame:"AgEUtFrame") -> list:
        """Incident light direction (unitless) on the body, in the requested frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._IncidentDirection_Array_metadata, frame, OutArg())

    _TransformVectorToBody_Array_metadata = { "offset" : _TransformVectorToBody_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformVectorToBody_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float) -> list:
        """Transforms a vector from the input frame to the body frame returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._TransformVectorToBody_Array_metadata, frameFrom, xFrom, yFrom, zFrom, OutArg())

    _TransformVectorFromBody_Array_metadata = { "offset" : _TransformVectorFromBody_Array_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVectorFromBody_Array(self, xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the body frame to the output frame returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._TransformVectorFromBody_Array_metadata, xFrom, yFrom, zFrom, frameTo, OutArg())

    _IncidentDirectionInBody_Array_metadata = { "offset" : _IncidentDirectionInBody_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionInBody_Array(self) -> list:
        """Incident light direction (unitless) on the body, in the body frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._IncidentDirectionInBody_Array_metadata, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._DateString_metadata, dateAbbrv, OutArg())

    _GetInputValue_metadata = { "offset" : _GetInputValue_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def GetInputValue(self, index:int) -> float:
        """Gets the value of an input to the plugin in internal units."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._GetInputValue_metadata, index, OutArg())

    _SetParameterOutputValue_metadata = { "offset" : _SetParameterOutputValue_method_offset,
            "arg_types" : (agcom.INT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def SetParameterOutputValue(self, index:int, val:float) -> None:
        """Sets the value of a parameter output of the plugin in internal units."""
        return self._intf.invoke(IAgAsLightReflectionResult._metadata, IAgAsLightReflectionResult._SetParameterOutputValue_metadata, index, val)

    _property_names[Mu] = "Mu"
    _property_names[CbName] = "CbName"
    _property_names[LightSpeed] = "LightSpeed"
    _property_names[SolarIntensity] = "SolarIntensity"
    _property_names[SolarFlux] = "SolarFlux"
    _property_names[TotalMass] = "TotalMass"
    _property_names[Altitude] = "Altitude"


agcls.AgClassCatalog.add_catalog_entry((4623001660734949206, 10971601212790303660), IAgAsLightReflectionResult)
agcls.AgTypeNameMap["IAgAsLightReflectionResult"] = IAgAsLightReflectionResult

class IAgAsLightReflectionResultEval(object):
    """LightReflection plugin interface used to get/set settings during evaluation. Used to set reflectance vector (and optionally its partial derivs) used in computation of the srp force. Supports the IAgEpoch interface."""

    _num_methods = 61
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _get_Mu_method_offset = 2
    _get_CbName_method_offset = 3
    _get_LightSpeed_method_offset = 4
    _get_SolarIntensity_method_offset = 5
    _get_SolarFlux_method_offset = 6
    _DayCount_method_offset = 7
    _DayCount_Array_method_offset = 8
    _get_TotalMass_method_offset = 9
    _get_Altitude_method_offset = 10
    _PosVel_method_offset = 11
    _PosVel_Array_method_offset = 12
    _LatLonAlt_method_offset = 13
    _LatLonAlt_Array_method_offset = 14
    _SunPosition_method_offset = 15
    _SunPosition_Array_method_offset = 16
    _TransformVector_method_offset = 17
    _TransformVector_Array_method_offset = 18
    _IncidentDirection_method_offset = 19
    _IncidentDirection_Array_method_offset = 20
    _SetReflectanceInBody_method_offset = 21
    _SetReflectance_method_offset = 22
    _IncidentDirectionVecInBodyPosPartials_method_offset = 23
    _IncidentDirectionVecInBodyPosPartials_Array_method_offset = 24
    _IncidentDirectionVecPosPartials_method_offset = 25
    _IncidentDirectionVecPosPartials_Array_method_offset = 26
    _IncidentDirectionBodyCompPosPartials_method_offset = 27
    _IncidentDirectionBodyCompPosPartials_Array_method_offset = 28
    _IncidentDirectionCompPosPartials_method_offset = 29
    _IncidentDirectionCompPosPartials_Array_method_offset = 30
    _IncidentDirectionBodyCompVelPartials_method_offset = 31
    _IncidentDirectionBodyCompVelPartials_Array_method_offset = 32
    _IncidentDirectionCompVelPartials_method_offset = 33
    _IncidentDirectionCompVelPartials_Array_method_offset = 34
    _SetReflectanceBodyCompPosPartials_method_offset = 35
    _SetReflectanceCompPosPartials_method_offset = 36
    _SetReflectanceBodyCompVelPartials_method_offset = 37
    _SetReflectanceCompVelPartials_method_offset = 38
    _BodyFixedVectorPosPartials_method_offset = 39
    _BodyFixedVectorPosPartials_Array_method_offset = 40
    _FrameFixedVectorPosPartials_method_offset = 41
    _FrameFixedVectorPosPartials_Array_method_offset = 42
    _BodyFixedVectorVelPartials_method_offset = 43
    _BodyFixedVectorVelPartials_Array_method_offset = 44
    _FrameFixedVectorVelPartials_method_offset = 45
    _FrameFixedVectorVelPartials_Array_method_offset = 46
    _ParameterValue_method_offset = 47
    _get_ParameterValue_Array_method_offset = 48
    _SetReflectanceInBodyParamPartials_method_offset = 49
    _SetReflectanceParamPartials_method_offset = 50
    _TransformVectorToBody_method_offset = 51
    _TransformVectorToBody_Array_method_offset = 52
    _TransformVectorFromBody_method_offset = 53
    _TransformVectorFromBody_Array_method_offset = 54
    _IncidentDirectionInBody_method_offset = 55
    _IncidentDirectionInBody_Array_method_offset = 56
    _DateElements_method_offset = 57
    _DateElements_Array_method_offset = 58
    _DateString_method_offset = 59
    _GetInputValue_method_offset = 60
    _SetParameterOutputValue_method_offset = 61
    _metadata = {
        "iid_data" : (5098585729371814727, 1854883725817174159),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsLightReflectionResultEval."""
        initialize_from_source_object(self, sourceObject, IAgAsLightReflectionResultEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsLightReflectionResultEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsLightReflectionResultEval, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._Trace_metadata, numCalls)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._get_Mu_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._get_CbName_metadata)

    _get_LightSpeed_metadata = { "offset" : _get_LightSpeed_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LightSpeed(self) -> float:
        """Speed of light in meters/second."""
        return self._intf.get_property(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._get_LightSpeed_metadata)

    _get_SolarIntensity_metadata = { "offset" : _get_SolarIntensity_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SolarIntensity(self) -> float:
        """Current solar intensity. Available only if SRP is on."""
        return self._intf.get_property(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._get_SolarIntensity_metadata)

    _get_SolarFlux_metadata = { "offset" : _get_SolarFlux_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SolarFlux(self) -> float:
        """Current solar flux in watts/meter^2. Available only if SRP is on."""
        return self._intf.get_property(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._get_SolarFlux_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._DayCount_Array_metadata, scale, OutArg())

    _get_TotalMass_metadata = { "offset" : _get_TotalMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TotalMass(self) -> float:
        """Total Mass in kilograms."""
        return self._intf.get_property(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._get_TotalMass_metadata)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude in meters."""
        return self._intf.get_property(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._get_Altitude_metadata)

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) in the requested frame returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._PosVel_Array_metadata, frame, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude (radians), detic longitude (radians), and altitude(meters) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._LatLonAlt_Array_metadata, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun in meters wrt the current satellite position, in the requested frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _IncidentDirection_Array_metadata = { "offset" : _IncidentDirection_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirection_Array(self, frame:"AgEUtFrame") -> list:
        """Incident light direction (unitless) on the body, in the requested framereturned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._IncidentDirection_Array_metadata, frame, OutArg())

    _SetReflectanceInBody_metadata = { "offset" : _SetReflectanceInBody_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceInBody(self, x:float, y:float, z:float) -> None:
        """Sets reflectance (in m^2) in body components. Force = solarIntensity*luminosity/(4*pi*speedOfLight*distanceToSun^2)*reflectanceVec. reflectanceVec = sum of surface contributions where each surface N is cr_N*area_N*unitDirection_N."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SetReflectanceInBody_metadata, x, y, z)

    _SetReflectance_metadata = { "offset" : _SetReflectance_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectance(self, frame:"AgEUtFrame", x:float, y:float, z:float) -> None:
        """Sets reflectance (in m^2) in specified frame. Force = solarIntensity*luminosity/(4*pi*speedOfLight*distanceToSun^2)*reflectanceVec. reflectanceVec = sum of surface contributions where each surface N is cr_N*area_N*unitDirection_N."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SetReflectance_metadata, frame, x, y, z)

    _IncidentDirectionVecInBodyPosPartials_Array_metadata = { "offset" : _IncidentDirectionVecInBodyPosPartials_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionVecInBodyPosPartials_Array(self) -> list:
        """The partial derivatives in meters^-1 of the incident direction wrt inertial position coordinates, expressed in body components, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._IncidentDirectionVecInBodyPosPartials_Array_metadata, OutArg())

    _IncidentDirectionVecPosPartials_Array_metadata = { "offset" : _IncidentDirectionVecPosPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionVecPosPartials_Array(self, frame:"AgEUtFrame") -> list:
        """The partial derivatives in meters^-1 of the incident direction wrt inertial position coordinates, expressed in components of the requested frame, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._IncidentDirectionVecPosPartials_Array_metadata, frame, OutArg())

    _IncidentDirectionBodyCompPosPartials_Array_metadata = { "offset" : _IncidentDirectionBodyCompPosPartials_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionBodyCompPosPartials_Array(self) -> list:
        """The partial derivatives in meters^-1 of the incident direction body components wrt inertial position coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._IncidentDirectionBodyCompPosPartials_Array_metadata, OutArg())

    _IncidentDirectionCompPosPartials_Array_metadata = { "offset" : _IncidentDirectionCompPosPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionCompPosPartials_Array(self, frame:"AgEUtFrame") -> list:
        """The partial derivatives in meters^-1 of the incident direction components, expressed in the requested frame, wrt inertial position coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._IncidentDirectionCompPosPartials_Array_metadata, frame, OutArg())

    _IncidentDirectionBodyCompVelPartials_Array_metadata = { "offset" : _IncidentDirectionBodyCompVelPartials_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionBodyCompVelPartials_Array(self) -> list:
        """The partial derivatives in seconds/meter of the incident direction body components wrt inertial velocity coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._IncidentDirectionBodyCompVelPartials_Array_metadata, OutArg())

    _IncidentDirectionCompVelPartials_Array_metadata = { "offset" : _IncidentDirectionCompVelPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionCompVelPartials_Array(self, frame:"AgEUtFrame") -> list:
        """The partial derivatives in seconds/meter of the incident direction components, expressed in the requested frame, wrt inertial velocity coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._IncidentDirectionCompVelPartials_Array_metadata, frame, OutArg())

    _SetReflectanceBodyCompPosPartials_metadata = { "offset" : _SetReflectanceBodyCompPosPartials_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceBodyCompPosPartials(self, reflectXwrtX:float, reflectXwrtY:float, reflectXwrtZ:float, reflectYwrtX:float, reflectYwrtY:float, reflectYwrtZ:float, reflectZwrtX:float, reflectZwrtY:float, reflectZwrtZ:float) -> None:
        """Sets the partial derivatives in meters of the body components of reflectance wrt inertial position coordinates."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SetReflectanceBodyCompPosPartials_metadata, reflectXwrtX, reflectXwrtY, reflectXwrtZ, reflectYwrtX, reflectYwrtY, reflectYwrtZ, reflectZwrtX, reflectZwrtY, reflectZwrtZ)

    _SetReflectanceCompPosPartials_metadata = { "offset" : _SetReflectanceCompPosPartials_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceCompPosPartials(self, frame:"AgEUtFrame", reflectXwrtX:float, reflectXwrtY:float, reflectXwrtZ:float, reflectYwrtX:float, reflectYwrtY:float, reflectYwrtZ:float, reflectZwrtX:float, reflectZwrtY:float, reflectZwrtZ:float) -> None:
        """Sets the partial derivatives in meters of the components of reflectance (expressed in the specified frame) wrt inertial position coordinates."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SetReflectanceCompPosPartials_metadata, frame, reflectXwrtX, reflectXwrtY, reflectXwrtZ, reflectYwrtX, reflectYwrtY, reflectYwrtZ, reflectZwrtX, reflectZwrtY, reflectZwrtZ)

    _SetReflectanceBodyCompVelPartials_metadata = { "offset" : _SetReflectanceBodyCompVelPartials_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceBodyCompVelPartials(self, reflectXwrtVX:float, reflectXwrtVY:float, reflectXwrtVZ:float, reflectYwrtVX:float, reflectYwrtVY:float, reflectYwrtVZ:float, reflectZwrtVX:float, reflectZwrtVY:float, reflectZwrtVZ:float) -> None:
        """Sets the partial derivatives in meter-seconds of the body components of reflectance wrt inertial velocity coordinates."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SetReflectanceBodyCompVelPartials_metadata, reflectXwrtVX, reflectXwrtVY, reflectXwrtVZ, reflectYwrtVX, reflectYwrtVY, reflectYwrtVZ, reflectZwrtVX, reflectZwrtVY, reflectZwrtVZ)

    _SetReflectanceCompVelPartials_metadata = { "offset" : _SetReflectanceCompVelPartials_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceCompVelPartials(self, frame:"AgEUtFrame", reflectXwrtVX:float, reflectXwrtVY:float, reflectXwrtVZ:float, reflectYwrtVX:float, reflectYwrtVY:float, reflectYwrtVZ:float, reflectZwrtVX:float, reflectZwrtVY:float, reflectZwrtVZ:float) -> None:
        """Sets the partial derivatives in meter-seconds of the components of reflectance (expressed in the specified frame) wrt inertial velocity coordinates."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SetReflectanceCompVelPartials_metadata, frame, reflectXwrtVX, reflectXwrtVY, reflectXwrtVZ, reflectYwrtVX, reflectYwrtVY, reflectYwrtVZ, reflectZwrtVX, reflectZwrtVY, reflectZwrtVZ)

    _BodyFixedVectorPosPartials_Array_metadata = { "offset" : _BodyFixedVectorPosPartials_Array_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def BodyFixedVectorPosPartials_Array(self, x:float, y:float, z:float) -> list:
        """The partial derivatives of the given body-fixed vector wrt inertial position coordinates in internal units, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._BodyFixedVectorPosPartials_Array_metadata, x, y, z, OutArg())

    _FrameFixedVectorPosPartials_Array_metadata = { "offset" : _FrameFixedVectorPosPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def FrameFixedVectorPosPartials_Array(self, frame:"AgEUtFrame", x:float, y:float, z:float) -> list:
        """The partial derivatives of the given frame-fixed vector wrt inertial position coordinates in internal units, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._FrameFixedVectorPosPartials_Array_metadata, frame, x, y, z, OutArg())

    _BodyFixedVectorVelPartials_Array_metadata = { "offset" : _BodyFixedVectorVelPartials_Array_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def BodyFixedVectorVelPartials_Array(self, x:float, y:float, z:float) -> list:
        """The partial derivatives of the given body-fixed vector wrt inertial velocity coordinates in internal units, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._BodyFixedVectorVelPartials_Array_metadata, x, y, z, OutArg())

    _FrameFixedVectorVelPartials_Array_metadata = { "offset" : _FrameFixedVectorVelPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def FrameFixedVectorVelPartials_Array(self, frame:"AgEUtFrame", x:float, y:float, z:float) -> list:
        """The partial derivatives of the given frame-fixed vector wrt inertial velocity coordinates in internal units, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._FrameFixedVectorVelPartials_Array_metadata, frame, x, y, z, OutArg())

    _ParameterValue_metadata = { "offset" : _ParameterValue_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.DOUBLE_arg,) }
    def ParameterValue(self, index:int) -> float:
        """Parameter value in internal units for a registered parameter with indicated index."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._ParameterValue_metadata, index, OutArg())

    _get_ParameterValue_Array_metadata = { "offset" : _get_ParameterValue_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def ParameterValue_Array(self) -> list:
        """Parameter values in internal units for all registered parameters, returned in index order."""
        return self._intf.get_property(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._get_ParameterValue_Array_metadata)

    _SetReflectanceInBodyParamPartials_metadata = { "offset" : _SetReflectanceInBodyParamPartials_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceInBodyParamPartials(self, index:int, reflectXwrtParam:float, reflectYwrtParam:float, reflectZwrtParam:float) -> None:
        """Sets the partial derivatives of the body components of reflectance wrt the registered parameter specified by Index.  Uses internal units."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SetReflectanceInBodyParamPartials_metadata, index, reflectXwrtParam, reflectYwrtParam, reflectZwrtParam)

    _SetReflectanceParamPartials_metadata = { "offset" : _SetReflectanceParamPartials_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceParamPartials(self, index:int, frame:"AgEUtFrame", reflectXwrtParam:float, reflectYwrtParam:float, reflectZwrtParam:float) -> None:
        """Sets the partial derivatives of the components of reflectance (expressed in the specified frame) wrt the registered parameter specified by Index.  Uses internal units."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SetReflectanceParamPartials_metadata, index, frame, reflectXwrtParam, reflectYwrtParam, reflectZwrtParam)

    _TransformVectorToBody_Array_metadata = { "offset" : _TransformVectorToBody_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformVectorToBody_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float) -> list:
        """Transforms a vector from the input frame to the body frame returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._TransformVectorToBody_Array_metadata, frameFrom, xFrom, yFrom, zFrom, OutArg())

    _TransformVectorFromBody_Array_metadata = { "offset" : _TransformVectorFromBody_Array_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVectorFromBody_Array(self, xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the body frame to the output frame returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._TransformVectorFromBody_Array_metadata, xFrom, yFrom, zFrom, frameTo, OutArg())

    _IncidentDirectionInBody_Array_metadata = { "offset" : _IncidentDirectionInBody_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionInBody_Array(self) -> list:
        """Incident light direction (unitless) on the body, in the body frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._IncidentDirectionInBody_Array_metadata, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._DateString_metadata, dateAbbrv, OutArg())

    _GetInputValue_metadata = { "offset" : _GetInputValue_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def GetInputValue(self, index:int) -> float:
        """Gets the value of an input to the plugin in internal units."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._GetInputValue_metadata, index, OutArg())

    _SetParameterOutputValue_metadata = { "offset" : _SetParameterOutputValue_method_offset,
            "arg_types" : (agcom.INT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def SetParameterOutputValue(self, index:int, val:float) -> None:
        """Sets the value of a parameter output of the plugin in internal units."""
        return self._intf.invoke(IAgAsLightReflectionResultEval._metadata, IAgAsLightReflectionResultEval._SetParameterOutputValue_metadata, index, val)

    _property_names[Mu] = "Mu"
    _property_names[CbName] = "CbName"
    _property_names[LightSpeed] = "LightSpeed"
    _property_names[SolarIntensity] = "SolarIntensity"
    _property_names[SolarFlux] = "SolarFlux"
    _property_names[TotalMass] = "TotalMass"
    _property_names[Altitude] = "Altitude"
    _property_names[ParameterValue_Array] = "ParameterValue_Array"


agcls.AgClassCatalog.add_catalog_entry((5098585729371814727, 1854883725817174159), IAgAsLightReflectionResultEval)
agcls.AgTypeNameMap["IAgAsLightReflectionResultEval"] = IAgAsLightReflectionResultEval

class IAgAsLightReflectionPluginSample(object):
    """Light Reflection sample plugin"""

    _num_methods = 4
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ReportFrequency_method_offset = 1
    _set_ReportFrequency_method_offset = 2
    _get_DebugMode_method_offset = 3
    _set_DebugMode_method_offset = 4
    _metadata = {
        "iid_data" : (5161121725609233707, 14984903058274700424),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsLightReflectionPluginSample."""
        initialize_from_source_object(self, sourceObject, IAgAsLightReflectionPluginSample)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsLightReflectionPluginSample)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsLightReflectionPluginSample, None)
    
    _get_ReportFrequency_metadata = { "offset" : _get_ReportFrequency_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ReportFrequency(self) -> int:
        """Frequency of output of debug messages, in number of integration steps."""
        return self._intf.get_property(IAgAsLightReflectionPluginSample._metadata, IAgAsLightReflectionPluginSample._get_ReportFrequency_metadata)

    _set_ReportFrequency_metadata = { "offset" : _set_ReportFrequency_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @ReportFrequency.setter
    def ReportFrequency(self, newFreq:int) -> None:
        """Frequency of output of debug messages, in number of integration steps."""
        return self._intf.set_property(IAgAsLightReflectionPluginSample._metadata, IAgAsLightReflectionPluginSample._set_ReportFrequency_metadata, newFreq)

    _get_DebugMode_metadata = { "offset" : _get_DebugMode_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def DebugMode(self) -> bool:
        """Flag to turn debug mode on/off. When on, messages are reported to message viewer at the ReportFrequency."""
        return self._intf.get_property(IAgAsLightReflectionPluginSample._metadata, IAgAsLightReflectionPluginSample._get_DebugMode_metadata)

    _set_DebugMode_metadata = { "offset" : _set_DebugMode_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @DebugMode.setter
    def DebugMode(self, newDebugMode:bool) -> None:
        """Flag to turn debug mode on/off. When on, messages are reported to message viewer at the ReportFrequency."""
        return self._intf.set_property(IAgAsLightReflectionPluginSample._metadata, IAgAsLightReflectionPluginSample._set_DebugMode_metadata, newDebugMode)

    _property_names[ReportFrequency] = "ReportFrequency"
    _property_names[DebugMode] = "DebugMode"


agcls.AgClassCatalog.add_catalog_entry((5161121725609233707, 14984903058274700424), IAgAsLightReflectionPluginSample)
agcls.AgTypeNameMap["IAgAsLightReflectionPluginSample"] = IAgAsLightReflectionPluginSample

class IAgAsDragModelResultRegister(object):
    """DragModel plugin interface used to register parameters that may be estimated."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _RegisterParameter_method_offset = 1
    _Message_method_offset = 2
    _get_InstallDirectory_method_offset = 3
    _get_ConfigDirectory_method_offset = 4
    _RegisterUserInput_method_offset = 5
    _RegisterUserParameterOutput_method_offset = 6
    _metadata = {
        "iid_data" : (4848536961784746060, 14639903582010992562),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDragModelResultRegister."""
        initialize_from_source_object(self, sourceObject, IAgAsDragModelResultRegister)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDragModelResultRegister)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDragModelResultRegister, None)
    
    _RegisterParameter_metadata = { "offset" : _RegisterParameter_method_offset,
            "arg_types" : (agcom.BSTR, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.BSTR, POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def RegisterParameter(self, name:str, defaultValue:float, minValue:float, maxValue:float, dimension:str) -> int:
        """Registers a parameter of the computation that may be estimated. Returns an index identifier of the parameter used by other interfaces."""
        return self._intf.invoke(IAgAsDragModelResultRegister._metadata, IAgAsDragModelResultRegister._RegisterParameter_metadata, name, defaultValue, minValue, maxValue, dimension, OutArg())

    _Message_metadata = { "offset" : _Message_method_offset,
            "arg_types" : (agcom.LONG, agcom.BSTR,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtLogMsgType), agmarshall.BSTR_arg,) }
    def Message(self, msgType:"AgEUtLogMsgType", message:str) -> None:
        """Send a message to the message viewer."""
        return self._intf.invoke(IAgAsDragModelResultRegister._metadata, IAgAsDragModelResultRegister._Message_metadata, msgType, message)

    _get_InstallDirectory_metadata = { "offset" : _get_InstallDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def InstallDirectory(self) -> str:
        """The directory path of the installation of the application."""
        return self._intf.get_property(IAgAsDragModelResultRegister._metadata, IAgAsDragModelResultRegister._get_InstallDirectory_metadata)

    _get_ConfigDirectory_metadata = { "offset" : _get_ConfigDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ConfigDirectory(self) -> str:
        """The directory path of the user configuration area."""
        return self._intf.get_property(IAgAsDragModelResultRegister._metadata, IAgAsDragModelResultRegister._get_ConfigDirectory_metadata)

    _RegisterUserInput_metadata = { "offset" : _RegisterUserInput_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def RegisterUserInput(self, userValue:str) -> int:
        """Registers as input to the plugin a user value in the state vector."""
        return self._intf.invoke(IAgAsDragModelResultRegister._metadata, IAgAsDragModelResultRegister._RegisterUserInput_metadata, userValue, OutArg())

    _RegisterUserParameterOutput_metadata = { "offset" : _RegisterUserParameterOutput_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def RegisterUserParameterOutput(self, userValue:str) -> int:
        """Registers a user value in the state vector as a parameter output of the plugin."""
        return self._intf.invoke(IAgAsDragModelResultRegister._metadata, IAgAsDragModelResultRegister._RegisterUserParameterOutput_metadata, userValue, OutArg())

    _property_names[InstallDirectory] = "InstallDirectory"
    _property_names[ConfigDirectory] = "ConfigDirectory"


agcls.AgClassCatalog.add_catalog_entry((4848536961784746060, 14639903582010992562), IAgAsDragModelResultRegister)
agcls.AgTypeNameMap["IAgAsDragModelResultRegister"] = IAgAsDragModelResultRegister

class IAgAsDragModelResult(object):
    """DragModel plugin interface used to get/set settings. Supports the IAgEpoch interface."""

    _num_methods = 36
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _get_Mu_method_offset = 2
    _get_CbName_method_offset = 3
    _DayCount_method_offset = 4
    _DayCount_Array_method_offset = 5
    _Date_method_offset = 6
    _Date_Array_method_offset = 7
    _get_TotalMass_method_offset = 8
    _get_Altitude_method_offset = 9
    _PosVel_method_offset = 10
    _PosVel_Array_method_offset = 11
    _LatLonAlt_method_offset = 12
    _LatLonAlt_Array_method_offset = 13
    _TransformVector_method_offset = 14
    _TransformVector_Array_method_offset = 15
    _IncidentDirection_method_offset = 16
    _IncidentDirection_Array_method_offset = 17
    _TransformVectorToBody_method_offset = 18
    _TransformVectorToBody_Array_method_offset = 19
    _TransformVectorFromBody_method_offset = 20
    _TransformVectorFromBody_Array_method_offset = 21
    _IncidentDirectionInBody_method_offset = 22
    _IncidentDirectionInBody_Array_method_offset = 23
    _IncidentVector_method_offset = 24
    _IncidentVector_Array_method_offset = 25
    _IncidentVectorInBody_method_offset = 26
    _IncidentVectorInBody_Array_method_offset = 27
    _SunPosition_method_offset = 28
    _SunPosition_Array_method_offset = 29
    _SunPositionInBody_method_offset = 30
    _SunPositionInBody_Array_method_offset = 31
    _DateElements_method_offset = 32
    _DateElements_Array_method_offset = 33
    _DateString_method_offset = 34
    _GetInputValue_method_offset = 35
    _SetParameterOutputValue_method_offset = 36
    _metadata = {
        "iid_data" : (5452516886716302327, 14642516972424839312),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDragModelResult."""
        initialize_from_source_object(self, sourceObject, IAgAsDragModelResult)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDragModelResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDragModelResult, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._Trace_metadata, numCalls)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsDragModelResult._metadata, IAgAsDragModelResult._get_Mu_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsDragModelResult._metadata, IAgAsDragModelResult._get_CbName_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._DayCount_Array_metadata, scale, OutArg())

    _Date_Array_metadata = { "offset" : _Date_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def Date_Array(self, scale:"AgEUtTimeScale") -> list:
        """This method is deprecated. Use DateElements instead. Current epoch in requested time scale expressed in date format returned as an array representing year [yyyy], dayOfYear, month [0-11], hour [0-23], minute [0-59], seconds. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._Date_Array_metadata, scale, OutArg())

    _get_TotalMass_metadata = { "offset" : _get_TotalMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TotalMass(self) -> float:
        """Total Mass in kilograms."""
        return self._intf.get_property(IAgAsDragModelResult._metadata, IAgAsDragModelResult._get_TotalMass_metadata)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude in meters."""
        return self._intf.get_property(IAgAsDragModelResult._metadata, IAgAsDragModelResult._get_Altitude_metadata)

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) in the requested frame returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._PosVel_Array_metadata, frame, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude (radians), detic longitude (radians), and altitude(meters) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._LatLonAlt_Array_metadata, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _IncidentDirection_Array_metadata = { "offset" : _IncidentDirection_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirection_Array(self, frame:"AgEUtFrame") -> list:
        """Incident particle direction (unitless) on the body, in the requested frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._IncidentDirection_Array_metadata, frame, OutArg())

    _TransformVectorToBody_Array_metadata = { "offset" : _TransformVectorToBody_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformVectorToBody_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float) -> list:
        """Transforms a vector from the input frame to the body frame returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._TransformVectorToBody_Array_metadata, frameFrom, xFrom, yFrom, zFrom, OutArg())

    _TransformVectorFromBody_Array_metadata = { "offset" : _TransformVectorFromBody_Array_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVectorFromBody_Array(self, xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the body frame to the output frame returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._TransformVectorFromBody_Array_metadata, xFrom, yFrom, zFrom, frameTo, OutArg())

    _IncidentDirectionInBody_Array_metadata = { "offset" : _IncidentDirectionInBody_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionInBody_Array(self) -> list:
        """Incident particle direction (unitless) on the body, in the body frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._IncidentDirectionInBody_Array_metadata, OutArg())

    _IncidentVector_Array_metadata = { "offset" : _IncidentVector_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentVector_Array(self, frame:"AgEUtFrame") -> list:
        """Incident particle vector on the body in meters/second, in the requested frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._IncidentVector_Array_metadata, frame, OutArg())

    _IncidentVectorInBody_Array_metadata = { "offset" : _IncidentVectorInBody_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentVectorInBody_Array(self) -> list:
        """Incident particle vector on the body in meters/second, in the body frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._IncidentVectorInBody_Array_metadata, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun in meters wrt the current satellite position, in the requested frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _SunPositionInBody_Array_metadata = { "offset" : _SunPositionInBody_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.LPSAFEARRAY_arg,) }
    def SunPositionInBody_Array(self, sunPosType:"AgEUtSunPosType") -> list:
        """Position of the sun in meters wrt the current satellite position, in the body frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._SunPositionInBody_Array_metadata, sunPosType, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._DateString_metadata, dateAbbrv, OutArg())

    _GetInputValue_metadata = { "offset" : _GetInputValue_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def GetInputValue(self, index:int) -> float:
        """Gets the value of an input to the plugin in internal units."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._GetInputValue_metadata, index, OutArg())

    _SetParameterOutputValue_metadata = { "offset" : _SetParameterOutputValue_method_offset,
            "arg_types" : (agcom.INT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def SetParameterOutputValue(self, index:int, val:float) -> None:
        """Sets the value of a parameter output of the plugin in internal units."""
        return self._intf.invoke(IAgAsDragModelResult._metadata, IAgAsDragModelResult._SetParameterOutputValue_metadata, index, val)

    _property_names[Mu] = "Mu"
    _property_names[CbName] = "CbName"
    _property_names[TotalMass] = "TotalMass"
    _property_names[Altitude] = "Altitude"


agcls.AgClassCatalog.add_catalog_entry((5452516886716302327, 14642516972424839312), IAgAsDragModelResult)
agcls.AgTypeNameMap["IAgAsDragModelResult"] = IAgAsDragModelResult

class IAgAsDragModelResultEval(object):
    """DragModel plugin interface used to get/set settings during evaluation. Used to set reflectance vector (and optionally its partial derivs) used in computation of the drag/lift/side force. Supports the IAgEpoch interface."""

    _num_methods = 71
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _get_Mu_method_offset = 2
    _get_CbName_method_offset = 3
    _DayCount_method_offset = 4
    _DayCount_Array_method_offset = 5
    _Date_method_offset = 6
    _Date_Array_method_offset = 7
    _get_TotalMass_method_offset = 8
    _get_Altitude_method_offset = 9
    _PosVel_method_offset = 10
    _PosVel_Array_method_offset = 11
    _LatLonAlt_method_offset = 12
    _LatLonAlt_Array_method_offset = 13
    _SunPosition_method_offset = 14
    _SunPosition_Array_method_offset = 15
    _TransformVector_method_offset = 16
    _TransformVector_Array_method_offset = 17
    _IncidentDirection_method_offset = 18
    _IncidentDirection_Array_method_offset = 19
    _SetReflectanceInBody_method_offset = 20
    _SetReflectance_method_offset = 21
    _IncidentDirectionVecInBodyPosPartials_method_offset = 22
    _IncidentDirectionVecInBodyPosPartials_Array_method_offset = 23
    _IncidentDirectionVecPosPartials_method_offset = 24
    _IncidentDirectionVecPosPartials_Array_method_offset = 25
    _IncidentDirectionBodyCompPosPartials_method_offset = 26
    _IncidentDirectionBodyCompPosPartials_Array_method_offset = 27
    _IncidentDirectionCompPosPartials_method_offset = 28
    _IncidentDirectionCompPosPartials_Array_method_offset = 29
    _IncidentDirectionBodyCompVelPartials_method_offset = 30
    _IncidentDirectionBodyCompVelPartials_Array_method_offset = 31
    _IncidentDirectionCompVelPartials_method_offset = 32
    _IncidentDirectionCompVelPartials_Array_method_offset = 33
    _SetReflectanceBodyCompPosPartials_method_offset = 34
    _SetReflectanceCompPosPartials_method_offset = 35
    _SetReflectanceBodyCompVelPartials_method_offset = 36
    _SetReflectanceCompVelPartials_method_offset = 37
    _BodyFixedVectorPosPartials_method_offset = 38
    _BodyFixedVectorPosPartials_Array_method_offset = 39
    _FrameFixedVectorPosPartials_method_offset = 40
    _FrameFixedVectorPosPartials_Array_method_offset = 41
    _BodyFixedVectorVelPartials_method_offset = 42
    _BodyFixedVectorVelPartials_Array_method_offset = 43
    _FrameFixedVectorVelPartials_method_offset = 44
    _FrameFixedVectorVelPartials_Array_method_offset = 45
    _ParameterValue_method_offset = 46
    _get_ParameterValue_Array_method_offset = 47
    _SetReflectanceInBodyParamPartials_method_offset = 48
    _SetReflectanceParamPartials_method_offset = 49
    _TransformVectorToBody_method_offset = 50
    _TransformVectorToBody_Array_method_offset = 51
    _TransformVectorFromBody_method_offset = 52
    _TransformVectorFromBody_Array_method_offset = 53
    _IncidentDirectionInBody_method_offset = 54
    _IncidentDirectionInBody_Array_method_offset = 55
    _IncidentVector_method_offset = 56
    _IncidentVector_Array_method_offset = 57
    _IncidentVectorInBody_method_offset = 58
    _IncidentVectorInBody_Array_method_offset = 59
    _SunPositionInBody_method_offset = 60
    _SunPositionInBody_Array_method_offset = 61
    _get_Density_method_offset = 62
    _get_AtmPressure_method_offset = 63
    _get_AtmTemperature_method_offset = 64
    _get_DragAltitude_method_offset = 65
    _get_MeanMolecularMass_method_offset = 66
    _DateElements_method_offset = 67
    _DateElements_Array_method_offset = 68
    _DateString_method_offset = 69
    _GetInputValue_method_offset = 70
    _SetParameterOutputValue_method_offset = 71
    _metadata = {
        "iid_data" : (5452835633417316440, 3116266928942207369),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDragModelResultEval."""
        initialize_from_source_object(self, sourceObject, IAgAsDragModelResultEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDragModelResultEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDragModelResultEval, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._Trace_metadata, numCalls)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_Mu_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_CbName_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._DayCount_Array_metadata, scale, OutArg())

    _Date_Array_metadata = { "offset" : _Date_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def Date_Array(self, scale:"AgEUtTimeScale") -> list:
        """This method is deprecated. Use DateElements instead. Current epoch in requested time scale expressed in date format returned as an array representing year [yyyy], dayOfYear, month [0-11], hour [0-23], minute [0-59], seconds. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._Date_Array_metadata, scale, OutArg())

    _get_TotalMass_metadata = { "offset" : _get_TotalMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TotalMass(self) -> float:
        """Total Mass in kilograms."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_TotalMass_metadata)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude in meters."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_Altitude_metadata)

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) in the requested frame returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._PosVel_Array_metadata, frame, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude (radians), detic longitude (radians), and altitude(meters) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._LatLonAlt_Array_metadata, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun in meters wrt the current satellite position, in the requested frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _IncidentDirection_Array_metadata = { "offset" : _IncidentDirection_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirection_Array(self, frame:"AgEUtFrame") -> list:
        """Incident particle direction (unitless) on the body, in the requested frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentDirection_Array_metadata, frame, OutArg())

    _SetReflectanceInBody_metadata = { "offset" : _SetReflectanceInBody_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceInBody(self, x:float, y:float, z:float) -> None:
        """Sets reflectance (in m^2) in body components. Force = 0.5*density*velCBF^2*reflectanceVec. reflectanceVec = sum of surface contributions where each surface N is cd_N*area_N*unitDirection_N."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SetReflectanceInBody_metadata, x, y, z)

    _SetReflectance_metadata = { "offset" : _SetReflectance_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectance(self, frame:"AgEUtFrame", x:float, y:float, z:float) -> None:
        """Sets reflectance (in m^2) in specified frame. Force = 0.5*density*velCBF^2*reflectanceVec. reflectanceVec = sum of surface contributions where each surface N is cd_N*area_N*unitDirection_N."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SetReflectance_metadata, frame, x, y, z)

    _IncidentDirectionVecInBodyPosPartials_Array_metadata = { "offset" : _IncidentDirectionVecInBodyPosPartials_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionVecInBodyPosPartials_Array(self) -> list:
        """The partial derivatives in meters^-1 of the incident direction wrt inertial position coordinates, expressed in body components, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentDirectionVecInBodyPosPartials_Array_metadata, OutArg())

    _IncidentDirectionVecPosPartials_Array_metadata = { "offset" : _IncidentDirectionVecPosPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionVecPosPartials_Array(self, frame:"AgEUtFrame") -> list:
        """The partial derivatives in meters^-1 of the incident direction wrt inertial position coordinates, expressed in components of the requested frame, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentDirectionVecPosPartials_Array_metadata, frame, OutArg())

    _IncidentDirectionBodyCompPosPartials_Array_metadata = { "offset" : _IncidentDirectionBodyCompPosPartials_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionBodyCompPosPartials_Array(self) -> list:
        """The partial derivatives in meters^-1 of the incident direction body components wrt inertial position coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentDirectionBodyCompPosPartials_Array_metadata, OutArg())

    _IncidentDirectionCompPosPartials_Array_metadata = { "offset" : _IncidentDirectionCompPosPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionCompPosPartials_Array(self, frame:"AgEUtFrame") -> list:
        """The partial derivatives in meters^-1 of the incident direction components, expressed in the requested frame, wrt inertial position coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentDirectionCompPosPartials_Array_metadata, frame, OutArg())

    _IncidentDirectionBodyCompVelPartials_Array_metadata = { "offset" : _IncidentDirectionBodyCompVelPartials_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionBodyCompVelPartials_Array(self) -> list:
        """The partial derivatives in seconds/meter of the incident direction body components wrt inertial velocity coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentDirectionBodyCompVelPartials_Array_metadata, OutArg())

    _IncidentDirectionCompVelPartials_Array_metadata = { "offset" : _IncidentDirectionCompVelPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionCompVelPartials_Array(self, frame:"AgEUtFrame") -> list:
        """The partial derivatives in seconds/meter of the incident direction components, expressed in the requested frame, wrt inertial velocity coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentDirectionCompVelPartials_Array_metadata, frame, OutArg())

    _SetReflectanceBodyCompPosPartials_metadata = { "offset" : _SetReflectanceBodyCompPosPartials_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceBodyCompPosPartials(self, reflectXwrtX:float, reflectXwrtY:float, reflectXwrtZ:float, reflectYwrtX:float, reflectYwrtY:float, reflectYwrtZ:float, reflectZwrtX:float, reflectZwrtY:float, reflectZwrtZ:float) -> None:
        """Sets the partial derivatives in meters of the body components of reflectance wrt inertial position coordinates."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SetReflectanceBodyCompPosPartials_metadata, reflectXwrtX, reflectXwrtY, reflectXwrtZ, reflectYwrtX, reflectYwrtY, reflectYwrtZ, reflectZwrtX, reflectZwrtY, reflectZwrtZ)

    _SetReflectanceCompPosPartials_metadata = { "offset" : _SetReflectanceCompPosPartials_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceCompPosPartials(self, frame:"AgEUtFrame", reflectXwrtX:float, reflectXwrtY:float, reflectXwrtZ:float, reflectYwrtX:float, reflectYwrtY:float, reflectYwrtZ:float, reflectZwrtX:float, reflectZwrtY:float, reflectZwrtZ:float) -> None:
        """Sets the partial derivatives in meters of the components of reflectance (expressed in the specified frame) wrt inertial position coordinates."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SetReflectanceCompPosPartials_metadata, frame, reflectXwrtX, reflectXwrtY, reflectXwrtZ, reflectYwrtX, reflectYwrtY, reflectYwrtZ, reflectZwrtX, reflectZwrtY, reflectZwrtZ)

    _SetReflectanceBodyCompVelPartials_metadata = { "offset" : _SetReflectanceBodyCompVelPartials_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceBodyCompVelPartials(self, reflectXwrtVX:float, reflectXwrtVY:float, reflectXwrtVZ:float, reflectYwrtVX:float, reflectYwrtVY:float, reflectYwrtVZ:float, reflectZwrtVX:float, reflectZwrtVY:float, reflectZwrtVZ:float) -> None:
        """Sets the partial derivatives in meter-seconds of the body components of reflectance wrt inertial velocity coordinates."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SetReflectanceBodyCompVelPartials_metadata, reflectXwrtVX, reflectXwrtVY, reflectXwrtVZ, reflectYwrtVX, reflectYwrtVY, reflectYwrtVZ, reflectZwrtVX, reflectZwrtVY, reflectZwrtVZ)

    _SetReflectanceCompVelPartials_metadata = { "offset" : _SetReflectanceCompVelPartials_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceCompVelPartials(self, frame:"AgEUtFrame", reflectXwrtVX:float, reflectXwrtVY:float, reflectXwrtVZ:float, reflectYwrtVX:float, reflectYwrtVY:float, reflectYwrtVZ:float, reflectZwrtVX:float, reflectZwrtVY:float, reflectZwrtVZ:float) -> None:
        """Sets the partial derivatives in meter-seconds of the components of reflectance (expressed in the specified frame) wrt inertial velocity coordinates."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SetReflectanceCompVelPartials_metadata, frame, reflectXwrtVX, reflectXwrtVY, reflectXwrtVZ, reflectYwrtVX, reflectYwrtVY, reflectYwrtVZ, reflectZwrtVX, reflectZwrtVY, reflectZwrtVZ)

    _BodyFixedVectorPosPartials_Array_metadata = { "offset" : _BodyFixedVectorPosPartials_Array_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def BodyFixedVectorPosPartials_Array(self, x:float, y:float, z:float) -> list:
        """The partial derivatives of the given body-fixed vector wrt inertial position coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients.  Uses internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._BodyFixedVectorPosPartials_Array_metadata, x, y, z, OutArg())

    _FrameFixedVectorPosPartials_Array_metadata = { "offset" : _FrameFixedVectorPosPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def FrameFixedVectorPosPartials_Array(self, frame:"AgEUtFrame", x:float, y:float, z:float) -> list:
        """The partial derivatives of the given frame-fixed vector wrt inertial position coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients.  Uses internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._FrameFixedVectorPosPartials_Array_metadata, frame, x, y, z, OutArg())

    _BodyFixedVectorVelPartials_Array_metadata = { "offset" : _BodyFixedVectorVelPartials_Array_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def BodyFixedVectorVelPartials_Array(self, x:float, y:float, z:float) -> list:
        """The partial derivatives of the given body-fixed vector wrt inertial velocity coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients.  Uses internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._BodyFixedVectorVelPartials_Array_metadata, x, y, z, OutArg())

    _FrameFixedVectorVelPartials_Array_metadata = { "offset" : _FrameFixedVectorVelPartials_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def FrameFixedVectorVelPartials_Array(self, frame:"AgEUtFrame", x:float, y:float, z:float) -> list:
        """The partial derivatives of the given frame-fixed vector wrt inertial velocity coordinates, returned as an array representing the rows of the matrix. Useful for scripting clients.  Uses internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._FrameFixedVectorVelPartials_Array_metadata, frame, x, y, z, OutArg())

    _ParameterValue_metadata = { "offset" : _ParameterValue_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.DOUBLE_arg,) }
    def ParameterValue(self, index:int) -> float:
        """Parameter value for a registered parameter with indicated index.  Uses internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._ParameterValue_metadata, index, OutArg())

    _get_ParameterValue_Array_metadata = { "offset" : _get_ParameterValue_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def ParameterValue_Array(self) -> list:
        """Parameter values for all registered parameters, returned in index order.  Uses internal units."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_ParameterValue_Array_metadata)

    _SetReflectanceInBodyParamPartials_metadata = { "offset" : _SetReflectanceInBodyParamPartials_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceInBodyParamPartials(self, index:int, reflectXwrtParam:float, reflectYwrtParam:float, reflectZwrtParam:float) -> None:
        """Sets the partial derivatives of the body components of reflectance wrt the registered parameter specified by Index.  Uses internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SetReflectanceInBodyParamPartials_metadata, index, reflectXwrtParam, reflectYwrtParam, reflectZwrtParam)

    _SetReflectanceParamPartials_metadata = { "offset" : _SetReflectanceParamPartials_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetReflectanceParamPartials(self, index:int, frame:"AgEUtFrame", reflectXwrtParam:float, reflectYwrtParam:float, reflectZwrtParam:float) -> None:
        """Sets the partial derivatives of the components of reflectance (expressed in the specified frame) wrt the registered parameter specified by Index.  Uses internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SetReflectanceParamPartials_metadata, index, frame, reflectXwrtParam, reflectYwrtParam, reflectZwrtParam)

    _TransformVectorToBody_Array_metadata = { "offset" : _TransformVectorToBody_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def TransformVectorToBody_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float) -> list:
        """Transforms a vector from the input frame to the body frame returned as an array representing x, y, z. Useful for scripting clients.  Uses internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._TransformVectorToBody_Array_metadata, frameFrom, xFrom, yFrom, zFrom, OutArg())

    _TransformVectorFromBody_Array_metadata = { "offset" : _TransformVectorFromBody_Array_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVectorFromBody_Array(self, xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the body frame to the output frame returned as an array representing x, y, z. Useful for scripting clients.  Uses internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._TransformVectorFromBody_Array_metadata, xFrom, yFrom, zFrom, frameTo, OutArg())

    _IncidentDirectionInBody_Array_metadata = { "offset" : _IncidentDirectionInBody_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentDirectionInBody_Array(self) -> list:
        """Incident particle direction (unitless) on the body, in the body frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentDirectionInBody_Array_metadata, OutArg())

    _IncidentVector_Array_metadata = { "offset" : _IncidentVector_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def IncidentVector_Array(self, frame:"AgEUtFrame") -> list:
        """Incident particle vector on the body in meters/second, in the requested frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentVector_Array_metadata, frame, OutArg())

    _IncidentVectorInBody_Array_metadata = { "offset" : _IncidentVectorInBody_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def IncidentVectorInBody_Array(self) -> list:
        """Incident particle vector on the body in meters/second, in the body frame, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._IncidentVectorInBody_Array_metadata, OutArg())

    _SunPositionInBody_Array_metadata = { "offset" : _SunPositionInBody_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.LPSAFEARRAY_arg,) }
    def SunPositionInBody_Array(self, sunPosType:"AgEUtSunPosType") -> list:
        """Position of the sun in meters wrt the current satellite position, in the body frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SunPositionInBody_Array_metadata, sunPosType, OutArg())

    _get_Density_metadata = { "offset" : _get_Density_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Density(self) -> float:
        """Current atmospheric density in kg/meter^3."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_Density_metadata)

    _get_AtmPressure_metadata = { "offset" : _get_AtmPressure_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AtmPressure(self) -> float:
        """Current atmospheric pressure in pascals (N/m^2). Available if supported by atm density model (MSIS)."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_AtmPressure_metadata)

    _get_AtmTemperature_metadata = { "offset" : _get_AtmTemperature_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AtmTemperature(self) -> float:
        """Current atmospheric temperature in K. Available if supported by atm density model (MSIS)."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_AtmTemperature_metadata)

    _get_DragAltitude_metadata = { "offset" : _get_DragAltitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DragAltitude(self) -> float:
        """Altitude used for current atmospheric density computation in meters."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_DragAltitude_metadata)

    _get_MeanMolecularMass_metadata = { "offset" : _get_MeanMolecularMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def MeanMolecularMass(self) -> float:
        """Mean molecular mass from current atmospheric density computation in kg/kmol. Available if supported by atm density model (MSIS)."""
        return self._intf.get_property(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._get_MeanMolecularMass_metadata)

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._DateString_metadata, dateAbbrv, OutArg())

    _GetInputValue_metadata = { "offset" : _GetInputValue_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def GetInputValue(self, index:int) -> float:
        """Gets the value of an input to the plugin in internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._GetInputValue_metadata, index, OutArg())

    _SetParameterOutputValue_metadata = { "offset" : _SetParameterOutputValue_method_offset,
            "arg_types" : (agcom.INT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def SetParameterOutputValue(self, index:int, val:float) -> None:
        """Sets the value of a parameter output of the plugin in internal units."""
        return self._intf.invoke(IAgAsDragModelResultEval._metadata, IAgAsDragModelResultEval._SetParameterOutputValue_metadata, index, val)

    _property_names[Mu] = "Mu"
    _property_names[CbName] = "CbName"
    _property_names[TotalMass] = "TotalMass"
    _property_names[Altitude] = "Altitude"
    _property_names[ParameterValue_Array] = "ParameterValue_Array"
    _property_names[Density] = "Density"
    _property_names[AtmPressure] = "AtmPressure"
    _property_names[AtmTemperature] = "AtmTemperature"
    _property_names[DragAltitude] = "DragAltitude"
    _property_names[MeanMolecularMass] = "MeanMolecularMass"


agcls.AgClassCatalog.add_catalog_entry((5452835633417316440, 3116266928942207369), IAgAsDragModelResultEval)
agcls.AgTypeNameMap["IAgAsDragModelResultEval"] = IAgAsDragModelResultEval

class IAgAsDragModelPluginSample(object):
    """Drag model sample plugin"""

    _num_methods = 4
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ReportFrequency_method_offset = 1
    _set_ReportFrequency_method_offset = 2
    _get_DebugMode_method_offset = 3
    _set_DebugMode_method_offset = 4
    _metadata = {
        "iid_data" : (4751982735288084489, 15792251551539764352),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDragModelPluginSample."""
        initialize_from_source_object(self, sourceObject, IAgAsDragModelPluginSample)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDragModelPluginSample)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDragModelPluginSample, None)
    
    _get_ReportFrequency_metadata = { "offset" : _get_ReportFrequency_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ReportFrequency(self) -> int:
        """Frequency of output of debug messages, in number of integration steps."""
        return self._intf.get_property(IAgAsDragModelPluginSample._metadata, IAgAsDragModelPluginSample._get_ReportFrequency_metadata)

    _set_ReportFrequency_metadata = { "offset" : _set_ReportFrequency_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @ReportFrequency.setter
    def ReportFrequency(self, newFreq:int) -> None:
        """Frequency of output of debug messages, in number of integration steps."""
        return self._intf.set_property(IAgAsDragModelPluginSample._metadata, IAgAsDragModelPluginSample._set_ReportFrequency_metadata, newFreq)

    _get_DebugMode_metadata = { "offset" : _get_DebugMode_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def DebugMode(self) -> bool:
        """Flag to turn debug mode on/off. When on, messages are reported to message viewer at the ReportFrequency."""
        return self._intf.get_property(IAgAsDragModelPluginSample._metadata, IAgAsDragModelPluginSample._get_DebugMode_metadata)

    _set_DebugMode_metadata = { "offset" : _set_DebugMode_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @DebugMode.setter
    def DebugMode(self, newDebugMode:bool) -> None:
        """Flag to turn debug mode on/off. When on, messages are reported to message viewer at the ReportFrequency."""
        return self._intf.set_property(IAgAsDragModelPluginSample._metadata, IAgAsDragModelPluginSample._set_DebugMode_metadata, newDebugMode)

    _property_names[ReportFrequency] = "ReportFrequency"
    _property_names[DebugMode] = "DebugMode"


agcls.AgClassCatalog.add_catalog_entry((4751982735288084489, 15792251551539764352), IAgAsDragModelPluginSample)
agcls.AgTypeNameMap["IAgAsDragModelPluginSample"] = IAgAsDragModelPluginSample

class IAgAsEOMFuncPluginRegisterHandler(object):
    """EOM func plugin interface used to register the plugin's inputs, outputs, and events."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _RegisterInput_method_offset = 1
    _RegisterUserInput_method_offset = 2
    _RegisterParameterOutput_method_offset = 3
    _RegisterUserParameterOutput_method_offset = 4
    _RegisterUserDerivativeOutput_method_offset = 5
    _ExcludeEvent_method_offset = 6
    _metadata = {
        "iid_data" : (5502685421369993931, 7158173269888239805),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsEOMFuncPluginRegisterHandler."""
        initialize_from_source_object(self, sourceObject, IAgAsEOMFuncPluginRegisterHandler)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsEOMFuncPluginRegisterHandler)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsEOMFuncPluginRegisterHandler, None)
    
    _RegisterInput_metadata = { "offset" : _RegisterInput_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEOMFuncPluginInputStateValues),) }
    def RegisterInput(self, stateValue:"AgEAsEOMFuncPluginInputStateValues") -> None:
        """Registers as input to the plugin a built-in value in the state vector."""
        return self._intf.invoke(IAgAsEOMFuncPluginRegisterHandler._metadata, IAgAsEOMFuncPluginRegisterHandler._RegisterInput_metadata, stateValue)

    _RegisterUserInput_metadata = { "offset" : _RegisterUserInput_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def RegisterUserInput(self, userValue:str) -> None:
        """Registers as input to the plugin a user value in the state vector."""
        return self._intf.invoke(IAgAsEOMFuncPluginRegisterHandler._metadata, IAgAsEOMFuncPluginRegisterHandler._RegisterUserInput_metadata, userValue)

    _RegisterParameterOutput_metadata = { "offset" : _RegisterParameterOutput_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEOMFuncPluginOutputStateValues),) }
    def RegisterParameterOutput(self, stateValue:"AgEAsEOMFuncPluginOutputStateValues") -> None:
        """Registers a built-in value in the state vector as a parameter output of the plugin."""
        return self._intf.invoke(IAgAsEOMFuncPluginRegisterHandler._metadata, IAgAsEOMFuncPluginRegisterHandler._RegisterParameterOutput_metadata, stateValue)

    _RegisterUserParameterOutput_metadata = { "offset" : _RegisterUserParameterOutput_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def RegisterUserParameterOutput(self, userValue:str) -> None:
        """Registers a user value in the state vector as a parameter output of the plugin."""
        return self._intf.invoke(IAgAsEOMFuncPluginRegisterHandler._metadata, IAgAsEOMFuncPluginRegisterHandler._RegisterUserParameterOutput_metadata, userValue)

    _RegisterUserDerivativeOutput_metadata = { "offset" : _RegisterUserDerivativeOutput_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def RegisterUserDerivativeOutput(self, userValue:str) -> None:
        """Registers a user value in the state vector of which the plugin will give the 1st derivative."""
        return self._intf.invoke(IAgAsEOMFuncPluginRegisterHandler._metadata, IAgAsEOMFuncPluginRegisterHandler._RegisterUserDerivativeOutput_metadata, userValue)

    _ExcludeEvent_metadata = { "offset" : _ExcludeEvent_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEOMFuncPluginEventTypes),) }
    def ExcludeEvent(self, eventType:"AgEAsEOMFuncPluginEventTypes") -> None:
        """Registers an event on which the plugin should not be run."""
        return self._intf.invoke(IAgAsEOMFuncPluginRegisterHandler._metadata, IAgAsEOMFuncPluginRegisterHandler._ExcludeEvent_metadata, eventType)


agcls.AgClassCatalog.add_catalog_entry((5502685421369993931, 7158173269888239805), IAgAsEOMFuncPluginRegisterHandler)
agcls.AgTypeNameMap["IAgAsEOMFuncPluginRegisterHandler"] = IAgAsEOMFuncPluginRegisterHandler

class IAgAsEOMFuncPluginSetIndicesHandler(object):
    """EOM func plugin interface used to set the indices of the plugin's input and output."""

    _num_methods = 5
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _GetInputIndex_method_offset = 1
    _GetUserInputIndex_method_offset = 2
    _GetParameterOutputIndex_method_offset = 3
    _GetUserParameterOutputIndex_method_offset = 4
    _GetUserDerivativeOutputIndex_method_offset = 5
    _metadata = {
        "iid_data" : (5698059112549762175, 2334973546591001530),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsEOMFuncPluginSetIndicesHandler."""
        initialize_from_source_object(self, sourceObject, IAgAsEOMFuncPluginSetIndicesHandler)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsEOMFuncPluginSetIndicesHandler)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsEOMFuncPluginSetIndicesHandler, None)
    
    _GetInputIndex_metadata = { "offset" : _GetInputIndex_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.INT),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEOMFuncPluginInputStateValues), agmarshall.INT_arg,) }
    def GetInputIndex(self, stateValue:"AgEAsEOMFuncPluginInputStateValues") -> int:
        """Gets the index of an input to the plugin of a built-in value in the state vector."""
        return self._intf.invoke(IAgAsEOMFuncPluginSetIndicesHandler._metadata, IAgAsEOMFuncPluginSetIndicesHandler._GetInputIndex_metadata, stateValue, OutArg())

    _GetUserInputIndex_metadata = { "offset" : _GetUserInputIndex_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.INT),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.INT_arg,) }
    def GetUserInputIndex(self, userValue:str) -> int:
        """Gets the index of an input to the plugin of a user value in the state vector."""
        return self._intf.invoke(IAgAsEOMFuncPluginSetIndicesHandler._metadata, IAgAsEOMFuncPluginSetIndicesHandler._GetUserInputIndex_metadata, userValue, OutArg())

    _GetParameterOutputIndex_metadata = { "offset" : _GetParameterOutputIndex_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.INT),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsEOMFuncPluginOutputStateValues), agmarshall.INT_arg,) }
    def GetParameterOutputIndex(self, stateValue:"AgEAsEOMFuncPluginOutputStateValues") -> int:
        """Gets the index of parameter output of the plugin of a built-in value in the state vector."""
        return self._intf.invoke(IAgAsEOMFuncPluginSetIndicesHandler._metadata, IAgAsEOMFuncPluginSetIndicesHandler._GetParameterOutputIndex_metadata, stateValue, OutArg())

    _GetUserParameterOutputIndex_metadata = { "offset" : _GetUserParameterOutputIndex_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.INT),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.INT_arg,) }
    def GetUserParameterOutputIndex(self, userValue:str) -> int:
        """Gets the index of parameter output of the plugin of a built-in value in the state vector."""
        return self._intf.invoke(IAgAsEOMFuncPluginSetIndicesHandler._metadata, IAgAsEOMFuncPluginSetIndicesHandler._GetUserParameterOutputIndex_metadata, userValue, OutArg())

    _GetUserDerivativeOutputIndex_metadata = { "offset" : _GetUserDerivativeOutputIndex_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.INT),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.INT_arg,) }
    def GetUserDerivativeOutputIndex(self, userValue:str) -> int:
        """Gets the index of a user value in the state vector of which the plugin will give the 1st derivative."""
        return self._intf.invoke(IAgAsEOMFuncPluginSetIndicesHandler._metadata, IAgAsEOMFuncPluginSetIndicesHandler._GetUserDerivativeOutputIndex_metadata, userValue, OutArg())


agcls.AgClassCatalog.add_catalog_entry((5698059112549762175, 2334973546591001530), IAgAsEOMFuncPluginSetIndicesHandler)
agcls.AgTypeNameMap["IAgAsEOMFuncPluginSetIndicesHandler"] = IAgAsEOMFuncPluginSetIndicesHandler

class IAgAsEOMFuncPluginStateVector(object):
    """State vector interface for EOM func plugins."""

    _num_methods = 22
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _GetInputValue_method_offset = 1
    _SetParameterOutputValue_method_offset = 2
    _AddDerivativeOutputValue_method_offset = 3
    _get_TimeSinceRefEpoch_method_offset = 4
    _DayCount_method_offset = 5
    _get_CbName_method_offset = 6
    _DayCount_Array_method_offset = 7
    _PosVel_method_offset = 8
    _PosVel_Array_method_offset = 9
    _TransformVector_method_offset = 10
    _TransformVector_Array_method_offset = 11
    _AddAcceleration_method_offset = 12
    _get_Mu_method_offset = 13
    _StopPropagation_method_offset = 14
    _IndicateEvent_method_offset = 15
    _SetMaxStep_method_offset = 16
    _DateElements_method_offset = 17
    _DateElements_Array_method_offset = 18
    _DateString_method_offset = 19
    _RefEpochElements_method_offset = 20
    _RefEpochElements_Array_method_offset = 21
    _RefEpochString_method_offset = 22
    _metadata = {
        "iid_data" : (5267272738674619620, 12501782248143201439),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsEOMFuncPluginStateVector."""
        initialize_from_source_object(self, sourceObject, IAgAsEOMFuncPluginStateVector)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsEOMFuncPluginStateVector)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsEOMFuncPluginStateVector, None)
    
    _GetInputValue_metadata = { "offset" : _GetInputValue_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def GetInputValue(self, index:int) -> float:
        """Gets the value of an input to the plugin in internal units."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._GetInputValue_metadata, index, OutArg())

    _SetParameterOutputValue_metadata = { "offset" : _SetParameterOutputValue_method_offset,
            "arg_types" : (agcom.INT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def SetParameterOutputValue(self, index:int, val:float) -> None:
        """Sets the value of a parameter output of the plugin in internal units."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._SetParameterOutputValue_metadata, index, val)

    _AddDerivativeOutputValue_metadata = { "offset" : _AddDerivativeOutputValue_method_offset,
            "arg_types" : (agcom.INT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def AddDerivativeOutputValue(self, index:int, val:float) -> None:
        """Sets the value of a first derivative in internal units."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._AddDerivativeOutputValue_metadata, index, val)

    _get_TimeSinceRefEpoch_metadata = { "offset" : _get_TimeSinceRefEpoch_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TimeSinceRefEpoch(self) -> float:
        """Current epoch expressed in seconds since reference epoch."""
        return self._intf.get_property(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._get_TimeSinceRefEpoch_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._get_CbName_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._DayCount_Array_metadata, scale, OutArg())

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) in the requested frame returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._PosVel_Array_metadata, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _AddAcceleration_metadata = { "offset" : _AddAcceleration_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AddAcceleration(self, frame:"AgEUtFrame", x:float, y:float, z:float) -> None:
        """Add the acceleration in meters/second^2 in the given frame to the force model."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._AddAcceleration_metadata, frame, x, y, z)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._get_Mu_metadata)

    _StopPropagation_metadata = { "offset" : _StopPropagation_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def StopPropagation(self) -> None:
        """Stops propagation.  For fatal errors."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._StopPropagation_metadata, )

    _IndicateEvent_metadata = { "offset" : _IndicateEvent_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsHpopPluginEventIndicators),) }
    def IndicateEvent(self, eventIndicator:"AgEAsHpopPluginEventIndicators") -> None:
        """Marks an event to the propagator."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._IndicateEvent_metadata, eventIndicator)

    _SetMaxStep_metadata = { "offset" : _SetMaxStep_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetMaxStep(self, maxStep:float) -> None:
        """Sets the maximum step size in seconds for the propagator."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._SetMaxStep_metadata, maxStep)

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._DateString_metadata, dateAbbrv, OutArg())

    _RefEpochElements_Array_metadata = { "offset" : _RefEpochElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def RefEpochElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Reference epoch expressed in requested time scale in day count and date formats as the array: WholeDays, SecsIntoDay, Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._RefEpochElements_Array_metadata, scale, OutArg())

    _RefEpochString_metadata = { "offset" : _RefEpochString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def RefEpochString(self, dateAbbrv:str) -> str:
        """Reference epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsEOMFuncPluginStateVector._metadata, IAgAsEOMFuncPluginStateVector._RefEpochString_metadata, dateAbbrv, OutArg())

    _property_names[TimeSinceRefEpoch] = "TimeSinceRefEpoch"
    _property_names[CbName] = "CbName"
    _property_names[Mu] = "Mu"


agcls.AgClassCatalog.add_catalog_entry((5267272738674619620, 12501782248143201439), IAgAsEOMFuncPluginStateVector)
agcls.AgTypeNameMap["IAgAsEOMFuncPluginStateVector"] = IAgAsEOMFuncPluginStateVector

class IAgAsDensityModelResultRegister(object):
    """DensityModel plugin interface used to register parameters that may be estimated."""

    _num_methods = 7
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _RegisterParameter_method_offset = 1
    _RegisterUserInput_method_offset = 2
    _RegisterUserParameterOutput_method_offset = 3
    _Message_method_offset = 4
    _get_InstallDirectory_method_offset = 5
    _get_ConfigDirectory_method_offset = 6
    _SetParameterizationName_method_offset = 7
    _metadata = {
        "iid_data" : (4848536961784746060, 14567845987973064626),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDensityModelResultRegister."""
        initialize_from_source_object(self, sourceObject, IAgAsDensityModelResultRegister)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDensityModelResultRegister)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDensityModelResultRegister, None)
    
    _RegisterParameter_metadata = { "offset" : _RegisterParameter_method_offset,
            "arg_types" : (agcom.BSTR, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.BSTR, POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def RegisterParameter(self, name:str, defaultValue:float, minValue:float, maxValue:float, dimension:str) -> int:
        """Registers a parameter of the computation that may be estimated. Returns an index identifier of the parameter used by other interfaces."""
        return self._intf.invoke(IAgAsDensityModelResultRegister._metadata, IAgAsDensityModelResultRegister._RegisterParameter_metadata, name, defaultValue, minValue, maxValue, dimension, OutArg())

    _RegisterUserInput_metadata = { "offset" : _RegisterUserInput_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def RegisterUserInput(self, userValue:str) -> int:
        """Registers as input to the plugin a user value in the state vector."""
        return self._intf.invoke(IAgAsDensityModelResultRegister._metadata, IAgAsDensityModelResultRegister._RegisterUserInput_metadata, userValue, OutArg())

    _RegisterUserParameterOutput_metadata = { "offset" : _RegisterUserParameterOutput_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.LONG_arg,) }
    def RegisterUserParameterOutput(self, userValue:str) -> int:
        """Registers a user value in the state vector as a parameter output of the plugin."""
        return self._intf.invoke(IAgAsDensityModelResultRegister._metadata, IAgAsDensityModelResultRegister._RegisterUserParameterOutput_metadata, userValue, OutArg())

    _Message_metadata = { "offset" : _Message_method_offset,
            "arg_types" : (agcom.LONG, agcom.BSTR,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtLogMsgType), agmarshall.BSTR_arg,) }
    def Message(self, msgType:"AgEUtLogMsgType", message:str) -> None:
        """Send a message to the message viewer."""
        return self._intf.invoke(IAgAsDensityModelResultRegister._metadata, IAgAsDensityModelResultRegister._Message_metadata, msgType, message)

    _get_InstallDirectory_metadata = { "offset" : _get_InstallDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def InstallDirectory(self) -> str:
        """The directory path of the installation of the application."""
        return self._intf.get_property(IAgAsDensityModelResultRegister._metadata, IAgAsDensityModelResultRegister._get_InstallDirectory_metadata)

    _get_ConfigDirectory_metadata = { "offset" : _get_ConfigDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ConfigDirectory(self) -> str:
        """The directory path of the user configuration area."""
        return self._intf.get_property(IAgAsDensityModelResultRegister._metadata, IAgAsDensityModelResultRegister._get_ConfigDirectory_metadata)

    _SetParameterizationName_metadata = { "offset" : _SetParameterizationName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def SetParameterizationName(self, name:str) -> None:
        """Registers a name for the estimation parameterization. This name is used during the selection of estimation parameters and to validate files of pre-computed corrections."""
        return self._intf.invoke(IAgAsDensityModelResultRegister._metadata, IAgAsDensityModelResultRegister._SetParameterizationName_metadata, name)

    _property_names[InstallDirectory] = "InstallDirectory"
    _property_names[ConfigDirectory] = "ConfigDirectory"


agcls.AgClassCatalog.add_catalog_entry((4848536961784746060, 14567845987973064626), IAgAsDensityModelResultRegister)
agcls.AgTypeNameMap["IAgAsDensityModelResultRegister"] = IAgAsDensityModelResultRegister

class IAgAsDensityModelResult(object):
    """DensityModel plugin interface used to get settings during numerical integration events. Supports the IAgEpoch interface."""

    _num_methods = 30
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _get_Mu_method_offset = 2
    _get_CbName_method_offset = 3
    _DayCount_method_offset = 4
    _DayCount_Array_method_offset = 5
    _get_Altitude_method_offset = 6
    _LatLonAlt_method_offset = 7
    _LatLonAlt_Array_method_offset = 8
    _PosVel_method_offset = 9
    _PosVel_Array_method_offset = 10
    _SunPosition_method_offset = 11
    _SunPosition_Array_method_offset = 12
    _ParameterValue_method_offset = 13
    _get_ParameterValue_Array_method_offset = 14
    _GetInputValue_method_offset = 15
    _SetParameterOutputValue_method_offset = 16
    _CurrentAtmFlux_method_offset = 17
    _CurrentAtmFlux_Array_method_offset = 18
    _AtmFlux_method_offset = 19
    _AtmFlux_Array_method_offset = 20
    _AtmFluxLags_method_offset = 21
    _AtmFluxLags_Array_method_offset = 22
    _CurrentAugmentedAtmFlux_method_offset = 23
    _CurrentAugmentedAtmFlux_Array_method_offset = 24
    _AugmentedAtmFlux_method_offset = 25
    _AugmentedAtmFlux_Array_method_offset = 26
    _get_ComputeParameterPartials_method_offset = 27
    _DateElements_method_offset = 28
    _DateElements_Array_method_offset = 29
    _DateString_method_offset = 30
    _metadata = {
        "iid_data" : (5015600965411305757, 7165381929689609400),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDensityModelResult."""
        initialize_from_source_object(self, sourceObject, IAgAsDensityModelResult)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDensityModelResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDensityModelResult, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._Trace_metadata, numCalls)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._get_Mu_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._get_CbName_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._DayCount_Array_metadata, scale, OutArg())

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current detic altitude in meters."""
        return self._intf.get_property(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._get_Altitude_metadata)

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude (radians), detic longitude (radians), and altitude(meters) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._LatLonAlt_Array_metadata, OutArg())

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) returned as an array representing X, Y, Z, VX, VY, VZ. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._PosVel_Array_metadata, frame, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun in meters wrt the current satellite position, in the requested frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _ParameterValue_metadata = { "offset" : _ParameterValue_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.DOUBLE_arg,) }
    def ParameterValue(self, index:int) -> float:
        """Parameter value for a registered parameter with indicated index.  Uses internal units."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._ParameterValue_metadata, index, OutArg())

    _get_ParameterValue_Array_metadata = { "offset" : _get_ParameterValue_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def ParameterValue_Array(self) -> list:
        """Parameter values for all registered parameters, returned in index order.  Uses internal units."""
        return self._intf.get_property(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._get_ParameterValue_Array_metadata)

    _GetInputValue_metadata = { "offset" : _GetInputValue_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def GetInputValue(self, index:int) -> float:
        """Gets the value of an input to the plugin in internal units."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._GetInputValue_metadata, index, OutArg())

    _SetParameterOutputValue_metadata = { "offset" : _SetParameterOutputValue_method_offset,
            "arg_types" : (agcom.INT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def SetParameterOutputValue(self, index:int, val:float) -> None:
        """Sets the value of a parameter output of the plugin in internal units."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._SetParameterOutputValue_metadata, index, val)

    _CurrentAtmFlux_Array_metadata = { "offset" : _CurrentAtmFlux_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def CurrentAtmFlux_Array(self) -> list:
        """Flux values used by the density model, evaluated at the current time using model supplied time lags, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._CurrentAtmFlux_Array_metadata, OutArg())

    _AtmFlux_Array_metadata = { "offset" : _AtmFlux_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def AtmFlux_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Flux values used by density models, evaluated at the requested time, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp. No time lags are incorporated."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._AtmFlux_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _AtmFluxLags_Array_metadata = { "offset" : _AtmFluxLags_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def AtmFluxLags_Array(self) -> list:
        """The lag times (in secs), relative to the current epoch, at which the density flux values are evaluated, returned as an array of F10.7 lag, geo flux lag."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._AtmFluxLags_Array_metadata, OutArg())

    _CurrentAugmentedAtmFlux_Array_metadata = { "offset" : _CurrentAugmentedAtmFlux_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def CurrentAugmentedAtmFlux_Array(self) -> list:
        """Augmented flux values used by the density model, evaluated at the current time using model supplied time lags, returned as an array representing M10.7, AvgM10.7, S10.7, AvgS10.7, Y10.7, AvgY10.7, DstDTc."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._CurrentAugmentedAtmFlux_Array_metadata, OutArg())

    _AugmentedAtmFlux_Array_metadata = { "offset" : _AugmentedAtmFlux_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def AugmentedAtmFlux_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Augmented flux values used by density models, evaluated at the requested time, returned as an array representing F10.7, AvgF10.7, M10.7, AvgM10.7, S10.7, AvgS10.7, Y10.7, AvgY10.7, DstDTc. No time lags are incorporated."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._AugmentedAtmFlux_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _get_ComputeParameterPartials_metadata = { "offset" : _get_ComputeParameterPartials_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def ComputeParameterPartials(self) -> bool:
        """Indicates if registered density model parameters are being estimated. If the returned value is false, parameter partials need not be computed"""
        return self._intf.get_property(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._get_ComputeParameterPartials_metadata)

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsDensityModelResult._metadata, IAgAsDensityModelResult._DateString_metadata, dateAbbrv, OutArg())

    _property_names[Mu] = "Mu"
    _property_names[CbName] = "CbName"
    _property_names[Altitude] = "Altitude"
    _property_names[ParameterValue_Array] = "ParameterValue_Array"
    _property_names[ComputeParameterPartials] = "ComputeParameterPartials"


agcls.AgClassCatalog.add_catalog_entry((5015600965411305757, 7165381929689609400), IAgAsDensityModelResult)
agcls.AgTypeNameMap["IAgAsDensityModelResult"] = IAgAsDensityModelResult

class IAgAsDensityModelResultEval(object):
    """DensityModel plugin interface used to get/set settings during evaluation. Supports the IAgEpoch interface."""

    _num_methods = 38
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _get_Mu_method_offset = 2
    _get_CbName_method_offset = 3
    _DayCount_method_offset = 4
    _DayCount_Array_method_offset = 5
    _Date_method_offset = 6
    _Date_Array_method_offset = 7
    _get_TotalMass_method_offset = 8
    _get_Altitude_method_offset = 9
    _LatLonAlt_method_offset = 10
    _LatLonAlt_Array_method_offset = 11
    _PosVel_method_offset = 12
    _PosVel_Array_method_offset = 13
    _SunPosition_method_offset = 14
    _SunPosition_Array_method_offset = 15
    _ParameterValue_method_offset = 16
    _get_ParameterValue_Array_method_offset = 17
    _SetDensity_method_offset = 18
    _SetTemperature_method_offset = 19
    _SetPressure_method_offset = 20
    _GetInputValue_method_offset = 21
    _SetParameterOutputValue_method_offset = 22
    _CurrentAtmFlux_method_offset = 23
    _CurrentAtmFlux_Array_method_offset = 24
    _AtmFlux_method_offset = 25
    _AtmFlux_Array_method_offset = 26
    _AtmFluxLags_method_offset = 27
    _AtmFluxLags_Array_method_offset = 28
    _CurrentAugmentedAtmFlux_method_offset = 29
    _CurrentAugmentedAtmFlux_Array_method_offset = 30
    _AugmentedAtmFlux_method_offset = 31
    _AugmentedAtmFlux_Array_method_offset = 32
    _SetParameterPartialDerivative_method_offset = 33
    _get_ComputeParameterPartials_method_offset = 34
    _ConstAugAtmFlux_method_offset = 35
    _DateElements_method_offset = 36
    _DateElements_Array_method_offset = 37
    _DateString_method_offset = 38
    _metadata = {
        "iid_data" : (5452835633417316440, 3188324522980135305),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDensityModelResultEval."""
        initialize_from_source_object(self, sourceObject, IAgAsDensityModelResultEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDensityModelResultEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDensityModelResultEval, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._Trace_metadata, numCalls)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant in meters^3/second^2."""
        return self._intf.get_property(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._get_Mu_metadata)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._get_CbName_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._DayCount_Array_metadata, scale, OutArg())

    _Date_Array_metadata = { "offset" : _Date_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def Date_Array(self, scale:"AgEUtTimeScale") -> list:
        """This method is deprecated. Use DateElements_Array instead. Current epoch in requested time scale expressed in date format returned as an array representing year [yyyy], dayOfYear, month [0-11], hour [0-23], minute [0-59], seconds."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._Date_Array_metadata, scale, OutArg())

    _get_TotalMass_metadata = { "offset" : _get_TotalMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TotalMass(self) -> float:
        """This property is deprecated. Total Mass of the satellite in kilograms."""
        return self._intf.get_property(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._get_TotalMass_metadata)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current detic altitude in meters."""
        return self._intf.get_property(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._get_Altitude_metadata)

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude (radians), detic longitude (radians), and altitude(meters) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._LatLonAlt_Array_metadata, OutArg())

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position (meters) and velocity (meters/second) returned as an array representing X, Y, Z, VX, VY, VZ. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._PosVel_Array_metadata, frame, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun in meters wrt the current satellite position, in the requested frame, computed in the requested manner, returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _ParameterValue_metadata = { "offset" : _ParameterValue_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.DOUBLE_arg,) }
    def ParameterValue(self, index:int) -> float:
        """Parameter value for a registered parameter with indicated index.  Uses internal units."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._ParameterValue_metadata, index, OutArg())

    _get_ParameterValue_Array_metadata = { "offset" : _get_ParameterValue_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def ParameterValue_Array(self) -> list:
        """Parameter values for all registered parameters, returned in index order.  Uses internal units."""
        return self._intf.get_property(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._get_ParameterValue_Array_metadata)

    _SetDensity_metadata = { "offset" : _SetDensity_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetDensity(self, density:float) -> None:
        """Sets the Density for the model"""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._SetDensity_metadata, density)

    _SetTemperature_metadata = { "offset" : _SetTemperature_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetTemperature(self, temperature:float) -> None:
        """Sets the Temperature for the model in Kelvin"""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._SetTemperature_metadata, temperature)

    _SetPressure_metadata = { "offset" : _SetPressure_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetPressure(self, pressure:float) -> None:
        """Sets the Pressure for the model"""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._SetPressure_metadata, pressure)

    _GetInputValue_metadata = { "offset" : _GetInputValue_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def GetInputValue(self, index:int) -> float:
        """Gets the value of an input to the plugin in internal units."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._GetInputValue_metadata, index, OutArg())

    _SetParameterOutputValue_metadata = { "offset" : _SetParameterOutputValue_method_offset,
            "arg_types" : (agcom.INT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.DOUBLE_arg,) }
    def SetParameterOutputValue(self, index:int, val:float) -> None:
        """Sets the value of a parameter output of the plugin in internal units."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._SetParameterOutputValue_metadata, index, val)

    _CurrentAtmFlux_Array_metadata = { "offset" : _CurrentAtmFlux_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def CurrentAtmFlux_Array(self) -> list:
        """Flux values used by the density model, evaluated at the current time using model supplied time lags, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._CurrentAtmFlux_Array_metadata, OutArg())

    _AtmFlux_Array_metadata = { "offset" : _AtmFlux_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def AtmFlux_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Flux values used by density models, evaluated at the requested time, returned as an array representing F10.7, AvgF10.7, Ap, DailyAp, Kp, DailyKp. No time lags are incorporated."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._AtmFlux_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _AtmFluxLags_Array_metadata = { "offset" : _AtmFluxLags_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def AtmFluxLags_Array(self) -> list:
        """The lag times (in secs), relative to the current epoch, at which the density flux values are evaluated, returned as an array of F10.7 lag, geo flux lag."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._AtmFluxLags_Array_metadata, OutArg())

    _CurrentAugmentedAtmFlux_Array_metadata = { "offset" : _CurrentAugmentedAtmFlux_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def CurrentAugmentedAtmFlux_Array(self) -> list:
        """Augmented flux values used by the density model, evaluated at the current time using model supplied time lags, returned as an array representing M10.7, AvgM10.7, S10.7, AvgS10.7, Y10.7, AvgY10.7, DstDTc."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._CurrentAugmentedAtmFlux_Array_metadata, OutArg())

    _AugmentedAtmFlux_Array_metadata = { "offset" : _AugmentedAtmFlux_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LONG_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def AugmentedAtmFlux_Array(self, scale:"AgEUtTimeScale", wholeDays:int, secsIntoDay:float) -> list:
        """Augmented flux values used by density models, evaluated at the requested time, returned as an array representing F10.7, AvgF10.7, M10.7, AvgM10.7, S10.7, AvgS10.7, Y10.7, AvgY10.7, DstDTc. No time lags are incorporated."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._AugmentedAtmFlux_Array_metadata, scale, wholeDays, secsIntoDay, OutArg())

    _SetParameterPartialDerivative_metadata = { "offset" : _SetParameterPartialDerivative_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE,),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.DOUBLE_arg,) }
    def SetParameterPartialDerivative(self, index:int, partialDeriv:float) -> None:
        """Set value of partial derivative of density with respect to parameter value for a registered parameter with indicated index. Required for parameter estimation. Uses internal units."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._SetParameterPartialDerivative_metadata, index, partialDeriv)

    _get_ComputeParameterPartials_metadata = { "offset" : _get_ComputeParameterPartials_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def ComputeParameterPartials(self) -> bool:
        """Indicates if registered density model parameters are being estimated. If the returned value is false, parameter partials need not be computed"""
        return self._intf.get_property(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._get_ComputeParameterPartials_metadata)

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAsDensityModelResultEval._metadata, IAgAsDensityModelResultEval._DateString_metadata, dateAbbrv, OutArg())

    _property_names[Mu] = "Mu"
    _property_names[CbName] = "CbName"
    _property_names[TotalMass] = "TotalMass"
    _property_names[Altitude] = "Altitude"
    _property_names[ParameterValue_Array] = "ParameterValue_Array"
    _property_names[ComputeParameterPartials] = "ComputeParameterPartials"


agcls.AgClassCatalog.add_catalog_entry((5452835633417316440, 3188324522980135305), IAgAsDensityModelResultEval)
agcls.AgTypeNameMap["IAgAsDensityModelResultEval"] = IAgAsDensityModelResultEval

class IAgAsDensityModelPluginAtmFluxLagsConfig(object):
    """DensityModel plugin interface used to get/set AtmFluxLag values"""

    _num_methods = 20
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _set_F10p7Lag_method_offset = 1
    _get_F10p7Lag_method_offset = 2
    _set_F10p7MeanLag_method_offset = 3
    _get_F10p7MeanLag_method_offset = 4
    _set_GeoFluxLag_method_offset = 5
    _get_GeoFluxLag_method_offset = 6
    _set_M10p7Lag_method_offset = 7
    _get_M10p7Lag_method_offset = 8
    _set_M10p7MeanLag_method_offset = 9
    _get_M10p7MeanLag_method_offset = 10
    _set_S10p7Lag_method_offset = 11
    _get_S10p7Lag_method_offset = 12
    _set_S10p7MeanLag_method_offset = 13
    _get_S10p7MeanLag_method_offset = 14
    _set_Y10p7Lag_method_offset = 15
    _get_Y10p7Lag_method_offset = 16
    _set_Y10p7MeanLag_method_offset = 17
    _get_Y10p7MeanLag_method_offset = 18
    _set_DstDTcLag_method_offset = 19
    _get_DstDTcLag_method_offset = 20
    _metadata = {
        "iid_data" : (5061211996893124558, 10135002474165956739),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDensityModelPluginAtmFluxLagsConfig."""
        initialize_from_source_object(self, sourceObject, IAgAsDensityModelPluginAtmFluxLagsConfig)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDensityModelPluginAtmFluxLagsConfig)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDensityModelPluginAtmFluxLagsConfig, None)
    
    _get_F10p7Lag_metadata = { "offset" : _get_F10p7Lag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def F10p7Lag(self) -> float:
        """Gets or sets the F10p7Lag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_F10p7Lag_metadata)

    _set_F10p7Lag_metadata = { "offset" : _set_F10p7Lag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @F10p7Lag.setter
    def F10p7Lag(self, val:float) -> None:
        """Gets or sets the F10p7Lag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_F10p7Lag_metadata, val)

    _get_F10p7MeanLag_metadata = { "offset" : _get_F10p7MeanLag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def F10p7MeanLag(self) -> float:
        """Gets or sets the F10p7MeanLag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_F10p7MeanLag_metadata)

    _set_F10p7MeanLag_metadata = { "offset" : _set_F10p7MeanLag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @F10p7MeanLag.setter
    def F10p7MeanLag(self, val:float) -> None:
        """Gets or sets the F10p7MeanLag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_F10p7MeanLag_metadata, val)

    _get_GeoFluxLag_metadata = { "offset" : _get_GeoFluxLag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def GeoFluxLag(self) -> float:
        """Gets or sets the GeoFluxLag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_GeoFluxLag_metadata)

    _set_GeoFluxLag_metadata = { "offset" : _set_GeoFluxLag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @GeoFluxLag.setter
    def GeoFluxLag(self, val:float) -> None:
        """Gets or sets the GeoFluxLag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_GeoFluxLag_metadata, val)

    _get_M10p7Lag_metadata = { "offset" : _get_M10p7Lag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def M10p7Lag(self) -> float:
        """Gets or sets the M10p7Lag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_M10p7Lag_metadata)

    _set_M10p7Lag_metadata = { "offset" : _set_M10p7Lag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @M10p7Lag.setter
    def M10p7Lag(self, val:float) -> None:
        """Gets or sets the M10p7Lag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_M10p7Lag_metadata, val)

    _get_M10p7MeanLag_metadata = { "offset" : _get_M10p7MeanLag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def M10p7MeanLag(self) -> float:
        """Gets or sets the M10p7MeanLag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_M10p7MeanLag_metadata)

    _set_M10p7MeanLag_metadata = { "offset" : _set_M10p7MeanLag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @M10p7MeanLag.setter
    def M10p7MeanLag(self, val:float) -> None:
        """Gets or sets the M10p7MeanLag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_M10p7MeanLag_metadata, val)

    _get_S10p7Lag_metadata = { "offset" : _get_S10p7Lag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def S10p7Lag(self) -> float:
        """Gets or sets the S10p7Lag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_S10p7Lag_metadata)

    _set_S10p7Lag_metadata = { "offset" : _set_S10p7Lag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @S10p7Lag.setter
    def S10p7Lag(self, val:float) -> None:
        """Gets or sets the S10p7Lag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_S10p7Lag_metadata, val)

    _get_S10p7MeanLag_metadata = { "offset" : _get_S10p7MeanLag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def S10p7MeanLag(self) -> float:
        """Gets or sets the S10p7MeanLag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_S10p7MeanLag_metadata)

    _set_S10p7MeanLag_metadata = { "offset" : _set_S10p7MeanLag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @S10p7MeanLag.setter
    def S10p7MeanLag(self, val:float) -> None:
        """Gets or sets the S10p7MeanLag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_S10p7MeanLag_metadata, val)

    _get_Y10p7Lag_metadata = { "offset" : _get_Y10p7Lag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Y10p7Lag(self) -> float:
        """Gets or sets the Y10p7Lag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_Y10p7Lag_metadata)

    _set_Y10p7Lag_metadata = { "offset" : _set_Y10p7Lag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Y10p7Lag.setter
    def Y10p7Lag(self, val:float) -> None:
        """Gets or sets the Y10p7Lag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_Y10p7Lag_metadata, val)

    _get_Y10p7MeanLag_metadata = { "offset" : _get_Y10p7MeanLag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Y10p7MeanLag(self) -> float:
        """Gets or sets the Y10p7MeanLag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_Y10p7MeanLag_metadata)

    _set_Y10p7MeanLag_metadata = { "offset" : _set_Y10p7MeanLag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Y10p7MeanLag.setter
    def Y10p7MeanLag(self, val:float) -> None:
        """Gets or sets the Y10p7MeanLag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_Y10p7MeanLag_metadata, val)

    _get_DstDTcLag_metadata = { "offset" : _get_DstDTcLag_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DstDTcLag(self) -> float:
        """Gets or sets the DstDTcLag"""
        return self._intf.get_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._get_DstDTcLag_metadata)

    _set_DstDTcLag_metadata = { "offset" : _set_DstDTcLag_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @DstDTcLag.setter
    def DstDTcLag(self, val:float) -> None:
        """Gets or sets the DstDTcLag"""
        return self._intf.set_property(IAgAsDensityModelPluginAtmFluxLagsConfig._metadata, IAgAsDensityModelPluginAtmFluxLagsConfig._set_DstDTcLag_metadata, val)

    _property_names[F10p7Lag] = "F10p7Lag"
    _property_names[F10p7MeanLag] = "F10p7MeanLag"
    _property_names[GeoFluxLag] = "GeoFluxLag"
    _property_names[M10p7Lag] = "M10p7Lag"
    _property_names[M10p7MeanLag] = "M10p7MeanLag"
    _property_names[S10p7Lag] = "S10p7Lag"
    _property_names[S10p7MeanLag] = "S10p7MeanLag"
    _property_names[Y10p7Lag] = "Y10p7Lag"
    _property_names[Y10p7MeanLag] = "Y10p7MeanLag"
    _property_names[DstDTcLag] = "DstDTcLag"


agcls.AgClassCatalog.add_catalog_entry((5061211996893124558, 10135002474165956739), IAgAsDensityModelPluginAtmFluxLagsConfig)
agcls.AgTypeNameMap["IAgAsDensityModelPluginAtmFluxLagsConfig"] = IAgAsDensityModelPluginAtmFluxLagsConfig

class IAgAsDensityModelPluginAtmFluxLags(object):
    """Density Model plugin interface that handles the getting/setting of AtmFluxLags"""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _OverrideAtmFluxLags_method_offset = 1
    _metadata = {
        "iid_data" : (5687744966566579551, 7912874074880847234),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDensityModelPluginAtmFluxLags."""
        initialize_from_source_object(self, sourceObject, IAgAsDensityModelPluginAtmFluxLags)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDensityModelPluginAtmFluxLags)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDensityModelPluginAtmFluxLags, None)
    
    _OverrideAtmFluxLags_metadata = { "offset" : _OverrideAtmFluxLags_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgAsDensityModelPluginAtmFluxLagsConfig"),) }
    def OverrideAtmFluxLags(self, fluxLags:"IAgAsDensityModelPluginAtmFluxLagsConfig") -> None:
        """The lag times (in secs), relative to the current epoch, at which the density flux values are evaluated."""
        return self._intf.invoke(IAgAsDensityModelPluginAtmFluxLags._metadata, IAgAsDensityModelPluginAtmFluxLags._OverrideAtmFluxLags_metadata, fluxLags)


agcls.AgClassCatalog.add_catalog_entry((5687744966566579551, 7912874074880847234), IAgAsDensityModelPluginAtmFluxLags)
agcls.AgTypeNameMap["IAgAsDensityModelPluginAtmFluxLags"] = IAgAsDensityModelPluginAtmFluxLags

class IAgAsDensityModelPluginSample(object):
    """Density model sample plugin"""

    _num_methods = 4
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ReportFrequency_method_offset = 1
    _set_ReportFrequency_method_offset = 2
    _get_DebugMode_method_offset = 3
    _set_DebugMode_method_offset = 4
    _metadata = {
        "iid_data" : (4751982735288084489, 15864309145577692288),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAsDensityModelPluginSample."""
        initialize_from_source_object(self, sourceObject, IAgAsDensityModelPluginSample)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAsDensityModelPluginSample)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAsDensityModelPluginSample, None)
    
    _get_ReportFrequency_metadata = { "offset" : _get_ReportFrequency_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ReportFrequency(self) -> int:
        """Frequency of output of debug messages, in number of integration steps."""
        return self._intf.get_property(IAgAsDensityModelPluginSample._metadata, IAgAsDensityModelPluginSample._get_ReportFrequency_metadata)

    _set_ReportFrequency_metadata = { "offset" : _set_ReportFrequency_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @ReportFrequency.setter
    def ReportFrequency(self, newFreq:int) -> None:
        """Frequency of output of debug messages, in number of integration steps."""
        return self._intf.set_property(IAgAsDensityModelPluginSample._metadata, IAgAsDensityModelPluginSample._set_ReportFrequency_metadata, newFreq)

    _get_DebugMode_metadata = { "offset" : _get_DebugMode_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def DebugMode(self) -> bool:
        """Flag to turn debug mode on/off. When on, messages are reported to message viewer at the ReportFrequency."""
        return self._intf.get_property(IAgAsDensityModelPluginSample._metadata, IAgAsDensityModelPluginSample._get_DebugMode_metadata)

    _set_DebugMode_metadata = { "offset" : _set_DebugMode_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @DebugMode.setter
    def DebugMode(self, newDebugMode:bool) -> None:
        """Flag to turn debug mode on/off. When on, messages are reported to message viewer at the ReportFrequency."""
        return self._intf.set_property(IAgAsDensityModelPluginSample._metadata, IAgAsDensityModelPluginSample._set_DebugMode_metadata, newDebugMode)

    _property_names[ReportFrequency] = "ReportFrequency"
    _property_names[DebugMode] = "DebugMode"


agcls.AgClassCatalog.add_catalog_entry((4751982735288084489, 15864309145577692288), IAgAsDensityModelPluginSample)
agcls.AgTypeNameMap["IAgAsDensityModelPluginSample"] = IAgAsDensityModelPluginSample


class IAgAsHpopPlugin(object):
    """
    HPOP plugin engine interface whose methods are called at certain events in the propagation process. A method returning false indicates an error.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered when the plugin is initialized to allow for any additional needed initialization. Must return true to turn on use of plugin."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is freed from use to allow for any additional cleanup."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")

    def PrePropagate(self, result:"IAgAsHpopPluginResult") -> bool:
        """Triggered just before propagation starts. Use the input interface to access force model settings. Set initial values for parameters and variables in this method."""
        raise STKPluginMethodNotImplementedError("PrePropagate was not implemented.")

    def PostPropagate(self, result:"IAgAsHpopPluginResult") -> bool:
        """Triggered just after the last propagation step has been taken. Use the input interface to access force model settings."""
        raise STKPluginMethodNotImplementedError("PostPropagate was not implemented.")

    def PreNextStep(self, result:"IAgAsHpopPluginResult") -> bool:
        """Triggered just before the next propagation step is attempted. Use the input interface to access force model settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("PreNextStep was not implemented.")

    def Evaluate(self, resultEval:"IAgAsHpopPluginResultEval") -> bool:
        """Triggered on every force model evaluation during the propagation of a step. Use the input interface to access force model settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")

    def PostEvaluate(self, resultPostEval:"IAgAsHpopPluginResultPostEval") -> bool:
        """Triggered on every force model evaluation during the propagation of a step, but after the individual force model components have been computed. The components can be obtained from the input interface. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("PostEvaluate was not implemented.")

    def Name(self) -> str:
        """Triggered after initialization to set the name of the plugin used in messages."""
        raise STKPluginMethodNotImplementedError("Name was not implemented.")


class IAgAsLightReflectionPlugin(object):
    """
    This interface is deprecated. Use IAgAsLightReflectionPlugin2 instead. Used to set reflectance vector (and optionally its partial derivs) used in computation of the srp force. A method returning false indicates an error.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Register(self, result:"IAgAsLightReflectionResultRegister") -> None:
        """Triggered before computation starts, when configuration settings are sought. Used to used to register parameters that may be estimated."""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered when the plugin is initialized to allow for any additional needed initialization. Must return true to turn on use of plugin."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is freed from use to allow for any additional cleanup."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")

    def PreCompute(self, result:"IAgAsLightReflectionResult") -> bool:
        """Triggered just before the computation starts. Use the input interface to access settings."""
        raise STKPluginMethodNotImplementedError("PreCompute was not implemented.")

    def PostCompute(self, result:"IAgAsLightReflectionResult") -> bool:
        """Triggered after the last evaluation before the plugin calls Free(). Use the input interface to access settings."""
        raise STKPluginMethodNotImplementedError("PostCompute was not implemented.")

    def Evaluate(self, resultEval:"IAgAsLightReflectionResultEval") -> bool:
        """Triggered on every force model evaluation during the propagation of a step. Use the input interface to access force model settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")


class IAgAsLightReflectionPlugin2(IAgAsLightReflectionPlugin):
    """
    Light Reflection plugin interface. Inherits from IAgAsLightReflectionPlugin. Used to set reflectance vector (and optionally its partial derivs) used in computation of the srp force. A method returning false indicates an error.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def PreNextStep(self, result:"IAgAsLightReflectionResult") -> bool:
        """Triggered just before the next propagation step is attempted. Use the input interface to access settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("PreNextStep was not implemented.")


class IAgAsDragModelPlugin(object):
    """
    This interface is deprecated. Use IAgAsDragModelPlugin2 instead. Used to set reflectance vector (and optionally its partial derivs) used in computation of the drag/lift/side force. A method returning false indicates an error.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Register(self, result:"IAgAsDragModelResultRegister") -> None:
        """Triggered before computation starts, when configuration settings are sought. Used to used to register parameters that may be estimated."""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered when the plugin is initialized to allow for any additional needed initialization. Must return true to turn on use of plugin."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is freed from use to allow for any additional cleanup."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")

    def PreCompute(self, result:"IAgAsDragModelResult") -> bool:
        """Triggered just before the computation starts. Use the input interface to access settings."""
        raise STKPluginMethodNotImplementedError("PreCompute was not implemented.")

    def PostCompute(self, result:"IAgAsDragModelResult") -> bool:
        """Triggered after the last evaluation before the plugin calls Free(). Use the input interface to access settings."""
        raise STKPluginMethodNotImplementedError("PostCompute was not implemented.")

    def Evaluate(self, resultEval:"IAgAsDragModelResultEval") -> bool:
        """Triggered on every force model evaluation during the propagation of a step. Use the input interface to access force model settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")


class IAgAsDragModelPlugin2(IAgAsDragModelPlugin):
    """
    Drag model plugin interface. Inherits from IAgAsDragModelPlugin. Used to set reflectance vector (and optionally its partial derivs) used in computation of the drag/lift/side force. A method returning false indicates an error.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def PreNextStep(self, result:"IAgAsDragModelResult") -> bool:
        """Triggered just before the next propagation step is attempted. Use the input interface to access settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("PreNextStep was not implemented.")


class IAgAsEOMFuncPlugin(object):
    """
    HPOP plugin engine interface for user-defined equations of motion.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered when the plugin is initialized to allow for any additional needed initialization. Must return true to turn on use of plugin."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is freed from use to allow for any additional cleanup."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")

    def Register(self, pRegisterHandler:"IAgAsEOMFuncPluginRegisterHandler") -> bool:
        """Method to register the plugin's inputs, outputs, and events"""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def SetIndices(self, pSetIndicesHandler:"IAgAsEOMFuncPluginSetIndicesHandler") -> bool:
        """Gives the plugin the indices into the state vector for its inputs/outputs"""
        raise STKPluginMethodNotImplementedError("SetIndices was not implemented.")

    def Calc(self, eventType:"AgEAsEOMFuncPluginEventTypes", pStateVector:"IAgAsEOMFuncPluginStateVector") -> bool:
        """Calculate method for plugin"""
        raise STKPluginMethodNotImplementedError("Calc was not implemented.")

    def Name(self) -> str:
        """Triggered after initialization to set the name of the plugin used in messages."""
        raise STKPluginMethodNotImplementedError("Name was not implemented.")


class IAgAsDensityModelPlugin(object):
    """
    Density model plugin interface. A method returning false indicates an error.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Register(self, result:"IAgAsDensityModelResultRegister") -> None:
        """Triggered before computation starts, when configuration settings are sought. Used to used to register parameters that may be estimated."""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered when the plugin is initialized to allow for any additional needed initialization. Must return true to turn on use of plugin."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is freed from use to allow for any additional cleanup."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")

    def Evaluate(self, resultEval:"IAgAsDensityModelResultEval") -> bool:
        """Triggered on every force model evaluation during the propagation of a step. Use the input interface to access force model settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")

    def CentralBody(self) -> str:
        """Triggered on every density plugin before evaluation to determine the central body for which the atmosphere model applies."""
        raise STKPluginMethodNotImplementedError("CentralBody was not implemented.")

    def ComputesTemperature(self) -> bool:
        """Triggered on every density plugin before evaluation to check if the plugin computes temperature."""
        raise STKPluginMethodNotImplementedError("ComputesTemperature was not implemented.")

    def ComputesPressure(self) -> bool:
        """Triggered on every density plugin before evaluation to check if the plugin computes pressure."""
        raise STKPluginMethodNotImplementedError("ComputesPressure was not implemented.")

    def UsesAugmentedSpaceWeather(self) -> bool:
        """Triggered on every density plugin before evaluation to check if the plugin uses augmented space weather data such as M10, S10, Y10 and DstDTc."""
        raise STKPluginMethodNotImplementedError("UsesAugmentedSpaceWeather was not implemented.")

    def GetLowestValidAltitude(self) -> float:
        """The lowest valid altitude for input to atmospheric density model in meters."""
        raise STKPluginMethodNotImplementedError("GetLowestValidAltitude was not implemented.")


class IAgAsDensityModelPluginExtended(IAgAsDensityModelPlugin):
    """
    Extends the IAgAsDensityModelPlugin interface for use with numerical integration events.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def PreCompute(self, result:"IAgAsDensityModelResult") -> bool:
        """Triggered just before numerical integration starts. Use the input interface to access settings."""
        raise STKPluginMethodNotImplementedError("PreCompute was not implemented.")

    def PreNextStep(self, result:"IAgAsDensityModelResult") -> bool:
        """Triggered just before the next propagation step is attempted during numerical integration. Use the input interface to access settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("PreNextStep was not implemented.")

    def PostCompute(self, result:"IAgAsDensityModelResult") -> bool:
        """Triggered after the last evaluation of numerical integration before the plugin calls Free(). Use the input interface to access settings."""
        raise STKPluginMethodNotImplementedError("PostCompute was not implemented.")




class AgAsHpopPluginResult(IAgAsHpopPluginResult, SupportsDeleteCallback):
    """HPOP plugin class used to get/set force model settings"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsHpopPluginResult."""
        SupportsDeleteCallback.__init__(self)
        IAgAsHpopPluginResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsHpopPluginResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsHpopPluginResult, [IAgAsHpopPluginResult])

agcls.AgClassCatalog.add_catalog_entry((4995595556546760219, 16606146915998022046), AgAsHpopPluginResult)
agcls.AgTypeNameMap["AgAsHpopPluginResult"] = AgAsHpopPluginResult

class AgAsHpopPluginResultEval(IAgAsHpopPluginResultEval, SupportsDeleteCallback):
    """HPOP plugin class used to get/set force model settings during the propagation of a step"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsHpopPluginResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgAsHpopPluginResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsHpopPluginResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsHpopPluginResultEval, [IAgAsHpopPluginResultEval])

agcls.AgClassCatalog.add_catalog_entry((5757514008809973485, 7308816953691277246), AgAsHpopPluginResultEval)
agcls.AgTypeNameMap["AgAsHpopPluginResultEval"] = AgAsHpopPluginResultEval

class AgAsHpopPluginResultPostEval(IAgAsHpopPluginResultPostEval, SupportsDeleteCallback):
    """HPOP plugin class used to get/set force model settings during the propagation of a step"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsHpopPluginResultPostEval."""
        SupportsDeleteCallback.__init__(self)
        IAgAsHpopPluginResultPostEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsHpopPluginResultPostEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsHpopPluginResultPostEval, [IAgAsHpopPluginResultPostEval])

agcls.AgClassCatalog.add_catalog_entry((4858175998739013279, 8181960101710916750), AgAsHpopPluginResultPostEval)
agcls.AgTypeNameMap["AgAsHpopPluginResultPostEval"] = AgAsHpopPluginResultPostEval

class AgAsHpopPluginSampleEngine(IAgAsHpopPluginSampleEngine, IAgAsHpopPlugin, IAgUtPluginConfig, SupportsDeleteCallback):
    """Sample HPOP Plugin Class"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsHpopPluginSampleEngine."""
        SupportsDeleteCallback.__init__(self)
        IAgAsHpopPluginSampleEngine.__init__(self, sourceObject)
        IAgAsHpopPlugin.__init__(self, sourceObject)
        IAgUtPluginConfig.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsHpopPluginSampleEngine._private_init(self, intf)
        IAgAsHpopPlugin._private_init(self, intf)
        IAgUtPluginConfig._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsHpopPluginSampleEngine, [IAgAsHpopPluginSampleEngine, IAgAsHpopPlugin, IAgUtPluginConfig])

agcls.AgClassCatalog.add_catalog_entry((4900734076800862643, 1074278451643463824), AgAsHpopPluginSampleEngine)
agcls.AgTypeNameMap["AgAsHpopPluginSampleEngine"] = AgAsHpopPluginSampleEngine

class AgAsLightReflectionResultRegister(IAgAsLightReflectionResultRegister, SupportsDeleteCallback):
    """LightReflection plugin interface used to register parameters that may be estimated."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsLightReflectionResultRegister."""
        SupportsDeleteCallback.__init__(self)
        IAgAsLightReflectionResultRegister.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsLightReflectionResultRegister._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsLightReflectionResultRegister, [IAgAsLightReflectionResultRegister])

agcls.AgClassCatalog.add_catalog_entry((5154556040552975132, 17061489486855678354), AgAsLightReflectionResultRegister)
agcls.AgTypeNameMap["AgAsLightReflectionResultRegister"] = AgAsLightReflectionResultRegister

class AgAsLightReflectionResult(IAgAsLightReflectionResult, SupportsDeleteCallback):
    """Light reflection plugin class used to get/set reflection settings"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsLightReflectionResult."""
        SupportsDeleteCallback.__init__(self)
        IAgAsLightReflectionResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsLightReflectionResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsLightReflectionResult, [IAgAsLightReflectionResult])

agcls.AgClassCatalog.add_catalog_entry((5219935541903908631, 17133342233054624421), AgAsLightReflectionResult)
agcls.AgTypeNameMap["AgAsLightReflectionResult"] = AgAsLightReflectionResult

class AgAsLightReflectionResultEval(IAgAsLightReflectionResultEval, SupportsDeleteCallback):
    """Light reflection plugin class used to get/set reflection settings during Evaluation call"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsLightReflectionResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgAsLightReflectionResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsLightReflectionResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsLightReflectionResultEval, [IAgAsLightReflectionResultEval])

agcls.AgClassCatalog.add_catalog_entry((4909293966349450967, 5192906428973881769), AgAsLightReflectionResultEval)
agcls.AgTypeNameMap["AgAsLightReflectionResultEval"] = AgAsLightReflectionResultEval

class AgAsLightReflectionPluginSample(IAgAsLightReflectionPluginSample, IAgAsLightReflectionPlugin2, IAgUtPluginConfig, SupportsDeleteCallback):
    """Sample Light Reflection Plugin Class"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsLightReflectionPluginSample."""
        SupportsDeleteCallback.__init__(self)
        IAgAsLightReflectionPluginSample.__init__(self, sourceObject)
        IAgAsLightReflectionPlugin2.__init__(self, sourceObject)
        IAgUtPluginConfig.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsLightReflectionPluginSample._private_init(self, intf)
        IAgAsLightReflectionPlugin2._private_init(self, intf)
        IAgUtPluginConfig._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsLightReflectionPluginSample, [IAgAsLightReflectionPluginSample, IAgAsLightReflectionPlugin2, IAgUtPluginConfig])

agcls.AgClassCatalog.add_catalog_entry((5698842784711320493, 14248876990296765584), AgAsLightReflectionPluginSample)
agcls.AgTypeNameMap["AgAsLightReflectionPluginSample"] = AgAsLightReflectionPluginSample

class AgAsDragModelResultRegister(IAgAsDragModelResultRegister, SupportsDeleteCallback):
    """DragModel plugin interface used to register parameters that may be estimated."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsDragModelResultRegister."""
        SupportsDeleteCallback.__init__(self)
        IAgAsDragModelResultRegister.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsDragModelResultRegister._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsDragModelResultRegister, [IAgAsDragModelResultRegister])

agcls.AgClassCatalog.add_catalog_entry((5309141249243947870, 18228425322043743890), AgAsDragModelResultRegister)
agcls.AgTypeNameMap["AgAsDragModelResultRegister"] = AgAsDragModelResultRegister

class AgAsDragModelResult(IAgAsDragModelResult, SupportsDeleteCallback):
    """DragModel plugin class used to get/set particle reflection settings"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsDragModelResult."""
        SupportsDeleteCallback.__init__(self)
        IAgAsDragModelResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsDragModelResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsDragModelResult, [IAgAsDragModelResult])

agcls.AgClassCatalog.add_catalog_entry((5322047841968081152, 10427774370389718423), AgAsDragModelResult)
agcls.AgTypeNameMap["AgAsDragModelResult"] = AgAsDragModelResult

class AgAsDragModelResultEval(IAgAsDragModelResultEval, SupportsDeleteCallback):
    """DragModel plugin class used to get/set particle reflection settings during Evaluation call"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsDragModelResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgAsDragModelResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsDragModelResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsDragModelResultEval, [IAgAsDragModelResultEval])

agcls.AgClassCatalog.add_catalog_entry((5740143274085295005, 8934333533071372198), AgAsDragModelResultEval)
agcls.AgTypeNameMap["AgAsDragModelResultEval"] = AgAsDragModelResultEval

class AgAsDragModelPluginSample(IAgAsDragModelPluginSample, IAgAsDragModelPlugin2, IAgUtPluginConfig, SupportsDeleteCallback):
    """Sample DragModel Plugin Class"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsDragModelPluginSample."""
        SupportsDeleteCallback.__init__(self)
        IAgAsDragModelPluginSample.__init__(self, sourceObject)
        IAgAsDragModelPlugin2.__init__(self, sourceObject)
        IAgUtPluginConfig.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsDragModelPluginSample._private_init(self, intf)
        IAgAsDragModelPlugin2._private_init(self, intf)
        IAgUtPluginConfig._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsDragModelPluginSample, [IAgAsDragModelPluginSample, IAgAsDragModelPlugin2, IAgUtPluginConfig])

agcls.AgClassCatalog.add_catalog_entry((5005269310928064485, 18065952597569194891), AgAsDragModelPluginSample)
agcls.AgTypeNameMap["AgAsDragModelPluginSample"] = AgAsDragModelPluginSample

class AgAsDensityModelResultRegister(IAgAsDensityModelResultRegister, SupportsDeleteCallback):
    """DensityModel plugin interface used to register parameters that may be estimated."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsDensityModelResultRegister."""
        SupportsDeleteCallback.__init__(self)
        IAgAsDensityModelResultRegister.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsDensityModelResultRegister._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsDensityModelResultRegister, [IAgAsDensityModelResultRegister])

agcls.AgClassCatalog.add_catalog_entry((4699945601782492552, 7612873973787270278), AgAsDensityModelResultRegister)
agcls.AgTypeNameMap["AgAsDensityModelResultRegister"] = AgAsDensityModelResultRegister

class AgAsDensityModelResult(IAgAsDensityModelResult, SupportsDeleteCallback):
    """DensityModel plugin class used to get settings during numerical integration events."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsDensityModelResult."""
        SupportsDeleteCallback.__init__(self)
        IAgAsDensityModelResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsDensityModelResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsDensityModelResult, [IAgAsDensityModelResult])

agcls.AgClassCatalog.add_catalog_entry((5405386450314959055, 15649578934435131562), AgAsDensityModelResult)
agcls.AgTypeNameMap["AgAsDensityModelResult"] = AgAsDensityModelResult

class AgAsDensityModelResultEval(IAgAsDensityModelResultEval, SupportsDeleteCallback):
    """DensityModel plugin class used to get/set density settings during Evaluation call"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsDensityModelResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgAsDensityModelResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsDensityModelResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsDensityModelResultEval, [IAgAsDensityModelResultEval])

agcls.AgClassCatalog.add_catalog_entry((5585859163529708569, 14394039348317825681), AgAsDensityModelResultEval)
agcls.AgTypeNameMap["AgAsDensityModelResultEval"] = AgAsDensityModelResultEval

class AgAsDensityModelPluginAtmFluxLagsConfig(IAgAsDensityModelPluginAtmFluxLagsConfig, SupportsDeleteCallback):
    """DensityModel plugin class used to get/set AtmFluxLag values"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsDensityModelPluginAtmFluxLagsConfig."""
        SupportsDeleteCallback.__init__(self)
        IAgAsDensityModelPluginAtmFluxLagsConfig.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsDensityModelPluginAtmFluxLagsConfig._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsDensityModelPluginAtmFluxLagsConfig, [IAgAsDensityModelPluginAtmFluxLagsConfig])

agcls.AgClassCatalog.add_catalog_entry((4880636445425286473, 10596265268029772962), AgAsDensityModelPluginAtmFluxLagsConfig)
agcls.AgTypeNameMap["AgAsDensityModelPluginAtmFluxLagsConfig"] = AgAsDensityModelPluginAtmFluxLagsConfig

class AgAsDensityModelPluginSample(IAgAsDensityModelPluginExtended, IAgAsDensityModelPluginSample, IAgAsDensityModelPlugin, IAgUtPluginConfig, SupportsDeleteCallback):
    """Sample DensityModel Plugin Class"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsDensityModelPluginSample."""
        SupportsDeleteCallback.__init__(self)
        IAgAsDensityModelPluginExtended.__init__(self, sourceObject)
        IAgAsDensityModelPluginSample.__init__(self, sourceObject)
        IAgAsDensityModelPlugin.__init__(self, sourceObject)
        IAgUtPluginConfig.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsDensityModelPluginExtended._private_init(self, intf)
        IAgAsDensityModelPluginSample._private_init(self, intf)
        IAgAsDensityModelPlugin._private_init(self, intf)
        IAgUtPluginConfig._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsDensityModelPluginSample, [IAgAsDensityModelPluginExtended, IAgAsDensityModelPluginSample, IAgAsDensityModelPlugin, IAgUtPluginConfig])

agcls.AgClassCatalog.add_catalog_entry((5621786545743726937, 5028601293267674759), AgAsDensityModelPluginSample)
agcls.AgTypeNameMap["AgAsDensityModelPluginSample"] = AgAsDensityModelPluginSample

class AgEOMFuncHPOPPluginResult(IAgAsHpopPluginResult, SupportsDeleteCallback):
    """Plugin class used to get/set propagator settings with EOM Manager"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgEOMFuncHPOPPluginResult."""
        SupportsDeleteCallback.__init__(self)
        IAgAsHpopPluginResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsHpopPluginResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgEOMFuncHPOPPluginResult, [IAgAsHpopPluginResult])

agcls.AgClassCatalog.add_catalog_entry((5446187798380491025, 13426309531629116071), AgEOMFuncHPOPPluginResult)
agcls.AgTypeNameMap["AgEOMFuncHPOPPluginResult"] = AgEOMFuncHPOPPluginResult

class AgEOMFuncHPOPPluginResultEval(IAgAsHpopPluginResultEval, SupportsDeleteCallback):
    """APlugin class used to get/set propagator settings during the propagation of a step with EOM Manager"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgEOMFuncHPOPPluginResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgAsHpopPluginResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsHpopPluginResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgEOMFuncHPOPPluginResultEval, [IAgAsHpopPluginResultEval])

agcls.AgClassCatalog.add_catalog_entry((5733230949542604042, 8059859427921744264), AgEOMFuncHPOPPluginResultEval)
agcls.AgTypeNameMap["AgEOMFuncHPOPPluginResultEval"] = AgEOMFuncHPOPPluginResultEval

class AgEOMFuncHPOPPluginResultPostEval(IAgAsHpopPluginResultPostEval, SupportsDeleteCallback):
    """Plugin class used to get/set propagator settings during the propagation of a step with EOM Manager"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgEOMFuncHPOPPluginResultPostEval."""
        SupportsDeleteCallback.__init__(self)
        IAgAsHpopPluginResultPostEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsHpopPluginResultPostEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgEOMFuncHPOPPluginResultPostEval, [IAgAsHpopPluginResultPostEval])

agcls.AgClassCatalog.add_catalog_entry((5472090150943106537, 12506339760923055776), AgEOMFuncHPOPPluginResultPostEval)
agcls.AgTypeNameMap["AgEOMFuncHPOPPluginResultPostEval"] = AgEOMFuncHPOPPluginResultPostEval

class AgAsEOMFuncPluginRegisterHandler(IAgAsEOMFuncPluginRegisterHandler, SupportsDeleteCallback):
    """Plugin class used to register plugin's inputs and outputs"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsEOMFuncPluginRegisterHandler."""
        SupportsDeleteCallback.__init__(self)
        IAgAsEOMFuncPluginRegisterHandler.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsEOMFuncPluginRegisterHandler._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsEOMFuncPluginRegisterHandler, [IAgAsEOMFuncPluginRegisterHandler])

agcls.AgClassCatalog.add_catalog_entry((5711803105848347816, 4028319026585369749), AgAsEOMFuncPluginRegisterHandler)
agcls.AgTypeNameMap["AgAsEOMFuncPluginRegisterHandler"] = AgAsEOMFuncPluginRegisterHandler

class AgAsEOMFuncPluginSetIndicesHandler(IAgAsEOMFuncPluginSetIndicesHandler, SupportsDeleteCallback):
    """Plugin class used to set plugin's indices"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsEOMFuncPluginSetIndicesHandler."""
        SupportsDeleteCallback.__init__(self)
        IAgAsEOMFuncPluginSetIndicesHandler.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsEOMFuncPluginSetIndicesHandler._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsEOMFuncPluginSetIndicesHandler, [IAgAsEOMFuncPluginSetIndicesHandler])

agcls.AgClassCatalog.add_catalog_entry((5604457527007695947, 3194814213610706079), AgAsEOMFuncPluginSetIndicesHandler)
agcls.AgTypeNameMap["AgAsEOMFuncPluginSetIndicesHandler"] = AgAsEOMFuncPluginSetIndicesHandler

class AgAsEOMFuncPluginStateVector(IAgAsEOMFuncPluginStateVector, SupportsDeleteCallback):
    """Plugin class used to get and set state values during propagation in plugin's calc method"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAsEOMFuncPluginStateVector."""
        SupportsDeleteCallback.__init__(self)
        IAgAsEOMFuncPluginStateVector.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAsEOMFuncPluginStateVector._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAsEOMFuncPluginStateVector, [IAgAsEOMFuncPluginStateVector])

agcls.AgClassCatalog.add_catalog_entry((4765723707233542512, 519930447003963013), AgAsEOMFuncPluginStateVector)
agcls.AgTypeNameMap["AgAsEOMFuncPluginStateVector"] = AgAsEOMFuncPluginStateVector


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
