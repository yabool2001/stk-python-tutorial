################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgEGatorPluginErrorCodes", "AgESearchControlTypes", "AgESearchPluginErrorCodes", "AgGatorPropagatorScriptDriver", 
"IAgGatorPropagatorScriptDriver", "IAgPluginSearch", "IAgPluginSearchStatusGrid", "IAgSearchControl", "IAgSearchControlCollection", 
"IAgSearchControlReal", "IAgSearchPluginOperand", "IAgSearchResult", "IAgSearchResultCollection"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.utplugin import *
from ..plugins.hpopplugin import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEGatorPluginErrorCodes(IntEnum):
    """Enumeration of AgGatorPlugin General Error Codes"""
   
    eGatorPluginInternalFailure = (((1 << 31) | (4 << 16)) | 0x101)
    """Gator Plugin: An internal failure occurred."""
    eGatorPluginNotConfigured = (((1 << 31) | (4 << 16)) | 0x102)
    """Gator Plugin: Not configured properly."""
    eGatorPluginCentralBodyUndefined = (((1 << 31) | (4 << 16)) | 0x103)
    """Gator Plugin: Central Body is undefined."""
    eGatorPluginSunPositionTypeSRPNotSupported = (((1 << 31) | (4 << 16)) | 0x104)
    """Gator Plugin: Sun Position Type SRP not supported."""
    eGatorPluginInvalidSqr = (((1 << 31) | (4 << 16)) | 0x105)
    """Gator Plugin: The Square Root of an invalid value occurred."""
    eGatorPluginReferenceAxesUnavailable = (((1 << 31) | (4 << 16)) | 0x106)
    """Gator Plugin: Reference Axes Unavailable."""
    eGatorPluginInvalidColor = (((1 << 31) | (4 << 16)) | 0x107)
    """Gator Plugin: Color not valid."""

AgEGatorPluginErrorCodes.eGatorPluginInternalFailure.__doc__ = "Gator Plugin: An internal failure occurred."
AgEGatorPluginErrorCodes.eGatorPluginNotConfigured.__doc__ = "Gator Plugin: Not configured properly."
AgEGatorPluginErrorCodes.eGatorPluginCentralBodyUndefined.__doc__ = "Gator Plugin: Central Body is undefined."
AgEGatorPluginErrorCodes.eGatorPluginSunPositionTypeSRPNotSupported.__doc__ = "Gator Plugin: Sun Position Type SRP not supported."
AgEGatorPluginErrorCodes.eGatorPluginInvalidSqr.__doc__ = "Gator Plugin: The Square Root of an invalid value occurred."
AgEGatorPluginErrorCodes.eGatorPluginReferenceAxesUnavailable.__doc__ = "Gator Plugin: Reference Axes Unavailable."
AgEGatorPluginErrorCodes.eGatorPluginInvalidColor.__doc__ = "Gator Plugin: Color not valid."

agcls.AgTypeNameMap["AgEGatorPluginErrorCodes"] = AgEGatorPluginErrorCodes

class AgESearchPluginErrorCodes(IntEnum):
    """Enumeration of AgSearchPlugin General Error Codes."""
   
    eSearchPluginErrorCodesOperandError = (((1 << 31) | (4 << 16)) | 0x108)
    """Search Plugin: Operand Error."""
    eSearchPluginErrorCodesOperandProfileFailure = (((1 << 31) | (4 << 16)) | 0x109)
    """Search Plugin: Profile Failure."""
    eSearchPluginErrorCodesGUIDataFailure = (((1 << 31) | (4 << 16)) | 0x110)
    """Search Plugin: GUI Data Failure."""
    eSearchPluginErrorCodesOperandStopped = (((1 << 31) | (4 << 16)) | 0x111)
    """Search Plugin: Operand Stopped."""
    eSearchPluginErrorCodesOperandCanceled = (((1 << 31) | (4 << 16)) | 0x112)
    """Search Plugin: Operand Canceled."""

AgESearchPluginErrorCodes.eSearchPluginErrorCodesOperandError.__doc__ = "Search Plugin: Operand Error."
AgESearchPluginErrorCodes.eSearchPluginErrorCodesOperandProfileFailure.__doc__ = "Search Plugin: Profile Failure."
AgESearchPluginErrorCodes.eSearchPluginErrorCodesGUIDataFailure.__doc__ = "Search Plugin: GUI Data Failure."
AgESearchPluginErrorCodes.eSearchPluginErrorCodesOperandStopped.__doc__ = "Search Plugin: Operand Stopped."
AgESearchPluginErrorCodes.eSearchPluginErrorCodesOperandCanceled.__doc__ = "Search Plugin: Operand Canceled."

agcls.AgTypeNameMap["AgESearchPluginErrorCodes"] = AgESearchPluginErrorCodes

class AgESearchControlTypes(IntEnum):
    """Enumeration of control types for search plugins."""
   
    eSearchControlTypesReal = 0
    """Real numbers (doubles)"""

AgESearchControlTypes.eSearchControlTypesReal.__doc__ = "Real numbers (doubles)"

agcls.AgTypeNameMap["AgESearchControlTypes"] = AgESearchControlTypes


class IAgGatorPropagatorScriptDriver(object):
    """HPOP plugin engine interface utilizing a script driver interface (VBScript, Matlab)"""

    _num_methods = 30
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_UseInitFile_method_offset = 1
    _set_UseInitFile_method_offset = 2
    _get_InitFile_method_offset = 3
    _set_InitFile_method_offset = 4
    _get_InitFileRWFlag_method_offset = 5
    _get_UsePrePropagateFile_method_offset = 6
    _set_UsePrePropagateFile_method_offset = 7
    _get_PrePropagateFile_method_offset = 8
    _set_PrePropagateFile_method_offset = 9
    _get_PrePropagateFileRWFlag_method_offset = 10
    _get_UsePreNextStepFile_method_offset = 11
    _set_UsePreNextStepFile_method_offset = 12
    _get_PreNextStepFile_method_offset = 13
    _set_PreNextStepFile_method_offset = 14
    _get_PreNextStepFileRWFlag_method_offset = 15
    _get_UseEvaluateFile_method_offset = 16
    _set_UseEvaluateFile_method_offset = 17
    _get_EvaluateFile_method_offset = 18
    _set_EvaluateFile_method_offset = 19
    _get_EvaluateFileRWFlag_method_offset = 20
    _get_UsePostPropagateFile_method_offset = 21
    _set_UsePostPropagateFile_method_offset = 22
    _get_PostPropagateFile_method_offset = 23
    _set_PostPropagateFile_method_offset = 24
    _get_PostPropagateFileRWFlag_method_offset = 25
    _get_UseFreeFile_method_offset = 26
    _set_UseFreeFile_method_offset = 27
    _get_FreeFile_method_offset = 28
    _set_FreeFile_method_offset = 29
    _get_FreeFileRWFlag_method_offset = 30
    _metadata = {
        "iid_data" : (5256219757754404526, 17772617395180108181),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgGatorPropagatorScriptDriver."""
        initialize_from_source_object(self, sourceObject, IAgGatorPropagatorScriptDriver)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgGatorPropagatorScriptDriver)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgGatorPropagatorScriptDriver, None)
    
    _get_UseInitFile_metadata = { "offset" : _get_UseInitFile_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UseInitFile(self) -> bool:
        """Use Init File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_UseInitFile_metadata)

    _set_UseInitFile_metadata = { "offset" : _set_UseInitFile_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UseInitFile.setter
    def UseInitFile(self, newVal:bool) -> None:
        """Use Init File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_UseInitFile_metadata, newVal)

    _get_InitFile_metadata = { "offset" : _get_InitFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def InitFile(self) -> str:
        """Init File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_InitFile_metadata)

    _set_InitFile_metadata = { "offset" : _set_InitFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @InitFile.setter
    def InitFile(self, newVal:str) -> None:
        """Init File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_InitFile_metadata, newVal)

    _get_InitFileRWFlag_metadata = { "offset" : _get_InitFileRWFlag_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def InitFileRWFlag(self) -> int:
        """Init File RW Flag"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_InitFileRWFlag_metadata)

    _get_UsePrePropagateFile_metadata = { "offset" : _get_UsePrePropagateFile_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UsePrePropagateFile(self) -> bool:
        """Use PrePropagate File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_UsePrePropagateFile_metadata)

    _set_UsePrePropagateFile_metadata = { "offset" : _set_UsePrePropagateFile_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UsePrePropagateFile.setter
    def UsePrePropagateFile(self, newVal:bool) -> None:
        """Use PrePropagate File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_UsePrePropagateFile_metadata, newVal)

    _get_PrePropagateFile_metadata = { "offset" : _get_PrePropagateFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def PrePropagateFile(self) -> str:
        """PrePropagate File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_PrePropagateFile_metadata)

    _set_PrePropagateFile_metadata = { "offset" : _set_PrePropagateFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @PrePropagateFile.setter
    def PrePropagateFile(self, newVal:str) -> None:
        """PrePropagate File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_PrePropagateFile_metadata, newVal)

    _get_PrePropagateFileRWFlag_metadata = { "offset" : _get_PrePropagateFileRWFlag_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def PrePropagateFileRWFlag(self) -> int:
        """PrePropagate File RW Flag"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_PrePropagateFileRWFlag_metadata)

    _get_UsePreNextStepFile_metadata = { "offset" : _get_UsePreNextStepFile_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UsePreNextStepFile(self) -> bool:
        """Use PreNextStep File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_UsePreNextStepFile_metadata)

    _set_UsePreNextStepFile_metadata = { "offset" : _set_UsePreNextStepFile_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UsePreNextStepFile.setter
    def UsePreNextStepFile(self, newVal:bool) -> None:
        """Use PreNextStep File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_UsePreNextStepFile_metadata, newVal)

    _get_PreNextStepFile_metadata = { "offset" : _get_PreNextStepFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def PreNextStepFile(self) -> str:
        """PreNextStep File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_PreNextStepFile_metadata)

    _set_PreNextStepFile_metadata = { "offset" : _set_PreNextStepFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @PreNextStepFile.setter
    def PreNextStepFile(self, newVal:str) -> None:
        """PreNextStep File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_PreNextStepFile_metadata, newVal)

    _get_PreNextStepFileRWFlag_metadata = { "offset" : _get_PreNextStepFileRWFlag_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def PreNextStepFileRWFlag(self) -> int:
        """PreNextStep File RW Flag"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_PreNextStepFileRWFlag_metadata)

    _get_UseEvaluateFile_metadata = { "offset" : _get_UseEvaluateFile_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UseEvaluateFile(self) -> bool:
        """Use Evaluate File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_UseEvaluateFile_metadata)

    _set_UseEvaluateFile_metadata = { "offset" : _set_UseEvaluateFile_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UseEvaluateFile.setter
    def UseEvaluateFile(self, newVal:bool) -> None:
        """Use Evaluate File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_UseEvaluateFile_metadata, newVal)

    _get_EvaluateFile_metadata = { "offset" : _get_EvaluateFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def EvaluateFile(self) -> str:
        """Evaluate File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_EvaluateFile_metadata)

    _set_EvaluateFile_metadata = { "offset" : _set_EvaluateFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @EvaluateFile.setter
    def EvaluateFile(self, newVal:str) -> None:
        """Evaluate File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_EvaluateFile_metadata, newVal)

    _get_EvaluateFileRWFlag_metadata = { "offset" : _get_EvaluateFileRWFlag_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def EvaluateFileRWFlag(self) -> int:
        """Evaluate File RW Flag"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_EvaluateFileRWFlag_metadata)

    _get_UsePostPropagateFile_metadata = { "offset" : _get_UsePostPropagateFile_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UsePostPropagateFile(self) -> bool:
        """Use PostPropagate File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_UsePostPropagateFile_metadata)

    _set_UsePostPropagateFile_metadata = { "offset" : _set_UsePostPropagateFile_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UsePostPropagateFile.setter
    def UsePostPropagateFile(self, newVal:bool) -> None:
        """Use PostPropagate File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_UsePostPropagateFile_metadata, newVal)

    _get_PostPropagateFile_metadata = { "offset" : _get_PostPropagateFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def PostPropagateFile(self) -> str:
        """PostPropagate File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_PostPropagateFile_metadata)

    _set_PostPropagateFile_metadata = { "offset" : _set_PostPropagateFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @PostPropagateFile.setter
    def PostPropagateFile(self, newVal:str) -> None:
        """PostPropagate File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_PostPropagateFile_metadata, newVal)

    _get_PostPropagateFileRWFlag_metadata = { "offset" : _get_PostPropagateFileRWFlag_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def PostPropagateFileRWFlag(self) -> int:
        """PostPropagate File RW Flag"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_PostPropagateFileRWFlag_metadata)

    _get_UseFreeFile_metadata = { "offset" : _get_UseFreeFile_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UseFreeFile(self) -> bool:
        """Use Free File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_UseFreeFile_metadata)

    _set_UseFreeFile_metadata = { "offset" : _set_UseFreeFile_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UseFreeFile.setter
    def UseFreeFile(self, newVal:bool) -> None:
        """Use Free File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_UseFreeFile_metadata, newVal)

    _get_FreeFile_metadata = { "offset" : _get_FreeFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FreeFile(self) -> str:
        """Free File"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_FreeFile_metadata)

    _set_FreeFile_metadata = { "offset" : _set_FreeFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @FreeFile.setter
    def FreeFile(self, newVal:str) -> None:
        """Free File"""
        return self._intf.set_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._set_FreeFile_metadata, newVal)

    _get_FreeFileRWFlag_metadata = { "offset" : _get_FreeFileRWFlag_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def FreeFileRWFlag(self) -> int:
        """Free File RW Flag"""
        return self._intf.get_property(IAgGatorPropagatorScriptDriver._metadata, IAgGatorPropagatorScriptDriver._get_FreeFileRWFlag_metadata)

    _property_names[UseInitFile] = "UseInitFile"
    _property_names[InitFile] = "InitFile"
    _property_names[InitFileRWFlag] = "InitFileRWFlag"
    _property_names[UsePrePropagateFile] = "UsePrePropagateFile"
    _property_names[PrePropagateFile] = "PrePropagateFile"
    _property_names[PrePropagateFileRWFlag] = "PrePropagateFileRWFlag"
    _property_names[UsePreNextStepFile] = "UsePreNextStepFile"
    _property_names[PreNextStepFile] = "PreNextStepFile"
    _property_names[PreNextStepFileRWFlag] = "PreNextStepFileRWFlag"
    _property_names[UseEvaluateFile] = "UseEvaluateFile"
    _property_names[EvaluateFile] = "EvaluateFile"
    _property_names[EvaluateFileRWFlag] = "EvaluateFileRWFlag"
    _property_names[UsePostPropagateFile] = "UsePostPropagateFile"
    _property_names[PostPropagateFile] = "PostPropagateFile"
    _property_names[PostPropagateFileRWFlag] = "PostPropagateFileRWFlag"
    _property_names[UseFreeFile] = "UseFreeFile"
    _property_names[FreeFile] = "FreeFile"
    _property_names[FreeFileRWFlag] = "FreeFileRWFlag"


agcls.AgClassCatalog.add_catalog_entry((5256219757754404526, 17772617395180108181), IAgGatorPropagatorScriptDriver)
agcls.AgTypeNameMap["IAgGatorPropagatorScriptDriver"] = IAgGatorPropagatorScriptDriver

class IAgSearchControl(object):
    """Plugin search algorithm control"""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ObjectName_method_offset = 1
    _set_ObjectName_method_offset = 2
    _get_ControlName_method_offset = 3
    _set_ControlName_method_offset = 4
    _get_ControlType_method_offset = 5
    _set_ControlType_method_offset = 6
    _metadata = {
        "iid_data" : (5248930937300647200, 3064136084831292605),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSearchControl."""
        initialize_from_source_object(self, sourceObject, IAgSearchControl)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSearchControl)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSearchControl, None)
    
    _get_ObjectName_metadata = { "offset" : _get_ObjectName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectName(self) -> str:
        """Name of the object associated with the control.  Set by STK."""
        return self._intf.get_property(IAgSearchControl._metadata, IAgSearchControl._get_ObjectName_metadata)

    _set_ObjectName_metadata = { "offset" : _set_ObjectName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ObjectName.setter
    def ObjectName(self, objectName:str) -> None:
        """Name of the object associated with the control.  Set by STK."""
        return self._intf.set_property(IAgSearchControl._metadata, IAgSearchControl._set_ObjectName_metadata, objectName)

    _get_ControlName_metadata = { "offset" : _get_ControlName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ControlName(self) -> str:
        """Name of the control.  Set by STK."""
        return self._intf.get_property(IAgSearchControl._metadata, IAgSearchControl._get_ControlName_metadata)

    _set_ControlName_metadata = { "offset" : _set_ControlName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ControlName.setter
    def ControlName(self, controlName:str) -> None:
        """Name of the control.  Set by STK."""
        return self._intf.set_property(IAgSearchControl._metadata, IAgSearchControl._set_ControlName_metadata, controlName)

    _get_ControlType_metadata = { "offset" : _get_ControlType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgESearchControlTypes),) }
    @property
    def ControlType(self) -> "AgESearchControlTypes":
        """Type of the control.  Set by STK."""
        return self._intf.get_property(IAgSearchControl._metadata, IAgSearchControl._get_ControlType_metadata)

    _set_ControlType_metadata = { "offset" : _set_ControlType_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgESearchControlTypes),) }
    @ControlType.setter
    def ControlType(self, type:"AgESearchControlTypes") -> None:
        """Type of the control.  Set by STK."""
        return self._intf.set_property(IAgSearchControl._metadata, IAgSearchControl._set_ControlType_metadata, type)

    _property_names[ObjectName] = "ObjectName"
    _property_names[ControlName] = "ControlName"
    _property_names[ControlType] = "ControlType"


agcls.AgClassCatalog.add_catalog_entry((5248930937300647200, 3064136084831292605), IAgSearchControl)
agcls.AgTypeNameMap["IAgSearchControl"] = IAgSearchControl

class IAgSearchControlReal(IAgSearchControl):
    """Plugin search algorithm control, real number"""

    _num_methods = 8
    _vtable_offset = IAgSearchControl._vtable_offset + IAgSearchControl._num_methods
    _get_CurrentValue_method_offset = 1
    _set_CurrentValue_method_offset = 2
    _get_InitialValue_method_offset = 3
    _set_InitialValue_method_offset = 4
    _get_Dimension_method_offset = 5
    _set_Dimension_method_offset = 6
    _get_InternalUnit_method_offset = 7
    _set_InternalUnit_method_offset = 8
    _metadata = {
        "iid_data" : (5249232782072747011, 6911246567843744424),
        "vtable_reference" : IAgSearchControl._vtable_offset + IAgSearchControl._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSearchControlReal."""
        initialize_from_source_object(self, sourceObject, IAgSearchControlReal)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgSearchControl._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSearchControlReal)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSearchControlReal, IAgSearchControl)
    
    _get_CurrentValue_metadata = { "offset" : _get_CurrentValue_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def CurrentValue(self) -> float:
        """The current value of the control.  Set by the plugin search algorithm."""
        return self._intf.get_property(IAgSearchControlReal._metadata, IAgSearchControlReal._get_CurrentValue_metadata)

    _set_CurrentValue_metadata = { "offset" : _set_CurrentValue_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @CurrentValue.setter
    def CurrentValue(self, currentValue:float) -> None:
        """The current value of the control.  Set by the plugin search algorithm."""
        return self._intf.set_property(IAgSearchControlReal._metadata, IAgSearchControlReal._set_CurrentValue_metadata, currentValue)

    _get_InitialValue_metadata = { "offset" : _get_InitialValue_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def InitialValue(self) -> float:
        """The value of the control at the start of the plugin search run.  Set by STK."""
        return self._intf.get_property(IAgSearchControlReal._metadata, IAgSearchControlReal._get_InitialValue_metadata)

    _set_InitialValue_metadata = { "offset" : _set_InitialValue_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @InitialValue.setter
    def InitialValue(self, initialValue:float) -> None:
        """The value of the control at the start of the plugin search run.  Set by STK."""
        return self._intf.set_property(IAgSearchControlReal._metadata, IAgSearchControlReal._set_InitialValue_metadata, initialValue)

    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Dimension(self) -> str:
        """The dimension of the control.  Set by STK."""
        return self._intf.get_property(IAgSearchControlReal._metadata, IAgSearchControlReal._get_Dimension_metadata)

    _set_Dimension_metadata = { "offset" : _set_Dimension_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Dimension.setter
    def Dimension(self, dimension:str) -> None:
        """The dimension of the control.  Set by STK."""
        return self._intf.set_property(IAgSearchControlReal._metadata, IAgSearchControlReal._set_Dimension_metadata, dimension)

    _get_InternalUnit_metadata = { "offset" : _get_InternalUnit_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def InternalUnit(self) -> str:
        """The internal unit of the control.  Set by STK."""
        return self._intf.get_property(IAgSearchControlReal._metadata, IAgSearchControlReal._get_InternalUnit_metadata)

    _set_InternalUnit_metadata = { "offset" : _set_InternalUnit_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @InternalUnit.setter
    def InternalUnit(self, internalUnit:str) -> None:
        """The internal unit of the control.  Set by STK."""
        return self._intf.set_property(IAgSearchControlReal._metadata, IAgSearchControlReal._set_InternalUnit_metadata, internalUnit)

    _property_names[CurrentValue] = "CurrentValue"
    _property_names[InitialValue] = "InitialValue"
    _property_names[Dimension] = "Dimension"
    _property_names[InternalUnit] = "InternalUnit"


agcls.AgClassCatalog.add_catalog_entry((5249232782072747011, 6911246567843744424), IAgSearchControlReal)
agcls.AgTypeNameMap["IAgSearchControlReal"] = IAgSearchControlReal

class IAgSearchControlCollection(object):
    """Collection for plugin search algorithm controls"""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Item_method_offset = 1
    _get__NewEnum_method_offset = 2
    _get_Count_method_offset = 3
    _metadata = {
        "iid_data" : (4817333564014069873, 4174051031908957622),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSearchControlCollection."""
        initialize_from_source_object(self, sourceObject, IAgSearchControlCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSearchControlCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSearchControlCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgSearchControlCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgSearchControl":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgSearchControl":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgSearchControlCollection._metadata, IAgSearchControlCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgSearchControlCollection._metadata, IAgSearchControlCollection._get__NewEnum_metadata)

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Number of items in the collection"""
        return self._intf.get_property(IAgSearchControlCollection._metadata, IAgSearchControlCollection._get_Count_metadata)

    __getitem__ = Item


    _property_names[_NewEnum] = "_NewEnum"
    _property_names[Count] = "Count"


agcls.AgClassCatalog.add_catalog_entry((4817333564014069873, 4174051031908957622), IAgSearchControlCollection)
agcls.AgTypeNameMap["IAgSearchControlCollection"] = IAgSearchControlCollection

class IAgSearchResult(object):
    """Plugin search algorithm result"""

    _num_methods = 12
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ObjectName_method_offset = 1
    _set_ObjectName_method_offset = 2
    _get_ResultName_method_offset = 3
    _set_ResultName_method_offset = 4
    _get_CurrentValue_method_offset = 5
    _set_CurrentValue_method_offset = 6
    _get_IsValid_method_offset = 7
    _set_IsValid_method_offset = 8
    _get_Dimension_method_offset = 9
    _set_Dimension_method_offset = 10
    _get_InternalUnit_method_offset = 11
    _set_InternalUnit_method_offset = 12
    _metadata = {
        "iid_data" : (5633184418980211356, 6738053313163812509),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSearchResult."""
        initialize_from_source_object(self, sourceObject, IAgSearchResult)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSearchResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSearchResult, None)
    
    _get_ObjectName_metadata = { "offset" : _get_ObjectName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectName(self) -> str:
        """Name of the object associated with the result.  Set by STK."""
        return self._intf.get_property(IAgSearchResult._metadata, IAgSearchResult._get_ObjectName_metadata)

    _set_ObjectName_metadata = { "offset" : _set_ObjectName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ObjectName.setter
    def ObjectName(self, objectName:str) -> None:
        """Name of the object associated with the result.  Set by STK."""
        return self._intf.set_property(IAgSearchResult._metadata, IAgSearchResult._set_ObjectName_metadata, objectName)

    _get_ResultName_metadata = { "offset" : _get_ResultName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ResultName(self) -> str:
        """Name of the result.  Set by STK."""
        return self._intf.get_property(IAgSearchResult._metadata, IAgSearchResult._get_ResultName_metadata)

    _set_ResultName_metadata = { "offset" : _set_ResultName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ResultName.setter
    def ResultName(self, resultName:str) -> None:
        """Name of the result.  Set by STK."""
        return self._intf.set_property(IAgSearchResult._metadata, IAgSearchResult._set_ResultName_metadata, resultName)

    _get_CurrentValue_metadata = { "offset" : _get_CurrentValue_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def CurrentValue(self) -> float:
        """The current value of the result.  Set by STK."""
        return self._intf.get_property(IAgSearchResult._metadata, IAgSearchResult._get_CurrentValue_metadata)

    _set_CurrentValue_metadata = { "offset" : _set_CurrentValue_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @CurrentValue.setter
    def CurrentValue(self, currentValue:float) -> None:
        """The current value of the result.  Set by STK."""
        return self._intf.set_property(IAgSearchResult._metadata, IAgSearchResult._set_CurrentValue_metadata, currentValue)

    _get_IsValid_metadata = { "offset" : _get_IsValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsValid(self) -> bool:
        """Whether the current value of the result is valid.  Set by STK."""
        return self._intf.get_property(IAgSearchResult._metadata, IAgSearchResult._get_IsValid_metadata)

    _set_IsValid_metadata = { "offset" : _set_IsValid_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @IsValid.setter
    def IsValid(self, isValid:bool) -> None:
        """Whether the current value of the result is valid.  Set by STK."""
        return self._intf.set_property(IAgSearchResult._metadata, IAgSearchResult._set_IsValid_metadata, isValid)

    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Dimension(self) -> str:
        """The dimension of the result.  Set by STK."""
        return self._intf.get_property(IAgSearchResult._metadata, IAgSearchResult._get_Dimension_metadata)

    _set_Dimension_metadata = { "offset" : _set_Dimension_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Dimension.setter
    def Dimension(self, dimension:str) -> None:
        """The dimension of the result.  Set by STK."""
        return self._intf.set_property(IAgSearchResult._metadata, IAgSearchResult._set_Dimension_metadata, dimension)

    _get_InternalUnit_metadata = { "offset" : _get_InternalUnit_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def InternalUnit(self) -> str:
        """The internal unit of the result.  Set by STK."""
        return self._intf.get_property(IAgSearchResult._metadata, IAgSearchResult._get_InternalUnit_metadata)

    _set_InternalUnit_metadata = { "offset" : _set_InternalUnit_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @InternalUnit.setter
    def InternalUnit(self, internalUnit:str) -> None:
        """The internal unit of the result.  Set by STK."""
        return self._intf.set_property(IAgSearchResult._metadata, IAgSearchResult._set_InternalUnit_metadata, internalUnit)

    _property_names[ObjectName] = "ObjectName"
    _property_names[ResultName] = "ResultName"
    _property_names[CurrentValue] = "CurrentValue"
    _property_names[IsValid] = "IsValid"
    _property_names[Dimension] = "Dimension"
    _property_names[InternalUnit] = "InternalUnit"


agcls.AgClassCatalog.add_catalog_entry((5633184418980211356, 6738053313163812509), IAgSearchResult)
agcls.AgTypeNameMap["IAgSearchResult"] = IAgSearchResult

class IAgSearchResultCollection(object):
    """Collection for plugin search algorithm results"""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Item_method_offset = 1
    _get__NewEnum_method_offset = 2
    _get_Count_method_offset = 3
    _metadata = {
        "iid_data" : (5656514049306996644, 11793295204362099593),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSearchResultCollection."""
        initialize_from_source_object(self, sourceObject, IAgSearchResultCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSearchResultCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSearchResultCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgSearchResultCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgSearchResult":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgSearchResult":
        """Given an index, returns the element in the collection."""
        return self._intf.invoke(IAgSearchResultCollection._metadata, IAgSearchResultCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator for the collection."""
        return self._intf.get_property(IAgSearchResultCollection._metadata, IAgSearchResultCollection._get__NewEnum_metadata)

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Number of items in the collection"""
        return self._intf.get_property(IAgSearchResultCollection._metadata, IAgSearchResultCollection._get_Count_metadata)

    __getitem__ = Item


    _property_names[_NewEnum] = "_NewEnum"
    _property_names[Count] = "Count"


agcls.AgClassCatalog.add_catalog_entry((5656514049306996644, 11793295204362099593), IAgSearchResultCollection)
agcls.AgTypeNameMap["IAgSearchResultCollection"] = IAgSearchResultCollection

class IAgPluginSearchStatusGrid(object):
    """Astrogator plugin class for plugin search algorithm's status grid."""

    _num_methods = 11
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _CreateGrid_method_offset = 1
    _SetCellString_method_offset = 2
    _SetCellValue_method_offset = 3
    _SetStatus_method_offset = 4
    _Refresh_method_offset = 5
    _SetColumnToTruncateLeft_method_offset = 6
    _SetHeaderCellString_method_offset = 7
    _SetCellControlValue_method_offset = 8
    _SetCellResultValue_method_offset = 9
    _SetCellControlDeltaValue_method_offset = 10
    _SetCellResultDeltaValue_method_offset = 11
    _metadata = {
        "iid_data" : (4804227702417644637, 16963490168828732802),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgPluginSearchStatusGrid."""
        initialize_from_source_object(self, sourceObject, IAgPluginSearchStatusGrid)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgPluginSearchStatusGrid)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgPluginSearchStatusGrid, None)
    
    _CreateGrid_metadata = { "offset" : _CreateGrid_method_offset,
            "arg_types" : (agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg,) }
    def CreateGrid(self, numRows:int, numCols:int) -> None:
        """Creates the grid."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._CreateGrid_metadata, numRows, numCols)

    _SetCellString_metadata = { "offset" : _SetCellString_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.BSTR,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.BSTR_arg,) }
    def SetCellString(self, row:int, col:int, text:str) -> None:
        """Sets a string in a cell."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._SetCellString_metadata, row, col, text)

    _SetCellValue_metadata = { "offset" : _SetCellValue_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.DOUBLE, agcom.BSTR, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.DOUBLE_arg, agmarshall.BSTR_arg, agmarshall.INT_arg,) }
    def SetCellValue(self, row:int, col:int, value:float, dimension:str, numDigits:int) -> None:
        """Sets a number in a cell. Uses scenario units."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._SetCellValue_metadata, row, col, value, dimension, numDigits)

    _SetStatus_metadata = { "offset" : _SetStatus_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def SetStatus(self, value:str) -> None:
        """Sets the status in the title bar."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._SetStatus_metadata, value)

    _Refresh_metadata = { "offset" : _Refresh_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Refresh(self) -> None:
        """Refreshes the grid."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._Refresh_metadata, )

    _SetColumnToTruncateLeft_metadata = { "offset" : _SetColumnToTruncateLeft_method_offset,
            "arg_types" : (agcom.INT,),
            "marshallers" : (agmarshall.INT_arg,) }
    def SetColumnToTruncateLeft(self, col:int) -> None:
        """Sets a column to truncate left."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._SetColumnToTruncateLeft_metadata, col)

    _SetHeaderCellString_metadata = { "offset" : _SetHeaderCellString_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.BSTR,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.BSTR_arg,) }
    def SetHeaderCellString(self, row:int, col:int, text:str) -> None:
        """Sets a bold string in a cell."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._SetHeaderCellString_metadata, row, col, text)

    _SetCellControlValue_metadata = { "offset" : _SetCellControlValue_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT, agcom.DOUBLE, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.DOUBLE_arg, agmarshall.INT_arg,) }
    def SetCellControlValue(self, row:int, col:int, controlIndex:int, value:float, numDigits:int) -> None:
        """Sets a number in a cell in the units of a control value."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._SetCellControlValue_metadata, row, col, controlIndex, value, numDigits)

    _SetCellResultValue_metadata = { "offset" : _SetCellResultValue_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT, agcom.DOUBLE, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.DOUBLE_arg, agmarshall.INT_arg,) }
    def SetCellResultValue(self, row:int, col:int, resultIndex:int, value:float, numDigits:int) -> None:
        """Sets a number in a cell in the units of a result value."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._SetCellResultValue_metadata, row, col, resultIndex, value, numDigits)

    _SetCellControlDeltaValue_metadata = { "offset" : _SetCellControlDeltaValue_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT, agcom.DOUBLE, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.DOUBLE_arg, agmarshall.INT_arg,) }
    def SetCellControlDeltaValue(self, row:int, col:int, controlIndex:int, value:float, numDigits:int) -> None:
        """Sets a number in a cell in the delta units of a control value."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._SetCellControlDeltaValue_metadata, row, col, controlIndex, value, numDigits)

    _SetCellResultDeltaValue_metadata = { "offset" : _SetCellResultDeltaValue_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT, agcom.DOUBLE, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.DOUBLE_arg, agmarshall.INT_arg,) }
    def SetCellResultDeltaValue(self, row:int, col:int, resultIndex:int, value:float, numDigits:int) -> None:
        """Sets a number in a cell in the delta units of a result value."""
        return self._intf.invoke(IAgPluginSearchStatusGrid._metadata, IAgPluginSearchStatusGrid._SetCellResultDeltaValue_metadata, row, col, resultIndex, value, numDigits)


agcls.AgClassCatalog.add_catalog_entry((4804227702417644637, 16963490168828732802), IAgPluginSearchStatusGrid)
agcls.AgTypeNameMap["IAgPluginSearchStatusGrid"] = IAgPluginSearchStatusGrid

class IAgSearchPluginOperand(object):
    """Astrogator plugin class for plugin search algorithm's operand."""

    _num_methods = 8
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _Evaluate_method_offset = 2
    _get_Controls_method_offset = 3
    _get_Results_method_offset = 4
    _get_StatusGrid_method_offset = 5
    _Evaluate2_method_offset = 6
    _get_LogFile_method_offset = 7
    _get_ProfileName_method_offset = 8
    _metadata = {
        "iid_data" : (5245848673976739103, 13532969473186261419),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSearchPluginOperand."""
        initialize_from_source_object(self, sourceObject, IAgSearchPluginOperand)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSearchPluginOperand)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSearchPluginOperand, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgSearchPluginOperand._metadata, IAgSearchPluginOperand._Trace_metadata, numCalls)

    _Evaluate_metadata = { "offset" : _Evaluate_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def Evaluate(self) -> bool:
        """Evaluates the operand of the search.  Treated as a perturbation so graphs are not updated."""
        return self._intf.invoke(IAgSearchPluginOperand._metadata, IAgSearchPluginOperand._Evaluate_metadata, OutArg())

    _get_Controls_metadata = { "offset" : _get_Controls_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Controls(self) -> "IAgSearchControlCollection":
        """Collection of controls."""
        return self._intf.get_property(IAgSearchPluginOperand._metadata, IAgSearchPluginOperand._get_Controls_metadata)

    _get_Results_metadata = { "offset" : _get_Results_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Results(self) -> "IAgSearchResultCollection":
        """Collection of results."""
        return self._intf.get_property(IAgSearchPluginOperand._metadata, IAgSearchPluginOperand._get_Results_metadata)

    _get_StatusGrid_metadata = { "offset" : _get_StatusGrid_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def StatusGrid(self) -> "IAgPluginSearchStatusGrid":
        """Status Grid."""
        return self._intf.get_property(IAgSearchPluginOperand._metadata, IAgSearchPluginOperand._get_StatusGrid_metadata)

    _Evaluate2_metadata = { "offset" : _Evaluate2_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg, agmarshall.VARIANT_BOOL_arg,) }
    def Evaluate2(self, isIteration:bool) -> bool:
        """Evaluates the operand of the search.  Graphs are updated if IsIteration is true."""
        return self._intf.invoke(IAgSearchPluginOperand._metadata, IAgSearchPluginOperand._Evaluate2_metadata, isIteration, OutArg())

    _get_LogFile_metadata = { "offset" : _get_LogFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LogFile(self) -> str:
        """Log file plugin can use."""
        return self._intf.get_property(IAgSearchPluginOperand._metadata, IAgSearchPluginOperand._get_LogFile_metadata)

    _get_ProfileName_metadata = { "offset" : _get_ProfileName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ProfileName(self) -> str:
        """Name of this search profile."""
        return self._intf.get_property(IAgSearchPluginOperand._metadata, IAgSearchPluginOperand._get_ProfileName_metadata)

    _property_names[Controls] = "Controls"
    _property_names[Results] = "Results"
    _property_names[StatusGrid] = "StatusGrid"
    _property_names[LogFile] = "LogFile"
    _property_names[ProfileName] = "ProfileName"


agcls.AgClassCatalog.add_catalog_entry((5245848673976739103, 13532969473186261419), IAgSearchPluginOperand)
agcls.AgTypeNameMap["IAgSearchPluginOperand"] = IAgSearchPluginOperand


class IAgPluginSearch(object):
    """
    Plugin search algorithm interface. A method returning false indicates an error.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Name(self) -> str:
        """Triggered to set the name of the plugin used in messages."""
        raise STKPluginMethodNotImplementedError("Name was not implemented.")

    def GetControlsProgID(self, type:"AgESearchControlTypes") -> str:
        """Gets the progid of the controls of the specified type for this algorithm.  If a certain control type isn't supported, return an empty string."""
        raise STKPluginMethodNotImplementedError("GetControlsProgID was not implemented.")

    def GetResultsProgID(self) -> str:
        """Gets the progid of the results for this algorithm."""
        raise STKPluginMethodNotImplementedError("GetResultsProgID was not implemented.")

    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered when the plugin is initialized to allow for any additional needed initialization. Must return true to turn on use of plugin."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def Run(self, searchOperand:"IAgSearchPluginOperand", testing:bool) -> bool:
        """Triggered when the plugin is run."""
        raise STKPluginMethodNotImplementedError("Run was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is freed from use to allow for any additional cleanup."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")




class AgGatorPropagatorScriptDriver(IAgGatorPropagatorScriptDriver, IAgAsHpopPlugin, IAgUtPluginConfig, SupportsDeleteCallback):
    """Astrogator plugin class to use old script plug-ins as HPOP COM plugins"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgGatorPropagatorScriptDriver."""
        SupportsDeleteCallback.__init__(self)
        IAgGatorPropagatorScriptDriver.__init__(self, sourceObject)
        IAgAsHpopPlugin.__init__(self, sourceObject)
        IAgUtPluginConfig.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgGatorPropagatorScriptDriver._private_init(self, intf)
        IAgAsHpopPlugin._private_init(self, intf)
        IAgUtPluginConfig._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgGatorPropagatorScriptDriver, [IAgGatorPropagatorScriptDriver, IAgAsHpopPlugin, IAgUtPluginConfig])

agcls.AgClassCatalog.add_catalog_entry((4915623677724435227, 14758333001080891037), AgGatorPropagatorScriptDriver)
agcls.AgTypeNameMap["AgGatorPropagatorScriptDriver"] = AgGatorPropagatorScriptDriver


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
