################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgEEulerSequence", "AgEPropagatorWrapperPluginErrorCodes", "AgGatorPluginResultAttCtrl", "AgGatorPluginResultEvalEngineModel", 
"AgGatorPluginResultState", "IAgGatorPluginAttCtrl", "IAgGatorPluginEngineModel", "IAgGatorPluginResultAttCtrl", "IAgGatorPluginResultEvalEngineModel", 
"IAgGatorPluginResultState"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.utplugin import *
from ..plugins.hpopplugin import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEPropagatorWrapperPluginErrorCodes(IntEnum):
    """Enumeration of AgPropagatorWrapperPlugin General Error Codes"""
   
    E_PROPAGATOR_WRAPPERS_PLUGIN_INTERNAL_FAILURE = (((1 << 31) | (4 << 16)) | 0x101)
    """Gator Plugin: An internal failure occurred."""
    E_PROPAGATOR_WRAPPERS_PLUGIN_NOT_CONFIGURED = (((1 << 31) | (4 << 16)) | 0x102)
    """Gator Plugin: Not configured properly."""
    E_PROPAGATOR_WRAPPERS_PLUGIN_CENTRALBODY_UNDEFINED = (((1 << 31) | (4 << 16)) | 0x103)
    """Gator Plugin: Central Body is undefined."""
    E_PROPAGATOR_WRAPPERS_PLUGIN_SUNPOSTYPE_SRP_NOT_SUPPORTED = (((1 << 31) | (4 << 16)) | 0x104)
    """Gator Plugin: Sun Position Type SRP not supported."""
    E_PROPAGATOR_WRAPPERS_PLUGIN_INVALID_SQR = (((1 << 31) | (4 << 16)) | 0x105)
    """Gator Plugin: The Square Root of an invalid value occurred."""
    E_PROPAGATOR_WRAPPERS_PLUGIN_REF_AXES_UNAVAILABLE = (((1 << 31) | (4 << 16)) | 0x106)
    """Gator Plugin: Reference Axes Unavailable."""
    E_PROPAGATOR_WRAPPERS_PLUGIN_INVALID_COLOR = (((1 << 31) | (4 << 16)) | 0x107)
    """Gator Plugin: Color not valid."""

AgEPropagatorWrapperPluginErrorCodes.E_PROPAGATOR_WRAPPERS_PLUGIN_INTERNAL_FAILURE.__doc__ = "Gator Plugin: An internal failure occurred."
AgEPropagatorWrapperPluginErrorCodes.E_PROPAGATOR_WRAPPERS_PLUGIN_NOT_CONFIGURED.__doc__ = "Gator Plugin: Not configured properly."
AgEPropagatorWrapperPluginErrorCodes.E_PROPAGATOR_WRAPPERS_PLUGIN_CENTRALBODY_UNDEFINED.__doc__ = "Gator Plugin: Central Body is undefined."
AgEPropagatorWrapperPluginErrorCodes.E_PROPAGATOR_WRAPPERS_PLUGIN_SUNPOSTYPE_SRP_NOT_SUPPORTED.__doc__ = "Gator Plugin: Sun Position Type SRP not supported."
AgEPropagatorWrapperPluginErrorCodes.E_PROPAGATOR_WRAPPERS_PLUGIN_INVALID_SQR.__doc__ = "Gator Plugin: The Square Root of an invalid value occurred."
AgEPropagatorWrapperPluginErrorCodes.E_PROPAGATOR_WRAPPERS_PLUGIN_REF_AXES_UNAVAILABLE.__doc__ = "Gator Plugin: Reference Axes Unavailable."
AgEPropagatorWrapperPluginErrorCodes.E_PROPAGATOR_WRAPPERS_PLUGIN_INVALID_COLOR.__doc__ = "Gator Plugin: Color not valid."

agcls.AgTypeNameMap["AgEPropagatorWrapperPluginErrorCodes"] = AgEPropagatorWrapperPluginErrorCodes

class AgEEulerSequence(IntEnum):
    """Enumeration AgEEulerSequence."""
   
    e121 = 121
    """Sequence defined by rotation about x-axis, then about rotated y-axis, then about rotated x-axis."""
    e123 = 123
    """Sequence defined by rotation about x-axis, then about rotated y-axis, then about rotated z-axis."""
    e131 = 131
    """Sequence defined by rotation about x-axis, then about rotated z-axis, then about rotated x-axis."""
    e132 = 132
    """Sequence defined by rotation about x-axis, then about rotated z-axis, then about rotated y-axis."""
    e212 = 212
    """Sequence defined by rotation about y-axis, then about rotated x-axis, then about rotated y-axis."""
    e213 = 213
    """Sequence defined by rotation about y-axis, then about rotated x-axis, then about rotated z-axis."""
    e231 = 231
    """Sequence defined by rotation about y-axis, then about rotated z-axis, then about rotated x-axis."""
    e232 = 232
    """Sequence defined by rotation about y-axis, then about rotated z-axis, then about rotated y-axis."""
    e312 = 312
    """Sequence defined by rotation about z-axis, then about rotated x-axis, then about rotated y-axis."""
    e313 = 313
    """Sequence defined by rotation about z-axis, then about rotated x-axis, then about rotated z-axis."""
    e321 = 321
    """Sequence defined by rotation about z-axis, then about rotated y-axis, then about rotated x-axis."""
    e323 = 323
    """Sequence defined by rotation about z-axis, then about rotated y-axis, then about rotated x-axis."""

AgEEulerSequence.e121.__doc__ = "Sequence defined by rotation about x-axis, then about rotated y-axis, then about rotated x-axis."
AgEEulerSequence.e123.__doc__ = "Sequence defined by rotation about x-axis, then about rotated y-axis, then about rotated z-axis."
AgEEulerSequence.e131.__doc__ = "Sequence defined by rotation about x-axis, then about rotated z-axis, then about rotated x-axis."
AgEEulerSequence.e132.__doc__ = "Sequence defined by rotation about x-axis, then about rotated z-axis, then about rotated y-axis."
AgEEulerSequence.e212.__doc__ = "Sequence defined by rotation about y-axis, then about rotated x-axis, then about rotated y-axis."
AgEEulerSequence.e213.__doc__ = "Sequence defined by rotation about y-axis, then about rotated x-axis, then about rotated z-axis."
AgEEulerSequence.e231.__doc__ = "Sequence defined by rotation about y-axis, then about rotated z-axis, then about rotated x-axis."
AgEEulerSequence.e232.__doc__ = "Sequence defined by rotation about y-axis, then about rotated z-axis, then about rotated y-axis."
AgEEulerSequence.e312.__doc__ = "Sequence defined by rotation about z-axis, then about rotated x-axis, then about rotated y-axis."
AgEEulerSequence.e313.__doc__ = "Sequence defined by rotation about z-axis, then about rotated x-axis, then about rotated z-axis."
AgEEulerSequence.e321.__doc__ = "Sequence defined by rotation about z-axis, then about rotated y-axis, then about rotated x-axis."
AgEEulerSequence.e323.__doc__ = "Sequence defined by rotation about z-axis, then about rotated y-axis, then about rotated x-axis."

agcls.AgTypeNameMap["AgEEulerSequence"] = AgEEulerSequence


class IAgGatorPluginResultState(object):
    """Astrogator plugin interface used to get state values. Supports IAgGatorState and IAgEpoch."""

    _num_methods = 28
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _get_CbName_method_offset = 2
    _get_Mu_method_offset = 3
    _get_Cd_method_offset = 4
    _get_Cr_method_offset = 5
    _get_DragArea_method_offset = 6
    _get_SRPArea_method_offset = 7
    _get_Mass_method_offset = 8
    _get_DryMass_method_offset = 9
    _get_FuelMass_method_offset = 10
    _get_Altitude_method_offset = 11
    _DayCount_method_offset = 12
    _DayCount_Array_method_offset = 13
    _PosVel_method_offset = 14
    _PosVel_Array_method_offset = 15
    _LatLonAlt_method_offset = 16
    _LatLonAlt_Array_method_offset = 17
    _SunPosition_method_offset = 18
    _SunPosition_Array_method_offset = 19
    _TransformVector_method_offset = 20
    _TransformVector_Array_method_offset = 21
    _StopPropagation_method_offset = 22
    _IndicateEvent_method_offset = 23
    _SetMaxStep_method_offset = 24
    _SetColor_method_offset = 25
    _DateElements_method_offset = 26
    _DateElements_Array_method_offset = 27
    _DateString_method_offset = 28
    _metadata = {
        "iid_data" : (5622141985187418827, 5038402274981560995),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgGatorPluginResultState."""
        initialize_from_source_object(self, sourceObject, IAgGatorPluginResultState)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgGatorPluginResultState)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgGatorPluginResultState, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._Trace_metadata, numCalls)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_CbName_metadata)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant of the state central body"""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_Mu_metadata)

    _get_Cd_metadata = { "offset" : _get_Cd_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cd(self) -> float:
        """Drag Coefficient."""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_Cd_metadata)

    _get_Cr_metadata = { "offset" : _get_Cr_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cr(self) -> float:
        """SRP Coefficient."""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_Cr_metadata)

    _get_DragArea_metadata = { "offset" : _get_DragArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DragArea(self) -> float:
        """Drag Area."""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_DragArea_metadata)

    _get_SRPArea_metadata = { "offset" : _get_SRPArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SRPArea(self) -> float:
        """SRP Area."""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_SRPArea_metadata)

    _get_Mass_metadata = { "offset" : _get_Mass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mass(self) -> float:
        """Total Mass."""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_Mass_metadata)

    _get_DryMass_metadata = { "offset" : _get_DryMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DryMass(self) -> float:
        """Dry Mass."""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_DryMass_metadata)

    _get_FuelMass_metadata = { "offset" : _get_FuelMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def FuelMass(self) -> float:
        """Fuel Mass."""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_FuelMass_metadata)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude."""
        return self._intf.get_property(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._get_Altitude_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._DayCount_Array_metadata, scale, OutArg())

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position and velocity in the requested frame (in internal units) returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._PosVel_Array_metadata, frame, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude, detic longitude, and altitude(in internal units) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._LatLonAlt_Array_metadata, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun wrt the current satellite position, in the requested frame, computed in the requested manner, (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _StopPropagation_metadata = { "offset" : _StopPropagation_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def StopPropagation(self) -> None:
        """Stops propagation.  For fatal errors."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._StopPropagation_metadata, )

    _IndicateEvent_metadata = { "offset" : _IndicateEvent_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAsHpopPluginEventIndicators),) }
    def IndicateEvent(self, eEventIndicator:"AgEAsHpopPluginEventIndicators") -> None:
        """Marks an event to the propagator."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._IndicateEvent_metadata, eEventIndicator)

    _SetMaxStep_metadata = { "offset" : _SetMaxStep_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetMaxStep(self, maxStep:float) -> None:
        """Sets the maximum step size for the propagator."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._SetMaxStep_metadata, maxStep)

    _SetColor_metadata = { "offset" : _SetColor_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def SetColor(self, color:str) -> None:
        """Sets the segment color."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._SetColor_metadata, color)

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgGatorPluginResultState._metadata, IAgGatorPluginResultState._DateString_metadata, dateAbbrv, OutArg())

    _property_names[CbName] = "CbName"
    _property_names[Mu] = "Mu"
    _property_names[Cd] = "Cd"
    _property_names[Cr] = "Cr"
    _property_names[DragArea] = "DragArea"
    _property_names[SRPArea] = "SRPArea"
    _property_names[Mass] = "Mass"
    _property_names[DryMass] = "DryMass"
    _property_names[FuelMass] = "FuelMass"
    _property_names[Altitude] = "Altitude"


agcls.AgClassCatalog.add_catalog_entry((5622141985187418827, 5038402274981560995), IAgGatorPluginResultState)
agcls.AgTypeNameMap["IAgGatorPluginResultState"] = IAgGatorPluginResultState

class IAgGatorPluginResultEvalEngineModel(object):
    """Astrogator plugin interface used to get/set engine model settings during the computation of a step. Supports IAgGatorState and IAgEpoch."""

    _num_methods = 32
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _get_CbName_method_offset = 2
    _get_Mu_method_offset = 3
    _get_Cd_method_offset = 4
    _get_Cr_method_offset = 5
    _get_DragArea_method_offset = 6
    _get_SRPArea_method_offset = 7
    _get_Mass_method_offset = 8
    _get_DryMass_method_offset = 9
    _get_FuelMass_method_offset = 10
    _get_Altitude_method_offset = 11
    _DayCount_method_offset = 12
    _DayCount_Array_method_offset = 13
    _PosVel_method_offset = 14
    _PosVel_Array_method_offset = 15
    _LatLonAlt_method_offset = 16
    _LatLonAlt_Array_method_offset = 17
    _SunPosition_method_offset = 18
    _SunPosition_Array_method_offset = 19
    _TransformVector_method_offset = 20
    _TransformVector_Array_method_offset = 21
    _get_Thrust_method_offset = 22
    _get_Isp_method_offset = 23
    _get_MassFlowRate_method_offset = 24
    _get_TimeSinceIgnition_method_offset = 25
    _SetThrustAndIsp_method_offset = 26
    _SetThrustAndMassFlowRate_method_offset = 27
    _SetIspAndMassFlowRate_method_offset = 28
    _StopPropagation_method_offset = 29
    _DateElements_method_offset = 30
    _DateElements_Array_method_offset = 31
    _DateString_method_offset = 32
    _metadata = {
        "iid_data" : (5345973310400289310, 9740097643423806093),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgGatorPluginResultEvalEngineModel."""
        initialize_from_source_object(self, sourceObject, IAgGatorPluginResultEvalEngineModel)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgGatorPluginResultEvalEngineModel)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgGatorPluginResultEvalEngineModel, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._Trace_metadata, numCalls)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_CbName_metadata)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant of the state central body"""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_Mu_metadata)

    _get_Cd_metadata = { "offset" : _get_Cd_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cd(self) -> float:
        """Drag Coefficient."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_Cd_metadata)

    _get_Cr_metadata = { "offset" : _get_Cr_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cr(self) -> float:
        """SRP Coefficient."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_Cr_metadata)

    _get_DragArea_metadata = { "offset" : _get_DragArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DragArea(self) -> float:
        """Drag Area."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_DragArea_metadata)

    _get_SRPArea_metadata = { "offset" : _get_SRPArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SRPArea(self) -> float:
        """SRP Area."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_SRPArea_metadata)

    _get_Mass_metadata = { "offset" : _get_Mass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mass(self) -> float:
        """Total Mass."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_Mass_metadata)

    _get_DryMass_metadata = { "offset" : _get_DryMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DryMass(self) -> float:
        """Dry Mass."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_DryMass_metadata)

    _get_FuelMass_metadata = { "offset" : _get_FuelMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def FuelMass(self) -> float:
        """Fuel Mass."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_FuelMass_metadata)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_Altitude_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._DayCount_Array_metadata, scale, OutArg())

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position and velocity in the requested frame (in internal units) returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._PosVel_Array_metadata, frame, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude, detic longitude, and altitude(in internal units) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._LatLonAlt_Array_metadata, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun wrt the current satellite position, in the requested frame, computed in the requested manner, (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _get_Thrust_metadata = { "offset" : _get_Thrust_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Thrust(self) -> float:
        """Current thrust (N)."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_Thrust_metadata)

    _get_Isp_metadata = { "offset" : _get_Isp_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Isp(self) -> float:
        """Current Isp (secs)."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_Isp_metadata)

    _get_MassFlowRate_metadata = { "offset" : _get_MassFlowRate_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def MassFlowRate(self) -> float:
        """Current mass flow rate (kg/sec)."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_MassFlowRate_metadata)

    _get_TimeSinceIgnition_metadata = { "offset" : _get_TimeSinceIgnition_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TimeSinceIgnition(self) -> float:
        """Time since ignition (secs)."""
        return self._intf.get_property(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._get_TimeSinceIgnition_metadata)

    _SetThrustAndIsp_metadata = { "offset" : _SetThrustAndIsp_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetThrustAndIsp(self, thrust:float, isp:float) -> bool:
        """Sets the current thrust (N) and isp (secs). Computes the mass flow rate using the rocket equation. Returns false on an error."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._SetThrustAndIsp_metadata, thrust, isp, OutArg())

    _SetThrustAndMassFlowRate_metadata = { "offset" : _SetThrustAndMassFlowRate_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetThrustAndMassFlowRate(self, thrust:float, massFlowRate:float) -> bool:
        """Sets the current thrust(N) and mass flow rate (kg/sec). Computes the isp using the rocket equation. Returns false on an error."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._SetThrustAndMassFlowRate_metadata, thrust, massFlowRate, OutArg())

    _SetIspAndMassFlowRate_metadata = { "offset" : _SetIspAndMassFlowRate_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetIspAndMassFlowRate(self, isp:float, massFlowRate:float) -> bool:
        """Sets the current isp and mass flow rate. Computes the thrust using the rocket equation. Returns false on an error."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._SetIspAndMassFlowRate_metadata, isp, massFlowRate, OutArg())

    _StopPropagation_metadata = { "offset" : _StopPropagation_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def StopPropagation(self) -> None:
        """Stops propagation.  For fatal errors."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._StopPropagation_metadata, )

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgGatorPluginResultEvalEngineModel._metadata, IAgGatorPluginResultEvalEngineModel._DateString_metadata, dateAbbrv, OutArg())

    _property_names[CbName] = "CbName"
    _property_names[Mu] = "Mu"
    _property_names[Cd] = "Cd"
    _property_names[Cr] = "Cr"
    _property_names[DragArea] = "DragArea"
    _property_names[SRPArea] = "SRPArea"
    _property_names[Mass] = "Mass"
    _property_names[DryMass] = "DryMass"
    _property_names[FuelMass] = "FuelMass"
    _property_names[Altitude] = "Altitude"
    _property_names[Thrust] = "Thrust"
    _property_names[Isp] = "Isp"
    _property_names[MassFlowRate] = "MassFlowRate"
    _property_names[TimeSinceIgnition] = "TimeSinceIgnition"


agcls.AgClassCatalog.add_catalog_entry((5345973310400289310, 9740097643423806093), IAgGatorPluginResultEvalEngineModel)
agcls.AgTypeNameMap["IAgGatorPluginResultEvalEngineModel"] = IAgGatorPluginResultEvalEngineModel

class IAgGatorPluginResultAttCtrl(object):
    """Astrogator plugin interface used to get/set attitude controller settings. Supports IAgGatorState and IAgEpoch."""

    _num_methods = 33
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Trace_method_offset = 1
    _get_CbName_method_offset = 2
    _get_Mu_method_offset = 3
    _get_Cd_method_offset = 4
    _get_Cr_method_offset = 5
    _get_DragArea_method_offset = 6
    _get_SRPArea_method_offset = 7
    _get_Mass_method_offset = 8
    _get_DryMass_method_offset = 9
    _get_FuelMass_method_offset = 10
    _get_Altitude_method_offset = 11
    _DayCount_method_offset = 12
    _DayCount_Array_method_offset = 13
    _PosVel_method_offset = 14
    _PosVel_Array_method_offset = 15
    _LatLonAlt_method_offset = 16
    _LatLonAlt_Array_method_offset = 17
    _SunPosition_method_offset = 18
    _SunPosition_Array_method_offset = 19
    _TransformVector_method_offset = 20
    _TransformVector_Array_method_offset = 21
    _get_RefAxes_method_offset = 22
    _SetRefAxes_method_offset = 23
    _SetQuaternion_method_offset = 24
    _EulerRotate_method_offset = 25
    _GetQuaternion_method_offset = 26
    _GetQuaternion_Array_method_offset = 27
    _GetEulerRotation_method_offset = 28
    _GetEulerRotation_Array_method_offset = 29
    _StopPropagation_method_offset = 30
    _DateElements_method_offset = 31
    _DateElements_Array_method_offset = 32
    _DateString_method_offset = 33
    _metadata = {
        "iid_data" : (5354993015622909430, 6917240678609556378),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgGatorPluginResultAttCtrl."""
        initialize_from_source_object(self, sourceObject, IAgGatorPluginResultAttCtrl)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgGatorPluginResultAttCtrl)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgGatorPluginResultAttCtrl, None)
    
    _Trace_metadata = { "offset" : _Trace_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def Trace(self, numCalls:int) -> None:
        """Set this interface to trace the next numCalls by outputting a message to the message viewer."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._Trace_metadata, numCalls)

    _get_CbName_metadata = { "offset" : _get_CbName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CbName(self) -> str:
        """Name of the central body used as reference frame origin."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_CbName_metadata)

    _get_Mu_metadata = { "offset" : _get_Mu_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mu(self) -> float:
        """Gravitational constant of the state central body"""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_Mu_metadata)

    _get_Cd_metadata = { "offset" : _get_Cd_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cd(self) -> float:
        """Drag Coefficient."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_Cd_metadata)

    _get_Cr_metadata = { "offset" : _get_Cr_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Cr(self) -> float:
        """SRP Coefficient."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_Cr_metadata)

    _get_DragArea_metadata = { "offset" : _get_DragArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DragArea(self) -> float:
        """Drag Area."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_DragArea_metadata)

    _get_SRPArea_metadata = { "offset" : _get_SRPArea_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SRPArea(self) -> float:
        """SRP Area."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_SRPArea_metadata)

    _get_Mass_metadata = { "offset" : _get_Mass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Mass(self) -> float:
        """Total Mass."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_Mass_metadata)

    _get_DryMass_metadata = { "offset" : _get_DryMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def DryMass(self) -> float:
        """Dry Mass."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_DryMass_metadata)

    _get_FuelMass_metadata = { "offset" : _get_FuelMass_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def FuelMass(self) -> float:
        """Fuel Mass."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_FuelMass_metadata)

    _get_Altitude_metadata = { "offset" : _get_Altitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Altitude(self) -> float:
        """Current altitude."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_Altitude_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._DayCount_Array_metadata, scale, OutArg())

    _PosVel_Array_metadata = { "offset" : _PosVel_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def PosVel_Array(self, frame:"AgEUtFrame") -> list:
        """Current position and velocity in the requested frame (in internal units) returned as an array representing x, y, z, vx, vy, vz. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._PosVel_Array_metadata, frame, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """Current detic latitude, detic longitude, and altitude(in internal units) returned as an array representing lat, lon, alt. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._LatLonAlt_Array_metadata, OutArg())

    _SunPosition_Array_metadata = { "offset" : _SunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtSunPosType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def SunPosition_Array(self, sunPosType:"AgEUtSunPosType", frame:"AgEUtFrame") -> list:
        """Position of the sun wrt the current satellite position, in the requested frame, computed in the requested manner, (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._SunPosition_Array_metadata, sunPosType, frame, OutArg())

    _TransformVector_Array_metadata = { "offset" : _TransformVector_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def TransformVector_Array(self, frameFrom:"AgEUtFrame", xFrom:float, yFrom:float, zFrom:float, frameTo:"AgEUtFrame") -> list:
        """Transforms a vector from the input frame to the output frame (in internal units) returned as an array representing x, y, z. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._TransformVector_Array_metadata, frameFrom, xFrom, yFrom, zFrom, frameTo, OutArg())

    _get_RefAxes_metadata = { "offset" : _get_RefAxes_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def RefAxes(self) -> str:
        """Name of the reference axes."""
        return self._intf.get_property(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._get_RefAxes_metadata)

    _SetRefAxes_metadata = { "offset" : _SetRefAxes_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetRefAxes(self, name:str) -> bool:
        """Sets the reference axes."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._SetRefAxes_metadata, name, OutArg())

    _SetQuaternion_metadata = { "offset" : _SetQuaternion_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetQuaternion(self, q1:float, q2:float, q3:float, q4:float) -> None:
        """Sets the current orientation using a quaternion."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._SetQuaternion_metadata, q1, q2, q3, q4)

    _EulerRotate_metadata = { "offset" : _EulerRotate_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerSequence), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def EulerRotate(self, sequence:"AgEEulerSequence", first:float, second:float, third:float) -> None:
        """Sets the current orientation using a sequence of euler rotations."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._EulerRotate_metadata, sequence, first, second, third)

    _GetQuaternion_metadata = { "offset" : _GetQuaternion_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetQuaternion(self) -> typing.Tuple[float, float, float, float]:
        """Gets the current orientation as a quaternion."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._GetQuaternion_metadata, OutArg(), OutArg(), OutArg(), OutArg())

    _GetQuaternion_Array_metadata = { "offset" : _GetQuaternion_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def GetQuaternion_Array(self) -> list:
        """Gets the current orientation as a quaternion returned as an array representing Q1, Q2, Q3, and Q4. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._GetQuaternion_Array_metadata, OutArg())

    _GetEulerRotation_metadata = { "offset" : _GetEulerRotation_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerSequence), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetEulerRotation(self, sequence:"AgEEulerSequence") -> typing.Tuple[float, float, float]:
        """Gets the current orientation as euler angles."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._GetEulerRotation_metadata, sequence, OutArg(), OutArg(), OutArg())

    _GetEulerRotation_Array_metadata = { "offset" : _GetEulerRotation_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerSequence), agmarshall.LPSAFEARRAY_arg,) }
    def GetEulerRotation_Array(self, sequence:"AgEEulerSequence") -> list:
        """Gets the current orientation as euler rotations returned as an array. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._GetEulerRotation_Array_metadata, sequence, OutArg())

    _StopPropagation_metadata = { "offset" : _StopPropagation_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def StopPropagation(self) -> None:
        """Stops propagation.  For fatal errors."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._StopPropagation_metadata, )

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """Current epoch in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgGatorPluginResultAttCtrl._metadata, IAgGatorPluginResultAttCtrl._DateString_metadata, dateAbbrv, OutArg())

    _property_names[CbName] = "CbName"
    _property_names[Mu] = "Mu"
    _property_names[Cd] = "Cd"
    _property_names[Cr] = "Cr"
    _property_names[DragArea] = "DragArea"
    _property_names[SRPArea] = "SRPArea"
    _property_names[Mass] = "Mass"
    _property_names[DryMass] = "DryMass"
    _property_names[FuelMass] = "FuelMass"
    _property_names[Altitude] = "Altitude"
    _property_names[RefAxes] = "RefAxes"


agcls.AgClassCatalog.add_catalog_entry((5354993015622909430, 6917240678609556378), IAgGatorPluginResultAttCtrl)
agcls.AgTypeNameMap["IAgGatorPluginResultAttCtrl"] = IAgGatorPluginResultAttCtrl


class IAgGatorPluginEngineModel(object):
    """
    Astrogator plugin engine model interface whose methods are called at certain events in the propagation process. A method returning false indicates an error.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Name(self) -> str:
        """Triggered to set the name of the plugin used in messages."""
        raise STKPluginMethodNotImplementedError("Name was not implemented.")

    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered when the plugin is initialized to allow for any additional needed initialization. Must return true to turn on use of plugin."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def PrePropagate(self, resultState:"IAgGatorPluginResultState") -> bool:
        """Triggered just before propagation starts. Use the input interface to access engine model settings."""
        raise STKPluginMethodNotImplementedError("PrePropagate was not implemented.")

    def PreNextStep(self, resultState:"IAgGatorPluginResultState") -> bool:
        """Triggered just before the next propagation step is attempted. Use the input interface to access engine model settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("PreNextStep was not implemented.")

    def Evaluate(self, resultEvalEngineModel:"IAgGatorPluginResultEvalEngineModel") -> bool:
        """Triggered on every force model evaluation during the propagation of a step. Use the input interface to access engine model settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is freed from use to allow for any additional cleanup."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")


class IAgGatorPluginAttCtrl(object):
    """
    Astrogator plugin attitude controller interface whose methods are called at certain events in the propagation process. A method returning false indicates an error.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Name(self) -> str:
        """Triggered to set the name of the plugin used in messages."""
        raise STKPluginMethodNotImplementedError("Name was not implemented.")

    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered when the plugin is initialized to allow for any additional needed initialization. Must return true to turn on use of plugin."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def PrePropagate(self, resultAttCtrl:"IAgGatorPluginResultAttCtrl") -> bool:
        """Triggered just before propagation starts. Use the input interface to access attitude controller settings."""
        raise STKPluginMethodNotImplementedError("PrePropagate was not implemented.")

    def PreNextStep(self, resultAttCtrl:"IAgGatorPluginResultAttCtrl") -> bool:
        """Triggered just before the next propagation step is attempted. Use the input interface to access attitude controller settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("PreNextStep was not implemented.")

    def Evaluate(self, resultAttCtrl:"IAgGatorPluginResultAttCtrl") -> bool:
        """Triggered on every force model evaluation during the propagation of a step. Use the input interface to access attitude controller settings. Returning false will turn this callback off."""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is freed from use to allow for any additional cleanup."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")




class AgGatorPluginResultState(IAgGatorPluginResultState, SupportsDeleteCallback):
    """Astrogator plugin class used to get state values"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgGatorPluginResultState."""
        SupportsDeleteCallback.__init__(self)
        IAgGatorPluginResultState.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgGatorPluginResultState._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgGatorPluginResultState, [IAgGatorPluginResultState])

agcls.AgClassCatalog.add_catalog_entry((5066252559472924731, 3788255117784076982), AgGatorPluginResultState)
agcls.AgTypeNameMap["AgGatorPluginResultState"] = AgGatorPluginResultState

class AgGatorPluginResultEvalEngineModel(IAgGatorPluginResultEvalEngineModel, SupportsDeleteCallback):
    """Astrogator plugin class used to get/set engine model settings during the propagation of a step"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgGatorPluginResultEvalEngineModel."""
        SupportsDeleteCallback.__init__(self)
        IAgGatorPluginResultEvalEngineModel.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgGatorPluginResultEvalEngineModel._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgGatorPluginResultEvalEngineModel, [IAgGatorPluginResultEvalEngineModel])

agcls.AgClassCatalog.add_catalog_entry((5506631122966939720, 16892662721493426322), AgGatorPluginResultEvalEngineModel)
agcls.AgTypeNameMap["AgGatorPluginResultEvalEngineModel"] = AgGatorPluginResultEvalEngineModel

class AgGatorPluginResultAttCtrl(IAgGatorPluginResultAttCtrl, SupportsDeleteCallback):
    """Astrogator plugin class used to get/set attitude controller settings during the propagation of a step"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgGatorPluginResultAttCtrl."""
        SupportsDeleteCallback.__init__(self)
        IAgGatorPluginResultAttCtrl.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgGatorPluginResultAttCtrl._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgGatorPluginResultAttCtrl, [IAgGatorPluginResultAttCtrl])

agcls.AgClassCatalog.add_catalog_entry((5004631804343719852, 6907679871577555079), AgGatorPluginResultAttCtrl)
agcls.AgTypeNameMap["AgGatorPluginResultAttCtrl"] = AgGatorPluginResultAttCtrl


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
