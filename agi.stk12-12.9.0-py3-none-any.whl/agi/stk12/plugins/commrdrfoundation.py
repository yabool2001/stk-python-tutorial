################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgECRPolarizationRefAxis", "AgECRPolarizationType", "IAgCRPolarization", "IAgCRPolarizationElliptical", "IAgCRPolarizationLinear", 
"IAgCRSignal", "IAgCRSignalCollection"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.attrautomation import *
from ..plugins.utplugin import *
from ..plugins.crdnplugin import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgECRPolarizationRefAxis(IntEnum):
    """Enumeration of polarization reference axes."""
   
    eCRPolRefXAxis = 1
    """X Axis"""
    eCRPolRefYAxis = 2
    """Y Axis"""
    eCRPolRefZAxis = 3
    """Z Axis"""

AgECRPolarizationRefAxis.eCRPolRefXAxis.__doc__ = "X Axis"
AgECRPolarizationRefAxis.eCRPolRefYAxis.__doc__ = "Y Axis"
AgECRPolarizationRefAxis.eCRPolRefZAxis.__doc__ = "Z Axis"

agcls.AgTypeNameMap["AgECRPolarizationRefAxis"] = AgECRPolarizationRefAxis

class AgECRPolarizationType(IntEnum):
    """Enumeration of polarization types."""
   
    eCRLinearPol = 1
    """Linear"""
    eCRLHCPol = 2
    """Left-hand Circular"""
    eCRRHCPol = 3
    """Right-hand Circular"""
    eCREllipticalPol = 4
    """Elliptical"""

AgECRPolarizationType.eCRLinearPol.__doc__ = "Linear"
AgECRPolarizationType.eCRLHCPol.__doc__ = "Left-hand Circular"
AgECRPolarizationType.eCRRHCPol.__doc__ = "Right-hand Circular"
AgECRPolarizationType.eCREllipticalPol.__doc__ = "Elliptical"

agcls.AgTypeNameMap["AgECRPolarizationType"] = AgECRPolarizationType


class IAgCRPolarization(object):
    """Polarization object interface used to represent a signal polarization."""

    _num_methods = 4
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Type_method_offset = 1
    _get_TiltAngle_method_offset = 2
    _get_AxialRatio_method_offset = 3
    _get_ReferenceAxis_method_offset = 4
    _metadata = {
        "iid_data" : (5625402975859121908, 101809809614986672),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCRPolarization."""
        initialize_from_source_object(self, sourceObject, IAgCRPolarization)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCRPolarization)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCRPolarization, None)
    
    _get_Type_metadata = { "offset" : _get_Type_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgECRPolarizationType),) }
    @property
    def Type(self) -> "AgECRPolarizationType":
        """Gets the polarizatoin type."""
        return self._intf.get_property(IAgCRPolarization._metadata, IAgCRPolarization._get_Type_metadata)

    _get_TiltAngle_metadata = { "offset" : _get_TiltAngle_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TiltAngle(self) -> float:
        """Gets the tilt angle."""
        return self._intf.get_property(IAgCRPolarization._metadata, IAgCRPolarization._get_TiltAngle_metadata)

    _get_AxialRatio_metadata = { "offset" : _get_AxialRatio_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AxialRatio(self) -> float:
        """Gets the axial ratio."""
        return self._intf.get_property(IAgCRPolarization._metadata, IAgCRPolarization._get_AxialRatio_metadata)

    _get_ReferenceAxis_metadata = { "offset" : _get_ReferenceAxis_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgECRPolarizationRefAxis),) }
    @property
    def ReferenceAxis(self) -> "AgECRPolarizationRefAxis":
        """Gets the reference axis"""
        return self._intf.get_property(IAgCRPolarization._metadata, IAgCRPolarization._get_ReferenceAxis_metadata)

    _property_names[Type] = "Type"
    _property_names[TiltAngle] = "TiltAngle"
    _property_names[AxialRatio] = "AxialRatio"
    _property_names[ReferenceAxis] = "ReferenceAxis"


agcls.AgClassCatalog.add_catalog_entry((5625402975859121908, 101809809614986672), IAgCRPolarization)
agcls.AgTypeNameMap["IAgCRPolarization"] = IAgCRPolarization

class IAgCRPolarizationLinear(object):
    """Linear polarization object interface used to represent linear signal polarization."""

    _num_methods = 2
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _set_TiltAngle_method_offset = 1
    _set_ReferenceAxis_method_offset = 2
    _metadata = {
        "iid_data" : (5155368597796890700, 17125661755178213266),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCRPolarizationLinear."""
        initialize_from_source_object(self, sourceObject, IAgCRPolarizationLinear)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCRPolarizationLinear)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCRPolarizationLinear, None)
    
    _get_TiltAngle_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def TiltAngle(self) -> None:
        """TiltAngle is a write-only property."""
        raise RuntimeError("TiltAngle is a write-only property.")


    _set_TiltAngle_metadata = { "offset" : _set_TiltAngle_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @TiltAngle.setter
    def TiltAngle(self, tiltAngle:float) -> None:
        """Sets the tilt angle."""
        return self._intf.set_property(IAgCRPolarizationLinear._metadata, IAgCRPolarizationLinear._set_TiltAngle_metadata, tiltAngle)

    _get_ReferenceAxis_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def ReferenceAxis(self) -> None:
        """ReferenceAxis is a write-only property."""
        raise RuntimeError("ReferenceAxis is a write-only property.")


    _set_ReferenceAxis_metadata = { "offset" : _set_ReferenceAxis_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECRPolarizationRefAxis),) }
    @ReferenceAxis.setter
    def ReferenceAxis(self, referenceAxis:"AgECRPolarizationRefAxis") -> None:
        """Sets the reference axis"""
        return self._intf.set_property(IAgCRPolarizationLinear._metadata, IAgCRPolarizationLinear._set_ReferenceAxis_metadata, referenceAxis)

    _property_names[TiltAngle] = "TiltAngle"
    _property_names[ReferenceAxis] = "ReferenceAxis"


agcls.AgClassCatalog.add_catalog_entry((5155368597796890700, 17125661755178213266), IAgCRPolarizationLinear)
agcls.AgTypeNameMap["IAgCRPolarizationLinear"] = IAgCRPolarizationLinear

class IAgCRPolarizationElliptical(object):
    """Elliptical polarization object interface used to represent elliptical signal polarization."""

    _num_methods = 3
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _set_TiltAngle_method_offset = 1
    _set_AxialRatio_method_offset = 2
    _set_ReferenceAxis_method_offset = 3
    _metadata = {
        "iid_data" : (5588856870346839488, 1661134273339360679),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCRPolarizationElliptical."""
        initialize_from_source_object(self, sourceObject, IAgCRPolarizationElliptical)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCRPolarizationElliptical)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCRPolarizationElliptical, None)
    
    _get_TiltAngle_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def TiltAngle(self) -> None:
        """TiltAngle is a write-only property."""
        raise RuntimeError("TiltAngle is a write-only property.")


    _set_TiltAngle_metadata = { "offset" : _set_TiltAngle_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @TiltAngle.setter
    def TiltAngle(self, tiltAngle:float) -> None:
        """Sets the tilt angle."""
        return self._intf.set_property(IAgCRPolarizationElliptical._metadata, IAgCRPolarizationElliptical._set_TiltAngle_metadata, tiltAngle)

    _get_AxialRatio_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def AxialRatio(self) -> None:
        """AxialRatio is a write-only property."""
        raise RuntimeError("AxialRatio is a write-only property.")


    _set_AxialRatio_metadata = { "offset" : _set_AxialRatio_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @AxialRatio.setter
    def AxialRatio(self, axialRatio:float) -> None:
        """Sets the axial ratio."""
        return self._intf.set_property(IAgCRPolarizationElliptical._metadata, IAgCRPolarizationElliptical._set_AxialRatio_metadata, axialRatio)

    _get_ReferenceAxis_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def ReferenceAxis(self) -> None:
        """ReferenceAxis is a write-only property."""
        raise RuntimeError("ReferenceAxis is a write-only property.")


    _set_ReferenceAxis_metadata = { "offset" : _set_ReferenceAxis_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECRPolarizationRefAxis),) }
    @ReferenceAxis.setter
    def ReferenceAxis(self, referenceAxis:"AgECRPolarizationRefAxis") -> None:
        """Sets the reference axis"""
        return self._intf.set_property(IAgCRPolarizationElliptical._metadata, IAgCRPolarizationElliptical._set_ReferenceAxis_metadata, referenceAxis)

    _property_names[TiltAngle] = "TiltAngle"
    _property_names[AxialRatio] = "AxialRatio"
    _property_names[ReferenceAxis] = "ReferenceAxis"


agcls.AgClassCatalog.add_catalog_entry((5588856870346839488, 1661134273339360679), IAgCRPolarizationElliptical)
agcls.AgTypeNameMap["IAgCRPolarizationElliptical"] = IAgCRPolarizationElliptical

class IAgCRSignal(object):
    """Signal object interface used to represent an electromagnetic signal."""

    _num_methods = 13
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Time_method_offset = 1
    _get_Frequency_method_offset = 2
    _set_Frequency_method_offset = 3
    _get_UpperBandLimit_method_offset = 4
    _set_UpperBandLimit_method_offset = 5
    _get_LowerBandLimit_method_offset = 6
    _set_LowerBandLimit_method_offset = 7
    _get_Power_method_offset = 8
    _set_Power_method_offset = 9
    _get_Polarization_method_offset = 10
    _set_Polarization_method_offset = 11
    _ComputePolLoss_method_offset = 12
    _ComputePolRotationAngle_method_offset = 13
    _metadata = {
        "iid_data" : (5694453019028074050, 1725324753353575869),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCRSignal."""
        initialize_from_source_object(self, sourceObject, IAgCRSignal)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCRSignal)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCRSignal, None)
    
    _get_Time_metadata = { "offset" : _get_Time_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Time(self) -> float:
        """Gets the signal time in epoch seconds."""
        return self._intf.get_property(IAgCRSignal._metadata, IAgCRSignal._get_Time_metadata)

    _get_Frequency_metadata = { "offset" : _get_Frequency_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Frequency(self) -> float:
        """Gets or sets the signal frequency in Hz."""
        return self._intf.get_property(IAgCRSignal._metadata, IAgCRSignal._get_Frequency_metadata)

    _set_Frequency_metadata = { "offset" : _set_Frequency_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Frequency.setter
    def Frequency(self, frequency:float) -> None:
        """Gets or sets the signal frequency in Hz."""
        return self._intf.set_property(IAgCRSignal._metadata, IAgCRSignal._set_Frequency_metadata, frequency)

    _get_UpperBandLimit_metadata = { "offset" : _get_UpperBandLimit_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def UpperBandLimit(self) -> float:
        """Gets or sets the signal upper bandwidth limit in Hz."""
        return self._intf.get_property(IAgCRSignal._metadata, IAgCRSignal._get_UpperBandLimit_metadata)

    _set_UpperBandLimit_metadata = { "offset" : _set_UpperBandLimit_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @UpperBandLimit.setter
    def UpperBandLimit(self, upperLimit:float) -> None:
        """Gets or sets the signal upper bandwidth limit in Hz."""
        return self._intf.set_property(IAgCRSignal._metadata, IAgCRSignal._set_UpperBandLimit_metadata, upperLimit)

    _get_LowerBandLimit_metadata = { "offset" : _get_LowerBandLimit_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LowerBandLimit(self) -> float:
        """Gets or sets the signal lower bandwidth limit in Hz."""
        return self._intf.get_property(IAgCRSignal._metadata, IAgCRSignal._get_LowerBandLimit_metadata)

    _set_LowerBandLimit_metadata = { "offset" : _set_LowerBandLimit_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @LowerBandLimit.setter
    def LowerBandLimit(self, lowerLimit:float) -> None:
        """Gets or sets the signal lower bandwidth limit in Hz."""
        return self._intf.set_property(IAgCRSignal._metadata, IAgCRSignal._set_LowerBandLimit_metadata, lowerLimit)

    _get_Power_metadata = { "offset" : _get_Power_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Power(self) -> float:
        """Gets or sets the signal power in Watts."""
        return self._intf.get_property(IAgCRSignal._metadata, IAgCRSignal._get_Power_metadata)

    _set_Power_metadata = { "offset" : _set_Power_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Power.setter
    def Power(self, power:float) -> None:
        """Gets or sets the signal power in Watts."""
        return self._intf.set_property(IAgCRSignal._metadata, IAgCRSignal._set_Power_metadata, power)

    _get_Polarization_metadata = { "offset" : _get_Polarization_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Polarization(self) -> "IAgCRPolarization":
        """Gets or sets the signal polarization"""
        return self._intf.get_property(IAgCRSignal._metadata, IAgCRSignal._get_Polarization_metadata)

    _set_Polarization_metadata = { "offset" : _set_Polarization_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRPolarization"),) }
    @Polarization.setter
    def Polarization(self, polarization:"IAgCRPolarization") -> None:
        """Gets or sets the signal polarization"""
        return self._intf.set_property(IAgCRSignal._metadata, IAgCRSignal._set_Polarization_metadata, polarization)

    _ComputePolLoss_metadata = { "offset" : _ComputePolLoss_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRPolarization"), agmarshall.DOUBLE_arg,) }
    def ComputePolLoss(self, rcvSidePolarization:"IAgCRPolarization") -> float:
        """Computes the rotation angle for the receive side polarization."""
        return self._intf.invoke(IAgCRSignal._metadata, IAgCRSignal._ComputePolLoss_metadata, rcvSidePolarization, OutArg())

    _ComputePolRotationAngle_metadata = { "offset" : _ComputePolRotationAngle_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRPolarization"), agmarshall.DOUBLE_arg,) }
    def ComputePolRotationAngle(self, rcvSidePolarization:"IAgCRPolarization") -> float:
        """Computes the rotation angle for the receive side polarization."""
        return self._intf.invoke(IAgCRSignal._metadata, IAgCRSignal._ComputePolRotationAngle_metadata, rcvSidePolarization, OutArg())

    _property_names[Time] = "Time"
    _property_names[Frequency] = "Frequency"
    _property_names[UpperBandLimit] = "UpperBandLimit"
    _property_names[LowerBandLimit] = "LowerBandLimit"
    _property_names[Power] = "Power"
    _property_names[Polarization] = "Polarization"


agcls.AgClassCatalog.add_catalog_entry((5694453019028074050, 1725324753353575869), IAgCRSignal)
agcls.AgTypeNameMap["IAgCRSignal"] = IAgCRSignal

class IAgCRSignalCollection(object):
    """Interface implemented by a collection of signal objects."""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _metadata = {
        "iid_data" : (5290837799141938647, 6109973072256597170),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCRSignalCollection."""
        initialize_from_source_object(self, sourceObject, IAgCRSignalCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCRSignalCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCRSignalCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgCRSignalCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgCRSignal":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgCRSignalCollection._metadata, IAgCRSignalCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgCRSignal":
        """Given an index, returns an element in the collection."""
        return self._intf.invoke(IAgCRSignalCollection._metadata, IAgCRSignalCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator that can iterate through the collection."""
        return self._intf.get_property(IAgCRSignalCollection._metadata, IAgCRSignalCollection._get__NewEnum_metadata)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5290837799141938647, 6109973072256597170), IAgCRSignalCollection)
agcls.AgTypeNameMap["IAgCRSignalCollection"] = IAgCRSignalCollection



################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
