################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgAccessConstraintPluginObjectData", "AgAccessConstraintPluginObjectDescriptor", "AgAccessConstraintPluginResultEval", 
"AgAccessConstraintPluginResultPostCompute", "AgAccessConstraintPluginResultPreCompute", "AgAccessConstraintPluginResultRegister", 
"AgEAccessApparentPositionType", "AgEAccessConstraintDependencyFlags", "AgEAccessConstraintObjectType", "AgEAccessConstraintPluginErrorCodes", 
"AgEAccessLightTimeDelayFrame", "AgEAltitudeReference", "AgEApparentPositionAberrationType", "AgEApparentPositionSignalSense", 
"IAgAccessConstraintPlugin", "IAgAccessConstraintPluginObjectData", "IAgAccessConstraintPluginObjectDescriptor", "IAgAccessConstraintPluginResultEval", 
"IAgAccessConstraintPluginResultPostCompute", "IAgAccessConstraintPluginResultPreCompute", "IAgAccessConstraintPluginResultRegister"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.attrautomation import *
from ..plugins.utplugin import *
from ..plugins.crdnplugin import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEAccessConstraintPluginErrorCodes(IntEnum):
    """Enumeration of AgAccessConstraintPlugin General Error Codes"""
   
    eAccessConstraintPluginErrorInternalFailure = (((1 << 31) | (4 << 16)) | 0x101)
    """Access Constraint Plugin: An internal failure occurred."""
    eAccessConstraintPluginErrorObjectPathUnavailable = (((1 << 31) | (4 << 16)) | 0x102)
    """Access Constraint Plugin: Object path unavailable."""
    eAccessConstraintPluginErrorObjectCentralBodyNameUnavailable = (((1 << 31) | (4 << 16)) | 0x103)
    """Access Constraint Plugin: Central Body Name unavailable."""
    eAccessConstraintPluginErrorImplementationIncompleteError = (((1 << 31) | (4 << 16)) | 0x104)
    """Access Constraint Plugin: Implementation not yet complete, please contact AGI for more information."""
    eAccessConstraintPluginErrorPluginInitializationError = (((1 << 31) | (4 << 16)) | 0x105)
    """Access Constraint Plugin: Plugin initialization failure."""
    eAccessConstraintPluginErrorPluginUninitializationError = (((1 << 31) | (4 << 16)) | 0x106)
    """Access Constraint Plugin: Plugin uninitialization failure."""
    eAccessConstraintPluginErrorObjectTypeInvalid = (((1 << 31) | (4 << 16)) | 0x107)
    """Access Constraint Plugin: Invalid AgEAccessConstraintObjectType enum."""
    eAccessConstraintPluginErrorRegisterNoTargets = (((1 << 31) | (4 << 16)) | 0x108)
    """Access Constraint Plugin: No targets have been specified for registration."""
    eAccessConstraintPluginErrorBadRequestFrame = (((1 << 31) | (4 << 16)) | 0x109)
    """Access Constraint Plugin: Bad Frame request. Only eUtFrameInertial and eUtFrameFixed are supported."""
    eAccessConstraintPluginErrorGeometryNotComputed = (((1 << 31) | (4 << 16)) | 0x10A)
    """Access Constraint Plugin: Geometrical value not computed. Check registration dependency flags."""
    eAccessConstraintPluginErrorInvalidAltitudeReference = (((1 << 31) | (4 << 16)) | 0x10B)
    """Access Constraint Plugin: Invalid AgEAltitudeReference enum."""
    eAccessConstraintPluginErrorInvalidApparentPositionType = (((1 << 31) | (4 << 16)) | 0x10C)
    """Access Constraint Plugin: Invalid AgEAccessApparentPositionType enum."""
    eAccessConstraintPluginErrorInvalidDimension = (((1 << 31) | (4 << 16)) | 0x10D)
    """Access Constraint Plugin: Invalid dimension name."""
    eAccessConstraintPluginErrorInvalidWeight = (((1 << 31) | (4 << 16)) | 0x10E)
    """Access Constraint Plugin: Invalid computational weight value. Must be positive."""

AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorInternalFailure.__doc__ = "Access Constraint Plugin: An internal failure occurred."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorObjectPathUnavailable.__doc__ = "Access Constraint Plugin: Object path unavailable."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorObjectCentralBodyNameUnavailable.__doc__ = "Access Constraint Plugin: Central Body Name unavailable."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorImplementationIncompleteError.__doc__ = "Access Constraint Plugin: Implementation not yet complete, please contact AGI for more information."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorPluginInitializationError.__doc__ = "Access Constraint Plugin: Plugin initialization failure."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorPluginUninitializationError.__doc__ = "Access Constraint Plugin: Plugin uninitialization failure."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorObjectTypeInvalid.__doc__ = "Access Constraint Plugin: Invalid AgEAccessConstraintObjectType enum."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorRegisterNoTargets.__doc__ = "Access Constraint Plugin: No targets have been specified for registration."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorBadRequestFrame.__doc__ = "Access Constraint Plugin: Bad Frame request. Only eUtFrameInertial and eUtFrameFixed are supported."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorGeometryNotComputed.__doc__ = "Access Constraint Plugin: Geometrical value not computed. Check registration dependency flags."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorInvalidAltitudeReference.__doc__ = "Access Constraint Plugin: Invalid AgEAltitudeReference enum."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorInvalidApparentPositionType.__doc__ = "Access Constraint Plugin: Invalid AgEAccessApparentPositionType enum."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorInvalidDimension.__doc__ = "Access Constraint Plugin: Invalid dimension name."
AgEAccessConstraintPluginErrorCodes.eAccessConstraintPluginErrorInvalidWeight.__doc__ = "Access Constraint Plugin: Invalid computational weight value. Must be positive."

agcls.AgTypeNameMap["AgEAccessConstraintPluginErrorCodes"] = AgEAccessConstraintPluginErrorCodes

class AgEAccessConstraintObjectType(IntEnum):
    """Enumeration of valid objects for access constraint plugins."""
   
    eAircraft = 1
    """Aircraft."""
    eFacility = 8
    """Facility."""
    eGroundVehicle = 9
    """Ground Vehicle."""
    eLaunchVehicle = 10
    """Launch Vehicle."""
    eMissile = 13
    """Missile."""
    ePlanet = 15
    """Planet."""
    ePlace = 25
    """Place."""
    eRadar = 16
    """Radar."""
    eReceiver = 17
    """Receiver."""
    eSatellite = 18
    """Satellite."""
    eSensor = 20
    """Sensor."""
    eShip = 21
    """Ship."""
    eStar = 22
    """Star."""
    eSubmarine = 30
    """Submarine."""
    eTarget = 23
    """Target."""
    eTransmitter = 24
    """Transmitter."""

AgEAccessConstraintObjectType.eAircraft.__doc__ = "Aircraft."
AgEAccessConstraintObjectType.eFacility.__doc__ = "Facility."
AgEAccessConstraintObjectType.eGroundVehicle.__doc__ = "Ground Vehicle."
AgEAccessConstraintObjectType.eLaunchVehicle.__doc__ = "Launch Vehicle."
AgEAccessConstraintObjectType.eMissile.__doc__ = "Missile."
AgEAccessConstraintObjectType.ePlanet.__doc__ = "Planet."
AgEAccessConstraintObjectType.ePlace.__doc__ = "Place."
AgEAccessConstraintObjectType.eRadar.__doc__ = "Radar."
AgEAccessConstraintObjectType.eReceiver.__doc__ = "Receiver."
AgEAccessConstraintObjectType.eSatellite.__doc__ = "Satellite."
AgEAccessConstraintObjectType.eSensor.__doc__ = "Sensor."
AgEAccessConstraintObjectType.eShip.__doc__ = "Ship."
AgEAccessConstraintObjectType.eStar.__doc__ = "Star."
AgEAccessConstraintObjectType.eSubmarine.__doc__ = "Submarine."
AgEAccessConstraintObjectType.eTarget.__doc__ = "Target."
AgEAccessConstraintObjectType.eTransmitter.__doc__ = "Transmitter."

agcls.AgTypeNameMap["AgEAccessConstraintObjectType"] = AgEAccessConstraintObjectType

class AgEAccessConstraintDependencyFlags(IntEnum):
    """Enumeration of Access Constraint Dependency Flags"""
   
    eDependencyRelativePosVel = 0x0001
    """Relative position and velocity"""
    eDependencyRelativeAcc = 0x0002
    """Relative acceleration"""
    eDependencyPosVel = 0x0004
    """Position and velocity"""
    eDependencyAcc = 0x0008
    """Acceleration"""
    eDependencyAttitude = 0x0010
    """Attitude"""
    eDependencyRelSun = 0x0020
    """Relative position of Sun"""
    eDependencyNone = 0x1000
    """No dependencies nor light time delay effects computed"""

AgEAccessConstraintDependencyFlags.eDependencyRelativePosVel.__doc__ = "Relative position and velocity"
AgEAccessConstraintDependencyFlags.eDependencyRelativeAcc.__doc__ = "Relative acceleration"
AgEAccessConstraintDependencyFlags.eDependencyPosVel.__doc__ = "Position and velocity"
AgEAccessConstraintDependencyFlags.eDependencyAcc.__doc__ = "Acceleration"
AgEAccessConstraintDependencyFlags.eDependencyAttitude.__doc__ = "Attitude"
AgEAccessConstraintDependencyFlags.eDependencyRelSun.__doc__ = "Relative position of Sun"
AgEAccessConstraintDependencyFlags.eDependencyNone.__doc__ = "No dependencies nor light time delay effects computed"

agcls.AgTypeNameMap["AgEAccessConstraintDependencyFlags"] = AgEAccessConstraintDependencyFlags

class AgEAccessLightTimeDelayFrame(IntEnum):
    """Enumeration of frames used in Access to compute light time delay."""
   
    eLightTimeDelayFrameCBI = 1
    """CentralBody Inertial frame."""
    eLightTimeDelayFrameSSBary = 2
    """Solar system barycenter frame."""

AgEAccessLightTimeDelayFrame.eLightTimeDelayFrameCBI.__doc__ = "CentralBody Inertial frame."
AgEAccessLightTimeDelayFrame.eLightTimeDelayFrameSSBary.__doc__ = "Solar system barycenter frame."

agcls.AgTypeNameMap["AgEAccessLightTimeDelayFrame"] = AgEAccessLightTimeDelayFrame

class AgEApparentPositionSignalSense(IntEnum):
    """Enumeration of the signal sense of the apparent position computation."""
   
    eTransmitSignal = 1
    """Transmit signal."""
    eReceiveSignal = 2
    """Receive signal."""

AgEApparentPositionSignalSense.eTransmitSignal.__doc__ = "Transmit signal."
AgEApparentPositionSignalSense.eReceiveSignal.__doc__ = "Receive signal."

agcls.AgTypeNameMap["AgEApparentPositionSignalSense"] = AgEApparentPositionSignalSense

class AgEApparentPositionAberrationType(IntEnum):
    """Enumeration of methods of incorporating aberration into the apparent position computation."""
   
    eAberrationTotal = 1
    """The total effect of aberration."""
    eAberrationAnnual = 2
    """The annual effect of aberration."""
    eAberrationNone = 3
    """No aberration."""

AgEApparentPositionAberrationType.eAberrationTotal.__doc__ = "The total effect of aberration."
AgEApparentPositionAberrationType.eAberrationAnnual.__doc__ = "The annual effect of aberration."
AgEApparentPositionAberrationType.eAberrationNone.__doc__ = "No aberration."

agcls.AgTypeNameMap["AgEApparentPositionAberrationType"] = AgEApparentPositionAberrationType

class AgEAccessApparentPositionType(IntEnum):
    """Enumeration of types of apparent positions computed by Access."""
   
    eLightPathApparentPosition = 1
    """Light path apparent position. Accounts for the light time delay (if applied) between objects."""
    eRefractedApparentPosition = 2
    """Refracted apparent position. Accounts for refraction effects (if applied) on the light path apparent position."""
    eProperApparentPosition = 3
    """Proper Apparent position. Accounts for aberration effects (depending on the aberration type applied) on the refracted apparent position."""

AgEAccessApparentPositionType.eLightPathApparentPosition.__doc__ = "Light path apparent position. Accounts for the light time delay (if applied) between objects."
AgEAccessApparentPositionType.eRefractedApparentPosition.__doc__ = "Refracted apparent position. Accounts for refraction effects (if applied) on the light path apparent position."
AgEAccessApparentPositionType.eProperApparentPosition.__doc__ = "Proper Apparent position. Accounts for aberration effects (depending on the aberration type applied) on the refracted apparent position."

agcls.AgTypeNameMap["AgEAccessApparentPositionType"] = AgEAccessApparentPositionType

class AgEAltitudeReference(IntEnum):
    """Enumeration of references used for reporting altitude."""
   
    eEllispoidReference = 1
    """Central body ellipsoid."""
    eMSLReference = 2
    """Mean sea level. Only available for objects whose central body is Earth."""
    eTerrainReference = 3
    """Terrain."""

AgEAltitudeReference.eEllispoidReference.__doc__ = "Central body ellipsoid."
AgEAltitudeReference.eMSLReference.__doc__ = "Mean sea level. Only available for objects whose central body is Earth."
AgEAltitudeReference.eTerrainReference.__doc__ = "Terrain."

agcls.AgTypeNameMap["AgEAltitudeReference"] = AgEAltitudeReference


class IAgAccessConstraintPluginResultRegister(object):
    """Access Constraint Registration interface for the Register method."""

    _num_methods = 27
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Reset_method_offset = 1
    _ClearTargets_method_offset = 2
    _AddTarget_method_offset = 3
    _Targets_method_offset = 4
    _ObjectTypeName_method_offset = 5
    _Register_method_offset = 6
    _get_BaseObjectType_method_offset = 7
    _set_BaseObjectType_method_offset = 8
    _get_BaseDependency_method_offset = 9
    _set_BaseDependency_method_offset = 10
    _get_TargetDependency_method_offset = 11
    _set_TargetDependency_method_offset = 12
    _get_Dimension_method_offset = 13
    _set_Dimension_method_offset = 14
    _get_MinValue_method_offset = 15
    _set_MinValue_method_offset = 16
    _get_MaxValue_method_offset = 17
    _set_MaxValue_method_offset = 18
    _get_MaxRelMotion_method_offset = 19
    _set_MaxRelMotion_method_offset = 20
    _get_InstallDirectory_method_offset = 21
    _get_ConfigDirectory_method_offset = 22
    _Message_method_offset = 23
    _get_Weight_method_offset = 24
    _set_Weight_method_offset = 25
    _get_MaxTimeStep_method_offset = 26
    _set_MaxTimeStep_method_offset = 27
    _metadata = {
        "iid_data" : (4841786892696499208, 10668143819811320494),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAccessConstraintPluginResultRegister."""
        initialize_from_source_object(self, sourceObject, IAgAccessConstraintPluginResultRegister)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAccessConstraintPluginResultRegister)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAccessConstraintPluginResultRegister, None)
    
    _Reset_metadata = { "offset" : _Reset_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Reset(self) -> None:
        """Resets property values to defaults values and clears targets."""
        return self._intf.invoke(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._Reset_metadata, )

    _ClearTargets_metadata = { "offset" : _ClearTargets_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ClearTargets(self) -> None:
        """Clears the target list."""
        return self._intf.invoke(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._ClearTargets_metadata, )

    _AddTarget_metadata = { "offset" : _AddTarget_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessConstraintObjectType),) }
    def AddTarget(self, type:"AgEAccessConstraintObjectType") -> None:
        """Adds a target to the target list."""
        return self._intf.invoke(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._AddTarget_metadata, type)

    _Targets_metadata = { "offset" : _Targets_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def Targets(self) -> list:
        """Returns the current target list."""
        return self._intf.invoke(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._Targets_metadata, OutArg())

    _ObjectTypeName_metadata = { "offset" : _ObjectTypeName_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessConstraintObjectType), agmarshall.BSTR_arg,) }
    def ObjectTypeName(self, type:"AgEAccessConstraintObjectType") -> str:
        """Returns the name of associated object type."""
        return self._intf.invoke(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._ObjectTypeName_metadata, type, OutArg())

    _Register_metadata = { "offset" : _Register_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Register(self) -> None:
        """Registers the constraint using the current settings."""
        return self._intf.invoke(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._Register_metadata, )

    _get_BaseObjectType_metadata = { "offset" : _get_BaseObjectType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessConstraintObjectType),) }
    @property
    def BaseObjectType(self) -> "AgEAccessConstraintObjectType":
        """This object type is permitted to own this constraint."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_BaseObjectType_metadata)

    _set_BaseObjectType_metadata = { "offset" : _set_BaseObjectType_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessConstraintObjectType),) }
    @BaseObjectType.setter
    def BaseObjectType(self, type:"AgEAccessConstraintObjectType") -> None:
        """This object type is permitted to own this constraint."""
        return self._intf.set_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._set_BaseObjectType_metadata, type)

    _get_BaseDependency_metadata = { "offset" : _get_BaseDependency_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def BaseDependency(self) -> int:
        """Dependency mask of the Base object indicating the geometric dependencies of the constraint computation."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_BaseDependency_metadata)

    _set_BaseDependency_metadata = { "offset" : _set_BaseDependency_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @BaseDependency.setter
    def BaseDependency(self, newDepMask:int) -> None:
        """Dependency mask of the Base object indicating the geometric dependencies of the constraint computation."""
        return self._intf.set_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._set_BaseDependency_metadata, newDepMask)

    _get_TargetDependency_metadata = { "offset" : _get_TargetDependency_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def TargetDependency(self) -> int:
        """Dependency mask of the Target object indicating the geometric dependencies of the constraint computation."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_TargetDependency_metadata)

    _set_TargetDependency_metadata = { "offset" : _set_TargetDependency_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @TargetDependency.setter
    def TargetDependency(self, newDepMask:int) -> None:
        """Dependency mask of the Target object indicating the geometric dependencies of the constraint computation."""
        return self._intf.set_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._set_TargetDependency_metadata, newDepMask)

    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Dimension(self) -> str:
        """Dimension of the computed constraint value."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_Dimension_metadata)

    _set_Dimension_metadata = { "offset" : _set_Dimension_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Dimension.setter
    def Dimension(self, newDimension:str) -> None:
        """Dimension of the computed constraint value."""
        return self._intf.set_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._set_Dimension_metadata, newDimension)

    _get_MinValue_metadata = { "offset" : _get_MinValue_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def MinValue(self) -> float:
        """Minimum value of the computed constraint value."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_MinValue_metadata)

    _set_MinValue_metadata = { "offset" : _set_MinValue_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @MinValue.setter
    def MinValue(self, newMinValue:float) -> None:
        """Minimum value of the computed constraint value."""
        return self._intf.set_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._set_MinValue_metadata, newMinValue)

    _get_MaxValue_metadata = { "offset" : _get_MaxValue_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def MaxValue(self) -> float:
        """Maximum value of the computed constraint value."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_MaxValue_metadata)

    _set_MaxValue_metadata = { "offset" : _set_MaxValue_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @MaxValue.setter
    def MaxValue(self, newMaxValue:float) -> None:
        """Maximum value of the computed constraint value."""
        return self._intf.set_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._set_MaxValue_metadata, newMaxValue)

    _get_MaxRelMotion_metadata = { "offset" : _get_MaxRelMotion_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def MaxRelMotion(self) -> float:
        """Maximum relative motion (in degrees) allowed between constraint samples."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_MaxRelMotion_metadata)

    _set_MaxRelMotion_metadata = { "offset" : _set_MaxRelMotion_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @MaxRelMotion.setter
    def MaxRelMotion(self, newMaxRelMotion:float) -> None:
        """Maximum relative motion (in dgerees) allowed between constraint samples."""
        return self._intf.set_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._set_MaxRelMotion_metadata, newMaxRelMotion)

    _get_InstallDirectory_metadata = { "offset" : _get_InstallDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def InstallDirectory(self) -> str:
        """The directory path of the installation of the application."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_InstallDirectory_metadata)

    _get_ConfigDirectory_metadata = { "offset" : _get_ConfigDirectory_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ConfigDirectory(self) -> str:
        """The directory path of the user configuration area."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_ConfigDirectory_metadata)

    _Message_metadata = { "offset" : _Message_method_offset,
            "arg_types" : (agcom.LONG, agcom.BSTR,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtLogMsgType), agmarshall.BSTR_arg,) }
    def Message(self, msgType:"AgEUtLogMsgType", message:str) -> None:
        """Send a message to the message viewer."""
        return self._intf.invoke(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._Message_metadata, msgType, message)

    _get_Weight_metadata = { "offset" : _get_Weight_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Weight(self) -> int:
        """Computational weight of the constraint. Must be positive."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_Weight_metadata)

    _set_Weight_metadata = { "offset" : _set_Weight_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @Weight.setter
    def Weight(self, newWeight:int) -> None:
        """Computational weight of the constraint. Must be positive."""
        return self._intf.set_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._set_Weight_metadata, newWeight)

    _get_MaxTimeStep_metadata = { "offset" : _get_MaxTimeStep_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def MaxTimeStep(self) -> float:
        """Maximum time step (in secs) allowed between constraint samples."""
        return self._intf.get_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._get_MaxTimeStep_metadata)

    _set_MaxTimeStep_metadata = { "offset" : _set_MaxTimeStep_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @MaxTimeStep.setter
    def MaxTimeStep(self, newMaxTimeStep:float) -> None:
        """Maximum time step (in secs) allowed between constraint samples."""
        return self._intf.set_property(IAgAccessConstraintPluginResultRegister._metadata, IAgAccessConstraintPluginResultRegister._set_MaxTimeStep_metadata, newMaxTimeStep)

    _property_names[BaseObjectType] = "BaseObjectType"
    _property_names[BaseDependency] = "BaseDependency"
    _property_names[TargetDependency] = "TargetDependency"
    _property_names[Dimension] = "Dimension"
    _property_names[MinValue] = "MinValue"
    _property_names[MaxValue] = "MaxValue"
    _property_names[MaxRelMotion] = "MaxRelMotion"
    _property_names[InstallDirectory] = "InstallDirectory"
    _property_names[ConfigDirectory] = "ConfigDirectory"
    _property_names[Weight] = "Weight"
    _property_names[MaxTimeStep] = "MaxTimeStep"


agcls.AgClassCatalog.add_catalog_entry((4841786892696499208, 10668143819811320494), IAgAccessConstraintPluginResultRegister)
agcls.AgTypeNameMap["IAgAccessConstraintPluginResultRegister"] = IAgAccessConstraintPluginResultRegister

class IAgAccessConstraintPluginObjectDescriptor(object):
    """Access Constraint Plugin Object Descriptor interface."""

    _num_methods = 10
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_IsValid_method_offset = 1
    _get_VectorToolProvider_method_offset = 2
    _get_ObjectType_method_offset = 3
    _get_ObjectPath_method_offset = 4
    _get_ShortDescription_method_offset = 5
    _set_ShortDescription_method_offset = 6
    _get_LongDescription_method_offset = 7
    _set_LongDescription_method_offset = 8
    _get_CentralBodyName_method_offset = 9
    _get_CalcToolProvider_method_offset = 10
    _metadata = {
        "iid_data" : (4841808593105500262, 14796445989463698820),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAccessConstraintPluginObjectDescriptor."""
        initialize_from_source_object(self, sourceObject, IAgAccessConstraintPluginObjectDescriptor)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAccessConstraintPluginObjectDescriptor)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAccessConstraintPluginObjectDescriptor, None)
    
    _get_IsValid_metadata = { "offset" : _get_IsValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsValid(self) -> bool:
        """True when the object is a valid object. If false, none of the other methods return valid data."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._get_IsValid_metadata)

    _get_VectorToolProvider_metadata = { "offset" : _get_VectorToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def VectorToolProvider(self) -> "IAgCrdnPluginProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._get_VectorToolProvider_metadata)

    _get_ObjectType_metadata = { "offset" : _get_ObjectType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessConstraintObjectType),) }
    @property
    def ObjectType(self) -> "AgEAccessConstraintObjectType":
        """The object type of the object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._get_ObjectType_metadata)

    _get_ObjectPath_metadata = { "offset" : _get_ObjectPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjectPath(self) -> str:
        """The STK object path of the object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._get_ObjectPath_metadata)

    _get_ShortDescription_metadata = { "offset" : _get_ShortDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ShortDescription(self) -> str:
        """The short description of the object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._get_ShortDescription_metadata)

    _set_ShortDescription_metadata = { "offset" : _set_ShortDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ShortDescription.setter
    def ShortDescription(self, newDescription:str) -> None:
        """The short description of the object."""
        return self._intf.set_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._set_ShortDescription_metadata, newDescription)

    _get_LongDescription_metadata = { "offset" : _get_LongDescription_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LongDescription(self) -> str:
        """The long description of the object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._get_LongDescription_metadata)

    _set_LongDescription_metadata = { "offset" : _set_LongDescription_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @LongDescription.setter
    def LongDescription(self, newDescription:str) -> None:
        """The long description of the object."""
        return self._intf.set_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._set_LongDescription_metadata, newDescription)

    _get_CentralBodyName_metadata = { "offset" : _get_CentralBodyName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CentralBodyName(self) -> str:
        """The name of the central body for this object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._get_CentralBodyName_metadata)

    _get_CalcToolProvider_metadata = { "offset" : _get_CalcToolProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CalcToolProvider(self) -> "IAgCrdnPluginCalcProvider":
        """Creates an IAgCrdnPluginProvider object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectDescriptor._metadata, IAgAccessConstraintPluginObjectDescriptor._get_CalcToolProvider_metadata)

    _property_names[IsValid] = "IsValid"
    _property_names[VectorToolProvider] = "VectorToolProvider"
    _property_names[ObjectType] = "ObjectType"
    _property_names[ObjectPath] = "ObjectPath"
    _property_names[ShortDescription] = "ShortDescription"
    _property_names[LongDescription] = "LongDescription"
    _property_names[CentralBodyName] = "CentralBodyName"
    _property_names[CalcToolProvider] = "CalcToolProvider"


agcls.AgClassCatalog.add_catalog_entry((4841808593105500262, 14796445989463698820), IAgAccessConstraintPluginObjectDescriptor)
agcls.AgTypeNameMap["IAgAccessConstraintPluginObjectDescriptor"] = IAgAccessConstraintPluginObjectDescriptor

class IAgAccessConstraintPluginResultPreCompute(object):
    """Access Constraint Plugin Result interface for the PreCompute method."""

    _num_methods = 2
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Base_method_offset = 1
    _get_Target_method_offset = 2
    _metadata = {
        "iid_data" : (4878954334194620734, 5091899640160099772),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAccessConstraintPluginResultPreCompute."""
        initialize_from_source_object(self, sourceObject, IAgAccessConstraintPluginResultPreCompute)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAccessConstraintPluginResultPreCompute)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAccessConstraintPluginResultPreCompute, None)
    
    _get_Base_metadata = { "offset" : _get_Base_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Base(self) -> "IAgAccessConstraintPluginObjectDescriptor":
        """An interface to a description of the object that owns this constraint."""
        return self._intf.get_property(IAgAccessConstraintPluginResultPreCompute._metadata, IAgAccessConstraintPluginResultPreCompute._get_Base_metadata)

    _get_Target_metadata = { "offset" : _get_Target_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Target(self) -> "IAgAccessConstraintPluginObjectDescriptor":
        """An interface to a description of the other object involved with this constraint."""
        return self._intf.get_property(IAgAccessConstraintPluginResultPreCompute._metadata, IAgAccessConstraintPluginResultPreCompute._get_Target_metadata)

    _property_names[Base] = "Base"
    _property_names[Target] = "Target"


agcls.AgClassCatalog.add_catalog_entry((4878954334194620734, 5091899640160099772), IAgAccessConstraintPluginResultPreCompute)
agcls.AgTypeNameMap["IAgAccessConstraintPluginResultPreCompute"] = IAgAccessConstraintPluginResultPreCompute

class IAgAccessConstraintPluginResultPostCompute(object):
    """Access Constraint Plugin Result interface for the PostCompute method."""

    _num_methods = 2
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Base_method_offset = 1
    _get_Target_method_offset = 2
    _metadata = {
        "iid_data" : (5199839075679570937, 10391326488783215273),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAccessConstraintPluginResultPostCompute."""
        initialize_from_source_object(self, sourceObject, IAgAccessConstraintPluginResultPostCompute)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAccessConstraintPluginResultPostCompute)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAccessConstraintPluginResultPostCompute, None)
    
    _get_Base_metadata = { "offset" : _get_Base_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Base(self) -> "IAgAccessConstraintPluginObjectDescriptor":
        """An interface to a description of the object that owns this constraint."""
        return self._intf.get_property(IAgAccessConstraintPluginResultPostCompute._metadata, IAgAccessConstraintPluginResultPostCompute._get_Base_metadata)

    _get_Target_metadata = { "offset" : _get_Target_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Target(self) -> "IAgAccessConstraintPluginObjectDescriptor":
        """An interface to a description of the other object involved with this constraint."""
        return self._intf.get_property(IAgAccessConstraintPluginResultPostCompute._metadata, IAgAccessConstraintPluginResultPostCompute._get_Target_metadata)

    _property_names[Base] = "Base"
    _property_names[Target] = "Target"


agcls.AgClassCatalog.add_catalog_entry((5199839075679570937, 10391326488783215273), IAgAccessConstraintPluginResultPostCompute)
agcls.AgTypeNameMap["IAgAccessConstraintPluginResultPostCompute"] = IAgAccessConstraintPluginResultPostCompute

class IAgAccessConstraintPluginObjectData(object):
    """Access Constraint Plugin Object Data interface used to get inputs and outputs during the Evaluate method call."""

    _num_methods = 33
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Descriptor_method_offset = 1
    _get_CentralBodyName_method_offset = 2
    _get_SignalSense_method_offset = 3
    _get_IsClockHost_method_offset = 4
    _get_IsRefractionComputed_method_offset = 5
    _get_GeometryMask_method_offset = 6
    _DayCount_method_offset = 7
    _DayCount_Array_method_offset = 8
    _Position_method_offset = 9
    _Position_Array_method_offset = 10
    _Velocity_method_offset = 11
    _Velocity_Array_method_offset = 12
    _Acceleration_method_offset = 13
    _Acceleration_Array_method_offset = 14
    _LatLonAlt_method_offset = 15
    _LatLonAlt_Array_method_offset = 16
    _Altitude_method_offset = 17
    _Range_method_offset = 18
    _RelativePosition_method_offset = 19
    _RelativePosition_Array_method_offset = 20
    _RelativeVelocity_method_offset = 21
    _RelativeVelocity_Array_method_offset = 22
    _RelativeAcceleration_method_offset = 23
    _RelativeAcceleration_Array_method_offset = 24
    _ApparentSunPosition_method_offset = 25
    _ApparentSunPosition_Array_method_offset = 26
    _Attitude_method_offset = 27
    _Attitude_Array_method_offset = 28
    _AngularVelocity_method_offset = 29
    _AngularVelocity_Array_method_offset = 30
    _DateElements_method_offset = 31
    _DateElements_Array_method_offset = 32
    _DateString_method_offset = 33
    _metadata = {
        "iid_data" : (5361481920311100818, 15848286910530104485),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAccessConstraintPluginObjectData."""
        initialize_from_source_object(self, sourceObject, IAgAccessConstraintPluginObjectData)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAccessConstraintPluginObjectData)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAccessConstraintPluginObjectData, None)
    
    _get_Descriptor_metadata = { "offset" : _get_Descriptor_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Descriptor(self) -> "IAgAccessConstraintPluginObjectDescriptor":
        """An interface to a description of the object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._get_Descriptor_metadata)

    _get_CentralBodyName_metadata = { "offset" : _get_CentralBodyName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CentralBodyName(self) -> str:
        """The name of the central body for this object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._get_CentralBodyName_metadata)

    _get_SignalSense_metadata = { "offset" : _get_SignalSense_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEApparentPositionSignalSense),) }
    @property
    def SignalSense(self) -> "AgEApparentPositionSignalSense":
        """The signal sense for this object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._get_SignalSense_metadata)

    _get_IsClockHost_metadata = { "offset" : _get_IsClockHost_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsClockHost(self) -> bool:
        """True if this object is the clock host for the access computation."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._get_IsClockHost_metadata)

    _get_IsRefractionComputed_metadata = { "offset" : _get_IsRefractionComputed_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsRefractionComputed(self) -> bool:
        """True if refraction was computed for the apparent relative position of the other object."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._get_IsRefractionComputed_metadata)

    _get_GeometryMask_metadata = { "offset" : _get_GeometryMask_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def GeometryMask(self) -> int:
        """A bit mask of AgEAccessConstraintDependencyFlags indicating which geometrical data was computed."""
        return self._intf.get_property(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._get_GeometryMask_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """The current time in requested time scale of the object expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._DayCount_Array_metadata, scale, OutArg())

    _Position_Array_metadata = { "offset" : _Position_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def Position_Array(self, frame:"AgEUtFrame") -> list:
        """The object position in the requested frame, returned as an array representing x, y, z. Only eUtFrameInertial and eUtFrameFixed are supported. Useful for scripting clients."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._Position_Array_metadata, frame, OutArg())

    _Velocity_Array_metadata = { "offset" : _Velocity_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def Velocity_Array(self, frame:"AgEUtFrame") -> list:
        """The object velocity in the requested frame, returned as an array representing vx, vy, vz. Only eUtFrameInertial and eUtFrameFixed are supported. Useful for scripting clients."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._Velocity_Array_metadata, frame, OutArg())

    _Acceleration_Array_metadata = { "offset" : _Acceleration_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def Acceleration_Array(self, frame:"AgEUtFrame") -> list:
        """The object acceleration in the requested frame, returned as an array representing ax, ay, az. Only eUtFrameInertial and eUtFrameFixed are supported. Useful for scripting clients."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._Acceleration_Array_metadata, frame, OutArg())

    _LatLonAlt_Array_metadata = { "offset" : _LatLonAlt_Array_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def LatLonAlt_Array(self) -> list:
        """The detic latitude, detic longitude, and altitude of the object, returned as an array representing latitude, longitude, altitude. Altitude is measured wrt the central body ellispoid of the object. (eg. Earth uses WGS84)"""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._LatLonAlt_Array_metadata, OutArg())

    _Altitude_metadata = { "offset" : _Altitude_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAltitudeReference), agmarshall.DOUBLE_arg,) }
    def Altitude(self, altRef:"AgEAltitudeReference") -> float:
        """The altitude of the object wrt the requested reference."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._Altitude_metadata, altRef, OutArg())

    _Range_metadata = { "offset" : _Range_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessApparentPositionType), agmarshall.DOUBLE_arg,) }
    def Range(self, type:"AgEAccessApparentPositionType") -> float:
        """Apparent range between the objects."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._Range_metadata, type, OutArg())

    _RelativePosition_Array_metadata = { "offset" : _RelativePosition_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessApparentPositionType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def RelativePosition_Array(self, type:"AgEAccessApparentPositionType", frame:"AgEUtFrame") -> list:
        """The apparent relative position of the other object with respect to this object, in the requested frame, returned as an array representing x, y, z. Only eUtFrameInertial and eUtFrameFixed are supported."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._RelativePosition_Array_metadata, type, frame, OutArg())

    _RelativeVelocity_Array_metadata = { "offset" : _RelativeVelocity_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessApparentPositionType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def RelativeVelocity_Array(self, type:"AgEAccessApparentPositionType", frame:"AgEUtFrame") -> list:
        """The apparent relative velocity of the other object with respect to this object, in the requested frame, returned as an array representing vx, vy, vz. Only eUtFrameInertial and eUtFrameFixed are supported."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._RelativeVelocity_Array_metadata, type, frame, OutArg())

    _RelativeAcceleration_Array_metadata = { "offset" : _RelativeAcceleration_Array_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessApparentPositionType), agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def RelativeAcceleration_Array(self, type:"AgEAccessApparentPositionType", frame:"AgEUtFrame") -> list:
        """The apparent relative acceleration of the other object with respect to this object, in the requested frame, returned as an array representing ax, ay, az. Only eUtFrameInertial and eUtFrameFixed are supported."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._RelativeAcceleration_Array_metadata, type, frame, OutArg())

    _ApparentSunPosition_Array_metadata = { "offset" : _ApparentSunPosition_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def ApparentSunPosition_Array(self, frame:"AgEUtFrame") -> list:
        """The apparent sun position with respect to the object in the requested frame, returned as an array representing x, y, z. Only eUtFrameInertial and eUtFrameFixed are supported. Useful for scripting clients."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._ApparentSunPosition_Array_metadata, frame, OutArg())

    _Attitude_Array_metadata = { "offset" : _Attitude_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def Attitude_Array(self, frame:"AgEUtFrame") -> list:
        """The attitude of the body frame of the object wrt the requested frame, returned as an array representing Q1, Q2, Q3 Q4. Only eUtFrameInertial and eUtFrameFixed are supported."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._Attitude_Array_metadata, frame, OutArg())

    _AngularVelocity_Array_metadata = { "offset" : _AngularVelocity_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtFrame), agmarshall.LPSAFEARRAY_arg,) }
    def AngularVelocity_Array(self, frame:"AgEUtFrame") -> list:
        """The angular velocity of the body frame of the object wrt the requested frame, returned as an array representing wx, wy, wz. Only eUtFrameInertial and eUtFrameFixed are supported."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._AngularVelocity_Array_metadata, frame, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """The current time of the object in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAccessConstraintPluginObjectData._metadata, IAgAccessConstraintPluginObjectData._DateString_metadata, dateAbbrv, OutArg())

    _property_names[Descriptor] = "Descriptor"
    _property_names[CentralBodyName] = "CentralBodyName"
    _property_names[SignalSense] = "SignalSense"
    _property_names[IsClockHost] = "IsClockHost"
    _property_names[IsRefractionComputed] = "IsRefractionComputed"
    _property_names[GeometryMask] = "GeometryMask"


agcls.AgClassCatalog.add_catalog_entry((5361481920311100818, 15848286910530104485), IAgAccessConstraintPluginObjectData)
agcls.AgTypeNameMap["IAgAccessConstraintPluginObjectData"] = IAgAccessConstraintPluginObjectData

class IAgAccessConstraintPluginResultEval(object):
    """Access Constraint Plugin Result interface for the Evaluate method."""

    _num_methods = 16
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Value_method_offset = 1
    _set_Value_method_offset = 2
    _get_MaxRelMotion_method_offset = 3
    _set_MaxRelMotion_method_offset = 4
    _get_StepSize_method_offset = 5
    _set_StepSize_method_offset = 6
    _get_IsLightTimeDelayConsidered_method_offset = 7
    _get_LightTimeDelayFrame_method_offset = 8
    _get_AberrationType_method_offset = 9
    _get_LightTimeDelay_method_offset = 10
    _get_LightPathRange_method_offset = 11
    _DayCount_method_offset = 12
    _DayCount_Array_method_offset = 13
    _DateElements_method_offset = 14
    _DateElements_Array_method_offset = 15
    _DateString_method_offset = 16
    _metadata = {
        "iid_data" : (4655138098806739612, 16847745053108783507),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgAccessConstraintPluginResultEval."""
        initialize_from_source_object(self, sourceObject, IAgAccessConstraintPluginResultEval)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgAccessConstraintPluginResultEval)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgAccessConstraintPluginResultEval, None)
    
    _get_Value_metadata = { "offset" : _get_Value_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Value(self) -> float:
        """The current value of the constraint."""
        return self._intf.get_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._get_Value_metadata)

    _set_Value_metadata = { "offset" : _set_Value_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Value.setter
    def Value(self, newValue:float) -> None:
        """The current value of the constraint."""
        return self._intf.set_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._set_Value_metadata, newValue)

    _get_MaxRelMotion_metadata = { "offset" : _get_MaxRelMotion_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def MaxRelMotion(self) -> float:
        """Maximum relative motion (in degrees) allowed between constraint samples."""
        return self._intf.get_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._get_MaxRelMotion_metadata)

    _set_MaxRelMotion_metadata = { "offset" : _set_MaxRelMotion_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @MaxRelMotion.setter
    def MaxRelMotion(self, newMaxRelMotion:float) -> None:
        """Maximum relative motion (in degrees) allowed between constraint samples."""
        return self._intf.set_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._set_MaxRelMotion_metadata, newMaxRelMotion)

    _get_StepSize_metadata = { "offset" : _get_StepSize_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def StepSize(self) -> float:
        """The current time step taken (secs)."""
        return self._intf.get_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._get_StepSize_metadata)

    _set_StepSize_metadata = { "offset" : _set_StepSize_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @StepSize.setter
    def StepSize(self, newRequestedStepSize:float) -> None:
        """The requested next time step to take (secs)."""
        return self._intf.set_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._set_StepSize_metadata, newRequestedStepSize)

    _get_IsLightTimeDelayConsidered_metadata = { "offset" : _get_IsLightTimeDelayConsidered_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsLightTimeDelayConsidered(self) -> bool:
        """True when light time delay is considered."""
        return self._intf.get_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._get_IsLightTimeDelayConsidered_metadata)

    _get_LightTimeDelayFrame_metadata = { "offset" : _get_LightTimeDelayFrame_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAccessLightTimeDelayFrame),) }
    @property
    def LightTimeDelayFrame(self) -> "AgEAccessLightTimeDelayFrame":
        """Frame in which light time delay is computed."""
        return self._intf.get_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._get_LightTimeDelayFrame_metadata)

    _get_AberrationType_metadata = { "offset" : _get_AberrationType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEApparentPositionAberrationType),) }
    @property
    def AberrationType(self) -> "AgEApparentPositionAberrationType":
        """The type of aberration applied"""
        return self._intf.get_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._get_AberrationType_metadata)

    _get_LightTimeDelay_metadata = { "offset" : _get_LightTimeDelay_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LightTimeDelay(self) -> float:
        """Light time delay in seconds."""
        return self._intf.get_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._get_LightTimeDelay_metadata)

    _get_LightPathRange_metadata = { "offset" : _get_LightPathRange_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LightPathRange(self) -> float:
        """The range in meters between the Base and Target objects only accounting for light time delay if applied (not refraction nor aberration)."""
        return self._intf.get_property(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._get_LightPathRange_metadata)

    _DayCount_Array_metadata = { "offset" : _DayCount_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DayCount_Array(self, scale:"AgEUtTimeScale") -> list:
        """The current time in requested time scale of the object that is the clock host expressed in day count format returned as an array representing wholeDays, secsIntoDay. Useful for scripting clients."""
        return self._intf.invoke(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._DayCount_Array_metadata, scale, OutArg())

    _DateElements_Array_metadata = { "offset" : _DateElements_Array_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEUtTimeScale), agmarshall.LPSAFEARRAY_arg,) }
    def DateElements_Array(self, scale:"AgEUtTimeScale") -> list:
        """The current time of the object in requested time scale expressed in date format returned as the array: Year [yyyy], DayOfYear [1-366], Month [1-12], DayOfMonth [1-31], Hour [0-23], Minute [0-59], Seconds [0-60]. Useful for scripting clients."""
        return self._intf.invoke(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._DateElements_Array_metadata, scale, OutArg())

    _DateString_metadata = { "offset" : _DateString_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def DateString(self, dateAbbrv:str) -> str:
        """Current epoch expressed using the date format abbreviation specified."""
        return self._intf.invoke(IAgAccessConstraintPluginResultEval._metadata, IAgAccessConstraintPluginResultEval._DateString_metadata, dateAbbrv, OutArg())

    _property_names[Value] = "Value"
    _property_names[MaxRelMotion] = "MaxRelMotion"
    _property_names[StepSize] = "StepSize"
    _property_names[IsLightTimeDelayConsidered] = "IsLightTimeDelayConsidered"
    _property_names[LightTimeDelayFrame] = "LightTimeDelayFrame"
    _property_names[AberrationType] = "AberrationType"
    _property_names[LightTimeDelay] = "LightTimeDelay"
    _property_names[LightPathRange] = "LightPathRange"


agcls.AgClassCatalog.add_catalog_entry((4655138098806739612, 16847745053108783507), IAgAccessConstraintPluginResultEval)
agcls.AgTypeNameMap["IAgAccessConstraintPluginResultEval"] = IAgAccessConstraintPluginResultEval


class IAgAccessConstraintPlugin(object):
    """
    Access Constraint plugin interface for an  Access Constraint.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def DisplayName(self) -> str:
        """Triggered when the plugin is being registered. This is the name of the constraint used by STK."""
        raise STKPluginMethodNotImplementedError("DisplayName was not implemented.")

    def Register(self, result:"IAgAccessConstraintPluginResultRegister") -> None:
        """Triggered after application start-up, in order to register the constraint for specific STK object pairs for which this constraint is applicable."""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Init(self, site:"IAgUtPluginSite") -> bool:
        """Triggered just before the first computational event trigger."""
        raise STKPluginMethodNotImplementedError("Init was not implemented.")

    def PreCompute(self, result:"IAgAccessConstraintPluginResultPreCompute") -> bool:
        """Triggered prior to the calls to the Evaluate method, to allow for any required initialization."""
        raise STKPluginMethodNotImplementedError("PreCompute was not implemented.")

    def Evaluate(self, result:"IAgAccessConstraintPluginResultEval", baseData:"IAgAccessConstraintPluginObjectData", targetData:"IAgAccessConstraintPluginObjectData") -> bool:
        """Triggered when the plugin is evaluated for an access constraint value"""
        raise STKPluginMethodNotImplementedError("Evaluate was not implemented.")

    def PostCompute(self, result:"IAgAccessConstraintPluginResultPostCompute") -> bool:
        """Triggered after the calls to the Evaluate method, to allow for any required clean up."""
        raise STKPluginMethodNotImplementedError("PostCompute was not implemented.")

    def Free(self) -> None:
        """Triggered just before the plugin is destroyed."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")




class AgAccessConstraintPluginResultRegister(IAgAccessConstraintPluginResultRegister, SupportsDeleteCallback):
    """Access Constraint Registration interface for the Register method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAccessConstraintPluginResultRegister."""
        SupportsDeleteCallback.__init__(self)
        IAgAccessConstraintPluginResultRegister.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAccessConstraintPluginResultRegister._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAccessConstraintPluginResultRegister, [IAgAccessConstraintPluginResultRegister])

agcls.AgClassCatalog.add_catalog_entry((5611141315398317090, 4284440463404044440), AgAccessConstraintPluginResultRegister)
agcls.AgTypeNameMap["AgAccessConstraintPluginResultRegister"] = AgAccessConstraintPluginResultRegister

class AgAccessConstraintPluginObjectData(IAgAccessConstraintPluginObjectData, SupportsDeleteCallback):
    """Access Constraint Plugin Object Data interface used to get inputs and outputs during the Evaluate method call."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAccessConstraintPluginObjectData."""
        SupportsDeleteCallback.__init__(self)
        IAgAccessConstraintPluginObjectData.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAccessConstraintPluginObjectData._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAccessConstraintPluginObjectData, [IAgAccessConstraintPluginObjectData])

agcls.AgClassCatalog.add_catalog_entry((5701052550108165639, 15304958412089692565), AgAccessConstraintPluginObjectData)
agcls.AgTypeNameMap["AgAccessConstraintPluginObjectData"] = AgAccessConstraintPluginObjectData

class AgAccessConstraintPluginObjectDescriptor(IAgAccessConstraintPluginObjectDescriptor, SupportsDeleteCallback):
    """Access Constraint Plugin Object Descriptor interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAccessConstraintPluginObjectDescriptor."""
        SupportsDeleteCallback.__init__(self)
        IAgAccessConstraintPluginObjectDescriptor.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAccessConstraintPluginObjectDescriptor._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAccessConstraintPluginObjectDescriptor, [IAgAccessConstraintPluginObjectDescriptor])

agcls.AgClassCatalog.add_catalog_entry((5125463790580902993, 11785078193576358808), AgAccessConstraintPluginObjectDescriptor)
agcls.AgTypeNameMap["AgAccessConstraintPluginObjectDescriptor"] = AgAccessConstraintPluginObjectDescriptor

class AgAccessConstraintPluginResultPreCompute(IAgAccessConstraintPluginResultPreCompute, SupportsDeleteCallback):
    """Access Constraint Plugin Result interface for the PreCompute method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAccessConstraintPluginResultPreCompute."""
        SupportsDeleteCallback.__init__(self)
        IAgAccessConstraintPluginResultPreCompute.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAccessConstraintPluginResultPreCompute._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAccessConstraintPluginResultPreCompute, [IAgAccessConstraintPluginResultPreCompute])

agcls.AgClassCatalog.add_catalog_entry((5562066404399104228, 10521294113793772172), AgAccessConstraintPluginResultPreCompute)
agcls.AgTypeNameMap["AgAccessConstraintPluginResultPreCompute"] = AgAccessConstraintPluginResultPreCompute

class AgAccessConstraintPluginResultEval(IAgAccessConstraintPluginResultEval, SupportsDeleteCallback):
    """Access Constraint Plugin Result interface for the Evaluate method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAccessConstraintPluginResultEval."""
        SupportsDeleteCallback.__init__(self)
        IAgAccessConstraintPluginResultEval.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAccessConstraintPluginResultEval._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAccessConstraintPluginResultEval, [IAgAccessConstraintPluginResultEval])

agcls.AgClassCatalog.add_catalog_entry((5367073929045246204, 13567901225916487045), AgAccessConstraintPluginResultEval)
agcls.AgTypeNameMap["AgAccessConstraintPluginResultEval"] = AgAccessConstraintPluginResultEval

class AgAccessConstraintPluginResultPostCompute(IAgAccessConstraintPluginResultPostCompute, SupportsDeleteCallback):
    """Access Constraint Plugin Result interface for the PostCompute method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgAccessConstraintPluginResultPostCompute."""
        SupportsDeleteCallback.__init__(self)
        IAgAccessConstraintPluginResultPostCompute.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgAccessConstraintPluginResultPostCompute._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgAccessConstraintPluginResultPostCompute, [IAgAccessConstraintPluginResultPostCompute])

agcls.AgClassCatalog.add_catalog_entry((5408959034702046241, 6093463767441539467), AgAccessConstraintPluginResultPostCompute)
agcls.AgTypeNameMap["AgAccessConstraintPluginResultPostCompute"] = AgAccessConstraintPluginResultPostCompute


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
