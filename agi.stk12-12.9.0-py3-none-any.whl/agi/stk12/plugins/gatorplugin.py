################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgGatorConfiguredCalcObject", "AgGatorPluginProvider", "IAgGatorConfiguredCalcObject", "IAgGatorPluginProvider"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class IAgGatorConfiguredCalcObject(object):
    """Astrogator Calc Object interface which computes its value. Inputs to the Calc Object are provided by the DispInterface which must support IAgGatorState."""

    _num_methods = 1
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Evaluate_method_offset = 1
    _metadata = {
        "iid_data" : (5357684743903637304, 3579517978430594184),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgGatorConfiguredCalcObject."""
        initialize_from_source_object(self, sourceObject, IAgGatorConfiguredCalcObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgGatorConfiguredCalcObject)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgGatorConfiguredCalcObject, None)
    
    _Evaluate_metadata = { "offset" : _Evaluate_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IDispatch"), agmarshall.DOUBLE_arg,) }
    def Evaluate(self, dispInterface:"IDispatch") -> float:
        """Computes the Value (in internal units) at the time indicated by the interface. The interface must support IAgGatorState."""
        return self._intf.invoke(IAgGatorConfiguredCalcObject._metadata, IAgGatorConfiguredCalcObject._Evaluate_metadata, dispInterface, OutArg())


agcls.AgClassCatalog.add_catalog_entry((5357684743903637304, 3579517978430594184), IAgGatorConfiguredCalcObject)
agcls.AgTypeNameMap["IAgGatorConfiguredCalcObject"] = IAgGatorConfiguredCalcObject

class IAgGatorPluginProvider(object):
    """Astrogator plugin provider interface."""

    _num_methods = 1
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _ConfigureCalcObject_method_offset = 1
    _metadata = {
        "iid_data" : (5395916712632398760, 11355812639360693181),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgGatorPluginProvider."""
        initialize_from_source_object(self, sourceObject, IAgGatorPluginProvider)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgGatorPluginProvider)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgGatorPluginProvider, None)
    
    _ConfigureCalcObject_metadata = { "offset" : _ConfigureCalcObject_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ConfigureCalcObject(self, name:str) -> "IAgGatorConfiguredCalcObject":
        """Creates an IAgGatorCalcObject object from Astrogator component browser."""
        return self._intf.invoke(IAgGatorPluginProvider._metadata, IAgGatorPluginProvider._ConfigureCalcObject_metadata, name, OutArg())


agcls.AgClassCatalog.add_catalog_entry((5395916712632398760, 11355812639360693181), IAgGatorPluginProvider)
agcls.AgTypeNameMap["IAgGatorPluginProvider"] = IAgGatorPluginProvider



class AgGatorConfiguredCalcObject(IAgGatorConfiguredCalcObject, SupportsDeleteCallback):
    """Astrogator Calc object from the component browser"""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgGatorConfiguredCalcObject."""
        SupportsDeleteCallback.__init__(self)
        IAgGatorConfiguredCalcObject.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgGatorConfiguredCalcObject._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgGatorConfiguredCalcObject, [IAgGatorConfiguredCalcObject])

agcls.AgClassCatalog.add_catalog_entry((4872536430994838999, 6401904516032651661), AgGatorConfiguredCalcObject)
agcls.AgTypeNameMap["AgGatorConfiguredCalcObject"] = AgGatorConfiguredCalcObject

class AgGatorPluginProvider(IAgGatorPluginProvider, SupportsDeleteCallback):
    """Astrogator plugin provider."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgGatorPluginProvider."""
        SupportsDeleteCallback.__init__(self)
        IAgGatorPluginProvider.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgGatorPluginProvider._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgGatorPluginProvider, [IAgGatorPluginProvider])

agcls.AgClassCatalog.add_catalog_entry((4737397448869600994, 3068001010179843756), AgGatorPluginProvider)
agcls.AgTypeNameMap["AgGatorPluginProvider"] = AgGatorPluginProvider


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
