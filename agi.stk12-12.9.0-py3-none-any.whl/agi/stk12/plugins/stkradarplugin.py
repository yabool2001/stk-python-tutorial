################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgCRPolarizationCircular", "AgCRPolarizationElliptical", "AgCRPolarizationLinear", "AgEStkRadarPosVelProviderRole", 
"AgEStkRadarTerrainInterpMethod", "AgEStkRadarValidSystems", "AgStkRadarCBIntersectComputeParams", "AgStkRadarCBIntersectComputeResult", 
"AgStkRadarClutterGeometryComputeParams", "AgStkRadarClutterGeometryPluginRegInfo", "AgStkRadarClutterMapComputeParams", 
"AgStkRadarClutterPatch", "AgStkRadarClutterPatchCollection", "AgStkRadarFixedPRFProbabilityDetectionComputeParams", "AgStkRadarLink", 
"AgStkRadarLinkGeometry", "AgStkRadarPosVelProvider", "AgStkRadarPositionProvider", "AgStkRadarRcsComputeParams", "AgStkRadarRcsProcessSignalsParams", 
"AgStkRadarSTCAttenComputeParams", "AgStkRadarSignal", "IAgSTKRadarSTCAttenComputeParams", "IAgSTKRadarSTCAttenPlugin", 
"IAgStkRadarCBIntersectComputeParams", "IAgStkRadarCBIntersectComputeResult", "IAgStkRadarClutterGeometryComputeParams", 
"IAgStkRadarClutterGeometryPlugin", "IAgStkRadarClutterGeometryPluginRegInfo", "IAgStkRadarClutterGeometryPluginScatteringModels", 
"IAgStkRadarClutterMapComputeParams", "IAgStkRadarClutterMapPlugin", "IAgStkRadarClutterPatch", "IAgStkRadarClutterPatchCollection", 
"IAgStkRadarFixedPRFProbabilityDetectionComputeParams", "IAgStkRadarFixedPRFProbabilityDetectionPlugin", "IAgStkRadarLink", 
"IAgStkRadarLinkGeometry", "IAgStkRadarPosVelProvider", "IAgStkRadarRcsComputeParams", "IAgStkRadarRcsPlugin", "IAgStkRadarRcsProcessSignalsParams", 
"IAgStkRadarSignal"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *

from ..plugins.attrautomation import *
from ..plugins.utplugin import *
from ..plugins.crdnplugin import *
from ..plugins.commrdrfoundation import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEStkRadarValidSystems(IntEnum):
    """Enumeration of valid radar systems."""
   
    eStkRadarAllSystems = 1
    """All radar systems."""
    eStkRadarMonostaticSystemsOnly = 2
    """Monostatic radar system only."""
    eStkRadarBistaticSystemsOnly = 3
    """Bistatic radar system only."""

AgEStkRadarValidSystems.eStkRadarAllSystems.__doc__ = "All radar systems."
AgEStkRadarValidSystems.eStkRadarMonostaticSystemsOnly.__doc__ = "Monostatic radar system only."
AgEStkRadarValidSystems.eStkRadarBistaticSystemsOnly.__doc__ = "Bistatic radar system only."

agcls.AgTypeNameMap["AgEStkRadarValidSystems"] = AgEStkRadarValidSystems

class AgEStkRadarPosVelProviderRole(IntEnum):
    """Enumeration of the position and velocity providers roles."""
   
    eStkRadarTransmitterPosVelRole = 1
    """Transmitter"""
    eStkRadarReceiverPosVelRole = 2
    """Receiver"""
    eStkRadarTargetPosVelRole = 3
    """Target"""
    eStkRadarClutterPatchPosVelRole = 4
    """Clutter Patch"""

AgEStkRadarPosVelProviderRole.eStkRadarTransmitterPosVelRole.__doc__ = "Transmitter"
AgEStkRadarPosVelProviderRole.eStkRadarReceiverPosVelRole.__doc__ = "Receiver"
AgEStkRadarPosVelProviderRole.eStkRadarTargetPosVelRole.__doc__ = "Target"
AgEStkRadarPosVelProviderRole.eStkRadarClutterPatchPosVelRole.__doc__ = "Clutter Patch"

agcls.AgTypeNameMap["AgEStkRadarPosVelProviderRole"] = AgEStkRadarPosVelProviderRole

class AgEStkRadarTerrainInterpMethod(IntEnum):
    """Enumeration of terrain interpolation methods."""
   
    eStkRadarBilinearTerrainInterp = 1
    """Bilinear Interpolation"""
    eStkRadarHighestPostTerrainInterp = 2
    """Highest Post"""
    eStkRadarTriPlanarTerrainInterp = 3
    """Tri-Planar"""

AgEStkRadarTerrainInterpMethod.eStkRadarBilinearTerrainInterp.__doc__ = "Bilinear Interpolation"
AgEStkRadarTerrainInterpMethod.eStkRadarHighestPostTerrainInterp.__doc__ = "Highest Post"
AgEStkRadarTerrainInterpMethod.eStkRadarTriPlanarTerrainInterp.__doc__ = "Tri-Planar"

agcls.AgTypeNameMap["AgEStkRadarTerrainInterpMethod"] = AgEStkRadarTerrainInterpMethod


class IAgStkRadarCBIntersectComputeParams(object):
    """Interface implemented by an object that represents the input parameters for a central body intersect computation."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _GetBasePositionCBF_method_offset = 1
    _get_BasePositionCBFArray_method_offset = 2
    _SetBasePositionCBF_method_offset = 3
    _GetDirectionCBF_method_offset = 4
    _get_DirectionCBFArray_method_offset = 5
    _SetDirectionCBF_method_offset = 6
    _metadata = {
        "iid_data" : (5224585966846178189, 3376322059052726179),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarCBIntersectComputeParams."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarCBIntersectComputeParams)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarCBIntersectComputeParams)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarCBIntersectComputeParams, None)
    
    _GetBasePositionCBF_metadata = { "offset" : _GetBasePositionCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetBasePositionCBF(self) -> typing.Tuple[float, float, float]:
        """Gets the base position vector in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarCBIntersectComputeParams._metadata, IAgStkRadarCBIntersectComputeParams._GetBasePositionCBF_metadata, OutArg(), OutArg(), OutArg())

    _get_BasePositionCBFArray_metadata = { "offset" : _get_BasePositionCBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def BasePositionCBFArray(self) -> list:
        """Gets the base position vector in central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarCBIntersectComputeParams._metadata, IAgStkRadarCBIntersectComputeParams._get_BasePositionCBFArray_metadata)

    _SetBasePositionCBF_metadata = { "offset" : _SetBasePositionCBF_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetBasePositionCBF(self, x:float, y:float, z:float) -> None:
        """Sets the base position vector in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarCBIntersectComputeParams._metadata, IAgStkRadarCBIntersectComputeParams._SetBasePositionCBF_metadata, x, y, z)

    _GetDirectionCBF_metadata = { "offset" : _GetDirectionCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetDirectionCBF(self) -> typing.Tuple[float, float, float]:
        """Gets the direction vector in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarCBIntersectComputeParams._metadata, IAgStkRadarCBIntersectComputeParams._GetDirectionCBF_metadata, OutArg(), OutArg(), OutArg())

    _get_DirectionCBFArray_metadata = { "offset" : _get_DirectionCBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def DirectionCBFArray(self) -> list:
        """Gets the direction vector in the central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarCBIntersectComputeParams._metadata, IAgStkRadarCBIntersectComputeParams._get_DirectionCBFArray_metadata)

    _SetDirectionCBF_metadata = { "offset" : _SetDirectionCBF_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetDirectionCBF(self, x:float, y:float, z:float) -> None:
        """Sets the direction vector in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarCBIntersectComputeParams._metadata, IAgStkRadarCBIntersectComputeParams._SetDirectionCBF_metadata, x, y, z)

    _property_names[BasePositionCBFArray] = "BasePositionCBFArray"
    _property_names[DirectionCBFArray] = "DirectionCBFArray"


agcls.AgClassCatalog.add_catalog_entry((5224585966846178189, 3376322059052726179), IAgStkRadarCBIntersectComputeParams)
agcls.AgTypeNameMap["IAgStkRadarCBIntersectComputeParams"] = IAgStkRadarCBIntersectComputeParams

class IAgStkRadarCBIntersectComputeResult(object):
    """Interface implemented by an object that represents the result of a central body computation."""

    _num_methods = 11
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_IntersectionFound_method_offset = 1
    _GetIntercept1CBF_method_offset = 2
    _get_Intercept1CBFArray_method_offset = 3
    _GetIntercept2CBF_method_offset = 4
    _get_Intercept2CBFArray_method_offset = 5
    _get_Multiplier1_method_offset = 6
    _get_Multiplier2_method_offset = 7
    _GetBasePositionCBF_method_offset = 8
    _get_BasePositionCBFArray_method_offset = 9
    _GetDirectionCBF_method_offset = 10
    _get_DirectionCBFArray_method_offset = 11
    _metadata = {
        "iid_data" : (4735548837884208667, 8784532128239226021),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarCBIntersectComputeResult."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarCBIntersectComputeResult)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarCBIntersectComputeResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarCBIntersectComputeResult, None)
    
    _get_IntersectionFound_metadata = { "offset" : _get_IntersectionFound_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IntersectionFound(self) -> bool:
        """Gets the intersection found indicator."""
        return self._intf.get_property(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._get_IntersectionFound_metadata)

    _GetIntercept1CBF_metadata = { "offset" : _GetIntercept1CBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetIntercept1CBF(self) -> typing.Tuple[float, float, float]:
        """Gets the position vector of the first point of intersection in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._GetIntercept1CBF_metadata, OutArg(), OutArg(), OutArg())

    _get_Intercept1CBFArray_metadata = { "offset" : _get_Intercept1CBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def Intercept1CBFArray(self) -> list:
        """Gets the position vector  of the first point of intersection in the central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._get_Intercept1CBFArray_metadata)

    _GetIntercept2CBF_metadata = { "offset" : _GetIntercept2CBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetIntercept2CBF(self) -> typing.Tuple[float, float, float]:
        """Gets the position vector of the second point of intersection in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._GetIntercept2CBF_metadata, OutArg(), OutArg(), OutArg())

    _get_Intercept2CBFArray_metadata = { "offset" : _get_Intercept2CBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def Intercept2CBFArray(self) -> list:
        """Gets the position vector of the second point of the intersection in the central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._get_Intercept2CBFArray_metadata)

    _get_Multiplier1_metadata = { "offset" : _get_Multiplier1_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Multiplier1(self) -> float:
        """Gets the first multiplier."""
        return self._intf.get_property(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._get_Multiplier1_metadata)

    _get_Multiplier2_metadata = { "offset" : _get_Multiplier2_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Multiplier2(self) -> float:
        """Gets the second multiplier."""
        return self._intf.get_property(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._get_Multiplier2_metadata)

    _GetBasePositionCBF_metadata = { "offset" : _GetBasePositionCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetBasePositionCBF(self) -> typing.Tuple[float, float, float]:
        """Gets the base position vector in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._GetBasePositionCBF_metadata, OutArg(), OutArg(), OutArg())

    _get_BasePositionCBFArray_metadata = { "offset" : _get_BasePositionCBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def BasePositionCBFArray(self) -> list:
        """Gets the base position vector in the central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._get_BasePositionCBFArray_metadata)

    _GetDirectionCBF_metadata = { "offset" : _GetDirectionCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetDirectionCBF(self) -> typing.Tuple[float, float, float]:
        """Gets the direction vector in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._GetDirectionCBF_metadata, OutArg(), OutArg(), OutArg())

    _get_DirectionCBFArray_metadata = { "offset" : _get_DirectionCBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def DirectionCBFArray(self) -> list:
        """Gets the direction vector in the central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarCBIntersectComputeResult._metadata, IAgStkRadarCBIntersectComputeResult._get_DirectionCBFArray_metadata)

    _property_names[IntersectionFound] = "IntersectionFound"
    _property_names[Intercept1CBFArray] = "Intercept1CBFArray"
    _property_names[Intercept2CBFArray] = "Intercept2CBFArray"
    _property_names[Multiplier1] = "Multiplier1"
    _property_names[Multiplier2] = "Multiplier2"
    _property_names[BasePositionCBFArray] = "BasePositionCBFArray"
    _property_names[DirectionCBFArray] = "DirectionCBFArray"


agcls.AgClassCatalog.add_catalog_entry((4735548837884208667, 8784532128239226021), IAgStkRadarCBIntersectComputeResult)
agcls.AgTypeNameMap["IAgStkRadarCBIntersectComputeResult"] = IAgStkRadarCBIntersectComputeResult

class IAgStkRadarPosVelProvider(object):
    """Interface implemented by an object that provides the position and velocity for an STK radar object or radar target object."""

    _num_methods = 34
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_CurrentTime_method_offset = 1
    _GetVelocityCBF_method_offset = 2
    _get_VelocityCBFArray_method_offset = 3
    _GetPositionCBF_method_offset = 4
    _get_PositionCBFArray_method_offset = 5
    _GetPositionLLA_method_offset = 6
    _get_PositionLLAArray_method_offset = 7
    _get_LocalRadiusDetic_method_offset = 8
    _get_LocalRadiusCentric_method_offset = 9
    _GetSurfaceNormalDetic_method_offset = 10
    _get_SurfaceNormalDeticArray_method_offset = 11
    _GetSurfaceNormalCentric_method_offset = 12
    _get_SurfaceNormalCentricArray_method_offset = 13
    _GetTerrainHeight_method_offset = 14
    _GetTerrainHeightForLatLon_method_offset = 15
    _ComputeLocalRadiusDetic_method_offset = 16
    _ComputeLocalRadiusCentric_method_offset = 17
    _ComputeSurfaceNormalDetic_method_offset = 18
    _ComputeSurfaceNormalDeticArray_method_offset = 19
    _ComputeSurfaceNormalCentric_method_offset = 20
    _ComputeSurfaceNormalCentricArray_method_offset = 21
    _ComputeCentralBodyIntersect_method_offset = 22
    _ConvertCBFCartesianToLLA_method_offset = 23
    _ConvertCBFCartesianToLLAArray_method_offset = 24
    _ConvertLLAToCBFCartesian_method_offset = 25
    _ConvertLLAToCBFCartesianArray_method_offset = 26
    _ConvertCBFCartesianToVVLHCartesian_method_offset = 27
    _ConvertCBFCartesianToVVLHCartesianArray_method_offset = 28
    _ConvertBodyCartesianToCBFCartesian_method_offset = 29
    _ConvertBodyCartesianToCBFCartesianArray_method_offset = 30
    _ConvertCBFCartesianToBodyCartesian_method_offset = 31
    _ConvertCBFCartesianToBodyCartesianArray_method_offset = 32
    _get_Role_method_offset = 33
    _ComputeCentralBodyIntersectInCBF_method_offset = 34
    _metadata = {
        "iid_data" : (5114281978580293677, 15313427104105113246),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarPosVelProvider."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarPosVelProvider)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarPosVelProvider)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarPosVelProvider, None)
    
    _get_CurrentTime_metadata = { "offset" : _get_CurrentTime_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def CurrentTime(self) -> float:
        """Gets the current time in EpSec."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_CurrentTime_metadata)

    _GetVelocityCBF_metadata = { "offset" : _GetVelocityCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetVelocityCBF(self) -> typing.Tuple[float, float, float]:
        """Gets velocity in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetVelocityCBF_metadata, OutArg(), OutArg(), OutArg())

    _get_VelocityCBFArray_metadata = { "offset" : _get_VelocityCBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def VelocityCBFArray(self) -> list:
        """Gets velocity in the central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_VelocityCBFArray_metadata)

    _GetPositionCBF_metadata = { "offset" : _GetPositionCBF_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetPositionCBF(self) -> typing.Tuple[float, float, float]:
        """Gets position in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetPositionCBF_metadata, OutArg(), OutArg(), OutArg())

    _get_PositionCBFArray_metadata = { "offset" : _get_PositionCBFArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def PositionCBFArray(self) -> list:
        """Gets position in the central body fixed frame as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_PositionCBFArray_metadata)

    _GetPositionLLA_metadata = { "offset" : _GetPositionLLA_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetPositionLLA(self) -> typing.Tuple[float, float, float]:
        """Gets position in latitude, longitude, and altitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetPositionLLA_metadata, OutArg(), OutArg(), OutArg())

    _get_PositionLLAArray_metadata = { "offset" : _get_PositionLLAArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def PositionLLAArray(self) -> list:
        """Gets position in latitude, longitude, and altitude as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_PositionLLAArray_metadata)

    _get_LocalRadiusDetic_metadata = { "offset" : _get_LocalRadiusDetic_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LocalRadiusDetic(self) -> float:
        """Gets the central body radius detic using the position/velocity provider's current latitude and longitude."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_LocalRadiusDetic_metadata)

    _get_LocalRadiusCentric_metadata = { "offset" : _get_LocalRadiusCentric_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def LocalRadiusCentric(self) -> float:
        """Gets the central body radius centric using the position/velocity provider's current latitude and longitude."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_LocalRadiusCentric_metadata)

    _GetSurfaceNormalDetic_metadata = { "offset" : _GetSurfaceNormalDetic_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetSurfaceNormalDetic(self) -> typing.Tuple[float, float, float]:
        """Gets the surface normal detic."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetSurfaceNormalDetic_metadata, OutArg(), OutArg(), OutArg())

    _get_SurfaceNormalDeticArray_metadata = { "offset" : _get_SurfaceNormalDeticArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SurfaceNormalDeticArray(self) -> list:
        """Gets the surface normal detic as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_SurfaceNormalDeticArray_metadata)

    _GetSurfaceNormalCentric_metadata = { "offset" : _GetSurfaceNormalCentric_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetSurfaceNormalCentric(self) -> typing.Tuple[float, float, float]:
        """Gets the surface normal centric as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetSurfaceNormalCentric_metadata, OutArg(), OutArg(), OutArg())

    _get_SurfaceNormalCentricArray_metadata = { "offset" : _get_SurfaceNormalCentricArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def SurfaceNormalCentricArray(self) -> list:
        """Gets the surface normal centric as an array."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_SurfaceNormalCentricArray_metadata)

    _GetTerrainHeight_metadata = { "offset" : _GetTerrainHeight_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEStkRadarTerrainInterpMethod), agmarshall.DOUBLE_arg,) }
    def GetTerrainHeight(self, interpMethod:"AgEStkRadarTerrainInterpMethod") -> float:
        """Gets the terrain height."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetTerrainHeight_metadata, interpMethod, OutArg())

    _GetTerrainHeightForLatLon_metadata = { "offset" : _GetTerrainHeightForLatLon_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEStkRadarTerrainInterpMethod), agmarshall.DOUBLE_arg,) }
    def GetTerrainHeightForLatLon(self, latitude:float, longitude:float, interpMethod:"AgEStkRadarTerrainInterpMethod") -> float:
        """Gets the terrain height for a specified latitude and longitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._GetTerrainHeightForLatLon_metadata, latitude, longitude, interpMethod, OutArg())

    _ComputeLocalRadiusDetic_metadata = { "offset" : _ComputeLocalRadiusDetic_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ComputeLocalRadiusDetic(self, latitude:float, longitude:float) -> float:
        """Computes the central body radius detic for a given latitude and longitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeLocalRadiusDetic_metadata, latitude, longitude, OutArg())

    _ComputeLocalRadiusCentric_metadata = { "offset" : _ComputeLocalRadiusCentric_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ComputeLocalRadiusCentric(self, latitude:float, longitude:float) -> float:
        """Computes the central body radius centric for a given latitude and longitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeLocalRadiusCentric_metadata, latitude, longitude, OutArg())

    _ComputeSurfaceNormalDetic_metadata = { "offset" : _ComputeSurfaceNormalDetic_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ComputeSurfaceNormalDetic(self, latitude:float, longitude:float) -> typing.Tuple[float, float, float]:
        """Computes the surface normal detic vector for a given latitude and longitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeSurfaceNormalDetic_metadata, latitude, longitude, OutArg(), OutArg(), OutArg())

    _ComputeSurfaceNormalDeticArray_metadata = { "offset" : _ComputeSurfaceNormalDeticArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ComputeSurfaceNormalDeticArray(self, latitude:float, longitude:float) -> list:
        """Computes the surface normal detic vector for a given latitude and longitude as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeSurfaceNormalDeticArray_metadata, latitude, longitude, OutArg())

    _ComputeSurfaceNormalCentric_metadata = { "offset" : _ComputeSurfaceNormalCentric_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ComputeSurfaceNormalCentric(self, latitude:float, longitude:float) -> typing.Tuple[float, float, float]:
        """Computes the surface normal centric vector for a given latitude and longitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeSurfaceNormalCentric_metadata, latitude, longitude, OutArg(), OutArg(), OutArg())

    _ComputeSurfaceNormalCentricArray_metadata = { "offset" : _ComputeSurfaceNormalCentricArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ComputeSurfaceNormalCentricArray(self, latitude:float, longitude:float) -> list:
        """Computes the surface normal centric vector for a given latitude and longitude as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeSurfaceNormalCentricArray_metadata, latitude, longitude, OutArg())

    _ConvertCBFCartesianToLLA_metadata = { "offset" : _ConvertCBFCartesianToLLA_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertCBFCartesianToLLA(self, x:float, y:float, z:float) -> typing.Tuple[float, float, float]:
        """Converts central body fixed cartesian to latitude, longitude, and altitude."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToLLA_metadata, x, y, z, OutArg(), OutArg(), OutArg())

    _ConvertCBFCartesianToLLAArray_metadata = { "offset" : _ConvertCBFCartesianToLLAArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertCBFCartesianToLLAArray(self, x:float, y:float, z:float) -> list:
        """Converts central body fixed cartesian to latitude, longitude, and altitude as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToLLAArray_metadata, x, y, z, OutArg())

    _ConvertLLAToCBFCartesian_metadata = { "offset" : _ConvertLLAToCBFCartesian_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertLLAToCBFCartesian(self, latitude:float, longitude:float, altitude:float) -> typing.Tuple[float, float, float]:
        """Converts latitude, longitude, and altitude to central body fixed cartesian."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertLLAToCBFCartesian_metadata, latitude, longitude, altitude, OutArg(), OutArg(), OutArg())

    _ConvertLLAToCBFCartesianArray_metadata = { "offset" : _ConvertLLAToCBFCartesianArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertLLAToCBFCartesianArray(self, latitude:float, longitude:float, altitude:float) -> list:
        """Converts latitude, longitude, and altitude to central body fixed cartesian as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertLLAToCBFCartesianArray_metadata, latitude, longitude, altitude, OutArg())

    _ConvertCBFCartesianToVVLHCartesian_metadata = { "offset" : _ConvertCBFCartesianToVVLHCartesian_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertCBFCartesianToVVLHCartesian(self, xCbf:float, yCbf:float, zCbf:float) -> typing.Tuple[float, float, float]:
        """Converts a central body fixed cartesian into the VVLA frame."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToVVLHCartesian_metadata, xCbf, yCbf, zCbf, OutArg(), OutArg(), OutArg())

    _ConvertCBFCartesianToVVLHCartesianArray_metadata = { "offset" : _ConvertCBFCartesianToVVLHCartesianArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertCBFCartesianToVVLHCartesianArray(self, xCbf:float, yCbf:float, zCbf:float) -> list:
        """Converts a central body fixed cartesian into the VVLA frame as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToVVLHCartesianArray_metadata, xCbf, yCbf, zCbf, OutArg())

    _ConvertBodyCartesianToCBFCartesian_metadata = { "offset" : _ConvertBodyCartesianToCBFCartesian_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertBodyCartesianToCBFCartesian(self, xBody:float, yBody:float, zBody:float) -> typing.Tuple[float, float, float]:
        """Converts a vector in body coordinates into CBF fixed coordinates"""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertBodyCartesianToCBFCartesian_metadata, xBody, yBody, zBody, OutArg(), OutArg(), OutArg())

    _ConvertBodyCartesianToCBFCartesianArray_metadata = { "offset" : _ConvertBodyCartesianToCBFCartesianArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertBodyCartesianToCBFCartesianArray(self, xBody:float, yBody:float, zBody:float) -> list:
        """Converts a vector in body coordinates into CBF fixed coordinates as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertBodyCartesianToCBFCartesianArray_metadata, xBody, yBody, zBody, OutArg())

    _ConvertCBFCartesianToBodyCartesian_metadata = { "offset" : _ConvertCBFCartesianToBodyCartesian_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertCBFCartesianToBodyCartesian(self, xCbf:float, yCbf:float, zCbf:float) -> typing.Tuple[float, float, float]:
        """Converts a vector in CBF coordinates into body coordinates."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToBodyCartesian_metadata, xCbf, yCbf, zCbf, OutArg(), OutArg(), OutArg())

    _ConvertCBFCartesianToBodyCartesianArray_metadata = { "offset" : _ConvertCBFCartesianToBodyCartesianArray_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertCBFCartesianToBodyCartesianArray(self, xCbf:float, yCbf:float, zCbf:float) -> list:
        """Converts a vector in CBF coordinates into body coordinates as an array."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ConvertCBFCartesianToBodyCartesianArray_metadata, xCbf, yCbf, zCbf, OutArg())

    _get_Role_metadata = { "offset" : _get_Role_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEStkRadarPosVelProviderRole),) }
    @property
    def Role(self) -> "AgEStkRadarPosVelProviderRole":
        """Gets the IAgStkRadarPosVelProvider role."""
        return self._intf.get_property(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._get_Role_metadata)

    _ComputeCentralBodyIntersectInCBF_metadata = { "offset" : _ComputeCentralBodyIntersectInCBF_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgInterface_out_arg,) }
    def ComputeCentralBodyIntersectInCBF(self, baseX:float, baseY:float, baseZ:float, dirX:float, dirY:float, dirZ:float) -> "IAgStkRadarCBIntersectComputeResult":
        """Computes the central body intersection using central body fixed coordinates."""
        return self._intf.invoke(IAgStkRadarPosVelProvider._metadata, IAgStkRadarPosVelProvider._ComputeCentralBodyIntersectInCBF_metadata, baseX, baseY, baseZ, dirX, dirY, dirZ, OutArg())

    _property_names[CurrentTime] = "CurrentTime"
    _property_names[VelocityCBFArray] = "VelocityCBFArray"
    _property_names[PositionCBFArray] = "PositionCBFArray"
    _property_names[PositionLLAArray] = "PositionLLAArray"
    _property_names[LocalRadiusDetic] = "LocalRadiusDetic"
    _property_names[LocalRadiusCentric] = "LocalRadiusCentric"
    _property_names[SurfaceNormalDeticArray] = "SurfaceNormalDeticArray"
    _property_names[SurfaceNormalCentricArray] = "SurfaceNormalCentricArray"
    _property_names[Role] = "Role"


agcls.AgClassCatalog.add_catalog_entry((5114281978580293677, 15313427104105113246), IAgStkRadarPosVelProvider)
agcls.AgTypeNameMap["IAgStkRadarPosVelProvider"] = IAgStkRadarPosVelProvider

class IAgStkRadarLinkGeometry(object):
    """Interface implemented by an object that provides the geometry for a radar link."""

    _num_methods = 30
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_TargetPosVelProvider_method_offset = 1
    _get_TransmitRadarPosVelProvider_method_offset = 2
    _get_ReceiveRadarPosVelProvider_method_offset = 3
    _get_ReceiveRadarRange_method_offset = 4
    _get_ReceiveRadarAngleRate_method_offset = 5
    _get_ReceiveRadarRangeRate_method_offset = 6
    _get_ReceiveRadarConeAngle_method_offset = 7
    _get_ReceiveRadarPropTime_method_offset = 8
    _get_TransmitRadarRange_method_offset = 9
    _get_TransmitRadarAngleRate_method_offset = 10
    _get_TransmitRadarRangeRate_method_offset = 11
    _get_TransmitRadarConeAngle_method_offset = 12
    _get_TransmitRadarPropTime_method_offset = 13
    _get_RangeSum_method_offset = 14
    _get_Closure_method_offset = 15
    _get_MLCVelocity_method_offset = 16
    _get_BistaticAngle_method_offset = 17
    _get_IncidentAzimuth_method_offset = 18
    _get_IncidentElevation_method_offset = 19
    _get_ReflectedAzimuth_method_offset = 20
    _get_ReflectedElevation_method_offset = 21
    _get_XYAngleRate_method_offset = 22
    _GetTgt2XmtRdrRelPosCBFCartesian_method_offset = 23
    _get_Tgt2XmtRdrRelPosCBFCartesianArray_method_offset = 24
    _GetTgt2RcvRdrRelPosCBFCartesian_method_offset = 25
    _get_Tgt2RcvRdrRelPosCBFCartesianArray_method_offset = 26
    _GetXmtRdr2TgtRelPosCBFCartesian_method_offset = 27
    _get_XmtRdr2TgtRelPosCBFCartesianArray_method_offset = 28
    _GetRcvRdr2TgtRelPosCBFCartesian_method_offset = 29
    _get_RcvRdr2TgtRelPosCBFCartesianArray_method_offset = 30
    _metadata = {
        "iid_data" : (5149015422948254792, 3429367408251648687),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarLinkGeometry."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarLinkGeometry)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarLinkGeometry)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarLinkGeometry, None)
    
    _get_TargetPosVelProvider_metadata = { "offset" : _get_TargetPosVelProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def TargetPosVelProvider(self) -> "IAgStkRadarPosVelProvider":
        """Gets the target position/velocity provider interface."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_TargetPosVelProvider_metadata)

    _get_TransmitRadarPosVelProvider_metadata = { "offset" : _get_TransmitRadarPosVelProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def TransmitRadarPosVelProvider(self) -> "IAgStkRadarPosVelProvider":
        """Gets the transmit radar position/velocity provider interface."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_TransmitRadarPosVelProvider_metadata)

    _get_ReceiveRadarPosVelProvider_metadata = { "offset" : _get_ReceiveRadarPosVelProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ReceiveRadarPosVelProvider(self) -> "IAgStkRadarPosVelProvider":
        """Gets the receive radar position/velocity provider interface."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_ReceiveRadarPosVelProvider_metadata)

    _get_ReceiveRadarRange_metadata = { "offset" : _get_ReceiveRadarRange_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def ReceiveRadarRange(self) -> float:
        """Gets the receive radar range."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_ReceiveRadarRange_metadata)

    _get_ReceiveRadarAngleRate_metadata = { "offset" : _get_ReceiveRadarAngleRate_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def ReceiveRadarAngleRate(self) -> float:
        """Gets the receive radar angle rate."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_ReceiveRadarAngleRate_metadata)

    _get_ReceiveRadarRangeRate_metadata = { "offset" : _get_ReceiveRadarRangeRate_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def ReceiveRadarRangeRate(self) -> float:
        """Gets the receive radar range rate."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_ReceiveRadarRangeRate_metadata)

    _get_ReceiveRadarConeAngle_metadata = { "offset" : _get_ReceiveRadarConeAngle_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def ReceiveRadarConeAngle(self) -> float:
        """Gets the receive radar cone angle."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_ReceiveRadarConeAngle_metadata)

    _get_ReceiveRadarPropTime_metadata = { "offset" : _get_ReceiveRadarPropTime_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def ReceiveRadarPropTime(self) -> float:
        """Gets the receive radar prop time."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_ReceiveRadarPropTime_metadata)

    _get_TransmitRadarRange_metadata = { "offset" : _get_TransmitRadarRange_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TransmitRadarRange(self) -> float:
        """Gets the transmit radar range."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_TransmitRadarRange_metadata)

    _get_TransmitRadarAngleRate_metadata = { "offset" : _get_TransmitRadarAngleRate_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TransmitRadarAngleRate(self) -> float:
        """Gets the transmit radar angle rate."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_TransmitRadarAngleRate_metadata)

    _get_TransmitRadarRangeRate_metadata = { "offset" : _get_TransmitRadarRangeRate_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TransmitRadarRangeRate(self) -> float:
        """Gets the transmit radar range rate."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_TransmitRadarRangeRate_metadata)

    _get_TransmitRadarConeAngle_metadata = { "offset" : _get_TransmitRadarConeAngle_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TransmitRadarConeAngle(self) -> float:
        """Gets the transmit radar cone angle."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_TransmitRadarConeAngle_metadata)

    _get_TransmitRadarPropTime_metadata = { "offset" : _get_TransmitRadarPropTime_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def TransmitRadarPropTime(self) -> float:
        """Gets the transmit radar prop time."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_TransmitRadarPropTime_metadata)

    _get_RangeSum_metadata = { "offset" : _get_RangeSum_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def RangeSum(self) -> float:
        """Gets the range sum."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_RangeSum_metadata)

    _get_Closure_metadata = { "offset" : _get_Closure_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Closure(self) -> float:
        """Gets the closure."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_Closure_metadata)

    _get_MLCVelocity_metadata = { "offset" : _get_MLCVelocity_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def MLCVelocity(self) -> float:
        """Gets the main lobe clutter velocity."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_MLCVelocity_metadata)

    _get_BistaticAngle_metadata = { "offset" : _get_BistaticAngle_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def BistaticAngle(self) -> float:
        """Gets the bistatic angle."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_BistaticAngle_metadata)

    _get_IncidentAzimuth_metadata = { "offset" : _get_IncidentAzimuth_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def IncidentAzimuth(self) -> float:
        """Gets the incident azimuth."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_IncidentAzimuth_metadata)

    _get_IncidentElevation_metadata = { "offset" : _get_IncidentElevation_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def IncidentElevation(self) -> float:
        """Gets the incident elevation."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_IncidentElevation_metadata)

    _get_ReflectedAzimuth_metadata = { "offset" : _get_ReflectedAzimuth_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def ReflectedAzimuth(self) -> float:
        """Gets the reflected azimuth."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_ReflectedAzimuth_metadata)

    _get_ReflectedElevation_metadata = { "offset" : _get_ReflectedElevation_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def ReflectedElevation(self) -> float:
        """Gets the reflected elevation."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_ReflectedElevation_metadata)

    _get_XYAngleRate_metadata = { "offset" : _get_XYAngleRate_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def XYAngleRate(self) -> float:
        """Gets the xy angle rate."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_XYAngleRate_metadata)

    _GetTgt2XmtRdrRelPosCBFCartesian_metadata = { "offset" : _GetTgt2XmtRdrRelPosCBFCartesian_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetTgt2XmtRdrRelPosCBFCartesian(self) -> typing.Tuple[float, float, float]:
        """Gets the relative position vector from the target to the transmitting radar in central body fixed coordinates"""
        return self._intf.invoke(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._GetTgt2XmtRdrRelPosCBFCartesian_metadata, OutArg(), OutArg(), OutArg())

    _get_Tgt2XmtRdrRelPosCBFCartesianArray_metadata = { "offset" : _get_Tgt2XmtRdrRelPosCBFCartesianArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def Tgt2XmtRdrRelPosCBFCartesianArray(self) -> list:
        """Gets the relative position vector from the target to the transmitting radar in central body fixed coordinates as an array."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_Tgt2XmtRdrRelPosCBFCartesianArray_metadata)

    _GetTgt2RcvRdrRelPosCBFCartesian_metadata = { "offset" : _GetTgt2RcvRdrRelPosCBFCartesian_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetTgt2RcvRdrRelPosCBFCartesian(self) -> typing.Tuple[float, float, float]:
        """Gets the relative position vector from the target to the receiving radar in central body fixed coordinates."""
        return self._intf.invoke(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._GetTgt2RcvRdrRelPosCBFCartesian_metadata, OutArg(), OutArg(), OutArg())

    _get_Tgt2RcvRdrRelPosCBFCartesianArray_metadata = { "offset" : _get_Tgt2RcvRdrRelPosCBFCartesianArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def Tgt2RcvRdrRelPosCBFCartesianArray(self) -> list:
        """Gets the relative position vector from the target to the receiving radar in central body fixed coordinates as an array."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_Tgt2RcvRdrRelPosCBFCartesianArray_metadata)

    _GetXmtRdr2TgtRelPosCBFCartesian_metadata = { "offset" : _GetXmtRdr2TgtRelPosCBFCartesian_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetXmtRdr2TgtRelPosCBFCartesian(self) -> typing.Tuple[float, float, float]:
        """Gets the relative position vector from the transmitting radar to the target in central body fixed coordinates."""
        return self._intf.invoke(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._GetXmtRdr2TgtRelPosCBFCartesian_metadata, OutArg(), OutArg(), OutArg())

    _get_XmtRdr2TgtRelPosCBFCartesianArray_metadata = { "offset" : _get_XmtRdr2TgtRelPosCBFCartesianArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def XmtRdr2TgtRelPosCBFCartesianArray(self) -> list:
        """Gets the relative position vector from the transmitting radar to the target in central body fixed coordinates as an array."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_XmtRdr2TgtRelPosCBFCartesianArray_metadata)

    _GetRcvRdr2TgtRelPosCBFCartesian_metadata = { "offset" : _GetRcvRdr2TgtRelPosCBFCartesian_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetRcvRdr2TgtRelPosCBFCartesian(self) -> typing.Tuple[float, float, float]:
        """Gets the relative position vector from the receiving radar to the target in central body fixed coordinates."""
        return self._intf.invoke(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._GetRcvRdr2TgtRelPosCBFCartesian_metadata, OutArg(), OutArg(), OutArg())

    _get_RcvRdr2TgtRelPosCBFCartesianArray_metadata = { "offset" : _get_RcvRdr2TgtRelPosCBFCartesianArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def RcvRdr2TgtRelPosCBFCartesianArray(self) -> list:
        """Gets the relative position vector from the receiving radar to the target in central body fixed coordinates as an array."""
        return self._intf.get_property(IAgStkRadarLinkGeometry._metadata, IAgStkRadarLinkGeometry._get_RcvRdr2TgtRelPosCBFCartesianArray_metadata)

    _property_names[TargetPosVelProvider] = "TargetPosVelProvider"
    _property_names[TransmitRadarPosVelProvider] = "TransmitRadarPosVelProvider"
    _property_names[ReceiveRadarPosVelProvider] = "ReceiveRadarPosVelProvider"
    _property_names[ReceiveRadarRange] = "ReceiveRadarRange"
    _property_names[ReceiveRadarAngleRate] = "ReceiveRadarAngleRate"
    _property_names[ReceiveRadarRangeRate] = "ReceiveRadarRangeRate"
    _property_names[ReceiveRadarConeAngle] = "ReceiveRadarConeAngle"
    _property_names[ReceiveRadarPropTime] = "ReceiveRadarPropTime"
    _property_names[TransmitRadarRange] = "TransmitRadarRange"
    _property_names[TransmitRadarAngleRate] = "TransmitRadarAngleRate"
    _property_names[TransmitRadarRangeRate] = "TransmitRadarRangeRate"
    _property_names[TransmitRadarConeAngle] = "TransmitRadarConeAngle"
    _property_names[TransmitRadarPropTime] = "TransmitRadarPropTime"
    _property_names[RangeSum] = "RangeSum"
    _property_names[Closure] = "Closure"
    _property_names[MLCVelocity] = "MLCVelocity"
    _property_names[BistaticAngle] = "BistaticAngle"
    _property_names[IncidentAzimuth] = "IncidentAzimuth"
    _property_names[IncidentElevation] = "IncidentElevation"
    _property_names[ReflectedAzimuth] = "ReflectedAzimuth"
    _property_names[ReflectedElevation] = "ReflectedElevation"
    _property_names[XYAngleRate] = "XYAngleRate"
    _property_names[Tgt2XmtRdrRelPosCBFCartesianArray] = "Tgt2XmtRdrRelPosCBFCartesianArray"
    _property_names[Tgt2RcvRdrRelPosCBFCartesianArray] = "Tgt2RcvRdrRelPosCBFCartesianArray"
    _property_names[XmtRdr2TgtRelPosCBFCartesianArray] = "XmtRdr2TgtRelPosCBFCartesianArray"
    _property_names[RcvRdr2TgtRelPosCBFCartesianArray] = "RcvRdr2TgtRelPosCBFCartesianArray"


agcls.AgClassCatalog.add_catalog_entry((5149015422948254792, 3429367408251648687), IAgStkRadarLinkGeometry)
agcls.AgTypeNameMap["IAgStkRadarLinkGeometry"] = IAgStkRadarLinkGeometry

class IAgStkRadarLink(object):
    """Interface implemented by an object that represents the multi-hop link from a radar transmitter to the target, and back to the receive radar."""

    _num_methods = 5
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Geometry_method_offset = 1
    _ComputeDopplerResolution_method_offset = 2
    _ComputeRangeResolution_method_offset = 3
    _ComputeIsoDoppler_method_offset = 4
    _ComputeIsoRange_method_offset = 5
    _metadata = {
        "iid_data" : (5250932541826117739, 17978494574995249338),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarLink."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarLink)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarLink)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarLink, None)
    
    _get_Geometry_metadata = { "offset" : _get_Geometry_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Geometry(self) -> "IAgStkRadarLinkGeometry":
        """Gets the link geometry."""
        return self._intf.get_property(IAgStkRadarLink._metadata, IAgStkRadarLink._get_Geometry_metadata)

    _ComputeDopplerResolution_metadata = { "offset" : _ComputeDopplerResolution_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRSignal"), agmarshall.DOUBLE_arg,) }
    def ComputeDopplerResolution(self, radarSignal:"IAgCRSignal") -> float:
        """Computes the doppler resolution for the supplied signal."""
        return self._intf.invoke(IAgStkRadarLink._metadata, IAgStkRadarLink._ComputeDopplerResolution_metadata, radarSignal, OutArg())

    _ComputeRangeResolution_metadata = { "offset" : _ComputeRangeResolution_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRSignal"), agmarshall.DOUBLE_arg,) }
    def ComputeRangeResolution(self, radarSignal:"IAgCRSignal") -> float:
        """Computes the range resolution for the supplied signal."""
        return self._intf.invoke(IAgStkRadarLink._metadata, IAgStkRadarLink._ComputeRangeResolution_metadata, radarSignal, OutArg())

    _ComputeIsoDoppler_metadata = { "offset" : _ComputeIsoDoppler_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRSignal"), agmarshall.LPSAFEARRAY_arg,) }
    def ComputeIsoDoppler(self, radarSignal:"IAgCRSignal") -> list:
        """Computes the iso doppler array for the supplied signal."""
        return self._intf.invoke(IAgStkRadarLink._metadata, IAgStkRadarLink._ComputeIsoDoppler_metadata, radarSignal, OutArg())

    _ComputeIsoRange_metadata = { "offset" : _ComputeIsoRange_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRSignal"), agmarshall.LPSAFEARRAY_arg,) }
    def ComputeIsoRange(self, radarSignal:"IAgCRSignal") -> list:
        """Computes the iso range array for the supplied signal."""
        return self._intf.invoke(IAgStkRadarLink._metadata, IAgStkRadarLink._ComputeIsoRange_metadata, radarSignal, OutArg())

    _property_names[Geometry] = "Geometry"


agcls.AgClassCatalog.add_catalog_entry((5250932541826117739, 17978494574995249338), IAgStkRadarLink)
agcls.AgTypeNameMap["IAgStkRadarLink"] = IAgStkRadarLink

class IAgStkRadarSignal(object):
    """Interface implemented by an object that represents a radar signal."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_PulseRepetitionFrequency_method_offset = 1
    _get_PulseCompressionRatio_method_offset = 2
    _get_PulseWidth_method_offset = 3
    _get_NumberOfPulses_method_offset = 4
    _get_Rcs_method_offset = 5
    _set_Rcs_method_offset = 6
    _metadata = {
        "iid_data" : (4856144443142938825, 16247509566458836105),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarSignal."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarSignal)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarSignal)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarSignal, None)
    
    _get_PulseRepetitionFrequency_metadata = { "offset" : _get_PulseRepetitionFrequency_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def PulseRepetitionFrequency(self) -> float:
        """Gets the signal pulse repetition frequency."""
        return self._intf.get_property(IAgStkRadarSignal._metadata, IAgStkRadarSignal._get_PulseRepetitionFrequency_metadata)

    _get_PulseCompressionRatio_metadata = { "offset" : _get_PulseCompressionRatio_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def PulseCompressionRatio(self) -> float:
        """Gets the signal pulse compression ratio."""
        return self._intf.get_property(IAgStkRadarSignal._metadata, IAgStkRadarSignal._get_PulseCompressionRatio_metadata)

    _get_PulseWidth_metadata = { "offset" : _get_PulseWidth_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def PulseWidth(self) -> float:
        """Gets the signal pulse width."""
        return self._intf.get_property(IAgStkRadarSignal._metadata, IAgStkRadarSignal._get_PulseWidth_metadata)

    _get_NumberOfPulses_metadata = { "offset" : _get_NumberOfPulses_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def NumberOfPulses(self) -> int:
        """Gets the number of pulses."""
        return self._intf.get_property(IAgStkRadarSignal._metadata, IAgStkRadarSignal._get_NumberOfPulses_metadata)

    _get_Rcs_metadata = { "offset" : _get_Rcs_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Rcs(self) -> float:
        """Gets or sets the signal RCS."""
        return self._intf.get_property(IAgStkRadarSignal._metadata, IAgStkRadarSignal._get_Rcs_metadata)

    _set_Rcs_metadata = { "offset" : _set_Rcs_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Rcs.setter
    def Rcs(self, rcs:float) -> None:
        """Gets or sets the signal RCS."""
        return self._intf.set_property(IAgStkRadarSignal._metadata, IAgStkRadarSignal._set_Rcs_metadata, rcs)

    _property_names[PulseRepetitionFrequency] = "PulseRepetitionFrequency"
    _property_names[PulseCompressionRatio] = "PulseCompressionRatio"
    _property_names[PulseWidth] = "PulseWidth"
    _property_names[NumberOfPulses] = "NumberOfPulses"
    _property_names[Rcs] = "Rcs"


agcls.AgClassCatalog.add_catalog_entry((4856144443142938825, 16247509566458836105), IAgStkRadarSignal)
agcls.AgTypeNameMap["IAgStkRadarSignal"] = IAgStkRadarSignal

class IAgStkRadarClutterPatch(object):
    """Interface implemented by an object that represents a clutter patch."""

    _num_methods = 7
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_PosVelProvider_method_offset = 1
    _SetPositionCBF_method_offset = 2
    _SetVelocityCBF_method_offset = 3
    _get_Area_method_offset = 4
    _set_Area_method_offset = 5
    _get_ScatteringPointComponentName_method_offset = 6
    _set_ScatteringPointComponentName_method_offset = 7
    _metadata = {
        "iid_data" : (5328853349714122859, 4386913630281959816),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarClutterPatch."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarClutterPatch)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarClutterPatch)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarClutterPatch, None)
    
    _get_PosVelProvider_metadata = { "offset" : _get_PosVelProvider_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def PosVelProvider(self) -> "IAgStkRadarPosVelProvider":
        """Gets the patch position/velocity provider interface."""
        return self._intf.get_property(IAgStkRadarClutterPatch._metadata, IAgStkRadarClutterPatch._get_PosVelProvider_metadata)

    _SetPositionCBF_metadata = { "offset" : _SetPositionCBF_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetPositionCBF(self, x:float, y:float, z:float) -> None:
        """Sets the patch position in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarClutterPatch._metadata, IAgStkRadarClutterPatch._SetPositionCBF_metadata, x, y, z)

    _SetVelocityCBF_metadata = { "offset" : _SetVelocityCBF_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def SetVelocityCBF(self, x:float, y:float, z:float) -> None:
        """Sets the patch velocity in the central body fixed frame."""
        return self._intf.invoke(IAgStkRadarClutterPatch._metadata, IAgStkRadarClutterPatch._SetVelocityCBF_metadata, x, y, z)

    _get_Area_metadata = { "offset" : _get_Area_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Area(self) -> float:
        """Gets or sets the patch area."""
        return self._intf.get_property(IAgStkRadarClutterPatch._metadata, IAgStkRadarClutterPatch._get_Area_metadata)

    _set_Area_metadata = { "offset" : _set_Area_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Area.setter
    def Area(self, area:float) -> None:
        """Gets or sets the patch area."""
        return self._intf.set_property(IAgStkRadarClutterPatch._metadata, IAgStkRadarClutterPatch._set_Area_metadata, area)

    _get_ScatteringPointComponentName_metadata = { "offset" : _get_ScatteringPointComponentName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ScatteringPointComponentName(self) -> str:
        """Gets or set the patch scattering point model by component name."""
        return self._intf.get_property(IAgStkRadarClutterPatch._metadata, IAgStkRadarClutterPatch._get_ScatteringPointComponentName_metadata)

    _set_ScatteringPointComponentName_metadata = { "offset" : _set_ScatteringPointComponentName_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ScatteringPointComponentName.setter
    def ScatteringPointComponentName(self, scatteringPoitnModelComponentName:str) -> None:
        """Gets or sets the patch scattering point model by component name."""
        return self._intf.set_property(IAgStkRadarClutterPatch._metadata, IAgStkRadarClutterPatch._set_ScatteringPointComponentName_metadata, scatteringPoitnModelComponentName)

    _property_names[PosVelProvider] = "PosVelProvider"
    _property_names[Area] = "Area"
    _property_names[ScatteringPointComponentName] = "ScatteringPointComponentName"


agcls.AgClassCatalog.add_catalog_entry((5328853349714122859, 4386913630281959816), IAgStkRadarClutterPatch)
agcls.AgTypeNameMap["IAgStkRadarClutterPatch"] = IAgStkRadarClutterPatch

class IAgStkRadarClutterPatchCollection(object):
    """Interface implemented by a collection of clutter patch objects."""

    _num_methods = 7
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _Remove_method_offset = 4
    _RemoveAt_method_offset = 5
    _RemoveAll_method_offset = 6
    _Add_method_offset = 7
    _metadata = {
        "iid_data" : (5056841026364961197, 6421181135870534586),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarClutterPatchCollection."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarClutterPatchCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarClutterPatchCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarClutterPatchCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgStkRadarClutterPatchCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgStkRadarClutterPatch":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of elements in the collection."""
        return self._intf.get_property(IAgStkRadarClutterPatchCollection._metadata, IAgStkRadarClutterPatchCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgStkRadarClutterPatch":
        """Given an index, returns an element in the collection."""
        return self._intf.invoke(IAgStkRadarClutterPatchCollection._metadata, IAgStkRadarClutterPatchCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumerator that can iterate through the collection."""
        return self._intf.get_property(IAgStkRadarClutterPatchCollection._metadata, IAgStkRadarClutterPatchCollection._get__NewEnum_metadata)

    _Remove_metadata = { "offset" : _Remove_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRadarClutterPatch"),) }
    def Remove(self, item:"IAgStkRadarClutterPatch") -> None:
        """Removes the specified element from the collection."""
        return self._intf.invoke(IAgStkRadarClutterPatchCollection._metadata, IAgStkRadarClutterPatchCollection._Remove_metadata, item)

    _RemoveAt_metadata = { "offset" : _RemoveAt_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def RemoveAt(self, index:int) -> None:
        """Removes an element from the collection using specified index."""
        return self._intf.invoke(IAgStkRadarClutterPatchCollection._metadata, IAgStkRadarClutterPatchCollection._RemoveAt_metadata, index)

    _RemoveAll_metadata = { "offset" : _RemoveAll_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RemoveAll(self) -> None:
        """Removes all elements from the collection."""
        return self._intf.invoke(IAgStkRadarClutterPatchCollection._metadata, IAgStkRadarClutterPatchCollection._RemoveAll_metadata, )

    _Add_metadata = { "offset" : _Add_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def Add(self) -> "IAgStkRadarClutterPatch":
        """Adds a new element to the collection."""
        return self._intf.invoke(IAgStkRadarClutterPatchCollection._metadata, IAgStkRadarClutterPatchCollection._Add_metadata, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5056841026364961197, 6421181135870534586), IAgStkRadarClutterPatchCollection)
agcls.AgTypeNameMap["IAgStkRadarClutterPatchCollection"] = IAgStkRadarClutterPatchCollection

class IAgStkRadarClutterGeometryPluginRegInfo(object):
    """Interface implemented by an object that represents the registration information for the clutter geometry plugin."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _set_ValidRadarSystems_method_offset = 1
    _metadata = {
        "iid_data" : (5726520331994639972, 14847930573645014185),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarClutterGeometryPluginRegInfo."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarClutterGeometryPluginRegInfo)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarClutterGeometryPluginRegInfo)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarClutterGeometryPluginRegInfo, None)
    
    _get_ValidRadarSystems_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def ValidRadarSystems(self) -> None:
        """ValidRadarSystems is a write-only property."""
        raise RuntimeError("ValidRadarSystems is a write-only property.")


    _set_ValidRadarSystems_metadata = { "offset" : _set_ValidRadarSystems_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEStkRadarValidSystems),) }
    @ValidRadarSystems.setter
    def ValidRadarSystems(self, validRadarSystems:"AgEStkRadarValidSystems") -> None:
        """Sets the valid radar system mask."""
        return self._intf.set_property(IAgStkRadarClutterGeometryPluginRegInfo._metadata, IAgStkRadarClutterGeometryPluginRegInfo._set_ValidRadarSystems_metadata, validRadarSystems)

    _property_names[ValidRadarSystems] = "ValidRadarSystems"


agcls.AgClassCatalog.add_catalog_entry((5726520331994639972, 14847930573645014185), IAgStkRadarClutterGeometryPluginRegInfo)
agcls.AgTypeNameMap["IAgStkRadarClutterGeometryPluginRegInfo"] = IAgStkRadarClutterGeometryPluginRegInfo

class IAgStkRadarClutterGeometryComputeParams(object):
    """Interface implemented by an object that represents the parameters to be passed into the clutter geometry plugin Compute method."""

    _num_methods = 3
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_RadarLink_method_offset = 1
    _get_Signal_method_offset = 2
    _get_ClutterPatches_method_offset = 3
    _metadata = {
        "iid_data" : (4731739011759059127, 1228982424158547612),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarClutterGeometryComputeParams."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarClutterGeometryComputeParams)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarClutterGeometryComputeParams)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarClutterGeometryComputeParams, None)
    
    _get_RadarLink_metadata = { "offset" : _get_RadarLink_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def RadarLink(self) -> "IAgStkRadarLink":
        """Gets the radar link"""
        return self._intf.get_property(IAgStkRadarClutterGeometryComputeParams._metadata, IAgStkRadarClutterGeometryComputeParams._get_RadarLink_metadata)

    _get_Signal_metadata = { "offset" : _get_Signal_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Signal(self) -> "IAgCRSignal":
        """Gets the transmit signal"""
        return self._intf.get_property(IAgStkRadarClutterGeometryComputeParams._metadata, IAgStkRadarClutterGeometryComputeParams._get_Signal_metadata)

    _get_ClutterPatches_metadata = { "offset" : _get_ClutterPatches_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ClutterPatches(self) -> "IAgStkRadarClutterPatchCollection":
        """Gets the clutter patch collection"""
        return self._intf.get_property(IAgStkRadarClutterGeometryComputeParams._metadata, IAgStkRadarClutterGeometryComputeParams._get_ClutterPatches_metadata)

    _property_names[RadarLink] = "RadarLink"
    _property_names[Signal] = "Signal"
    _property_names[ClutterPatches] = "ClutterPatches"


agcls.AgClassCatalog.add_catalog_entry((4731739011759059127, 1228982424158547612), IAgStkRadarClutterGeometryComputeParams)
agcls.AgTypeNameMap["IAgStkRadarClutterGeometryComputeParams"] = IAgStkRadarClutterGeometryComputeParams

class IAgStkRadarClutterGeometryPluginScatteringModels(object):
    """Interface implemented by an object that represents a clutter geometry plugin that can configure clutter patches with scattering models."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ScatteringModelComponentNames_method_offset = 1
    _metadata = {
        "iid_data" : (5406223617284367416, 4862826184367009704),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarClutterGeometryPluginScatteringModels."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarClutterGeometryPluginScatteringModels)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarClutterGeometryPluginScatteringModels)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarClutterGeometryPluginScatteringModels, None)
    
    _get_ScatteringModelComponentNames_metadata = { "offset" : _get_ScatteringModelComponentNames_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def ScatteringModelComponentNames(self) -> list:
        """Returns the list of scattering model component names which the plugin intends to set on the returned clutter patches."""
        return self._intf.get_property(IAgStkRadarClutterGeometryPluginScatteringModels._metadata, IAgStkRadarClutterGeometryPluginScatteringModels._get_ScatteringModelComponentNames_metadata)

    _property_names[ScatteringModelComponentNames] = "ScatteringModelComponentNames"


agcls.AgClassCatalog.add_catalog_entry((5406223617284367416, 4862826184367009704), IAgStkRadarClutterGeometryPluginScatteringModels)
agcls.AgTypeNameMap["IAgStkRadarClutterGeometryPluginScatteringModels"] = IAgStkRadarClutterGeometryPluginScatteringModels

class IAgStkRadarClutterMapComputeParams(object):
    """Interface implemented by an object that represents the parameters to be passed into the clutter map plugin Compute method."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_RadarLink_method_offset = 1
    _get_ClutterPatch_method_offset = 2
    _get_Signal_method_offset = 3
    _ConstructPolarization_method_offset = 4
    _ConstructPolarizationCopy_method_offset = 5
    _ConstructOrthogonalPolarization_method_offset = 6
    _metadata = {
        "iid_data" : (5045009382787308569, 1041245726555814023),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarClutterMapComputeParams."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarClutterMapComputeParams)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarClutterMapComputeParams)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarClutterMapComputeParams, None)
    
    _get_RadarLink_metadata = { "offset" : _get_RadarLink_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def RadarLink(self) -> "IAgStkRadarLink":
        """Gets the radar link."""
        return self._intf.get_property(IAgStkRadarClutterMapComputeParams._metadata, IAgStkRadarClutterMapComputeParams._get_RadarLink_metadata)

    _get_ClutterPatch_metadata = { "offset" : _get_ClutterPatch_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ClutterPatch(self) -> "IAgStkRadarClutterPatch":
        """Gets the clutter patch."""
        return self._intf.get_property(IAgStkRadarClutterMapComputeParams._metadata, IAgStkRadarClutterMapComputeParams._get_ClutterPatch_metadata)

    _get_Signal_metadata = { "offset" : _get_Signal_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Signal(self) -> "IAgCRSignal":
        """Gets the signal."""
        return self._intf.get_property(IAgStkRadarClutterMapComputeParams._metadata, IAgStkRadarClutterMapComputeParams._get_Signal_metadata)

    _ConstructPolarization_metadata = { "offset" : _ConstructPolarization_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgEnum_arg(AgECRPolarizationType), agmarshall.AgInterface_out_arg,) }
    def ConstructPolarization(self, polType:"AgECRPolarizationType") -> "IAgCRPolarization":
        """Constructs a new polarization object."""
        return self._intf.invoke(IAgStkRadarClutterMapComputeParams._metadata, IAgStkRadarClutterMapComputeParams._ConstructPolarization_metadata, polType, OutArg())

    _ConstructPolarizationCopy_metadata = { "offset" : _ConstructPolarizationCopy_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRPolarization"), agmarshall.AgInterface_out_arg,) }
    def ConstructPolarizationCopy(self, polarizationToCopy:"IAgCRPolarization") -> "IAgCRPolarization":
        """Constructs a copy of the specified polarization."""
        return self._intf.invoke(IAgStkRadarClutterMapComputeParams._metadata, IAgStkRadarClutterMapComputeParams._ConstructPolarizationCopy_metadata, polarizationToCopy, OutArg())

    _ConstructOrthogonalPolarization_metadata = { "offset" : _ConstructOrthogonalPolarization_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRPolarization"), agmarshall.AgInterface_out_arg,) }
    def ConstructOrthogonalPolarization(self, polarizationToCopy:"IAgCRPolarization") -> "IAgCRPolarization":
        """Constructs an orthogonal instance of the specified polarization."""
        return self._intf.invoke(IAgStkRadarClutterMapComputeParams._metadata, IAgStkRadarClutterMapComputeParams._ConstructOrthogonalPolarization_metadata, polarizationToCopy, OutArg())

    _property_names[RadarLink] = "RadarLink"
    _property_names[ClutterPatch] = "ClutterPatch"
    _property_names[Signal] = "Signal"


agcls.AgClassCatalog.add_catalog_entry((5045009382787308569, 1041245726555814023), IAgStkRadarClutterMapComputeParams)
agcls.AgTypeNameMap["IAgStkRadarClutterMapComputeParams"] = IAgStkRadarClutterMapComputeParams

class IAgStkRadarRcsProcessSignalsParams(object):
    """Interface implemented by an object that represents the parameters to be passed into the RCS plugin ProcessSignals method."""

    _num_methods = 9
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _GetIncidentBodyFixedVector_method_offset = 1
    _get_InicidentBodyFixedVectorArray_method_offset = 2
    _GetReflectedBodyFixedVector_method_offset = 3
    _get_ReflectedBodyFixedVectorArray_method_offset = 4
    _get_PrimaryPolChannelSignal_method_offset = 5
    _get_OrthoPolChannelSignal_method_offset = 6
    _ConstructPolarization_method_offset = 7
    _ConstructPolarizationCopy_method_offset = 8
    _ConstructOrthogonalPolarization_method_offset = 9
    _metadata = {
        "iid_data" : (5100936852841922643, 15462450439417460892),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarRcsProcessSignalsParams."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarRcsProcessSignalsParams)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarRcsProcessSignalsParams)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarRcsProcessSignalsParams, None)
    
    _GetIncidentBodyFixedVector_metadata = { "offset" : _GetIncidentBodyFixedVector_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetIncidentBodyFixedVector(self) -> typing.Tuple[float, float, float]:
        """Gets the incident body fixed vector."""
        return self._intf.invoke(IAgStkRadarRcsProcessSignalsParams._metadata, IAgStkRadarRcsProcessSignalsParams._GetIncidentBodyFixedVector_metadata, OutArg(), OutArg(), OutArg())

    _get_InicidentBodyFixedVectorArray_metadata = { "offset" : _get_InicidentBodyFixedVectorArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def InicidentBodyFixedVectorArray(self) -> list:
        """Gets the incident body fixed vector as an array."""
        return self._intf.get_property(IAgStkRadarRcsProcessSignalsParams._metadata, IAgStkRadarRcsProcessSignalsParams._get_InicidentBodyFixedVectorArray_metadata)

    _GetReflectedBodyFixedVector_metadata = { "offset" : _GetReflectedBodyFixedVector_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetReflectedBodyFixedVector(self) -> typing.Tuple[float, float, float]:
        """Gets the reflected body fixed vector."""
        return self._intf.invoke(IAgStkRadarRcsProcessSignalsParams._metadata, IAgStkRadarRcsProcessSignalsParams._GetReflectedBodyFixedVector_metadata, OutArg(), OutArg(), OutArg())

    _get_ReflectedBodyFixedVectorArray_metadata = { "offset" : _get_ReflectedBodyFixedVectorArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def ReflectedBodyFixedVectorArray(self) -> list:
        """Gets the reflected body fixed vector as an array."""
        return self._intf.get_property(IAgStkRadarRcsProcessSignalsParams._metadata, IAgStkRadarRcsProcessSignalsParams._get_ReflectedBodyFixedVectorArray_metadata)

    _get_PrimaryPolChannelSignal_metadata = { "offset" : _get_PrimaryPolChannelSignal_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def PrimaryPolChannelSignal(self) -> "IAgCRSignal":
        """Gets the read-only signal."""
        return self._intf.get_property(IAgStkRadarRcsProcessSignalsParams._metadata, IAgStkRadarRcsProcessSignalsParams._get_PrimaryPolChannelSignal_metadata)

    _get_OrthoPolChannelSignal_metadata = { "offset" : _get_OrthoPolChannelSignal_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def OrthoPolChannelSignal(self) -> "IAgCRSignal":
        """Gets the read-only signal."""
        return self._intf.get_property(IAgStkRadarRcsProcessSignalsParams._metadata, IAgStkRadarRcsProcessSignalsParams._get_OrthoPolChannelSignal_metadata)

    _ConstructPolarization_metadata = { "offset" : _ConstructPolarization_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgEnum_arg(AgECRPolarizationType), agmarshall.AgInterface_out_arg,) }
    def ConstructPolarization(self, polType:"AgECRPolarizationType") -> "IAgCRPolarization":
        """Constructs a new polarization object."""
        return self._intf.invoke(IAgStkRadarRcsProcessSignalsParams._metadata, IAgStkRadarRcsProcessSignalsParams._ConstructPolarization_metadata, polType, OutArg())

    _ConstructPolarizationCopy_metadata = { "offset" : _ConstructPolarizationCopy_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRPolarization"), agmarshall.AgInterface_out_arg,) }
    def ConstructPolarizationCopy(self, polarizationToCopy:"IAgCRPolarization") -> "IAgCRPolarization":
        """Constructs a copy of the specified polarization."""
        return self._intf.invoke(IAgStkRadarRcsProcessSignalsParams._metadata, IAgStkRadarRcsProcessSignalsParams._ConstructPolarizationCopy_metadata, polarizationToCopy, OutArg())

    _ConstructOrthogonalPolarization_metadata = { "offset" : _ConstructOrthogonalPolarization_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgCRPolarization"), agmarshall.AgInterface_out_arg,) }
    def ConstructOrthogonalPolarization(self, polarizationToCopy:"IAgCRPolarization") -> "IAgCRPolarization":
        """Constructs an orthogonal instance of the specified polarization."""
        return self._intf.invoke(IAgStkRadarRcsProcessSignalsParams._metadata, IAgStkRadarRcsProcessSignalsParams._ConstructOrthogonalPolarization_metadata, polarizationToCopy, OutArg())

    _property_names[InicidentBodyFixedVectorArray] = "InicidentBodyFixedVectorArray"
    _property_names[ReflectedBodyFixedVectorArray] = "ReflectedBodyFixedVectorArray"
    _property_names[PrimaryPolChannelSignal] = "PrimaryPolChannelSignal"
    _property_names[OrthoPolChannelSignal] = "OrthoPolChannelSignal"


agcls.AgClassCatalog.add_catalog_entry((5100936852841922643, 15462450439417460892), IAgStkRadarRcsProcessSignalsParams)
agcls.AgTypeNameMap["IAgStkRadarRcsProcessSignalsParams"] = IAgStkRadarRcsProcessSignalsParams

class IAgStkRadarRcsComputeParams(object):
    """Interface implemented by an object that represents the parameters to be passed into the RCS plugin Compute method."""

    _num_methods = 10
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Time_method_offset = 1
    _get_Frequency_method_offset = 2
    _GetIncidentBodyFixedVector_method_offset = 3
    _get_InicidentBodyFixedVectorArray_method_offset = 4
    _GetReflectedBodyFixedVector_method_offset = 5
    _get_ReflectedBodyFixedVectorArray_method_offset = 6
    _set_PrimaryChannelRcs_method_offset = 7
    _set_PrimaryChannelRcsCross_method_offset = 8
    _set_OrthoChannelRcs_method_offset = 9
    _set_OrthoChannelRcsCross_method_offset = 10
    _metadata = {
        "iid_data" : (5693662507541578689, 3224272045224979856),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarRcsComputeParams."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarRcsComputeParams)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarRcsComputeParams)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarRcsComputeParams, None)
    
    _get_Time_metadata = { "offset" : _get_Time_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Time(self) -> float:
        """Gets the current time."""
        return self._intf.get_property(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._get_Time_metadata)

    _get_Frequency_metadata = { "offset" : _get_Frequency_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Frequency(self) -> float:
        """Gets the signal frequency."""
        return self._intf.get_property(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._get_Frequency_metadata)

    _GetIncidentBodyFixedVector_metadata = { "offset" : _GetIncidentBodyFixedVector_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetIncidentBodyFixedVector(self) -> typing.Tuple[float, float, float]:
        """Gets the incident body fixed vector."""
        return self._intf.invoke(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._GetIncidentBodyFixedVector_metadata, OutArg(), OutArg(), OutArg())

    _get_InicidentBodyFixedVectorArray_metadata = { "offset" : _get_InicidentBodyFixedVectorArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def InicidentBodyFixedVectorArray(self) -> list:
        """Gets the incident body fixed vector as an array."""
        return self._intf.get_property(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._get_InicidentBodyFixedVectorArray_metadata)

    _GetReflectedBodyFixedVector_metadata = { "offset" : _GetReflectedBodyFixedVector_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetReflectedBodyFixedVector(self) -> typing.Tuple[float, float, float]:
        """Gets the reflected body fixed vector."""
        return self._intf.invoke(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._GetReflectedBodyFixedVector_metadata, OutArg(), OutArg(), OutArg())

    _get_ReflectedBodyFixedVectorArray_metadata = { "offset" : _get_ReflectedBodyFixedVectorArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def ReflectedBodyFixedVectorArray(self) -> list:
        """Gets the reflected body fixed vector as an array."""
        return self._intf.get_property(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._get_ReflectedBodyFixedVectorArray_metadata)

    _get_PrimaryChannelRcs_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def PrimaryChannelRcs(self) -> None:
        """PrimaryChannelRcs is a write-only property."""
        raise RuntimeError("PrimaryChannelRcs is a write-only property.")


    _set_PrimaryChannelRcs_metadata = { "offset" : _set_PrimaryChannelRcs_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @PrimaryChannelRcs.setter
    def PrimaryChannelRcs(self, rcs:float) -> None:
        """Sets the primary channel RCS value"""
        return self._intf.set_property(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._set_PrimaryChannelRcs_metadata, rcs)

    _get_PrimaryChannelRcsCross_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def PrimaryChannelRcsCross(self) -> None:
        """PrimaryChannelRcsCross is a write-only property."""
        raise RuntimeError("PrimaryChannelRcsCross is a write-only property.")


    _set_PrimaryChannelRcsCross_metadata = { "offset" : _set_PrimaryChannelRcsCross_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @PrimaryChannelRcsCross.setter
    def PrimaryChannelRcsCross(self, rcsCross:float) -> None:
        """Sets the primary channel cross pol RCS value"""
        return self._intf.set_property(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._set_PrimaryChannelRcsCross_metadata, rcsCross)

    _get_OrthoChannelRcs_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def OrthoChannelRcs(self) -> None:
        """OrthoChannelRcs is a write-only property."""
        raise RuntimeError("OrthoChannelRcs is a write-only property.")


    _set_OrthoChannelRcs_metadata = { "offset" : _set_OrthoChannelRcs_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @OrthoChannelRcs.setter
    def OrthoChannelRcs(self, rcs:float) -> None:
        """Sets the primary channel RCS value."""
        return self._intf.set_property(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._set_OrthoChannelRcs_metadata, rcs)

    _get_OrthoChannelRcsCross_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def OrthoChannelRcsCross(self) -> None:
        """OrthoChannelRcsCross is a write-only property."""
        raise RuntimeError("OrthoChannelRcsCross is a write-only property.")


    _set_OrthoChannelRcsCross_metadata = { "offset" : _set_OrthoChannelRcsCross_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @OrthoChannelRcsCross.setter
    def OrthoChannelRcsCross(self, rcsCross:float) -> None:
        """Sets the primary channel cross pol RCS value."""
        return self._intf.set_property(IAgStkRadarRcsComputeParams._metadata, IAgStkRadarRcsComputeParams._set_OrthoChannelRcsCross_metadata, rcsCross)

    _property_names[Time] = "Time"
    _property_names[Frequency] = "Frequency"
    _property_names[InicidentBodyFixedVectorArray] = "InicidentBodyFixedVectorArray"
    _property_names[ReflectedBodyFixedVectorArray] = "ReflectedBodyFixedVectorArray"
    _property_names[PrimaryChannelRcs] = "PrimaryChannelRcs"
    _property_names[PrimaryChannelRcsCross] = "PrimaryChannelRcsCross"
    _property_names[OrthoChannelRcs] = "OrthoChannelRcs"
    _property_names[OrthoChannelRcsCross] = "OrthoChannelRcsCross"


agcls.AgClassCatalog.add_catalog_entry((5693662507541578689, 3224272045224979856), IAgStkRadarRcsComputeParams)
agcls.AgTypeNameMap["IAgStkRadarRcsComputeParams"] = IAgStkRadarRcsComputeParams

class IAgStkRadarFixedPRFProbabilityDetectionComputeParams(object):
    """Interface implemented by an object that represents the parameters to be passed into the Probability of Detection CFAR plugin Compute method."""

    _num_methods = 9
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_SinglePulseSignaltoNoiseRatio_method_offset = 1
    _get_IntegratedSignaltoNoiseRatio_method_offset = 2
    _get_CoherentIntegration_method_offset = 3
    _get_NoisePower_method_offset = 4
    _get_NumberOfIntegratedPulses_method_offset = 5
    _get_ReceivedRadarSignal_method_offset = 6
    _get_ClutterSignals_method_offset = 7
    _SetProbabilityOfDetectionSinglePulse_method_offset = 8
    _SetProbabilityOfDetectionIntegrated_method_offset = 9
    _metadata = {
        "iid_data" : (4937686362971566406, 5944773199476312509),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarFixedPRFProbabilityDetectionComputeParams."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarFixedPRFProbabilityDetectionComputeParams)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarFixedPRFProbabilityDetectionComputeParams)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarFixedPRFProbabilityDetectionComputeParams, None)
    
    _get_SinglePulseSignaltoNoiseRatio_metadata = { "offset" : _get_SinglePulseSignaltoNoiseRatio_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SinglePulseSignaltoNoiseRatio(self) -> float:
        """Gets the radar link single pulse signal-to-noise ratio value."""
        return self._intf.get_property(IAgStkRadarFixedPRFProbabilityDetectionComputeParams._metadata, IAgStkRadarFixedPRFProbabilityDetectionComputeParams._get_SinglePulseSignaltoNoiseRatio_metadata)

    _get_IntegratedSignaltoNoiseRatio_metadata = { "offset" : _get_IntegratedSignaltoNoiseRatio_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def IntegratedSignaltoNoiseRatio(self) -> float:
        """Gets the radar link integrated signal-to-noise ratio value."""
        return self._intf.get_property(IAgStkRadarFixedPRFProbabilityDetectionComputeParams._metadata, IAgStkRadarFixedPRFProbabilityDetectionComputeParams._get_IntegratedSignaltoNoiseRatio_metadata)

    _get_CoherentIntegration_metadata = { "offset" : _get_CoherentIntegration_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def CoherentIntegration(self) -> bool:
        """Gets a flag indicating whether or not the signal-to-noise ratio was integrated coherently."""
        return self._intf.get_property(IAgStkRadarFixedPRFProbabilityDetectionComputeParams._metadata, IAgStkRadarFixedPRFProbabilityDetectionComputeParams._get_CoherentIntegration_metadata)

    _get_NoisePower_metadata = { "offset" : _get_NoisePower_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def NoisePower(self) -> float:
        """Gets the radar receiver noise power."""
        return self._intf.get_property(IAgStkRadarFixedPRFProbabilityDetectionComputeParams._metadata, IAgStkRadarFixedPRFProbabilityDetectionComputeParams._get_NoisePower_metadata)

    _get_NumberOfIntegratedPulses_metadata = { "offset" : _get_NumberOfIntegratedPulses_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def NumberOfIntegratedPulses(self) -> int:
        """Gets the radar link number of pulse integrated."""
        return self._intf.get_property(IAgStkRadarFixedPRFProbabilityDetectionComputeParams._metadata, IAgStkRadarFixedPRFProbabilityDetectionComputeParams._get_NumberOfIntegratedPulses_metadata)

    _get_ReceivedRadarSignal_metadata = { "offset" : _get_ReceivedRadarSignal_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ReceivedRadarSignal(self) -> "IAgCRSignal":
        """Gets the radar link signal data."""
        return self._intf.get_property(IAgStkRadarFixedPRFProbabilityDetectionComputeParams._metadata, IAgStkRadarFixedPRFProbabilityDetectionComputeParams._get_ReceivedRadarSignal_metadata)

    _get_ClutterSignals_metadata = { "offset" : _get_ClutterSignals_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ClutterSignals(self) -> "IAgCRSignalCollection":
        """Gets the radar link clutter signal collection."""
        return self._intf.get_property(IAgStkRadarFixedPRFProbabilityDetectionComputeParams._metadata, IAgStkRadarFixedPRFProbabilityDetectionComputeParams._get_ClutterSignals_metadata)

    _SetProbabilityOfDetectionSinglePulse_metadata = { "offset" : _SetProbabilityOfDetectionSinglePulse_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetProbabilityOfDetectionSinglePulse(self, probDetSinglePulse:float) -> None:
        """Sets the probability of detection single pulse value."""
        return self._intf.invoke(IAgStkRadarFixedPRFProbabilityDetectionComputeParams._metadata, IAgStkRadarFixedPRFProbabilityDetectionComputeParams._SetProbabilityOfDetectionSinglePulse_metadata, probDetSinglePulse)

    _SetProbabilityOfDetectionIntegrated_metadata = { "offset" : _SetProbabilityOfDetectionIntegrated_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetProbabilityOfDetectionIntegrated(self, probDetIntegrated:float) -> None:
        """Sets the integrated probability of detection value."""
        return self._intf.invoke(IAgStkRadarFixedPRFProbabilityDetectionComputeParams._metadata, IAgStkRadarFixedPRFProbabilityDetectionComputeParams._SetProbabilityOfDetectionIntegrated_metadata, probDetIntegrated)

    _property_names[SinglePulseSignaltoNoiseRatio] = "SinglePulseSignaltoNoiseRatio"
    _property_names[IntegratedSignaltoNoiseRatio] = "IntegratedSignaltoNoiseRatio"
    _property_names[CoherentIntegration] = "CoherentIntegration"
    _property_names[NoisePower] = "NoisePower"
    _property_names[NumberOfIntegratedPulses] = "NumberOfIntegratedPulses"
    _property_names[ReceivedRadarSignal] = "ReceivedRadarSignal"
    _property_names[ClutterSignals] = "ClutterSignals"


agcls.AgClassCatalog.add_catalog_entry((4937686362971566406, 5944773199476312509), IAgStkRadarFixedPRFProbabilityDetectionComputeParams)
agcls.AgTypeNameMap["IAgStkRadarFixedPRFProbabilityDetectionComputeParams"] = IAgStkRadarFixedPRFProbabilityDetectionComputeParams

class IAgStkRadarFixedPRFProbabilityDetectionPlugin(object):
    """Interface implemented by an object that represents a Probability of Detection CFAR plugin."""

    _num_methods = 8
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _Initialize_method_offset = 1
    _PreCompute_method_offset = 2
    _Compute_method_offset = 3
    _ComputeJamming_method_offset = 4
    _ComputeJammingClutter_method_offset = 5
    _PostCompute_method_offset = 6
    _Free_method_offset = 7
    _get_NumberOfConstantFalseAlarmRateCells_method_offset = 8
    _metadata = {
        "iid_data" : (5670607983370773675, 4497552814971684746),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgStkRadarFixedPRFProbabilityDetectionPlugin."""
        initialize_from_source_object(self, sourceObject, IAgStkRadarFixedPRFProbabilityDetectionPlugin)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgStkRadarFixedPRFProbabilityDetectionPlugin)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgStkRadarFixedPRFProbabilityDetectionPlugin, None)
    
    _Initialize_metadata = { "offset" : _Initialize_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgUtPluginSite"),) }
    def Initialize(self, site:"IAgUtPluginSite") -> None:
        """Initializes the plugin with the plugin site."""
        return self._intf.invoke(IAgStkRadarFixedPRFProbabilityDetectionPlugin._metadata, IAgStkRadarFixedPRFProbabilityDetectionPlugin._Initialize_metadata, site)

    _PreCompute_metadata = { "offset" : _PreCompute_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def PreCompute(self) -> bool:
        """Probability of Detection CFAR plugin pre-compute."""
        return self._intf.invoke(IAgStkRadarFixedPRFProbabilityDetectionPlugin._metadata, IAgStkRadarFixedPRFProbabilityDetectionPlugin._PreCompute_metadata, OutArg())

    _Compute_metadata = { "offset" : _Compute_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRadarFixedPRFProbabilityDetectionComputeParams"),) }
    def Compute(self, computeParams:"IAgStkRadarFixedPRFProbabilityDetectionComputeParams") -> None:
        """Probability of Detection CFAR plugin compute with SNR."""
        return self._intf.invoke(IAgStkRadarFixedPRFProbabilityDetectionPlugin._metadata, IAgStkRadarFixedPRFProbabilityDetectionPlugin._Compute_metadata, computeParams)

    _ComputeJamming_metadata = { "offset" : _ComputeJamming_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRadarFixedPRFProbabilityDetectionComputeParams"),) }
    def ComputeJamming(self, computeParams:"IAgStkRadarFixedPRFProbabilityDetectionComputeParams") -> None:
        """Probability of Detection CFAR plugin compute with S/(N+J)."""
        return self._intf.invoke(IAgStkRadarFixedPRFProbabilityDetectionPlugin._metadata, IAgStkRadarFixedPRFProbabilityDetectionPlugin._ComputeJamming_metadata, computeParams)

    _ComputeJammingClutter_metadata = { "offset" : _ComputeJammingClutter_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgStkRadarFixedPRFProbabilityDetectionComputeParams"),) }
    def ComputeJammingClutter(self, computeParams:"IAgStkRadarFixedPRFProbabilityDetectionComputeParams") -> None:
        """Probability of Detection CFAR plugin compute with S/(N+J+C)."""
        return self._intf.invoke(IAgStkRadarFixedPRFProbabilityDetectionPlugin._metadata, IAgStkRadarFixedPRFProbabilityDetectionPlugin._ComputeJammingClutter_metadata, computeParams)

    _PostCompute_metadata = { "offset" : _PostCompute_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def PostCompute(self) -> None:
        """Probability of Detection CFAR plugin post-compute."""
        return self._intf.invoke(IAgStkRadarFixedPRFProbabilityDetectionPlugin._metadata, IAgStkRadarFixedPRFProbabilityDetectionPlugin._PostCompute_metadata, )

    _Free_metadata = { "offset" : _Free_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Free(self) -> None:
        """Free Probability of Detection CFAR plugin."""
        return self._intf.invoke(IAgStkRadarFixedPRFProbabilityDetectionPlugin._metadata, IAgStkRadarFixedPRFProbabilityDetectionPlugin._Free_metadata, )

    _get_NumberOfConstantFalseAlarmRateCells_metadata = { "offset" : _get_NumberOfConstantFalseAlarmRateCells_method_offset,
            "arg_types" : (POINTER(agcom.INT),),
            "marshallers" : (agmarshall.INT_arg,) }
    @property
    def NumberOfConstantFalseAlarmRateCells(self) -> int:
        """Gets the number of constant false alarm rate cells."""
        return self._intf.get_property(IAgStkRadarFixedPRFProbabilityDetectionPlugin._metadata, IAgStkRadarFixedPRFProbabilityDetectionPlugin._get_NumberOfConstantFalseAlarmRateCells_metadata)

    _property_names[NumberOfConstantFalseAlarmRateCells] = "NumberOfConstantFalseAlarmRateCells"


agcls.AgClassCatalog.add_catalog_entry((5670607983370773675, 4497552814971684746), IAgStkRadarFixedPRFProbabilityDetectionPlugin)
agcls.AgTypeNameMap["IAgStkRadarFixedPRFProbabilityDetectionPlugin"] = IAgStkRadarFixedPRFProbabilityDetectionPlugin

class IAgSTKRadarSTCAttenComputeParams(object):
    """Interface implemented by an object that represents the parameters to be passed into the STC plugin Compute method."""

    _num_methods = 8
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Time_method_offset = 1
    _get_Frequency_method_offset = 2
    _get_Range_method_offset = 3
    _get_AzimuthAngle_method_offset = 4
    _get_ElevationAngle_method_offset = 5
    _GetDirection_method_offset = 6
    _get_DirectionArray_method_offset = 7
    _SetSTCAttenuation_method_offset = 8
    _metadata = {
        "iid_data" : (4938871654688516767, 11129756337177592198),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSTKRadarSTCAttenComputeParams."""
        initialize_from_source_object(self, sourceObject, IAgSTKRadarSTCAttenComputeParams)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSTKRadarSTCAttenComputeParams)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSTKRadarSTCAttenComputeParams, None)
    
    _get_Time_metadata = { "offset" : _get_Time_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Time(self) -> float:
        """Gets the time value."""
        return self._intf.get_property(IAgSTKRadarSTCAttenComputeParams._metadata, IAgSTKRadarSTCAttenComputeParams._get_Time_metadata)

    _get_Frequency_metadata = { "offset" : _get_Frequency_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Frequency(self) -> float:
        """Gets the frequency value."""
        return self._intf.get_property(IAgSTKRadarSTCAttenComputeParams._metadata, IAgSTKRadarSTCAttenComputeParams._get_Frequency_metadata)

    _get_Range_metadata = { "offset" : _get_Range_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Range(self) -> float:
        """Gets the radar link range value."""
        return self._intf.get_property(IAgSTKRadarSTCAttenComputeParams._metadata, IAgSTKRadarSTCAttenComputeParams._get_Range_metadata)

    _get_AzimuthAngle_metadata = { "offset" : _get_AzimuthAngle_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def AzimuthAngle(self) -> float:
        """Gets the radar link Azimuth angle value."""
        return self._intf.get_property(IAgSTKRadarSTCAttenComputeParams._metadata, IAgSTKRadarSTCAttenComputeParams._get_AzimuthAngle_metadata)

    _get_ElevationAngle_metadata = { "offset" : _get_ElevationAngle_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def ElevationAngle(self) -> float:
        """Gets the radar link Elevation Angle value."""
        return self._intf.get_property(IAgSTKRadarSTCAttenComputeParams._metadata, IAgSTKRadarSTCAttenComputeParams._get_ElevationAngle_metadata)

    _GetDirection_metadata = { "offset" : _GetDirection_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def GetDirection(self) -> typing.Tuple[float, float, float]:
        """Gets the direction vector in the body fixed frame."""
        return self._intf.invoke(IAgSTKRadarSTCAttenComputeParams._metadata, IAgSTKRadarSTCAttenComputeParams._GetDirection_metadata, OutArg(), OutArg(), OutArg())

    _get_DirectionArray_metadata = { "offset" : _get_DirectionArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    @property
    def DirectionArray(self) -> list:
        """Gets the direction vector in the body fixed frame as an array."""
        return self._intf.get_property(IAgSTKRadarSTCAttenComputeParams._metadata, IAgSTKRadarSTCAttenComputeParams._get_DirectionArray_metadata)

    _SetSTCAttenuation_metadata = { "offset" : _SetSTCAttenuation_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def SetSTCAttenuation(self, sTCAttenuation:float) -> None:
        """Sets the STC attenuation value."""
        return self._intf.invoke(IAgSTKRadarSTCAttenComputeParams._metadata, IAgSTKRadarSTCAttenComputeParams._SetSTCAttenuation_metadata, sTCAttenuation)

    _property_names[Time] = "Time"
    _property_names[Frequency] = "Frequency"
    _property_names[Range] = "Range"
    _property_names[AzimuthAngle] = "AzimuthAngle"
    _property_names[ElevationAngle] = "ElevationAngle"
    _property_names[DirectionArray] = "DirectionArray"


agcls.AgClassCatalog.add_catalog_entry((4938871654688516767, 11129756337177592198), IAgSTKRadarSTCAttenComputeParams)
agcls.AgTypeNameMap["IAgSTKRadarSTCAttenComputeParams"] = IAgSTKRadarSTCAttenComputeParams

class IAgSTKRadarSTCAttenPlugin(object):
    """Interface implemented by an object that represents a STC plugin."""

    _num_methods = 5
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _Initialize_method_offset = 1
    _PreCompute_method_offset = 2
    _ComputeAttenuation_method_offset = 3
    _PostCompute_method_offset = 4
    _Free_method_offset = 5
    _metadata = {
        "iid_data" : (5632773476200890378, 5784661356017895871),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSTKRadarSTCAttenPlugin."""
        initialize_from_source_object(self, sourceObject, IAgSTKRadarSTCAttenPlugin)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSTKRadarSTCAttenPlugin)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSTKRadarSTCAttenPlugin, None)
    
    _Initialize_metadata = { "offset" : _Initialize_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgUtPluginSite"),) }
    def Initialize(self, site:"IAgUtPluginSite") -> None:
        """Initializes the plugin with the plugin site."""
        return self._intf.invoke(IAgSTKRadarSTCAttenPlugin._metadata, IAgSTKRadarSTCAttenPlugin._Initialize_metadata, site)

    _PreCompute_metadata = { "offset" : _PreCompute_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def PreCompute(self) -> bool:
        """STC plugin pre-compute."""
        return self._intf.invoke(IAgSTKRadarSTCAttenPlugin._metadata, IAgSTKRadarSTCAttenPlugin._PreCompute_metadata, OutArg())

    _ComputeAttenuation_metadata = { "offset" : _ComputeAttenuation_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgSTKRadarSTCAttenComputeParams"),) }
    def ComputeAttenuation(self, computeParams:"IAgSTKRadarSTCAttenComputeParams") -> None:
        """STC plugin compute attenuation."""
        return self._intf.invoke(IAgSTKRadarSTCAttenPlugin._metadata, IAgSTKRadarSTCAttenPlugin._ComputeAttenuation_metadata, computeParams)

    _PostCompute_metadata = { "offset" : _PostCompute_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def PostCompute(self) -> None:
        """STC plugin post-compute."""
        return self._intf.invoke(IAgSTKRadarSTCAttenPlugin._metadata, IAgSTKRadarSTCAttenPlugin._PostCompute_metadata, )

    _Free_metadata = { "offset" : _Free_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Free(self) -> None:
        """Free STC plugin."""
        return self._intf.invoke(IAgSTKRadarSTCAttenPlugin._metadata, IAgSTKRadarSTCAttenPlugin._Free_metadata, )


agcls.AgClassCatalog.add_catalog_entry((5632773476200890378, 5784661356017895871), IAgSTKRadarSTCAttenPlugin)
agcls.AgTypeNameMap["IAgSTKRadarSTCAttenPlugin"] = IAgSTKRadarSTCAttenPlugin


class IAgStkRadarClutterGeometryPlugin(object):
    """
    Interface implemented by an object that represents a clutter geometry plugin.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Register(self, registrationInfo:"IAgStkRadarClutterGeometryPluginRegInfo") -> None:
        """Registers the plugin with the application."""
        raise STKPluginMethodNotImplementedError("Register was not implemented.")

    def Initialize(self, site:"IAgUtPluginSite") -> None:
        """Initializes the plugin with the plugin site."""
        raise STKPluginMethodNotImplementedError("Initialize was not implemented.")

    def PreCompute(self) -> bool:
        """Clutter geometry plugin pre-compute."""
        raise STKPluginMethodNotImplementedError("PreCompute was not implemented.")

    def Compute(self, computeParams:"IAgStkRadarClutterGeometryComputeParams") -> None:
        """Clutter geometry plugin compute."""
        raise STKPluginMethodNotImplementedError("Compute was not implemented.")

    def PostCompute(self) -> None:
        """Clutter geometry plugin post-compute."""
        raise STKPluginMethodNotImplementedError("PostCompute was not implemented.")

    def Free(self) -> None:
        """Free clutter geometry plugin."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")


class IAgStkRadarClutterMapPlugin(object):
    """
    Interface implemented by an object that represents a clutter map plugin.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Initialize(self, site:"IAgUtPluginSite") -> None:
        """Initializes the plugin with the plugin site."""
        raise STKPluginMethodNotImplementedError("Initialize was not implemented.")

    def PreCompute(self) -> bool:
        """Clutter map plugin pre-compute."""
        raise STKPluginMethodNotImplementedError("PreCompute was not implemented.")

    def Compute(self, computeParams:"IAgStkRadarClutterMapComputeParams") -> None:
        """Clutter map plugin compute."""
        raise STKPluginMethodNotImplementedError("Compute was not implemented.")

    def PostCompute(self) -> None:
        """Clutter map plugin post-compute."""
        raise STKPluginMethodNotImplementedError("PostCompute was not implemented.")

    def Free(self) -> None:
        """Free clutter map plugin."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")


class IAgStkRadarRcsPlugin(object):
    """
    Interface implemented by an object that represents an RCS plugin.
    This interface may be inherited from to assist in development of the plugin.  All methods should be overridden.
    """
    def Initialize(self, site:"IAgUtPluginSite") -> None:
        """Initializes the plugin with the plugin site."""
        raise STKPluginMethodNotImplementedError("Initialize was not implemented.")

    def PreCompute(self) -> bool:
        """RCS plugin pre-compute."""
        raise STKPluginMethodNotImplementedError("PreCompute was not implemented.")

    def ProcessSignals(self, processSignalsParams:"IAgStkRadarRcsProcessSignalsParams") -> None:
        """Processes the incident primary and orthogonal channel signals."""
        raise STKPluginMethodNotImplementedError("ProcessSignals was not implemented.")

    def Compute(self, computeRcsParams:"IAgStkRadarRcsComputeParams") -> None:
        """RCS plugin compute."""
        raise STKPluginMethodNotImplementedError("Compute was not implemented.")

    def PostCompute(self) -> None:
        """RCS plugin post-compute"""
        raise STKPluginMethodNotImplementedError("PostCompute was not implemented.")

    def Free(self) -> None:
        """Free RCS plugin."""
        raise STKPluginMethodNotImplementedError("Free was not implemented.")

    def IsDynamic(self) -> bool:
        """Gets a flag indicating whether or not the radar cross section is dynamic."""
        raise STKPluginMethodNotImplementedError("IsDynamic was not implemented.")




class AgCRPolarizationCircular(IAgCRPolarization, SupportsDeleteCallback):
    """The CoClass for the IAgCRPolarization interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCRPolarizationCircular."""
        SupportsDeleteCallback.__init__(self)
        IAgCRPolarization.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCRPolarization._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCRPolarizationCircular, [IAgCRPolarization])

agcls.AgClassCatalog.add_catalog_entry((5005715852689275966, 18368832400845262739), AgCRPolarizationCircular)
agcls.AgTypeNameMap["AgCRPolarizationCircular"] = AgCRPolarizationCircular

class AgCRPolarizationLinear(IAgCRPolarizationLinear, IAgCRPolarization, SupportsDeleteCallback):
    """The CoClass for the IAgCRPolarization and IAgCRPolarizationLinear interfaces."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCRPolarizationLinear."""
        SupportsDeleteCallback.__init__(self)
        IAgCRPolarizationLinear.__init__(self, sourceObject)
        IAgCRPolarization.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCRPolarizationLinear._private_init(self, intf)
        IAgCRPolarization._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCRPolarizationLinear, [IAgCRPolarizationLinear, IAgCRPolarization])

agcls.AgClassCatalog.add_catalog_entry((5010078144810697057, 10965896673022949545), AgCRPolarizationLinear)
agcls.AgTypeNameMap["AgCRPolarizationLinear"] = AgCRPolarizationLinear

class AgCRPolarizationElliptical(IAgCRPolarizationElliptical, IAgCRPolarization, SupportsDeleteCallback):
    """The CoClass for the IAgCRPolarization and IAgCRPolarizationElliptical interfaces."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCRPolarizationElliptical."""
        SupportsDeleteCallback.__init__(self)
        IAgCRPolarizationElliptical.__init__(self, sourceObject)
        IAgCRPolarization.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCRPolarizationElliptical._private_init(self, intf)
        IAgCRPolarization._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCRPolarizationElliptical, [IAgCRPolarizationElliptical, IAgCRPolarization])

agcls.AgClassCatalog.add_catalog_entry((5611950267845119101, 1261226532490531003), AgCRPolarizationElliptical)
agcls.AgTypeNameMap["AgCRPolarizationElliptical"] = AgCRPolarizationElliptical

class AgStkRadarCBIntersectComputeParams(IAgStkRadarCBIntersectComputeParams, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarCBIntersectComputeParams interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarCBIntersectComputeParams."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarCBIntersectComputeParams.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarCBIntersectComputeParams._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarCBIntersectComputeParams, [IAgStkRadarCBIntersectComputeParams])

agcls.AgClassCatalog.add_catalog_entry((5409336899813013704, 13610474112102215863), AgStkRadarCBIntersectComputeParams)
agcls.AgTypeNameMap["AgStkRadarCBIntersectComputeParams"] = AgStkRadarCBIntersectComputeParams

class AgStkRadarCBIntersectComputeResult(IAgStkRadarCBIntersectComputeResult, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarCBIntersectComputeResult interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarCBIntersectComputeResult."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarCBIntersectComputeResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarCBIntersectComputeResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarCBIntersectComputeResult, [IAgStkRadarCBIntersectComputeResult])

agcls.AgClassCatalog.add_catalog_entry((5082437260670604159, 12515665938220916670), AgStkRadarCBIntersectComputeResult)
agcls.AgTypeNameMap["AgStkRadarCBIntersectComputeResult"] = AgStkRadarCBIntersectComputeResult

class AgStkRadarPosVelProvider(IAgStkRadarPosVelProvider, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarPosVelProvider interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarPosVelProvider."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarPosVelProvider.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarPosVelProvider._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarPosVelProvider, [IAgStkRadarPosVelProvider])

agcls.AgClassCatalog.add_catalog_entry((4993261429861133593, 6387260263351057800), AgStkRadarPosVelProvider)
agcls.AgTypeNameMap["AgStkRadarPosVelProvider"] = AgStkRadarPosVelProvider

class AgStkRadarPositionProvider(IAgStkRadarPosVelProvider, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarPosVelProvider interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarPositionProvider."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarPosVelProvider.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarPosVelProvider._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarPositionProvider, [IAgStkRadarPosVelProvider])

agcls.AgClassCatalog.add_catalog_entry((5176194258291872500, 18037845158994883718), AgStkRadarPositionProvider)
agcls.AgTypeNameMap["AgStkRadarPositionProvider"] = AgStkRadarPositionProvider

class AgStkRadarLinkGeometry(IAgStkRadarLinkGeometry, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarLinkGeometry interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarLinkGeometry."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarLinkGeometry.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarLinkGeometry._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarLinkGeometry, [IAgStkRadarLinkGeometry])

agcls.AgClassCatalog.add_catalog_entry((5517996255841469063, 1220757159139539613), AgStkRadarLinkGeometry)
agcls.AgTypeNameMap["AgStkRadarLinkGeometry"] = AgStkRadarLinkGeometry

class AgStkRadarLink(IAgStkRadarLink, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarLink interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarLink."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarLink.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarLink._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarLink, [IAgStkRadarLink])

agcls.AgClassCatalog.add_catalog_entry((4878233582596144301, 11605759941190648741), AgStkRadarLink)
agcls.AgTypeNameMap["AgStkRadarLink"] = AgStkRadarLink

class AgStkRadarSignal(IAgCRSignal, IAgStkRadarSignal, SupportsDeleteCallback):
    """The CoClass for the IAgCRSignal and IAgStkRadarSignal interfaces."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarSignal."""
        SupportsDeleteCallback.__init__(self)
        IAgCRSignal.__init__(self, sourceObject)
        IAgStkRadarSignal.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCRSignal._private_init(self, intf)
        IAgStkRadarSignal._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarSignal, [IAgCRSignal, IAgStkRadarSignal])

agcls.AgClassCatalog.add_catalog_entry((4771336929022640334, 17344067796109648050), AgStkRadarSignal)
agcls.AgTypeNameMap["AgStkRadarSignal"] = AgStkRadarSignal

class AgStkRadarClutterPatch(IAgStkRadarClutterPatch, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarClutterPatch interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarClutterPatch."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarClutterPatch.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarClutterPatch._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarClutterPatch, [IAgStkRadarClutterPatch])

agcls.AgClassCatalog.add_catalog_entry((5103194720119250833, 90359511766110605), AgStkRadarClutterPatch)
agcls.AgTypeNameMap["AgStkRadarClutterPatch"] = AgStkRadarClutterPatch

class AgStkRadarClutterPatchCollection(IAgStkRadarClutterPatchCollection, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarClutterPatchCollection interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarClutterPatchCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarClutterPatchCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarClutterPatchCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarClutterPatchCollection, [IAgStkRadarClutterPatchCollection])

agcls.AgClassCatalog.add_catalog_entry((5347381108569007831, 9915888466859896506), AgStkRadarClutterPatchCollection)
agcls.AgTypeNameMap["AgStkRadarClutterPatchCollection"] = AgStkRadarClutterPatchCollection

class AgStkRadarClutterGeometryPluginRegInfo(IAgStkRadarClutterGeometryPluginRegInfo, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarClutterGeometryPluginRegInfo interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarClutterGeometryPluginRegInfo."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarClutterGeometryPluginRegInfo.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarClutterGeometryPluginRegInfo._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarClutterGeometryPluginRegInfo, [IAgStkRadarClutterGeometryPluginRegInfo])

agcls.AgClassCatalog.add_catalog_entry((5450053744166648470, 9080666654881431727), AgStkRadarClutterGeometryPluginRegInfo)
agcls.AgTypeNameMap["AgStkRadarClutterGeometryPluginRegInfo"] = AgStkRadarClutterGeometryPluginRegInfo

class AgStkRadarClutterGeometryComputeParams(IAgStkRadarClutterGeometryComputeParams, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarClutterGeometryComputeParams interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarClutterGeometryComputeParams."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarClutterGeometryComputeParams.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarClutterGeometryComputeParams._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarClutterGeometryComputeParams, [IAgStkRadarClutterGeometryComputeParams])

agcls.AgClassCatalog.add_catalog_entry((4936675910266815619, 17818130632058785717), AgStkRadarClutterGeometryComputeParams)
agcls.AgTypeNameMap["AgStkRadarClutterGeometryComputeParams"] = AgStkRadarClutterGeometryComputeParams

class AgStkRadarClutterMapComputeParams(IAgStkRadarClutterMapComputeParams, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarClutterMapComputeParams interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarClutterMapComputeParams."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarClutterMapComputeParams.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarClutterMapComputeParams._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarClutterMapComputeParams, [IAgStkRadarClutterMapComputeParams])

agcls.AgClassCatalog.add_catalog_entry((5466449593075710932, 11046144250900759181), AgStkRadarClutterMapComputeParams)
agcls.AgTypeNameMap["AgStkRadarClutterMapComputeParams"] = AgStkRadarClutterMapComputeParams

class AgStkRadarRcsProcessSignalsParams(IAgStkRadarRcsProcessSignalsParams, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarRcsProcessSignalsParams interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarRcsProcessSignalsParams."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarRcsProcessSignalsParams.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarRcsProcessSignalsParams._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarRcsProcessSignalsParams, [IAgStkRadarRcsProcessSignalsParams])

agcls.AgClassCatalog.add_catalog_entry((5614630858454813471, 13379507173703589813), AgStkRadarRcsProcessSignalsParams)
agcls.AgTypeNameMap["AgStkRadarRcsProcessSignalsParams"] = AgStkRadarRcsProcessSignalsParams

class AgStkRadarRcsComputeParams(IAgStkRadarRcsComputeParams, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarRcsComputeParams interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarRcsComputeParams."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarRcsComputeParams.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarRcsComputeParams._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarRcsComputeParams, [IAgStkRadarRcsComputeParams])

agcls.AgClassCatalog.add_catalog_entry((4707507458985183403, 2709988911661048764), AgStkRadarRcsComputeParams)
agcls.AgTypeNameMap["AgStkRadarRcsComputeParams"] = AgStkRadarRcsComputeParams

class AgStkRadarFixedPRFProbabilityDetectionComputeParams(IAgStkRadarFixedPRFProbabilityDetectionComputeParams, SupportsDeleteCallback):
    """The CoClass for the IAgStkRadarFixedPRFProbabilityDetectionComputeParams interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarFixedPRFProbabilityDetectionComputeParams."""
        SupportsDeleteCallback.__init__(self)
        IAgStkRadarFixedPRFProbabilityDetectionComputeParams.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgStkRadarFixedPRFProbabilityDetectionComputeParams._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarFixedPRFProbabilityDetectionComputeParams, [IAgStkRadarFixedPRFProbabilityDetectionComputeParams])

agcls.AgClassCatalog.add_catalog_entry((5679720370019666785, 15019771574418628235), AgStkRadarFixedPRFProbabilityDetectionComputeParams)
agcls.AgTypeNameMap["AgStkRadarFixedPRFProbabilityDetectionComputeParams"] = AgStkRadarFixedPRFProbabilityDetectionComputeParams

class AgStkRadarSTCAttenComputeParams(IAgSTKRadarSTCAttenComputeParams, SupportsDeleteCallback):
    """The CoClass for the IAgSTKRadarSTCAttenComputeParams interface."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgStkRadarSTCAttenComputeParams."""
        SupportsDeleteCallback.__init__(self)
        IAgSTKRadarSTCAttenComputeParams.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgSTKRadarSTCAttenComputeParams._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgStkRadarSTCAttenComputeParams, [IAgSTKRadarSTCAttenComputeParams])

agcls.AgClassCatalog.add_catalog_entry((5308473036934195844, 14063837449229859459), AgStkRadarSTCAttenComputeParams)
agcls.AgTypeNameMap["AgStkRadarSTCAttenComputeParams"] = AgStkRadarSTCAttenComputeParams


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
