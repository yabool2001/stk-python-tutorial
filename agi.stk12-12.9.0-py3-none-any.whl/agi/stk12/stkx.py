################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgDataObject", "AgDataObjectFiles", "AgDraw2DElemCollection", "AgDraw2DElemRect", "AgDrawElemCollection", "AgDrawElemLine", 
"AgDrawElemRect", "AgEButtonValues", "AgEExecMultiCmdResultAction", "AgEFeatureCodes", "AgEGfxAnalysisMode", "AgEGfxDrawCoords", 
"AgELineStyle", "AgELogMsgDispID", "AgELogMsgType", "AgELoggingMode", "AgEMouseMode", "AgEOLEDropMode", "AgEProgressImageXOrigin", 
"AgEProgressImageYOrigin", "AgEShiftValues", "AgEShowProgressImage", "AgExecCmdResult", "AgExecMultiCmdResult", "AgObjPathCollection", 
"AgPickInfoData", "AgRubberBandPickInfoData", "AgSTKXApplication", "AgSTKXApplicationPartnerAccess", "AgSTKXConControlQuitReceivedEventArgs", 
"AgSTKXSSLCertificateErrorEventArgs", "AgUiAx2DCntrl", "AgUiAxGfxAnalysisCntrl", "AgUiAxVOCntrl", "AgWinProjPos", "IAgDataObject", 
"IAgDataObjectFiles", "IAgDrawElem", "IAgDrawElemCollection", "IAgDrawElemLine", "IAgDrawElemRect", "IAgExecCmdResult", 
"IAgExecMultiCmdResult", "IAgObjPathCollection", "IAgPickInfoData", "IAgRubberBandPickInfoData", "IAgSTKXApplication", "IAgSTKXApplicationPartnerAccess", 
"IAgSTKXConControlQuitReceivedEventArgs", "IAgSTKXSSLCertificateErrorEventArgs", "IAgUiAx2DCntrl", "IAgUiAxGfxAnalysisCntrl", 
"IAgUiAxVOCntrl", "IAgWinProjPos"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from .internal  import comutil          as agcom
from .internal  import coclassutil      as agcls
from .internal  import marshall         as agmarshall
from .internal  import dataanalysisutil as agdata
from .utilities import colors           as agcolor
from .internal.comutil     import IUnknown, IDispatch, IPictureDisp
from .internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from .internal.eventutil   import *
from .utilities.exceptions import *

from .stkutil import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgELogMsgType(IntEnum):
    """Log message types."""
   
    eLogMsgDebug = 0
    """Debugging message."""
    eLogMsgInfo = 1
    """Informational message."""
    eLogMsgForceInfo = 2
    """Informational message."""
    eLogMsgWarning = 3
    """Warning message."""
    eLogMsgAlarm = 4
    """Alarm message."""

AgELogMsgType.eLogMsgDebug.__doc__ = "Debugging message."
AgELogMsgType.eLogMsgInfo.__doc__ = "Informational message."
AgELogMsgType.eLogMsgForceInfo.__doc__ = "Informational message."
AgELogMsgType.eLogMsgWarning.__doc__ = "Warning message."
AgELogMsgType.eLogMsgAlarm.__doc__ = "Alarm message."

agcls.AgTypeNameMap["AgELogMsgType"] = AgELogMsgType

class AgELogMsgDispID(IntEnum):
    """Log message destination options."""
   
    eLogMsgDispAll = -1
    """STK displays the message in all the log destination."""
    eLogMsgDispDefault = 0
    """STK displays the message in the default log destination."""
    eLogMsgDispMsgWin = 1
    """STK displays the message in the message window."""
    eLogMsgDispStatusBar = 2
    """STK displays the message in the status bar."""

AgELogMsgDispID.eLogMsgDispAll.__doc__ = "STK displays the message in all the log destination."
AgELogMsgDispID.eLogMsgDispDefault.__doc__ = "STK displays the message in the default log destination."
AgELogMsgDispID.eLogMsgDispMsgWin.__doc__ = "STK displays the message in the message window."
AgELogMsgDispID.eLogMsgDispStatusBar.__doc__ = "STK displays the message in the status bar."

agcls.AgTypeNameMap["AgELogMsgDispID"] = AgELogMsgDispID

class AgELineStyle(IntEnum):
    """Line Style."""
   
    eSolid = 0
    """Specifies a solid line."""
    eDashed = 1
    """Specifies a dashed line."""
    eDotted = 2
    """Specifies a dotted line."""
    eDotDashed = 3
    """Dot-dashed line."""
    eLongDashed = 4
    """Specifies a long dashed line."""
    eDashDotDotted = 5
    """Specifies an alternating dash-dot-dot line."""
    eMDash = 6
    """Specifies a user configurable medium dashed line."""
    eLDash = 7
    """Specifies a user configurable long dashed line."""
    eSDashDot = 8
    """Specifies a user configurable small dash-dotted line."""
    eMDashDot = 9
    """Specifies a user configurable medium dash-dotted line."""
    eLDashDot = 10
    """Specifies a user configurable long dash-dotted line."""
    eMSDash = 11
    """Specifies a user configurable medium followed by small dashed line."""
    eLSDash = 12
    """Specifies a user configurable long followed by small dashed line."""
    eLMDash = 13
    """Specifies a user configurable long followed by medium dashed line."""
    eLMSDash = 14
    """Specifies a user configurable medium followed by small dashed line."""
    eDot = 15
    """Specifies a dotted line."""
    eLongDash = 16
    """Specifies a long dashed line."""
    eSDash = 17
    """Specifies an alternating dash-dot line."""

AgELineStyle.eSolid.__doc__ = "Specifies a solid line."
AgELineStyle.eDashed.__doc__ = "Specifies a dashed line."
AgELineStyle.eDotted.__doc__ = "Specifies a dotted line."
AgELineStyle.eDotDashed.__doc__ = "Dot-dashed line."
AgELineStyle.eLongDashed.__doc__ = "Specifies a long dashed line."
AgELineStyle.eDashDotDotted.__doc__ = "Specifies an alternating dash-dot-dot line."
AgELineStyle.eMDash.__doc__ = "Specifies a user configurable medium dashed line."
AgELineStyle.eLDash.__doc__ = "Specifies a user configurable long dashed line."
AgELineStyle.eSDashDot.__doc__ = "Specifies a user configurable small dash-dotted line."
AgELineStyle.eMDashDot.__doc__ = "Specifies a user configurable medium dash-dotted line."
AgELineStyle.eLDashDot.__doc__ = "Specifies a user configurable long dash-dotted line."
AgELineStyle.eMSDash.__doc__ = "Specifies a user configurable medium followed by small dashed line."
AgELineStyle.eLSDash.__doc__ = "Specifies a user configurable long followed by small dashed line."
AgELineStyle.eLMDash.__doc__ = "Specifies a user configurable long followed by medium dashed line."
AgELineStyle.eLMSDash.__doc__ = "Specifies a user configurable medium followed by small dashed line."
AgELineStyle.eDot.__doc__ = "Specifies a dotted line."
AgELineStyle.eLongDash.__doc__ = "Specifies a long dashed line."
AgELineStyle.eSDash.__doc__ = "Specifies an alternating dash-dot line."

agcls.AgTypeNameMap["AgELineStyle"] = AgELineStyle

class AgEExecMultiCmdResultAction(IntFlag):
    """Enumeration defines a set of actions when an error occurs while executing a command batch."""
   
    eContinueOnError = 0
    """Continue executing the remaining commands in the command batch."""
    eStopOnError = 1
    """Terminate the execution of the command batch but do not throw an exception."""
    eExceptionOnError = 2
    """Terminate the execution of the command batch and throw an exception."""
    eIgnoreExecCmdResult = 0x8000
    """Ignore results returned by individual commands. The option must be used in combination with other flags."""

AgEExecMultiCmdResultAction.eContinueOnError.__doc__ = "Continue executing the remaining commands in the command batch."
AgEExecMultiCmdResultAction.eStopOnError.__doc__ = "Terminate the execution of the command batch but do not throw an exception."
AgEExecMultiCmdResultAction.eExceptionOnError.__doc__ = "Terminate the execution of the command batch and throw an exception."
AgEExecMultiCmdResultAction.eIgnoreExecCmdResult.__doc__ = "Ignore results returned by individual commands. The option must be used in combination with other flags."

agcls.AgTypeNameMap["AgEExecMultiCmdResultAction"] = AgEExecMultiCmdResultAction

class AgEShiftValues(IntEnum):
    """State of the Shift/Ctrl/Alt keys."""
   
    eShiftPressed = 1
    """The Shift key was pressed."""
    eCtrlPressed = 2
    """The Ctrl key was pressed."""
    eAltPressed = 4
    """The ALT key was pressed."""

AgEShiftValues.eShiftPressed.__doc__ = "The Shift key was pressed."
AgEShiftValues.eCtrlPressed.__doc__ = "The Ctrl key was pressed."
AgEShiftValues.eAltPressed.__doc__ = "The ALT key was pressed."

agcls.AgTypeNameMap["AgEShiftValues"] = AgEShiftValues

class AgEButtonValues(IntEnum):
    """Numeric value of the mouse button pressed."""
   
    eLeftPressed = 1
    """The left button is pressed."""
    eRightPressed = 2
    """The right button is pressed."""
    eMiddlePressed = 4
    """The middle button is pressed."""

AgEButtonValues.eLeftPressed.__doc__ = "The left button is pressed."
AgEButtonValues.eRightPressed.__doc__ = "The right button is pressed."
AgEButtonValues.eMiddlePressed.__doc__ = "The middle button is pressed."

agcls.AgTypeNameMap["AgEButtonValues"] = AgEButtonValues

class AgEOLEDropMode(IntEnum):
    """Specifies how to handle OLE drop operations."""
   
    eNone = 0
    """None. The control does not accept OLE drops and displays the No Drop cursor."""
    eManual = 1
    """Manual. The control triggers the OLE drop events, allowing the programmer to handle the OLE drop operation in code."""
    eAutomatic = 2
    """Automatic. The control automatically accepts OLE drops if the DataObject object contains data in a format it recognizes. No OLE drag/drop events on the target will occur when OLEDropMode is set to eAutomatic."""

AgEOLEDropMode.eNone.__doc__ = "None. The control does not accept OLE drops and displays the No Drop cursor."
AgEOLEDropMode.eManual.__doc__ = "Manual. The control triggers the OLE drop events, allowing the programmer to handle the OLE drop operation in code."
AgEOLEDropMode.eAutomatic.__doc__ = "Automatic. The control automatically accepts OLE drops if the DataObject object contains data in a format it recognizes. No OLE drag/drop events on the target will occur when OLEDropMode is set to eAutomatic."

agcls.AgTypeNameMap["AgEOLEDropMode"] = AgEOLEDropMode

class AgEMouseMode(IntEnum):
    """Mouse modes."""
   
    eMouseModeAutomatic = 0
    """Automatic. The control handles the mouse events and then fires the events to the container for additional processing."""
    eMouseModeManual = 1
    """None. No default action happens on mouse events. Events are fired to the container."""

AgEMouseMode.eMouseModeAutomatic.__doc__ = "Automatic. The control handles the mouse events and then fires the events to the container for additional processing."
AgEMouseMode.eMouseModeManual.__doc__ = "None. No default action happens on mouse events. Events are fired to the container."

agcls.AgTypeNameMap["AgEMouseMode"] = AgEMouseMode

class AgELoggingMode(IntEnum):
    """Specifies the state of the log file."""
   
    eLogInactive = 0
    """The log file is not created."""
    eLogActive = 1
    """The log file is created but deleted upon application termination."""
    eLogActiveKeepFile = 2
    """The log file is created and kept even after application is terminated."""

AgELoggingMode.eLogInactive.__doc__ = "The log file is not created."
AgELoggingMode.eLogActive.__doc__ = "The log file is created but deleted upon application termination."
AgELoggingMode.eLogActiveKeepFile.__doc__ = "The log file is created and kept even after application is terminated."

agcls.AgTypeNameMap["AgELoggingMode"] = AgELoggingMode

class AgEGfxAnalysisMode(IntEnum):
    """Specifies the mode of Gfx Analysis Control."""
   
    eSolarPanelTool = 1
    """The Solar Panel Tool mode."""
    eAreaTool = 2
    """The Area Tool mode."""
    eObscurationTool = 3
    """The Obscuration Tool mode."""
    eAzElMaskTool = 4
    """The AzElMask Tool mode."""

AgEGfxAnalysisMode.eSolarPanelTool.__doc__ = "The Solar Panel Tool mode."
AgEGfxAnalysisMode.eAreaTool.__doc__ = "The Area Tool mode."
AgEGfxAnalysisMode.eObscurationTool.__doc__ = "The Obscuration Tool mode."
AgEGfxAnalysisMode.eAzElMaskTool.__doc__ = "The AzElMask Tool mode."

agcls.AgTypeNameMap["AgEGfxAnalysisMode"] = AgEGfxAnalysisMode

class AgEGfxDrawCoords(IntEnum):
    """Specifies the draw coordinates for Map Control."""
   
    ePixelDrawCoords = 1
    """The draw coordinates values in pixels."""
    eScreenDrawCoords = 2
    """The draw coordinates values in screen coordinates."""

AgEGfxDrawCoords.ePixelDrawCoords.__doc__ = "The draw coordinates values in pixels."
AgEGfxDrawCoords.eScreenDrawCoords.__doc__ = "The draw coordinates values in screen coordinates."

agcls.AgTypeNameMap["AgEGfxDrawCoords"] = AgEGfxDrawCoords

class AgEShowProgressImage(IntEnum):
    """Specifies to show progress image."""
   
    eShowProgressImageNone = 1
    """Do not show any progress Image."""
    eShowProgressImageDefault = 2
    """Show the default progress image."""
    eShowProgressImageUser = 3
    """Show the user specified progress image."""

AgEShowProgressImage.eShowProgressImageNone.__doc__ = "Do not show any progress Image."
AgEShowProgressImage.eShowProgressImageDefault.__doc__ = "Show the default progress image."
AgEShowProgressImage.eShowProgressImageUser.__doc__ = "Show the user specified progress image."

agcls.AgTypeNameMap["AgEShowProgressImage"] = AgEShowProgressImage

class AgEFeatureCodes(IntEnum):
    """The enumeration values are used to check availability of a given feature."""
   
    eFeatureCodeEngineRuntime = 1
    """The enumeration is used to check whether the engine runtime is available."""
    eFeatureCodeGlobeControl = 2
    """The enumeration is used to check whether the globe is available."""

AgEFeatureCodes.eFeatureCodeEngineRuntime.__doc__ = "The enumeration is used to check whether the engine runtime is available."
AgEFeatureCodes.eFeatureCodeGlobeControl.__doc__ = "The enumeration is used to check whether the globe is available."

agcls.AgTypeNameMap["AgEFeatureCodes"] = AgEFeatureCodes

class AgEProgressImageXOrigin(IntEnum):
    """Specifies to align progress image X origin."""
   
    eProgressImageXLeft = 1
    """Align progress Image from X left."""
    eProgressImageXRight = 2
    """Align progress Image from X right."""
    eProgressImageXCenter = 3
    """Align progress Image from X center."""

AgEProgressImageXOrigin.eProgressImageXLeft.__doc__ = "Align progress Image from X left."
AgEProgressImageXOrigin.eProgressImageXRight.__doc__ = "Align progress Image from X right."
AgEProgressImageXOrigin.eProgressImageXCenter.__doc__ = "Align progress Image from X center."

agcls.AgTypeNameMap["AgEProgressImageXOrigin"] = AgEProgressImageXOrigin

class AgEProgressImageYOrigin(IntEnum):
    """Specifies to align progress image Y origin."""
   
    eProgressImageYTop = 1
    """Align progress Image from Y top."""
    eProgressImageYBottom = 2
    """Align progress Image from Y bottom."""
    eProgressImageYCenter = 3
    """Align progress Image from Y center."""

AgEProgressImageYOrigin.eProgressImageYTop.__doc__ = "Align progress Image from Y top."
AgEProgressImageYOrigin.eProgressImageYBottom.__doc__ = "Align progress Image from Y bottom."
AgEProgressImageYOrigin.eProgressImageYCenter.__doc__ = "Align progress Image from Y center."

agcls.AgTypeNameMap["AgEProgressImageYOrigin"] = AgEProgressImageYOrigin


class IAgSTKXSSLCertificateErrorEventArgs(object):
    """Provides information about an SSL certificate that is expired or invalid."""

    _num_methods = 12
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _SetIgnoreError_method_offset = 1
    _get_IsErrorIgnored_method_offset = 2
    _SetIgnoreErrorPermanently_method_offset = 3
    _get_SerialNumber_method_offset = 4
    _get_Issuer_method_offset = 5
    _get_Subject_method_offset = 6
    _get_ValidDate_method_offset = 7
    _get_ExpirationDate_method_offset = 8
    _get_IsExpired_method_offset = 9
    _get_PEMData_method_offset = 10
    _get_Handled_method_offset = 11
    _set_Handled_method_offset = 12
    _metadata = {
        "iid_data" : (5021181385185406140, 17247430173549626005),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSTKXSSLCertificateErrorEventArgs."""
        initialize_from_source_object(self, sourceObject, IAgSTKXSSLCertificateErrorEventArgs)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSTKXSSLCertificateErrorEventArgs)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSTKXSSLCertificateErrorEventArgs, None)
    
    _SetIgnoreError_metadata = { "offset" : _SetIgnoreError_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def SetIgnoreError(self, ignoreError:bool) -> None:
        """Specify True to ignore the certificate error and continue with establishing secure HTTP connection to the remote server."""
        return self._intf.invoke(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._SetIgnoreError_metadata, ignoreError)

    _get_IsErrorIgnored_metadata = { "offset" : _get_IsErrorIgnored_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsErrorIgnored(self) -> bool:
        """Returns whether the invalid certificate error is ignored."""
        return self._intf.get_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._get_IsErrorIgnored_metadata)

    _SetIgnoreErrorPermanently_metadata = { "offset" : _SetIgnoreErrorPermanently_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def SetIgnoreErrorPermanently(self, ignoreErrorPermanently:bool) -> None:
        """Specify True to ignore the certificate error and add the certificate to the list of trusted certificates."""
        return self._intf.invoke(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._SetIgnoreErrorPermanently_metadata, ignoreErrorPermanently)

    _get_SerialNumber_metadata = { "offset" : _get_SerialNumber_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def SerialNumber(self) -> str:
        """Certificate's serial number."""
        return self._intf.get_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._get_SerialNumber_metadata)

    _get_Issuer_metadata = { "offset" : _get_Issuer_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Issuer(self) -> str:
        """The provider who issued the certificate."""
        return self._intf.get_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._get_Issuer_metadata)

    _get_Subject_metadata = { "offset" : _get_Subject_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Subject(self) -> str:
        """Certificate's subject field."""
        return self._intf.get_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._get_Subject_metadata)

    _get_ValidDate_metadata = { "offset" : _get_ValidDate_method_offset,
            "arg_types" : (POINTER(agcom.DATE),),
            "marshallers" : (agmarshall.DATE_arg,) }
    @property
    def ValidDate(self) -> datetime:
        """Certificate's valid date."""
        return self._intf.get_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._get_ValidDate_metadata)

    _get_ExpirationDate_metadata = { "offset" : _get_ExpirationDate_method_offset,
            "arg_types" : (POINTER(agcom.DATE),),
            "marshallers" : (agmarshall.DATE_arg,) }
    @property
    def ExpirationDate(self) -> datetime:
        """Certificate's expiration date."""
        return self._intf.get_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._get_ExpirationDate_metadata)

    _get_IsExpired_metadata = { "offset" : _get_IsExpired_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsExpired(self) -> bool:
        """Whether the certificate is expired."""
        return self._intf.get_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._get_IsExpired_metadata)

    _get_PEMData_metadata = { "offset" : _get_PEMData_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def PEMData(self) -> str:
        """Certificate's PEM data encoded as base-64."""
        return self._intf.get_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._get_PEMData_metadata)

    _get_Handled_metadata = { "offset" : _get_Handled_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def Handled(self) -> bool:
        """Indicates whether the event should continue be routed to the listeners. Setting Handled to true will prevent the event from reaching any remaining listeners."""
        return self._intf.get_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._get_Handled_metadata)

    _set_Handled_metadata = { "offset" : _set_Handled_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @Handled.setter
    def Handled(self, bHandled:bool) -> None:
        """Indicates whether the event should continue be routed to the listeners. Setting Handled to true will prevent the event from reaching any remaining listeners."""
        return self._intf.set_property(IAgSTKXSSLCertificateErrorEventArgs._metadata, IAgSTKXSSLCertificateErrorEventArgs._set_Handled_metadata, bHandled)

    _property_names[IsErrorIgnored] = "IsErrorIgnored"
    _property_names[SerialNumber] = "SerialNumber"
    _property_names[Issuer] = "Issuer"
    _property_names[Subject] = "Subject"
    _property_names[ValidDate] = "ValidDate"
    _property_names[ExpirationDate] = "ExpirationDate"
    _property_names[IsExpired] = "IsExpired"
    _property_names[PEMData] = "PEMData"
    _property_names[Handled] = "Handled"


agcls.AgClassCatalog.add_catalog_entry((5021181385185406140, 17247430173549626005), IAgSTKXSSLCertificateErrorEventArgs)
agcls.AgTypeNameMap["IAgSTKXSSLCertificateErrorEventArgs"] = IAgSTKXSSLCertificateErrorEventArgs

class IAgSTKXConControlQuitReceivedEventArgs(object):
    """Arguments for the OnConControlQuitReceived event."""

    _num_methods = 2
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Acknowledge_method_offset = 1
    _set_Acknowledge_method_offset = 2
    _metadata = {
        "iid_data" : (5616982977185734553, 10125948910293673126),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSTKXConControlQuitReceivedEventArgs."""
        initialize_from_source_object(self, sourceObject, IAgSTKXConControlQuitReceivedEventArgs)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSTKXConControlQuitReceivedEventArgs)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSTKXConControlQuitReceivedEventArgs, None)
    
    _get_Acknowledge_metadata = { "offset" : _get_Acknowledge_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def Acknowledge(self) -> bool:
        """Indicates whether or not to acknowledge the connect command."""
        return self._intf.get_property(IAgSTKXConControlQuitReceivedEventArgs._metadata, IAgSTKXConControlQuitReceivedEventArgs._get_Acknowledge_metadata)

    _set_Acknowledge_metadata = { "offset" : _set_Acknowledge_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @Acknowledge.setter
    def Acknowledge(self, acknowledge:bool) -> None:
        """Indicates whether or not to acknowledge the connect command."""
        return self._intf.set_property(IAgSTKXConControlQuitReceivedEventArgs._metadata, IAgSTKXConControlQuitReceivedEventArgs._set_Acknowledge_metadata, acknowledge)

    _property_names[Acknowledge] = "Acknowledge"


agcls.AgClassCatalog.add_catalog_entry((5616982977185734553, 10125948910293673126), IAgSTKXConControlQuitReceivedEventArgs)
agcls.AgTypeNameMap["IAgSTKXConControlQuitReceivedEventArgs"] = IAgSTKXConControlQuitReceivedEventArgs

class IAgPickInfoData(object):
    """Mouse pick details."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_ObjPath_method_offset = 1
    _get_Lat_method_offset = 2
    _get_Lon_method_offset = 3
    _get_Alt_method_offset = 4
    _get_IsObjPathValid_method_offset = 5
    _get_IsLatLonAltValid_method_offset = 6
    _metadata = {
        "iid_data" : (5698141537397851098, 16489903714142238396),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgPickInfoData."""
        initialize_from_source_object(self, sourceObject, IAgPickInfoData)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgPickInfoData)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgPickInfoData, None)
    
    _get_ObjPath_metadata = { "offset" : _get_ObjPath_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ObjPath(self) -> str:
        """Path of the STK object picked if any (or empty string)."""
        return self._intf.get_property(IAgPickInfoData._metadata, IAgPickInfoData._get_ObjPath_metadata)

    _get_Lat_metadata = { "offset" : _get_Lat_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Lat(self) -> float:
        """Latitude of point clicked (if available)."""
        return self._intf.get_property(IAgPickInfoData._metadata, IAgPickInfoData._get_Lat_metadata)

    _get_Lon_metadata = { "offset" : _get_Lon_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Lon(self) -> float:
        """Longitude of point clicked (if available)."""
        return self._intf.get_property(IAgPickInfoData._metadata, IAgPickInfoData._get_Lon_metadata)

    _get_Alt_metadata = { "offset" : _get_Alt_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Alt(self) -> float:
        """Altitude of point clicked (if available)."""
        return self._intf.get_property(IAgPickInfoData._metadata, IAgPickInfoData._get_Alt_metadata)

    _get_IsObjPathValid_metadata = { "offset" : _get_IsObjPathValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsObjPathValid(self) -> bool:
        """Indicate if the ObjPath property is valid."""
        return self._intf.get_property(IAgPickInfoData._metadata, IAgPickInfoData._get_IsObjPathValid_metadata)

    _get_IsLatLonAltValid_metadata = { "offset" : _get_IsLatLonAltValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsLatLonAltValid(self) -> bool:
        """Indicate if the Lat/Lon/Alt properties are valid."""
        return self._intf.get_property(IAgPickInfoData._metadata, IAgPickInfoData._get_IsLatLonAltValid_metadata)

    _property_names[ObjPath] = "ObjPath"
    _property_names[Lat] = "Lat"
    _property_names[Lon] = "Lon"
    _property_names[Alt] = "Alt"
    _property_names[IsObjPathValid] = "IsObjPathValid"
    _property_names[IsLatLonAltValid] = "IsLatLonAltValid"


agcls.AgClassCatalog.add_catalog_entry((5698141537397851098, 16489903714142238396), IAgPickInfoData)
agcls.AgTypeNameMap["IAgPickInfoData"] = IAgPickInfoData

class IAgRubberBandPickInfoData(object):
    """Rubber-band mouse pick result."""

    _num_methods = 1
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_ObjPaths_method_offset = 1
    _metadata = {
        "iid_data" : (5465369937390436249, 5504180940665807527),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgRubberBandPickInfoData."""
        initialize_from_source_object(self, sourceObject, IAgRubberBandPickInfoData)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgRubberBandPickInfoData)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgRubberBandPickInfoData, None)
    
    _get_ObjPaths_metadata = { "offset" : _get_ObjPaths_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ObjPaths(self) -> "IAgObjPathCollection":
        """List of object paths selected."""
        return self._intf.get_property(IAgRubberBandPickInfoData._metadata, IAgRubberBandPickInfoData._get_ObjPaths_metadata)

    _property_names[ObjPaths] = "ObjPaths"


agcls.AgClassCatalog.add_catalog_entry((5465369937390436249, 5504180940665807527), IAgRubberBandPickInfoData)
agcls.AgTypeNameMap["IAgRubberBandPickInfoData"] = IAgRubberBandPickInfoData

class IAgSTKXApplication(object):
    """STK X Application object."""

    _num_methods = 28
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _ExecuteCommand_method_offset = 1
    _get_EnableConnect_method_offset = 2
    _set_EnableConnect_method_offset = 3
    _get_ConnectPort_method_offset = 4
    _set_ConnectPort_method_offset = 5
    _get_HostID_method_offset = 6
    _get_RegistrationID_method_offset = 7
    _get_Version_method_offset = 8
    _GetLicensingReport_method_offset = 9
    _get_VendorID_method_offset = 10
    _set_VendorID_method_offset = 11
    _SetOnlineOptions_method_offset = 12
    _GetOnlineOptions_method_offset = 13
    _SetConnectHandler_method_offset = 14
    _get_LogFileFullName_method_offset = 15
    _get_LoggingMode_method_offset = 16
    _set_LoggingMode_method_offset = 17
    _get_ConnectMaxConnections_method_offset = 18
    _set_ConnectMaxConnections_method_offset = 19
    _ExecuteMultipleCommands_method_offset = 20
    _IsFeatureAvailable_method_offset = 21
    _get_NoGraphics_method_offset = 22
    _set_NoGraphics_method_offset = 23
    _Terminate_method_offset = 24
    _get_ShowSLAIfNotAccepted_method_offset = 25
    _set_ShowSLAIfNotAccepted_method_offset = 26
    _set_UseHook_method_offset = 27
    _UseSoftwareRenderer_method_offset = 28
    _metadata = {
        "iid_data" : (5592884008737014642, 4650136333548635012),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSTKXApplication."""
        initialize_from_source_object(self, sourceObject, IAgSTKXApplication)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSTKXApplication)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSTKXApplication, None)
    def Subscribe(self) -> IAgSTKXApplicationEventHandler:
        """Return an IAgSTKXApplicationEventHandler that is subscribed to handle events associated with this instance of IAgSTKXApplication."""
        return IAgSTKXApplicationEventHandler(self._intf)
    
    _ExecuteCommand_metadata = { "offset" : _ExecuteCommand_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def ExecuteCommand(self, command:str) -> "IAgExecCmdResult":
        """Send a connect command to STK X."""
        return self._intf.invoke(IAgSTKXApplication._metadata, IAgSTKXApplication._ExecuteCommand_metadata, command, OutArg())

    _get_EnableConnect_metadata = { "offset" : _get_EnableConnect_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def EnableConnect(self) -> bool:
        """Enable or disable TCP/IP connect command processing (default: disabled)."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_EnableConnect_metadata)

    _set_EnableConnect_metadata = { "offset" : _set_EnableConnect_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @EnableConnect.setter
    def EnableConnect(self, newVal:bool) -> None:
        return self._intf.set_property(IAgSTKXApplication._metadata, IAgSTKXApplication._set_EnableConnect_metadata, newVal)

    _get_ConnectPort_metadata = { "offset" : _get_ConnectPort_method_offset,
            "arg_types" : (POINTER(agcom.SHORT),),
            "marshallers" : (agmarshall.SHORT_arg,) }
    @property
    def ConnectPort(self) -> int:
        """Specify TCP/IP port to be used by Connect (default: 5001)."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_ConnectPort_metadata)

    _set_ConnectPort_metadata = { "offset" : _set_ConnectPort_method_offset,
            "arg_types" : (agcom.SHORT,),
            "marshallers" : (agmarshall.SHORT_arg,) }
    @ConnectPort.setter
    def ConnectPort(self, newVal:int) -> None:
        return self._intf.set_property(IAgSTKXApplication._metadata, IAgSTKXApplication._set_ConnectPort_metadata, newVal)

    _get_HostID_metadata = { "offset" : _get_HostID_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def HostID(self) -> str:
        """Returns the Host ID."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_HostID_metadata)

    _get_RegistrationID_metadata = { "offset" : _get_RegistrationID_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def RegistrationID(self) -> str:
        """Returns the Registration ID."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_RegistrationID_metadata)

    _get_Version_metadata = { "offset" : _get_Version_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Version(self) -> str:
        """Returns the version number."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_Version_metadata)

    _GetLicensingReport_metadata = { "offset" : _GetLicensingReport_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def GetLicensingReport(self) -> str:
        """This method is deprecated. Returns a formatted string that contains the license names and their states. The string is formatted as an XML document."""
        return self._intf.invoke(IAgSTKXApplication._metadata, IAgSTKXApplication._GetLicensingReport_metadata, OutArg())

    _get_VendorID_metadata = { "offset" : _get_VendorID_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def VendorID(self) -> str:
        """This property is deprecated. The identifier of the vendor."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_VendorID_metadata)

    _set_VendorID_metadata = { "offset" : _set_VendorID_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @VendorID.setter
    def VendorID(self, vendorID:str) -> None:
        return self._intf.set_property(IAgSTKXApplication._metadata, IAgSTKXApplication._set_VendorID_metadata, vendorID)

    _SetOnlineOptions_metadata = { "offset" : _SetOnlineOptions_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL, agcom.BSTR, agcom.LONG, agcom.BSTR, agcom.BSTR, agcom.VARIANT_BOOL, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg, agmarshall.VARIANT_BOOL_arg,) }
    def SetOnlineOptions(self, useProxy:bool, serverName:str, portNum:int, userName:str, password:str, savePassword:bool) -> bool:
        """Set http proxy online options."""
        return self._intf.invoke(IAgSTKXApplication._metadata, IAgSTKXApplication._SetOnlineOptions_metadata, useProxy, serverName, portNum, userName, password, savePassword, OutArg())

    _GetOnlineOptions_metadata = { "offset" : _GetOnlineOptions_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL), POINTER(agcom.BSTR), POINTER(agcom.LONG), POINTER(agcom.BSTR), POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg, agmarshall.BSTR_arg, agmarshall.LONG_arg, agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg,) }
    def GetOnlineOptions(self) -> typing.Tuple[bool, str, int, str, bool]:
        """Get http proxy online options."""
        return self._intf.invoke(IAgSTKXApplication._metadata, IAgSTKXApplication._GetOnlineOptions_metadata, OutArg(), OutArg(), OutArg(), OutArg(), OutArg())

    _SetConnectHandler_metadata = { "offset" : _SetConnectHandler_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def SetConnectHandler(self, commandID:str, progID:str) -> None:
        """Set callback to handle a certain connect command."""
        return self._intf.invoke(IAgSTKXApplication._metadata, IAgSTKXApplication._SetConnectHandler_metadata, commandID, progID)

    _get_LogFileFullName_metadata = { "offset" : _get_LogFileFullName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def LogFileFullName(self) -> str:
        """Returns full path and log file name."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_LogFileFullName_metadata)

    _get_LoggingMode_metadata = { "offset" : _get_LoggingMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgELoggingMode),) }
    @property
    def LoggingMode(self) -> "AgELoggingMode":
        """Controls the log file generation, and if the log file is deleted or not on application exit."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_LoggingMode_metadata)

    _set_LoggingMode_metadata = { "offset" : _set_LoggingMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgELoggingMode),) }
    @LoggingMode.setter
    def LoggingMode(self, newVal:"AgELoggingMode") -> None:
        return self._intf.set_property(IAgSTKXApplication._metadata, IAgSTKXApplication._set_LoggingMode_metadata, newVal)

    _get_ConnectMaxConnections_metadata = { "offset" : _get_ConnectMaxConnections_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ConnectMaxConnections(self) -> int:
        """Specify the maximum number of Connect connections to allow."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_ConnectMaxConnections_metadata)

    _set_ConnectMaxConnections_metadata = { "offset" : _set_ConnectMaxConnections_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @ConnectMaxConnections.setter
    def ConnectMaxConnections(self, newVal:int) -> None:
        return self._intf.set_property(IAgSTKXApplication._metadata, IAgSTKXApplication._set_ConnectMaxConnections_metadata, newVal)

    _ExecuteMultipleCommands_metadata = { "offset" : _ExecuteMultipleCommands_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY), agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg, agmarshall.AgEnum_arg(AgEExecMultiCmdResultAction), agmarshall.AgInterface_out_arg,) }
    def ExecuteMultipleCommands(self, connectCommands:list, eAction:"AgEExecMultiCmdResultAction") -> "IAgExecMultiCmdResult":
        """Executes multiple CONNECT actions. The method throws an exception if any of the specified commands have failed."""
        return self._intf.invoke(IAgSTKXApplication._metadata, IAgSTKXApplication._ExecuteMultipleCommands_metadata, connectCommands, eAction, OutArg())

    _IsFeatureAvailable_metadata = { "offset" : _IsFeatureAvailable_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEFeatureCodes), agmarshall.VARIANT_BOOL_arg,) }
    def IsFeatureAvailable(self, featureCode:"AgEFeatureCodes") -> bool:
        """Returns true if the specified feature is available."""
        return self._intf.invoke(IAgSTKXApplication._metadata, IAgSTKXApplication._IsFeatureAvailable_metadata, featureCode, OutArg())

    _get_NoGraphics_metadata = { "offset" : _get_NoGraphics_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def NoGraphics(self) -> bool:
        """Start engine with or without graphics (default: engine starts with graphics.)."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_NoGraphics_metadata)

    _set_NoGraphics_metadata = { "offset" : _set_NoGraphics_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @NoGraphics.setter
    def NoGraphics(self, newVal:bool) -> None:
        return self._intf.set_property(IAgSTKXApplication._metadata, IAgSTKXApplication._set_NoGraphics_metadata, newVal)

    _Terminate_metadata = { "offset" : _Terminate_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Terminate(self) -> None:
        """Terminates the use of STK Engine. This must be the last call to STK Engine."""
        return self._intf.invoke(IAgSTKXApplication._metadata, IAgSTKXApplication._Terminate_metadata, )

    _get_ShowSLAIfNotAccepted_metadata = { "offset" : _get_ShowSLAIfNotAccepted_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def ShowSLAIfNotAccepted(self) -> bool:
        """Shows the Software License Agreement dialog if not already accepted."""
        return self._intf.get_property(IAgSTKXApplication._metadata, IAgSTKXApplication._get_ShowSLAIfNotAccepted_metadata)

    _set_ShowSLAIfNotAccepted_metadata = { "offset" : _set_ShowSLAIfNotAccepted_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @ShowSLAIfNotAccepted.setter
    def ShowSLAIfNotAccepted(self, newVal:bool) -> None:
        return self._intf.set_property(IAgSTKXApplication._metadata, IAgSTKXApplication._set_ShowSLAIfNotAccepted_metadata, newVal)

    _get_UseHook_metadata = { "offset" : 0,
            "arg_types" : (),
            "marshallers" : () }
    @property
    def UseHook(self) -> None:
        """UseHook is a write-only property."""
        raise RuntimeError("UseHook is a write-only property.")


    _set_UseHook_metadata = { "offset" : _set_UseHook_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UseHook.setter
    def UseHook(self, newVal:bool) -> None:
        """Start engine with or without message hook setup (default: engine starts with message hook setup.)."""
        return self._intf.set_property(IAgSTKXApplication._metadata, IAgSTKXApplication._set_UseHook_metadata, newVal)

    _UseSoftwareRenderer_metadata = { "offset" : _UseSoftwareRenderer_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def UseSoftwareRenderer(self) -> None:
        """Configure engine graphics to use a software renderer in order to meet minimum graphics requirements. Enabling this option will result in significant performance impacts."""
        return self._intf.invoke(IAgSTKXApplication._metadata, IAgSTKXApplication._UseSoftwareRenderer_metadata, )

    _property_names[EnableConnect] = "EnableConnect"
    _property_names[ConnectPort] = "ConnectPort"
    _property_names[HostID] = "HostID"
    _property_names[RegistrationID] = "RegistrationID"
    _property_names[Version] = "Version"
    _property_names[VendorID] = "VendorID"
    _property_names[LogFileFullName] = "LogFileFullName"
    _property_names[LoggingMode] = "LoggingMode"
    _property_names[ConnectMaxConnections] = "ConnectMaxConnections"
    _property_names[NoGraphics] = "NoGraphics"
    _property_names[ShowSLAIfNotAccepted] = "ShowSLAIfNotAccepted"
    _property_names[UseHook] = "UseHook"


agcls.AgClassCatalog.add_catalog_entry((5592884008737014642, 4650136333548635012), IAgSTKXApplication)
agcls.AgTypeNameMap["IAgSTKXApplication"] = IAgSTKXApplication

class IAgDataObject(object):
    """IAgDataObject is used for OLE drag and drop operations."""

    _num_methods = 1
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Files_method_offset = 1
    _metadata = {
        "iid_data" : (4629740546250705181, 15420305044692593073),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDataObject."""
        initialize_from_source_object(self, sourceObject, IAgDataObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDataObject)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDataObject, None)
    
    _get_Files_metadata = { "offset" : _get_Files_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Files(self) -> "IAgDataObjectFiles":
        """Returns a collection of filenames."""
        return self._intf.get_property(IAgDataObject._metadata, IAgDataObject._get_Files_metadata)

    _property_names[Files] = "Files"


agcls.AgClassCatalog.add_catalog_entry((4629740546250705181, 15420305044692593073), IAgDataObject)
agcls.AgTypeNameMap["IAgDataObject"] = IAgDataObject

class IAgObjPathCollection(object):
    """Collection of object paths."""

    _num_methods = 4
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _Range_method_offset = 4
    _metadata = {
        "iid_data" : (5633526467684881384, 4210768304776055218),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgObjPathCollection."""
        initialize_from_source_object(self, sourceObject, IAgObjPathCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgObjPathCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgObjPathCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgObjPathCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> str:
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Number of elements contained in the collection."""
        return self._intf.get_property(IAgObjPathCollection._metadata, IAgObjPathCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.BSTR_arg,) }
    def Item(self, index:int) -> str:
        """Gets the element at the specified index (0-based)."""
        return self._intf.invoke(IAgObjPathCollection._metadata, IAgObjPathCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an object that can be used to iterate through all the object paths in the collection."""
        return self._intf.get_property(IAgObjPathCollection._metadata, IAgObjPathCollection._get__NewEnum_metadata)

    _Range_metadata = { "offset" : _Range_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.LONG_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Range(self, startIndex:int, stopIndex:int) -> list:
        """Return the elements within the specified range."""
        return self._intf.invoke(IAgObjPathCollection._metadata, IAgObjPathCollection._Range_metadata, startIndex, stopIndex, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5633526467684881384, 4210768304776055218), IAgObjPathCollection)
agcls.AgTypeNameMap["IAgObjPathCollection"] = IAgObjPathCollection

class IAgDrawElem(object):
    """Draw element."""

    _num_methods = 2
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Visible_method_offset = 1
    _set_Visible_method_offset = 2
    _metadata = {
        "iid_data" : (4799429500509160029, 14297494079902626208),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDrawElem."""
        initialize_from_source_object(self, sourceObject, IAgDrawElem)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDrawElem)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDrawElem, None)
    
    _get_Visible_metadata = { "offset" : _get_Visible_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def Visible(self) -> bool:
        """Show or hide the element."""
        return self._intf.get_property(IAgDrawElem._metadata, IAgDrawElem._get_Visible_metadata)

    _set_Visible_metadata = { "offset" : _set_Visible_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @Visible.setter
    def Visible(self, newVal:bool) -> None:
        return self._intf.set_property(IAgDrawElem._metadata, IAgDrawElem._set_Visible_metadata, newVal)

    _property_names[Visible] = "Visible"


agcls.AgClassCatalog.add_catalog_entry((4799429500509160029, 14297494079902626208), IAgDrawElem)
agcls.AgTypeNameMap["IAgDrawElem"] = IAgDrawElem

class IAgDrawElemRect(IAgDrawElem):
    """Defines a rectangle in control coordinates."""

    _num_methods = 11
    _vtable_offset = IAgDrawElem._vtable_offset + IAgDrawElem._num_methods
    _get_Left_method_offset = 1
    _get_Right_method_offset = 2
    _get_Top_method_offset = 3
    _get_Bottom_method_offset = 4
    _Set_method_offset = 5
    _get_Color_method_offset = 6
    _set_Color_method_offset = 7
    _get_LineWidth_method_offset = 8
    _set_LineWidth_method_offset = 9
    _get_LineStyle_method_offset = 10
    _set_LineStyle_method_offset = 11
    _metadata = {
        "iid_data" : (5216817853639421657, 10124586112684702141),
        "vtable_reference" : IAgDrawElem._vtable_offset + IAgDrawElem._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDrawElemRect."""
        initialize_from_source_object(self, sourceObject, IAgDrawElemRect)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDrawElem._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDrawElemRect)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDrawElemRect, IAgDrawElem)
    
    _get_Left_metadata = { "offset" : _get_Left_method_offset,
            "arg_types" : (POINTER(agcom.OLE_XPOS_PIXELS),),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg,) }
    @property
    def Left(self) -> int:
        """The x-coordinate of the left edge of this rectangle."""
        return self._intf.get_property(IAgDrawElemRect._metadata, IAgDrawElemRect._get_Left_metadata)

    _get_Right_metadata = { "offset" : _get_Right_method_offset,
            "arg_types" : (POINTER(agcom.OLE_XPOS_PIXELS),),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg,) }
    @property
    def Right(self) -> int:
        """The x-coordinate of the right edge of this rectangle."""
        return self._intf.get_property(IAgDrawElemRect._metadata, IAgDrawElemRect._get_Right_metadata)

    _get_Top_metadata = { "offset" : _get_Top_method_offset,
            "arg_types" : (POINTER(agcom.OLE_YPOS_PIXELS),),
            "marshallers" : (agmarshall.OLE_YPOS_PIXELS_arg,) }
    @property
    def Top(self) -> int:
        """The y-coordinate of the top edge of this rectangle."""
        return self._intf.get_property(IAgDrawElemRect._metadata, IAgDrawElemRect._get_Top_metadata)

    _get_Bottom_metadata = { "offset" : _get_Bottom_method_offset,
            "arg_types" : (POINTER(agcom.OLE_YPOS_PIXELS),),
            "marshallers" : (agmarshall.OLE_YPOS_PIXELS_arg,) }
    @property
    def Bottom(self) -> int:
        """The y-coordinate of the bottom edge of this rectangle."""
        return self._intf.get_property(IAgDrawElemRect._metadata, IAgDrawElemRect._get_Bottom_metadata)

    _Set_metadata = { "offset" : _Set_method_offset,
            "arg_types" : (agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS, agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS,),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg, agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg,) }
    def Set(self, left:int, top:int, right:int, bottom:int) -> None:
        """Set the rectangle coordinates."""
        return self._intf.invoke(IAgDrawElemRect._metadata, IAgDrawElemRect._Set_metadata, left, top, right, bottom)

    _get_Color_metadata = { "offset" : _get_Color_method_offset,
            "arg_types" : (POINTER(agcom.OLE_COLOR),),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @property
    def Color(self) -> agcolor.Color:
        """Color of the rectangle."""
        return self._intf.get_property(IAgDrawElemRect._metadata, IAgDrawElemRect._get_Color_metadata)

    _set_Color_metadata = { "offset" : _set_Color_method_offset,
            "arg_types" : (agcom.OLE_COLOR,),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @Color.setter
    def Color(self, newVal:agcolor.Color) -> None:
        return self._intf.set_property(IAgDrawElemRect._metadata, IAgDrawElemRect._set_Color_metadata, newVal)

    _get_LineWidth_metadata = { "offset" : _get_LineWidth_method_offset,
            "arg_types" : (POINTER(agcom.FLOAT),),
            "marshallers" : (agmarshall.FLOAT_arg,) }
    @property
    def LineWidth(self) -> float:
        """Specifies the width of the line."""
        return self._intf.get_property(IAgDrawElemRect._metadata, IAgDrawElemRect._get_LineWidth_metadata)

    _set_LineWidth_metadata = { "offset" : _set_LineWidth_method_offset,
            "arg_types" : (agcom.FLOAT,),
            "marshallers" : (agmarshall.FLOAT_arg,) }
    @LineWidth.setter
    def LineWidth(self, newVal:float) -> None:
        return self._intf.set_property(IAgDrawElemRect._metadata, IAgDrawElemRect._set_LineWidth_metadata, newVal)

    _get_LineStyle_metadata = { "offset" : _get_LineStyle_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgELineStyle),) }
    @property
    def LineStyle(self) -> "AgELineStyle":
        """Specifies the style of the line."""
        return self._intf.get_property(IAgDrawElemRect._metadata, IAgDrawElemRect._get_LineStyle_metadata)

    _set_LineStyle_metadata = { "offset" : _set_LineStyle_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgELineStyle),) }
    @LineStyle.setter
    def LineStyle(self, newVal:"AgELineStyle") -> None:
        return self._intf.set_property(IAgDrawElemRect._metadata, IAgDrawElemRect._set_LineStyle_metadata, newVal)

    _property_names[Left] = "Left"
    _property_names[Right] = "Right"
    _property_names[Top] = "Top"
    _property_names[Bottom] = "Bottom"
    _property_names[Color] = "Color"
    _property_names[LineWidth] = "LineWidth"
    _property_names[LineStyle] = "LineStyle"


agcls.AgClassCatalog.add_catalog_entry((5216817853639421657, 10124586112684702141), IAgDrawElemRect)
agcls.AgTypeNameMap["IAgDrawElemRect"] = IAgDrawElemRect

class IAgDrawElemCollection(object):
    """Collection of elements to draw on the control."""

    _num_methods = 8
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _Clear_method_offset = 4
    _Add_method_offset = 5
    _Remove_method_offset = 6
    _get_Visible_method_offset = 7
    _set_Visible_method_offset = 8
    _metadata = {
        "iid_data" : (5345909665096890445, 1033150257057093781),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDrawElemCollection."""
        initialize_from_source_object(self, sourceObject, IAgDrawElemCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDrawElemCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDrawElemCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgDrawElemCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgDrawElem":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Number of elements contained in the collection."""
        return self._intf.get_property(IAgDrawElemCollection._metadata, IAgDrawElemCollection._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgDrawElem":
        """Gets the element at the specified index (0-based)."""
        return self._intf.invoke(IAgDrawElemCollection._metadata, IAgDrawElemCollection._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an object that can be used to iterate through all the strings in the collection."""
        return self._intf.get_property(IAgDrawElemCollection._metadata, IAgDrawElemCollection._get__NewEnum_metadata)

    _Clear_metadata = { "offset" : _Clear_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Clear(self) -> None:
        """Clears the contents of the collection and updates the display."""
        return self._intf.invoke(IAgDrawElemCollection._metadata, IAgDrawElemCollection._Clear_metadata, )

    _Add_metadata = { "offset" : _Add_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def Add(self, elemType:str) -> "IAgDrawElem":
        """Create and add a new element to the end of the sequence."""
        return self._intf.invoke(IAgDrawElemCollection._metadata, IAgDrawElemCollection._Add_metadata, elemType, OutArg())

    _Remove_metadata = { "offset" : _Remove_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgDrawElem"),) }
    def Remove(self, drawElem:"IAgDrawElem") -> None:
        """Remove the specified element."""
        return self._intf.invoke(IAgDrawElemCollection._metadata, IAgDrawElemCollection._Remove_metadata, drawElem)

    _get_Visible_metadata = { "offset" : _get_Visible_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def Visible(self) -> bool:
        """Show or hide all the elements."""
        return self._intf.get_property(IAgDrawElemCollection._metadata, IAgDrawElemCollection._get_Visible_metadata)

    _set_Visible_metadata = { "offset" : _set_Visible_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @Visible.setter
    def Visible(self, newVal:bool) -> None:
        return self._intf.set_property(IAgDrawElemCollection._metadata, IAgDrawElemCollection._set_Visible_metadata, newVal)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"
    _property_names[Visible] = "Visible"


agcls.AgClassCatalog.add_catalog_entry((5345909665096890445, 1033150257057093781), IAgDrawElemCollection)
agcls.AgTypeNameMap["IAgDrawElemCollection"] = IAgDrawElemCollection

class IAgWinProjPos(object):
    """Projected window position detail."""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_XPos_method_offset = 1
    _get_YPos_method_offset = 2
    _get_IsWinProjPosValid_method_offset = 3
    _metadata = {
        "iid_data" : (5662259557636712932, 6540783716662451641),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgWinProjPos."""
        initialize_from_source_object(self, sourceObject, IAgWinProjPos)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgWinProjPos)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgWinProjPos, None)
    
    _get_XPos_metadata = { "offset" : _get_XPos_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def XPos(self) -> float:
        """Projected window X position."""
        return self._intf.get_property(IAgWinProjPos._metadata, IAgWinProjPos._get_XPos_metadata)

    _get_YPos_metadata = { "offset" : _get_YPos_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def YPos(self) -> float:
        """Projected window Y position."""
        return self._intf.get_property(IAgWinProjPos._metadata, IAgWinProjPos._get_YPos_metadata)

    _get_IsWinProjPosValid_metadata = { "offset" : _get_IsWinProjPosValid_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsWinProjPosValid(self) -> bool:
        """Indicates if the returned projected position is valid or not."""
        return self._intf.get_property(IAgWinProjPos._metadata, IAgWinProjPos._get_IsWinProjPosValid_metadata)

    _property_names[XPos] = "XPos"
    _property_names[YPos] = "YPos"
    _property_names[IsWinProjPosValid] = "IsWinProjPosValid"


agcls.AgClassCatalog.add_catalog_entry((5662259557636712932, 6540783716662451641), IAgWinProjPos)
agcls.AgTypeNameMap["IAgWinProjPos"] = IAgWinProjPos

class IAgDrawElemLine(IAgDrawElem):
    """Defines a line in control coordinates."""

    _num_methods = 11
    _vtable_offset = IAgDrawElem._vtable_offset + IAgDrawElem._num_methods
    _get_Left_method_offset = 1
    _get_Right_method_offset = 2
    _get_Top_method_offset = 3
    _get_Bottom_method_offset = 4
    _Set_method_offset = 5
    _get_Color_method_offset = 6
    _set_Color_method_offset = 7
    _get_LineWidth_method_offset = 8
    _set_LineWidth_method_offset = 9
    _get_LineStyle_method_offset = 10
    _set_LineStyle_method_offset = 11
    _metadata = {
        "iid_data" : (5362792549588471260, 16309530468251733149),
        "vtable_reference" : IAgDrawElem._vtable_offset + IAgDrawElem._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDrawElemLine."""
        initialize_from_source_object(self, sourceObject, IAgDrawElemLine)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDrawElem._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDrawElemLine)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDrawElemLine, IAgDrawElem)
    
    _get_Left_metadata = { "offset" : _get_Left_method_offset,
            "arg_types" : (POINTER(agcom.OLE_XPOS_PIXELS),),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg,) }
    @property
    def Left(self) -> int:
        """The x-coordinate of the left edge of this line."""
        return self._intf.get_property(IAgDrawElemLine._metadata, IAgDrawElemLine._get_Left_metadata)

    _get_Right_metadata = { "offset" : _get_Right_method_offset,
            "arg_types" : (POINTER(agcom.OLE_XPOS_PIXELS),),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg,) }
    @property
    def Right(self) -> int:
        """The x-coordinate of the right edge of this line."""
        return self._intf.get_property(IAgDrawElemLine._metadata, IAgDrawElemLine._get_Right_metadata)

    _get_Top_metadata = { "offset" : _get_Top_method_offset,
            "arg_types" : (POINTER(agcom.OLE_YPOS_PIXELS),),
            "marshallers" : (agmarshall.OLE_YPOS_PIXELS_arg,) }
    @property
    def Top(self) -> int:
        """The y-coordinate of the top edge of this line."""
        return self._intf.get_property(IAgDrawElemLine._metadata, IAgDrawElemLine._get_Top_metadata)

    _get_Bottom_metadata = { "offset" : _get_Bottom_method_offset,
            "arg_types" : (POINTER(agcom.OLE_YPOS_PIXELS),),
            "marshallers" : (agmarshall.OLE_YPOS_PIXELS_arg,) }
    @property
    def Bottom(self) -> int:
        """The y-coordinate of the bottom edge of this line."""
        return self._intf.get_property(IAgDrawElemLine._metadata, IAgDrawElemLine._get_Bottom_metadata)

    _Set_metadata = { "offset" : _Set_method_offset,
            "arg_types" : (agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS, agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS,),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg, agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg,) }
    def Set(self, left:int, top:int, right:int, bottom:int) -> None:
        """Set the rectangle coordinates."""
        return self._intf.invoke(IAgDrawElemLine._metadata, IAgDrawElemLine._Set_metadata, left, top, right, bottom)

    _get_Color_metadata = { "offset" : _get_Color_method_offset,
            "arg_types" : (POINTER(agcom.OLE_COLOR),),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @property
    def Color(self) -> agcolor.Color:
        """Color of the rectangle."""
        return self._intf.get_property(IAgDrawElemLine._metadata, IAgDrawElemLine._get_Color_metadata)

    _set_Color_metadata = { "offset" : _set_Color_method_offset,
            "arg_types" : (agcom.OLE_COLOR,),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @Color.setter
    def Color(self, newVal:agcolor.Color) -> None:
        return self._intf.set_property(IAgDrawElemLine._metadata, IAgDrawElemLine._set_Color_metadata, newVal)

    _get_LineWidth_metadata = { "offset" : _get_LineWidth_method_offset,
            "arg_types" : (POINTER(agcom.FLOAT),),
            "marshallers" : (agmarshall.FLOAT_arg,) }
    @property
    def LineWidth(self) -> float:
        """Specifies the width of the line."""
        return self._intf.get_property(IAgDrawElemLine._metadata, IAgDrawElemLine._get_LineWidth_metadata)

    _set_LineWidth_metadata = { "offset" : _set_LineWidth_method_offset,
            "arg_types" : (agcom.FLOAT,),
            "marshallers" : (agmarshall.FLOAT_arg,) }
    @LineWidth.setter
    def LineWidth(self, newVal:float) -> None:
        return self._intf.set_property(IAgDrawElemLine._metadata, IAgDrawElemLine._set_LineWidth_metadata, newVal)

    _get_LineStyle_metadata = { "offset" : _get_LineStyle_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgELineStyle),) }
    @property
    def LineStyle(self) -> "AgELineStyle":
        """Specifies the style of the line."""
        return self._intf.get_property(IAgDrawElemLine._metadata, IAgDrawElemLine._get_LineStyle_metadata)

    _set_LineStyle_metadata = { "offset" : _set_LineStyle_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgELineStyle),) }
    @LineStyle.setter
    def LineStyle(self, newVal:"AgELineStyle") -> None:
        return self._intf.set_property(IAgDrawElemLine._metadata, IAgDrawElemLine._set_LineStyle_metadata, newVal)

    _property_names[Left] = "Left"
    _property_names[Right] = "Right"
    _property_names[Top] = "Top"
    _property_names[Bottom] = "Bottom"
    _property_names[Color] = "Color"
    _property_names[LineWidth] = "LineWidth"
    _property_names[LineStyle] = "LineStyle"


agcls.AgClassCatalog.add_catalog_entry((5362792549588471260, 16309530468251733149), IAgDrawElemLine)
agcls.AgTypeNameMap["IAgDrawElemLine"] = IAgDrawElemLine

class IAgExecCmdResult(object):
    """Collection of strings returned by the ExecuteCommand."""

    _num_methods = 5
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _Range_method_offset = 4
    _get_IsSucceeded_method_offset = 5
    _metadata = {
        "iid_data" : (5716458141758991619, 6151301240802116254),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgExecCmdResult."""
        initialize_from_source_object(self, sourceObject, IAgExecCmdResult)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgExecCmdResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgExecCmdResult, None)
    def __iter__(self):
        """Create an iterator for the IAgExecCmdResult object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> str:
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Number of elements contained in the collection."""
        return self._intf.get_property(IAgExecCmdResult._metadata, IAgExecCmdResult._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.BSTR_arg,) }
    def Item(self, index:int) -> str:
        """Gets the element at the specified index (0-based)."""
        return self._intf.invoke(IAgExecCmdResult._metadata, IAgExecCmdResult._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an object that can be used to iterate through all the strings in the collection."""
        return self._intf.get_property(IAgExecCmdResult._metadata, IAgExecCmdResult._get__NewEnum_metadata)

    _Range_metadata = { "offset" : _Range_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.LONG_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Range(self, startIndex:int, stopIndex:int) -> list:
        """Return the elements within the specified range."""
        return self._intf.invoke(IAgExecCmdResult._metadata, IAgExecCmdResult._Range_metadata, startIndex, stopIndex, OutArg())

    _get_IsSucceeded_metadata = { "offset" : _get_IsSucceeded_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsSucceeded(self) -> bool:
        """Indicates whether the object contains valid results."""
        return self._intf.get_property(IAgExecCmdResult._metadata, IAgExecCmdResult._get_IsSucceeded_metadata)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"
    _property_names[IsSucceeded] = "IsSucceeded"


agcls.AgClassCatalog.add_catalog_entry((5716458141758991619, 6151301240802116254), IAgExecCmdResult)
agcls.AgTypeNameMap["IAgExecCmdResult"] = IAgExecCmdResult

class IAgExecMultiCmdResult(object):
    """Collection of objects returned by the ExecuteMultipleCommands."""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _metadata = {
        "iid_data" : (5715823729797807758, 8585485072830197148),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgExecMultiCmdResult."""
        initialize_from_source_object(self, sourceObject, IAgExecMultiCmdResult)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgExecMultiCmdResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgExecMultiCmdResult, None)
    def __iter__(self):
        """Create an iterator for the IAgExecMultiCmdResult object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgExecCmdResult":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Number of elements contained in the collection."""
        return self._intf.get_property(IAgExecMultiCmdResult._metadata, IAgExecMultiCmdResult._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgExecCmdResult":
        """Gets the element at the specified index (0-based)."""
        return self._intf.invoke(IAgExecMultiCmdResult._metadata, IAgExecMultiCmdResult._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an object that can be used to iterate through all the objects in the collection."""
        return self._intf.get_property(IAgExecMultiCmdResult._metadata, IAgExecMultiCmdResult._get__NewEnum_metadata)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5715823729797807758, 8585485072830197148), IAgExecMultiCmdResult)
agcls.AgTypeNameMap["IAgExecMultiCmdResult"] = IAgExecMultiCmdResult

class IAgUiAxVOCntrl(object):
    """AGI Globe control."""

    _num_methods = 48
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_BackColor_method_offset = 1
    _set_BackColor_method_offset = 2
    _get_Picture_method_offset = 3
    _PicturePutRef_method_offset = 4
    _set_Picture_method_offset = 5
    _PickInfo_method_offset = 6
    _get_WinID_method_offset = 7
    _set_WinID_method_offset = 8
    _get_Application_method_offset = 9
    _ZoomIn_method_offset = 10
    _get_NoLogo_method_offset = 11
    _set_NoLogo_method_offset = 12
    _get_OLEDropMode_method_offset = 13
    _set_OLEDropMode_method_offset = 14
    _get_VendorID_method_offset = 15
    _set_VendorID_method_offset = 16
    _RubberBandPickInfo_method_offset = 17
    _get_MouseMode_method_offset = 18
    _set_MouseMode_method_offset = 19
    _get_DrawElements_method_offset = 20
    _get_ReadyState_method_offset = 21
    _get_PptPreloadMode_method_offset = 22
    _set_PptPreloadMode_method_offset = 23
    _get_AdvancedPickMode_method_offset = 24
    _set_AdvancedPickMode_method_offset = 25
    _CopyFromWinID_method_offset = 26
    _StartObjectEditing_method_offset = 27
    _ApplyObjectEditing_method_offset = 28
    _StopObjectEditing_method_offset = 29
    _get_IsObjectEditing_method_offset = 30
    _get_InZoomMode_method_offset = 31
    _SetMouseCursorFromFile_method_offset = 32
    _RestoreMouseCursor_method_offset = 33
    _SetMouseCursorFromHandle_method_offset = 34
    _get_ShowProgressImage_method_offset = 35
    _set_ShowProgressImage_method_offset = 36
    _get_ProgressImageXOffset_method_offset = 37
    _set_ProgressImageXOffset_method_offset = 38
    _get_ProgressImageYOffset_method_offset = 39
    _set_ProgressImageYOffset_method_offset = 40
    _get_ProgressImageFile_method_offset = 41
    _set_ProgressImageFile_method_offset = 42
    _get_ProgressImageXOrigin_method_offset = 43
    _set_ProgressImageXOrigin_method_offset = 44
    _get_ProgressImageYOrigin_method_offset = 45
    _set_ProgressImageYOrigin_method_offset = 46
    _get_PictureFromFile_method_offset = 47
    _set_PictureFromFile_method_offset = 48
    _metadata = {
        "iid_data" : (5444819458222045731, 10574496678292917690),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiAxVOCntrl."""
        initialize_from_source_object(self, sourceObject, IAgUiAxVOCntrl)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiAxVOCntrl)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiAxVOCntrl, None)
    def Subscribe(self) -> IAgUiAxVOCntrlEventHandler:
        """Return an IAgUiAxVOCntrlEventHandler that is subscribed to handle events associated with this instance of IAgUiAxVOCntrl."""
        return IAgUiAxVOCntrlEventHandler(self._intf)
    
    _get_BackColor_metadata = { "offset" : _get_BackColor_method_offset,
            "arg_types" : (POINTER(agcom.OLE_COLOR),),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @property
    def BackColor(self) -> agcolor.Color:
        """The background color of the control."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_BackColor_metadata)

    _set_BackColor_metadata = { "offset" : _set_BackColor_method_offset,
            "arg_types" : (agcom.OLE_COLOR,),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @BackColor.setter
    def BackColor(self, clr:agcolor.Color) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_BackColor_metadata, clr)

    _get_Picture_metadata = { "offset" : _get_Picture_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IPictureDisp_arg,) }
    @property
    def Picture(self) -> IPictureDisp:
        """The splash logo graphic to be displayed in the control."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_Picture_metadata)

    _PicturePutRef_metadata = { "offset" : _PicturePutRef_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IPictureDisp_arg,) }
    def PicturePutRef(self, pPicture:IPictureDisp) -> None:
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._PicturePutRef_metadata, pPicture)

    _set_Picture_metadata = { "offset" : _set_Picture_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IPictureDisp_arg,) }
    @Picture.setter
    def Picture(self, pPicture:IPictureDisp) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_Picture_metadata, pPicture)

    _PickInfo_metadata = { "offset" : _PickInfo_method_offset,
            "arg_types" : (agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg, agmarshall.AgInterface_out_arg,) }
    def PickInfo(self, x:int, y:int) -> "IAgPickInfoData":
        """Get detailed information about a mouse pick."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._PickInfo_metadata, x, y, OutArg())

    _get_WinID_metadata = { "offset" : _get_WinID_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def WinID(self) -> int:
        """Window identifier (for Connect commands)."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_WinID_metadata)

    _set_WinID_metadata = { "offset" : _set_WinID_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @WinID.setter
    def WinID(self, newVal:int) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_WinID_metadata, newVal)

    _get_Application_metadata = { "offset" : _get_Application_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Application(self) -> "IAgSTKXApplication":
        """Reference to the STK X application object."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_Application_metadata)

    _ZoomIn_metadata = { "offset" : _ZoomIn_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ZoomIn(self) -> None:
        """Enter zoom-in mode. User must left click-and-drag mouse to define area to zoom."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._ZoomIn_metadata, )

    _get_NoLogo_metadata = { "offset" : _get_NoLogo_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def NoLogo(self) -> bool:
        """If true, the splash logo is not shown."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_NoLogo_metadata)

    _set_NoLogo_metadata = { "offset" : _set_NoLogo_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @NoLogo.setter
    def NoLogo(self, bNoLogo:bool) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_NoLogo_metadata, bNoLogo)

    _get_OLEDropMode_metadata = { "offset" : _get_OLEDropMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEOLEDropMode),) }
    @property
    def OLEDropMode(self) -> "AgEOLEDropMode":
        """How the control handles drop operations."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_OLEDropMode_metadata)

    _set_OLEDropMode_metadata = { "offset" : _set_OLEDropMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEOLEDropMode),) }
    @OLEDropMode.setter
    def OLEDropMode(self, psOLEDropMode:"AgEOLEDropMode") -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_OLEDropMode_metadata, psOLEDropMode)

    _get_VendorID_metadata = { "offset" : _get_VendorID_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def VendorID(self) -> str:
        """This property is deprecated. The identifier of the vendor."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_VendorID_metadata)

    _set_VendorID_metadata = { "offset" : _set_VendorID_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @VendorID.setter
    def VendorID(self, vendorID:str) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_VendorID_metadata, vendorID)

    _RubberBandPickInfo_metadata = { "offset" : _RubberBandPickInfo_method_offset,
            "arg_types" : (agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS, agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg, agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg, agmarshall.AgInterface_out_arg,) }
    def RubberBandPickInfo(self, left:int, top:int, right:int, bottom:int) -> "IAgRubberBandPickInfoData":
        """Get detailed information about a rubber-band mouse pick. The values must be within the VO window (0 to width-1 for left and right, 0 to height-1 for top and bottom)."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._RubberBandPickInfo_metadata, left, top, right, bottom, OutArg())

    _get_MouseMode_metadata = { "offset" : _get_MouseMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEMouseMode),) }
    @property
    def MouseMode(self) -> "AgEMouseMode":
        """Whether this control responds to mouse events."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_MouseMode_metadata)

    _set_MouseMode_metadata = { "offset" : _set_MouseMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEMouseMode),) }
    @MouseMode.setter
    def MouseMode(self, psMouseMode:"AgEMouseMode") -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_MouseMode_metadata, psMouseMode)

    _get_DrawElements_metadata = { "offset" : _get_DrawElements_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def DrawElements(self) -> "IAgDrawElemCollection":
        """Elements to draw on the control."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_DrawElements_metadata)

    _get_ReadyState_metadata = { "offset" : _get_ReadyState_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ReadyState(self) -> int:
        """Returns/sets the background color of the control."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_ReadyState_metadata)

    _get_PptPreloadMode_metadata = { "offset" : _get_PptPreloadMode_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def PptPreloadMode(self) -> bool:
        """Special mode for PowerPoint : if true the VO control window is kept around when switching between slides."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_PptPreloadMode_metadata)

    _set_PptPreloadMode_metadata = { "offset" : _set_PptPreloadMode_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @PptPreloadMode.setter
    def PptPreloadMode(self, bPptPreloadMode:bool) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_PptPreloadMode_metadata, bPptPreloadMode)

    _get_AdvancedPickMode_metadata = { "offset" : _get_AdvancedPickMode_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def AdvancedPickMode(self) -> bool:
        """If true, sets the advance pick mode."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_AdvancedPickMode_metadata)

    _set_AdvancedPickMode_metadata = { "offset" : _set_AdvancedPickMode_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @AdvancedPickMode.setter
    def AdvancedPickMode(self, bAdvancePickMode:bool) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_AdvancedPickMode_metadata, bAdvancePickMode)

    _CopyFromWinID_metadata = { "offset" : _CopyFromWinID_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def CopyFromWinID(self, winID:int) -> None:
        """Copies an existing Window's scene into this control."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._CopyFromWinID_metadata, winID)

    _StartObjectEditing_metadata = { "offset" : _StartObjectEditing_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def StartObjectEditing(self, objEditPath:str) -> None:
        """Enters into 3D object editing mode."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._StartObjectEditing_metadata, objEditPath)

    _ApplyObjectEditing_metadata = { "offset" : _ApplyObjectEditing_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ApplyObjectEditing(self) -> None:
        """Commits changes when in 3D object editing mode."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._ApplyObjectEditing_metadata, )

    _StopObjectEditing_metadata = { "offset" : _StopObjectEditing_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    def StopObjectEditing(self, canceled:bool) -> None:
        """Ends 3D object editing mode."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._StopObjectEditing_metadata, canceled)

    _get_IsObjectEditing_metadata = { "offset" : _get_IsObjectEditing_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsObjectEditing(self) -> bool:
        """Returns true if in 3D object editing mode."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_IsObjectEditing_metadata)

    _get_InZoomMode_metadata = { "offset" : _get_InZoomMode_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def InZoomMode(self) -> bool:
        """Returns true if in zoom in mode."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_InZoomMode_metadata)

    _SetMouseCursorFromFile_metadata = { "offset" : _SetMouseCursorFromFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def SetMouseCursorFromFile(self, cursorFileName:str) -> None:
        """Sets mouse cursor to the selected cursor file."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._SetMouseCursorFromFile_metadata, cursorFileName)

    _RestoreMouseCursor_metadata = { "offset" : _RestoreMouseCursor_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RestoreMouseCursor(self) -> None:
        """Restores mouse cursor back to normal."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._RestoreMouseCursor_metadata, )

    _SetMouseCursorFromHandle_metadata = { "offset" : _SetMouseCursorFromHandle_method_offset,
            "arg_types" : (agcom.OLE_HANDLE,),
            "marshallers" : (agmarshall.OLE_HANDLE_arg,) }
    def SetMouseCursorFromHandle(self, cursorHandle:int) -> None:
        """Sets mouse cursor to the passed cursor handle."""
        return self._intf.invoke(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._SetMouseCursorFromHandle_metadata, cursorHandle)

    _get_ShowProgressImage_metadata = { "offset" : _get_ShowProgressImage_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEShowProgressImage),) }
    @property
    def ShowProgressImage(self) -> "AgEShowProgressImage":
        """The animated progress image type."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_ShowProgressImage_metadata)

    _set_ShowProgressImage_metadata = { "offset" : _set_ShowProgressImage_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEShowProgressImage),) }
    @ShowProgressImage.setter
    def ShowProgressImage(self, psProgressImage:"AgEShowProgressImage") -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_ShowProgressImage_metadata, psProgressImage)

    _get_ProgressImageXOffset_metadata = { "offset" : _get_ProgressImageXOffset_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ProgressImageXOffset(self) -> int:
        """The horizontal X offset for animated progress image."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_ProgressImageXOffset_metadata)

    _set_ProgressImageXOffset_metadata = { "offset" : _set_ProgressImageXOffset_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @ProgressImageXOffset.setter
    def ProgressImageXOffset(self, xOffset:int) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_ProgressImageXOffset_metadata, xOffset)

    _get_ProgressImageYOffset_metadata = { "offset" : _get_ProgressImageYOffset_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ProgressImageYOffset(self) -> int:
        """The vertical Y offset for animated progress image."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_ProgressImageYOffset_metadata)

    _set_ProgressImageYOffset_metadata = { "offset" : _set_ProgressImageYOffset_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @ProgressImageYOffset.setter
    def ProgressImageYOffset(self, yOffset:int) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_ProgressImageYOffset_metadata, yOffset)

    _get_ProgressImageFile_metadata = { "offset" : _get_ProgressImageFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ProgressImageFile(self) -> str:
        """The complete image file name/path for animated progress image."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_ProgressImageFile_metadata)

    _set_ProgressImageFile_metadata = { "offset" : _set_ProgressImageFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ProgressImageFile.setter
    def ProgressImageFile(self, imageFile:str) -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_ProgressImageFile_metadata, imageFile)

    _get_ProgressImageXOrigin_metadata = { "offset" : _get_ProgressImageXOrigin_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEProgressImageXOrigin),) }
    @property
    def ProgressImageXOrigin(self) -> "AgEProgressImageXOrigin":
        """The X origin alignment for animated progress image."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_ProgressImageXOrigin_metadata)

    _set_ProgressImageXOrigin_metadata = { "offset" : _set_ProgressImageXOrigin_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEProgressImageXOrigin),) }
    @ProgressImageXOrigin.setter
    def ProgressImageXOrigin(self, progressImageXOrigin:"AgEProgressImageXOrigin") -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_ProgressImageXOrigin_metadata, progressImageXOrigin)

    _get_ProgressImageYOrigin_metadata = { "offset" : _get_ProgressImageYOrigin_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEProgressImageYOrigin),) }
    @property
    def ProgressImageYOrigin(self) -> "AgEProgressImageYOrigin":
        """The Y origin alignment for animated progress image."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_ProgressImageYOrigin_metadata)

    _set_ProgressImageYOrigin_metadata = { "offset" : _set_ProgressImageYOrigin_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEProgressImageYOrigin),) }
    @ProgressImageYOrigin.setter
    def ProgressImageYOrigin(self, progressImageYOrigin:"AgEProgressImageYOrigin") -> None:
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_ProgressImageYOrigin_metadata, progressImageYOrigin)

    _get_PictureFromFile_metadata = { "offset" : _get_PictureFromFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def PictureFromFile(self) -> str:
        """Gets or sets the splash logo graphic file to be displayed in the control."""
        return self._intf.get_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._get_PictureFromFile_metadata)

    _set_PictureFromFile_metadata = { "offset" : _set_PictureFromFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @PictureFromFile.setter
    def PictureFromFile(self, pictureFile:str) -> None:
        """Gets or sets the splash logo graphic file to be displayed in the control."""
        return self._intf.set_property(IAgUiAxVOCntrl._metadata, IAgUiAxVOCntrl._set_PictureFromFile_metadata, pictureFile)

    _property_names[BackColor] = "BackColor"
    _property_names[Picture] = "Picture"
    _property_names[WinID] = "WinID"
    _property_names[Application] = "Application"
    _property_names[NoLogo] = "NoLogo"
    _property_names[OLEDropMode] = "OLEDropMode"
    _property_names[VendorID] = "VendorID"
    _property_names[MouseMode] = "MouseMode"
    _property_names[DrawElements] = "DrawElements"
    _property_names[ReadyState] = "ReadyState"
    _property_names[PptPreloadMode] = "PptPreloadMode"
    _property_names[AdvancedPickMode] = "AdvancedPickMode"
    _property_names[IsObjectEditing] = "IsObjectEditing"
    _property_names[InZoomMode] = "InZoomMode"
    _property_names[ShowProgressImage] = "ShowProgressImage"
    _property_names[ProgressImageXOffset] = "ProgressImageXOffset"
    _property_names[ProgressImageYOffset] = "ProgressImageYOffset"
    _property_names[ProgressImageFile] = "ProgressImageFile"
    _property_names[ProgressImageXOrigin] = "ProgressImageXOrigin"
    _property_names[ProgressImageYOrigin] = "ProgressImageYOrigin"
    _property_names[PictureFromFile] = "PictureFromFile"


agcls.AgClassCatalog.add_catalog_entry((5444819458222045731, 10574496678292917690), IAgUiAxVOCntrl)
agcls.AgTypeNameMap["IAgUiAxVOCntrl"] = IAgUiAxVOCntrl

class IAgUiAx2DCntrl(object):
    """AGI Map control."""

    _num_methods = 45
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_BackColor_method_offset = 1
    _set_BackColor_method_offset = 2
    _get_Picture_method_offset = 3
    _PicturePutRef_method_offset = 4
    _set_Picture_method_offset = 5
    _get_WinID_method_offset = 6
    _set_WinID_method_offset = 7
    _ZoomIn_method_offset = 8
    _ZoomOut_method_offset = 9
    _PickInfo_method_offset = 10
    _get_Application_method_offset = 11
    _get_NoLogo_method_offset = 12
    _set_NoLogo_method_offset = 13
    _get_OLEDropMode_method_offset = 14
    _set_OLEDropMode_method_offset = 15
    _get_VendorID_method_offset = 16
    _set_VendorID_method_offset = 17
    _get_MouseMode_method_offset = 18
    _set_MouseMode_method_offset = 19
    _get_ReadyState_method_offset = 20
    _CopyFromWinID_method_offset = 21
    _RubberBandPickInfo_method_offset = 22
    _get_AdvancedPickMode_method_offset = 23
    _set_AdvancedPickMode_method_offset = 24
    _GetWindowProjectedPosition_method_offset = 25
    _get_InZoomMode_method_offset = 26
    _SetMouseCursorFromFile_method_offset = 27
    _RestoreMouseCursor_method_offset = 28
    _SetMouseCursorFromHandle_method_offset = 29
    _get_ShowProgressImage_method_offset = 30
    _set_ShowProgressImage_method_offset = 31
    _get_ProgressImageXOffset_method_offset = 32
    _set_ProgressImageXOffset_method_offset = 33
    _get_ProgressImageYOffset_method_offset = 34
    _set_ProgressImageYOffset_method_offset = 35
    _get_ProgressImageFile_method_offset = 36
    _set_ProgressImageFile_method_offset = 37
    _get_ProgressImageXOrigin_method_offset = 38
    _set_ProgressImageXOrigin_method_offset = 39
    _get_ProgressImageYOrigin_method_offset = 40
    _set_ProgressImageYOrigin_method_offset = 41
    _get_PictureFromFile_method_offset = 42
    _set_PictureFromFile_method_offset = 43
    _get_PanModeEnabled_method_offset = 44
    _set_PanModeEnabled_method_offset = 45
    _metadata = {
        "iid_data" : (5744647361091700561, 18202512224966495930),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiAx2DCntrl."""
        initialize_from_source_object(self, sourceObject, IAgUiAx2DCntrl)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiAx2DCntrl)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiAx2DCntrl, None)
    def Subscribe(self) -> IAgUiAx2DCntrlEventHandler:
        """Return an IAgUiAx2DCntrlEventHandler that is subscribed to handle events associated with this instance of IAgUiAx2DCntrl."""
        return IAgUiAx2DCntrlEventHandler(self._intf)
    
    _get_BackColor_metadata = { "offset" : _get_BackColor_method_offset,
            "arg_types" : (POINTER(agcom.OLE_COLOR),),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @property
    def BackColor(self) -> agcolor.Color:
        """The background color of the control."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_BackColor_metadata)

    _set_BackColor_metadata = { "offset" : _set_BackColor_method_offset,
            "arg_types" : (agcom.OLE_COLOR,),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @BackColor.setter
    def BackColor(self, clr:agcolor.Color) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_BackColor_metadata, clr)

    _get_Picture_metadata = { "offset" : _get_Picture_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IPictureDisp_arg,) }
    @property
    def Picture(self) -> IPictureDisp:
        """The splash logo graphic to be displayed in the control."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_Picture_metadata)

    _PicturePutRef_metadata = { "offset" : _PicturePutRef_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IPictureDisp_arg,) }
    def PicturePutRef(self, pPicture:IPictureDisp) -> None:
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._PicturePutRef_metadata, pPicture)

    _set_Picture_metadata = { "offset" : _set_Picture_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IPictureDisp_arg,) }
    @Picture.setter
    def Picture(self, pPicture:IPictureDisp) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_Picture_metadata, pPicture)

    _get_WinID_metadata = { "offset" : _get_WinID_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def WinID(self) -> int:
        """Window identifier (for Connect commands)."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_WinID_metadata)

    _set_WinID_metadata = { "offset" : _set_WinID_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @WinID.setter
    def WinID(self, newVal:int) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_WinID_metadata, newVal)

    _ZoomIn_metadata = { "offset" : _ZoomIn_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ZoomIn(self) -> None:
        """Enter zoom-in mode. User must left click-and-drag mouse to define area to zoom."""
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._ZoomIn_metadata, )

    _ZoomOut_metadata = { "offset" : _ZoomOut_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ZoomOut(self) -> None:
        """Zoom out to view a larger portion of a previously magnified map."""
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._ZoomOut_metadata, )

    _PickInfo_metadata = { "offset" : _PickInfo_method_offset,
            "arg_types" : (agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg, agmarshall.AgInterface_out_arg,) }
    def PickInfo(self, x:int, y:int) -> "IAgPickInfoData":
        """Get detailed information about a mouse pick."""
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._PickInfo_metadata, x, y, OutArg())

    _get_Application_metadata = { "offset" : _get_Application_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Application(self) -> "IAgSTKXApplication":
        """Reference to the STK X application object."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_Application_metadata)

    _get_NoLogo_metadata = { "offset" : _get_NoLogo_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def NoLogo(self) -> bool:
        """If true, the splash logo is not shown."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_NoLogo_metadata)

    _set_NoLogo_metadata = { "offset" : _set_NoLogo_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @NoLogo.setter
    def NoLogo(self, bNoLogo:bool) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_NoLogo_metadata, bNoLogo)

    _get_OLEDropMode_metadata = { "offset" : _get_OLEDropMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEOLEDropMode),) }
    @property
    def OLEDropMode(self) -> "AgEOLEDropMode":
        """How the control handles drop operations."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_OLEDropMode_metadata)

    _set_OLEDropMode_metadata = { "offset" : _set_OLEDropMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEOLEDropMode),) }
    @OLEDropMode.setter
    def OLEDropMode(self, psOLEDropMode:"AgEOLEDropMode") -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_OLEDropMode_metadata, psOLEDropMode)

    _get_VendorID_metadata = { "offset" : _get_VendorID_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def VendorID(self) -> str:
        """This property is deprecated. The identifier of the vendor."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_VendorID_metadata)

    _set_VendorID_metadata = { "offset" : _set_VendorID_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @VendorID.setter
    def VendorID(self, vendorID:str) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_VendorID_metadata, vendorID)

    _get_MouseMode_metadata = { "offset" : _get_MouseMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEMouseMode),) }
    @property
    def MouseMode(self) -> "AgEMouseMode":
        """Whether this control responds to mouse events."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_MouseMode_metadata)

    _set_MouseMode_metadata = { "offset" : _set_MouseMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEMouseMode),) }
    @MouseMode.setter
    def MouseMode(self, psMouseMode:"AgEMouseMode") -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_MouseMode_metadata, psMouseMode)

    _get_ReadyState_metadata = { "offset" : _get_ReadyState_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ReadyState(self) -> int:
        """Returns/sets the background color of the control."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_ReadyState_metadata)

    _CopyFromWinID_metadata = { "offset" : _CopyFromWinID_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def CopyFromWinID(self, winID:int) -> None:
        """Copies an existing Window's scene into this control."""
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._CopyFromWinID_metadata, winID)

    _RubberBandPickInfo_metadata = { "offset" : _RubberBandPickInfo_method_offset,
            "arg_types" : (agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS, agcom.OLE_XPOS_PIXELS, agcom.OLE_YPOS_PIXELS, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg, agmarshall.OLE_XPOS_PIXELS_arg, agmarshall.OLE_YPOS_PIXELS_arg, agmarshall.AgInterface_out_arg,) }
    def RubberBandPickInfo(self, left:int, top:int, right:int, bottom:int) -> "IAgRubberBandPickInfoData":
        """Get detailed information about a rubber-band mouse pick. The values must be within the 2D window (0 to width-1 for left and right, 0 to height-1 for top and bottom)."""
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._RubberBandPickInfo_metadata, left, top, right, bottom, OutArg())

    _get_AdvancedPickMode_metadata = { "offset" : _get_AdvancedPickMode_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def AdvancedPickMode(self) -> bool:
        """If true, sets the advance pick mode."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_AdvancedPickMode_metadata)

    _set_AdvancedPickMode_metadata = { "offset" : _set_AdvancedPickMode_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @AdvancedPickMode.setter
    def AdvancedPickMode(self, bAdvancePickMode:bool) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_AdvancedPickMode_metadata, bAdvancePickMode)

    _GetWindowProjectedPosition_metadata = { "offset" : _GetWindowProjectedPosition_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.AgEnum_arg(AgEGfxDrawCoords), agmarshall.AgInterface_out_arg,) }
    def GetWindowProjectedPosition(self, lat:float, lon:float, alt:float, drawCoords:"AgEGfxDrawCoords") -> "IAgWinProjPos":
        """Get the window projected position for given values."""
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._GetWindowProjectedPosition_metadata, lat, lon, alt, drawCoords, OutArg())

    _get_InZoomMode_metadata = { "offset" : _get_InZoomMode_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def InZoomMode(self) -> bool:
        """Returns true if in zoom in mode."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_InZoomMode_metadata)

    _SetMouseCursorFromFile_metadata = { "offset" : _SetMouseCursorFromFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def SetMouseCursorFromFile(self, cursorFileName:str) -> None:
        """Sets mouse cursor to the selected cursor file."""
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._SetMouseCursorFromFile_metadata, cursorFileName)

    _RestoreMouseCursor_metadata = { "offset" : _RestoreMouseCursor_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RestoreMouseCursor(self) -> None:
        """Restores mouse cursor back to normal."""
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._RestoreMouseCursor_metadata, )

    _SetMouseCursorFromHandle_metadata = { "offset" : _SetMouseCursorFromHandle_method_offset,
            "arg_types" : (agcom.OLE_HANDLE,),
            "marshallers" : (agmarshall.OLE_HANDLE_arg,) }
    def SetMouseCursorFromHandle(self, cursorHandle:int) -> None:
        """Sets mouse cursor to the passed cursor handle."""
        return self._intf.invoke(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._SetMouseCursorFromHandle_metadata, cursorHandle)

    _get_ShowProgressImage_metadata = { "offset" : _get_ShowProgressImage_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEShowProgressImage),) }
    @property
    def ShowProgressImage(self) -> "AgEShowProgressImage":
        """The animated progress image type."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_ShowProgressImage_metadata)

    _set_ShowProgressImage_metadata = { "offset" : _set_ShowProgressImage_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEShowProgressImage),) }
    @ShowProgressImage.setter
    def ShowProgressImage(self, psProgressImage:"AgEShowProgressImage") -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_ShowProgressImage_metadata, psProgressImage)

    _get_ProgressImageXOffset_metadata = { "offset" : _get_ProgressImageXOffset_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ProgressImageXOffset(self) -> int:
        """The horizontal X offset for animated progress image."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_ProgressImageXOffset_metadata)

    _set_ProgressImageXOffset_metadata = { "offset" : _set_ProgressImageXOffset_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @ProgressImageXOffset.setter
    def ProgressImageXOffset(self, xOffset:int) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_ProgressImageXOffset_metadata, xOffset)

    _get_ProgressImageYOffset_metadata = { "offset" : _get_ProgressImageYOffset_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ProgressImageYOffset(self) -> int:
        """The vertical Y offset for animated progress image."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_ProgressImageYOffset_metadata)

    _set_ProgressImageYOffset_metadata = { "offset" : _set_ProgressImageYOffset_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @ProgressImageYOffset.setter
    def ProgressImageYOffset(self, yOffset:int) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_ProgressImageYOffset_metadata, yOffset)

    _get_ProgressImageFile_metadata = { "offset" : _get_ProgressImageFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def ProgressImageFile(self) -> str:
        """The complete image file name/path for animated progress image."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_ProgressImageFile_metadata)

    _set_ProgressImageFile_metadata = { "offset" : _set_ProgressImageFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @ProgressImageFile.setter
    def ProgressImageFile(self, imageFile:str) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_ProgressImageFile_metadata, imageFile)

    _get_ProgressImageXOrigin_metadata = { "offset" : _get_ProgressImageXOrigin_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEProgressImageXOrigin),) }
    @property
    def ProgressImageXOrigin(self) -> "AgEProgressImageXOrigin":
        """The X origin alignment for animated progress image."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_ProgressImageXOrigin_metadata)

    _set_ProgressImageXOrigin_metadata = { "offset" : _set_ProgressImageXOrigin_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEProgressImageXOrigin),) }
    @ProgressImageXOrigin.setter
    def ProgressImageXOrigin(self, progressImageXOrigin:"AgEProgressImageXOrigin") -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_ProgressImageXOrigin_metadata, progressImageXOrigin)

    _get_ProgressImageYOrigin_metadata = { "offset" : _get_ProgressImageYOrigin_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEProgressImageYOrigin),) }
    @property
    def ProgressImageYOrigin(self) -> "AgEProgressImageYOrigin":
        """The Y origin alignment for animated progress image."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_ProgressImageYOrigin_metadata)

    _set_ProgressImageYOrigin_metadata = { "offset" : _set_ProgressImageYOrigin_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEProgressImageYOrigin),) }
    @ProgressImageYOrigin.setter
    def ProgressImageYOrigin(self, progressImageYOrigin:"AgEProgressImageYOrigin") -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_ProgressImageYOrigin_metadata, progressImageYOrigin)

    _get_PictureFromFile_metadata = { "offset" : _get_PictureFromFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def PictureFromFile(self) -> str:
        """Gets or sets the splash logo graphic file to be displayed in the control."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_PictureFromFile_metadata)

    _set_PictureFromFile_metadata = { "offset" : _set_PictureFromFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @PictureFromFile.setter
    def PictureFromFile(self, pictureFile:str) -> None:
        """Gets or sets the splash logo graphic file to be displayed in the control."""
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_PictureFromFile_metadata, pictureFile)

    _get_PanModeEnabled_metadata = { "offset" : _get_PanModeEnabled_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def PanModeEnabled(self) -> bool:
        """Enables/disables pan mode for map control."""
        return self._intf.get_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._get_PanModeEnabled_metadata)

    _set_PanModeEnabled_metadata = { "offset" : _set_PanModeEnabled_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @PanModeEnabled.setter
    def PanModeEnabled(self, bPanMode:bool) -> None:
        return self._intf.set_property(IAgUiAx2DCntrl._metadata, IAgUiAx2DCntrl._set_PanModeEnabled_metadata, bPanMode)

    _property_names[BackColor] = "BackColor"
    _property_names[Picture] = "Picture"
    _property_names[WinID] = "WinID"
    _property_names[Application] = "Application"
    _property_names[NoLogo] = "NoLogo"
    _property_names[OLEDropMode] = "OLEDropMode"
    _property_names[VendorID] = "VendorID"
    _property_names[MouseMode] = "MouseMode"
    _property_names[ReadyState] = "ReadyState"
    _property_names[AdvancedPickMode] = "AdvancedPickMode"
    _property_names[InZoomMode] = "InZoomMode"
    _property_names[ShowProgressImage] = "ShowProgressImage"
    _property_names[ProgressImageXOffset] = "ProgressImageXOffset"
    _property_names[ProgressImageYOffset] = "ProgressImageYOffset"
    _property_names[ProgressImageFile] = "ProgressImageFile"
    _property_names[ProgressImageXOrigin] = "ProgressImageXOrigin"
    _property_names[ProgressImageYOrigin] = "ProgressImageYOrigin"
    _property_names[PictureFromFile] = "PictureFromFile"
    _property_names[PanModeEnabled] = "PanModeEnabled"


agcls.AgClassCatalog.add_catalog_entry((5744647361091700561, 18202512224966495930), IAgUiAx2DCntrl)
agcls.AgTypeNameMap["IAgUiAx2DCntrl"] = IAgUiAx2DCntrl

class IAgSTKXApplicationPartnerAccess(object):
    """Access to the application object model for business partners."""

    _num_methods = 1
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _GrantPartnerAccess_method_offset = 1
    _metadata = {
        "iid_data" : (4662950884101382286, 14871068326245298338),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSTKXApplicationPartnerAccess."""
        initialize_from_source_object(self, sourceObject, IAgSTKXApplicationPartnerAccess)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSTKXApplicationPartnerAccess)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSTKXApplicationPartnerAccess, None)
    
    _GrantPartnerAccess_metadata = { "offset" : _GrantPartnerAccess_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GrantPartnerAccess(self, vendor:str, product:str, key:str) -> "IAgSTKXApplication":
        """Provide object model root for authorized business partners."""
        return self._intf.invoke(IAgSTKXApplicationPartnerAccess._metadata, IAgSTKXApplicationPartnerAccess._GrantPartnerAccess_metadata, vendor, product, key, OutArg())


agcls.AgClassCatalog.add_catalog_entry((4662950884101382286, 14871068326245298338), IAgSTKXApplicationPartnerAccess)
agcls.AgTypeNameMap["IAgSTKXApplicationPartnerAccess"] = IAgSTKXApplicationPartnerAccess

class IAgDataObjectFiles(object):
    """Collection of file names."""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get__NewEnum_method_offset = 1
    _Item_method_offset = 2
    _get_Count_method_offset = 3
    _metadata = {
        "iid_data" : (5022012349477980193, 9093199729173088151),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDataObjectFiles."""
        initialize_from_source_object(self, sourceObject, IAgDataObjectFiles)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDataObjectFiles)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDataObjectFiles, None)
    def __iter__(self):
        """Create an iterator for the IAgDataObjectFiles object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> str:
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an object that can be used to iterate through all the file names in the collection."""
        return self._intf.get_property(IAgDataObjectFiles._metadata, IAgDataObjectFiles._get__NewEnum_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.BSTR_arg,) }
    def Item(self, index:int) -> str:
        """Gets the file name at the specified index (0-based)."""
        return self._intf.invoke(IAgDataObjectFiles._metadata, IAgDataObjectFiles._Item_metadata, index, OutArg())

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Number of file names contained in the collection."""
        return self._intf.get_property(IAgDataObjectFiles._metadata, IAgDataObjectFiles._get_Count_metadata)

    __getitem__ = Item


    _property_names[_NewEnum] = "_NewEnum"
    _property_names[Count] = "Count"


agcls.AgClassCatalog.add_catalog_entry((5022012349477980193, 9093199729173088151), IAgDataObjectFiles)
agcls.AgTypeNameMap["IAgDataObjectFiles"] = IAgDataObjectFiles

class IAgUiAxGfxAnalysisCntrl(object):
    """AGI Gfx Analysis control."""

    _num_methods = 17
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_BackColor_method_offset = 1
    _set_BackColor_method_offset = 2
    _get_Picture_method_offset = 3
    _PicturePutRef_method_offset = 4
    _set_Picture_method_offset = 5
    _get_NoLogo_method_offset = 6
    _set_NoLogo_method_offset = 7
    _get_VendorID_method_offset = 8
    _set_VendorID_method_offset = 9
    _get_ReadyState_method_offset = 10
    _get_Application_method_offset = 11
    _get_ControlMode_method_offset = 12
    _set_ControlMode_method_offset = 13
    _get_PictureFromFile_method_offset = 14
    _set_PictureFromFile_method_offset = 15
    _get_WinID_method_offset = 16
    _set_WinID_method_offset = 17
    _metadata = {
        "iid_data" : (5436709951419699304, 6539416614287221654),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiAxGfxAnalysisCntrl."""
        initialize_from_source_object(self, sourceObject, IAgUiAxGfxAnalysisCntrl)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiAxGfxAnalysisCntrl)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiAxGfxAnalysisCntrl, None)
    
    _get_BackColor_metadata = { "offset" : _get_BackColor_method_offset,
            "arg_types" : (POINTER(agcom.OLE_COLOR),),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @property
    def BackColor(self) -> agcolor.Color:
        """The background color of the control."""
        return self._intf.get_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._get_BackColor_metadata)

    _set_BackColor_metadata = { "offset" : _set_BackColor_method_offset,
            "arg_types" : (agcom.OLE_COLOR,),
            "marshallers" : (agmarshall.OLE_COLOR_arg,) }
    @BackColor.setter
    def BackColor(self, clr:agcolor.Color) -> None:
        return self._intf.set_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._set_BackColor_metadata, clr)

    _get_Picture_metadata = { "offset" : _get_Picture_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IPictureDisp_arg,) }
    @property
    def Picture(self) -> IPictureDisp:
        """The splash logo graphic to be displayed in the control."""
        return self._intf.get_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._get_Picture_metadata)

    _PicturePutRef_metadata = { "offset" : _PicturePutRef_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IPictureDisp_arg,) }
    def PicturePutRef(self, pPicture:IPictureDisp) -> None:
        return self._intf.invoke(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._PicturePutRef_metadata, pPicture)

    _set_Picture_metadata = { "offset" : _set_Picture_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IPictureDisp_arg,) }
    @Picture.setter
    def Picture(self, pPicture:IPictureDisp) -> None:
        return self._intf.set_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._set_Picture_metadata, pPicture)

    _get_NoLogo_metadata = { "offset" : _get_NoLogo_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def NoLogo(self) -> bool:
        """If true, the splash logo is not shown."""
        return self._intf.get_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._get_NoLogo_metadata)

    _set_NoLogo_metadata = { "offset" : _set_NoLogo_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @NoLogo.setter
    def NoLogo(self, bNoLogo:bool) -> None:
        return self._intf.set_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._set_NoLogo_metadata, bNoLogo)

    _get_VendorID_metadata = { "offset" : _get_VendorID_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def VendorID(self) -> str:
        """This property is deprecated. The identifier of the vendor."""
        return self._intf.get_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._get_VendorID_metadata)

    _set_VendorID_metadata = { "offset" : _set_VendorID_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @VendorID.setter
    def VendorID(self, vendorID:str) -> None:
        return self._intf.set_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._set_VendorID_metadata, vendorID)

    _get_ReadyState_metadata = { "offset" : _get_ReadyState_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ReadyState(self) -> int:
        """Returns the ready state of the control."""
        return self._intf.get_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._get_ReadyState_metadata)

    _get_Application_metadata = { "offset" : _get_Application_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Application(self) -> "IAgSTKXApplication":
        """Reference to the STK X application object."""
        return self._intf.get_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._get_Application_metadata)

    _get_ControlMode_metadata = { "offset" : _get_ControlMode_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEGfxAnalysisMode),) }
    @property
    def ControlMode(self) -> "AgEGfxAnalysisMode":
        """The Graphics control mode."""
        return self._intf.get_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._get_ControlMode_metadata)

    _set_ControlMode_metadata = { "offset" : _set_ControlMode_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEGfxAnalysisMode),) }
    @ControlMode.setter
    def ControlMode(self, eGfxAnalysisMode:"AgEGfxAnalysisMode") -> None:
        return self._intf.set_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._set_ControlMode_metadata, eGfxAnalysisMode)

    _get_PictureFromFile_metadata = { "offset" : _get_PictureFromFile_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def PictureFromFile(self) -> str:
        """Gets or sets the splash logo graphic file to be displayed in the control."""
        return self._intf.get_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._get_PictureFromFile_metadata)

    _set_PictureFromFile_metadata = { "offset" : _set_PictureFromFile_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @PictureFromFile.setter
    def PictureFromFile(self, pictureFile:str) -> None:
        """Gets or sets the splash logo graphic file to be displayed in the control."""
        return self._intf.set_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._set_PictureFromFile_metadata, pictureFile)

    _get_WinID_metadata = { "offset" : _get_WinID_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def WinID(self) -> int:
        """Window identifier (for Connect commands)."""
        return self._intf.get_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._get_WinID_metadata)

    _set_WinID_metadata = { "offset" : _set_WinID_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @WinID.setter
    def WinID(self, newVal:int) -> None:
        return self._intf.set_property(IAgUiAxGfxAnalysisCntrl._metadata, IAgUiAxGfxAnalysisCntrl._set_WinID_metadata, newVal)

    _property_names[BackColor] = "BackColor"
    _property_names[Picture] = "Picture"
    _property_names[NoLogo] = "NoLogo"
    _property_names[VendorID] = "VendorID"
    _property_names[ReadyState] = "ReadyState"
    _property_names[Application] = "Application"
    _property_names[ControlMode] = "ControlMode"
    _property_names[PictureFromFile] = "PictureFromFile"
    _property_names[WinID] = "WinID"


agcls.AgClassCatalog.add_catalog_entry((5436709951419699304, 6539416614287221654), IAgUiAxGfxAnalysisCntrl)
agcls.AgTypeNameMap["IAgUiAxGfxAnalysisCntrl"] = IAgUiAxGfxAnalysisCntrl



class AgExecCmdResult(IAgExecCmdResult, SupportsDeleteCallback):
    """Collection of strings returned by the ExecuteCommand."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgExecCmdResult."""
        SupportsDeleteCallback.__init__(self)
        IAgExecCmdResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgExecCmdResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgExecCmdResult, [IAgExecCmdResult])

agcls.AgClassCatalog.add_catalog_entry((5401841140219967001, 15290883466624675763), AgExecCmdResult)
agcls.AgTypeNameMap["AgExecCmdResult"] = AgExecCmdResult

class AgExecMultiCmdResult(IAgExecMultiCmdResult, SupportsDeleteCallback):
    """Collection of objects returned by the ExecuteMultipleCommands."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgExecMultiCmdResult."""
        SupportsDeleteCallback.__init__(self)
        IAgExecMultiCmdResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgExecMultiCmdResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgExecMultiCmdResult, [IAgExecMultiCmdResult])

agcls.AgClassCatalog.add_catalog_entry((4795452590337402372, 16534845572987253386), AgExecMultiCmdResult)
agcls.AgTypeNameMap["AgExecMultiCmdResult"] = AgExecMultiCmdResult

class AgUiAxVOCntrl(IAgUiAxVOCntrl, SupportsDeleteCallback):
    """AGI Globe control."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiAxVOCntrl."""
        SupportsDeleteCallback.__init__(self)
        IAgUiAxVOCntrl.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiAxVOCntrl._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiAxVOCntrl, [IAgUiAxVOCntrl])

agcls.AgClassCatalog.add_catalog_entry((5003010835586718402, 17495775815022733215), AgUiAxVOCntrl)
agcls.AgTypeNameMap["AgUiAxVOCntrl"] = AgUiAxVOCntrl

class AgUiAx2DCntrl(IAgUiAx2DCntrl, SupportsDeleteCallback):
    """AGI Map control."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiAx2DCntrl."""
        SupportsDeleteCallback.__init__(self)
        IAgUiAx2DCntrl.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiAx2DCntrl._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiAx2DCntrl, [IAgUiAx2DCntrl])

agcls.AgClassCatalog.add_catalog_entry((4768515753680544793, 142788673313023873), AgUiAx2DCntrl)
agcls.AgTypeNameMap["AgUiAx2DCntrl"] = AgUiAx2DCntrl

class AgPickInfoData(IAgPickInfoData, SupportsDeleteCallback):
    """Single mouse pick result."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgPickInfoData."""
        SupportsDeleteCallback.__init__(self)
        IAgPickInfoData.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPickInfoData._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgPickInfoData, [IAgPickInfoData])

agcls.AgClassCatalog.add_catalog_entry((5212232262739807565, 596295451586007969), AgPickInfoData)
agcls.AgTypeNameMap["AgPickInfoData"] = AgPickInfoData

class AgSTKXApplication(IAgSTKXApplication, SupportsDeleteCallback):
    """STK X Application object."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgSTKXApplication."""
        SupportsDeleteCallback.__init__(self)
        IAgSTKXApplication.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgSTKXApplication._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgSTKXApplication, [IAgSTKXApplication])

agcls.AgClassCatalog.add_catalog_entry((5023115714797155685, 12229237601155197353), AgSTKXApplication)
agcls.AgTypeNameMap["AgSTKXApplication"] = AgSTKXApplication

class AgSTKXApplicationPartnerAccess(IAgSTKXApplicationPartnerAccess, SupportsDeleteCallback):
    """STK X Application Partner Access object."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgSTKXApplicationPartnerAccess."""
        SupportsDeleteCallback.__init__(self)
        IAgSTKXApplicationPartnerAccess.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgSTKXApplicationPartnerAccess._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgSTKXApplicationPartnerAccess, [IAgSTKXApplicationPartnerAccess])

agcls.AgClassCatalog.add_catalog_entry((5641990270821292264, 4458084339625729464), AgSTKXApplicationPartnerAccess)
agcls.AgTypeNameMap["AgSTKXApplicationPartnerAccess"] = AgSTKXApplicationPartnerAccess

class AgDataObject(IAgDataObject, SupportsDeleteCallback):
    """Data Object for OLE drag & drop operations."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDataObject."""
        SupportsDeleteCallback.__init__(self)
        IAgDataObject.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDataObject._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDataObject, [IAgDataObject])

agcls.AgClassCatalog.add_catalog_entry((5114260017860305690, 8438919698207166871), AgDataObject)
agcls.AgTypeNameMap["AgDataObject"] = AgDataObject

class AgDataObjectFiles(IAgDataObjectFiles, SupportsDeleteCallback):
    """Collection of files for OLE drag & drop operations."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDataObjectFiles."""
        SupportsDeleteCallback.__init__(self)
        IAgDataObjectFiles.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDataObjectFiles._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDataObjectFiles, [IAgDataObjectFiles])

agcls.AgClassCatalog.add_catalog_entry((4834386749312660211, 7512407219312220557), AgDataObjectFiles)
agcls.AgTypeNameMap["AgDataObjectFiles"] = AgDataObjectFiles

class AgRubberBandPickInfoData(IAgRubberBandPickInfoData, SupportsDeleteCallback):
    """Rubber-band mouse pick result."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgRubberBandPickInfoData."""
        SupportsDeleteCallback.__init__(self)
        IAgRubberBandPickInfoData.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgRubberBandPickInfoData._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgRubberBandPickInfoData, [IAgRubberBandPickInfoData])

agcls.AgClassCatalog.add_catalog_entry((4985968678511795353, 17743300322106185909), AgRubberBandPickInfoData)
agcls.AgTypeNameMap["AgRubberBandPickInfoData"] = AgRubberBandPickInfoData

class AgObjPathCollection(IAgObjPathCollection, SupportsDeleteCallback):
    """Collection of object paths."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgObjPathCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgObjPathCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgObjPathCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgObjPathCollection, [IAgObjPathCollection])

agcls.AgClassCatalog.add_catalog_entry((5468637706198187096, 15368573397963727005), AgObjPathCollection)
agcls.AgTypeNameMap["AgObjPathCollection"] = AgObjPathCollection

class AgDrawElemRect(IAgDrawElemRect, SupportsDeleteCallback):
    """Defines a rectangle in window coordinates."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDrawElemRect."""
        SupportsDeleteCallback.__init__(self)
        IAgDrawElemRect.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDrawElemRect._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDrawElemRect, [IAgDrawElemRect])

agcls.AgClassCatalog.add_catalog_entry((5240823309103310773, 8687967398961860752), AgDrawElemRect)
agcls.AgTypeNameMap["AgDrawElemRect"] = AgDrawElemRect

class AgDrawElemCollection(IAgDrawElemCollection, SupportsDeleteCallback):
    """Collection of elements to draw on the control."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDrawElemCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgDrawElemCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDrawElemCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDrawElemCollection, [IAgDrawElemCollection])

agcls.AgClassCatalog.add_catalog_entry((4818369897478707705, 12447301819569005480), AgDrawElemCollection)
agcls.AgTypeNameMap["AgDrawElemCollection"] = AgDrawElemCollection

class AgDraw2DElemRect(IAgDrawElemRect, SupportsDeleteCallback):
    """Defines a rectangle in window coordinates for map control."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDraw2DElemRect."""
        SupportsDeleteCallback.__init__(self)
        IAgDrawElemRect.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDrawElemRect._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDraw2DElemRect, [IAgDrawElemRect])

agcls.AgClassCatalog.add_catalog_entry((5576559474231799426, 4548115262096126086), AgDraw2DElemRect)
agcls.AgTypeNameMap["AgDraw2DElemRect"] = AgDraw2DElemRect

class AgDraw2DElemCollection(IAgDrawElemCollection, SupportsDeleteCallback):
    """Collection of elements to draw on map control."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDraw2DElemCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgDrawElemCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDrawElemCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDraw2DElemCollection, [IAgDrawElemCollection])

agcls.AgClassCatalog.add_catalog_entry((5331482112311797798, 13317960878959927180), AgDraw2DElemCollection)
agcls.AgTypeNameMap["AgDraw2DElemCollection"] = AgDraw2DElemCollection

class AgUiAxGfxAnalysisCntrl(IAgUiAxGfxAnalysisCntrl, SupportsDeleteCallback):
    """AGI Graphics Analysis Control."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiAxGfxAnalysisCntrl."""
        SupportsDeleteCallback.__init__(self)
        IAgUiAxGfxAnalysisCntrl.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiAxGfxAnalysisCntrl._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiAxGfxAnalysisCntrl, [IAgUiAxGfxAnalysisCntrl])

agcls.AgClassCatalog.add_catalog_entry((5164937275880325572, 6916941637376451755), AgUiAxGfxAnalysisCntrl)
agcls.AgTypeNameMap["AgUiAxGfxAnalysisCntrl"] = AgUiAxGfxAnalysisCntrl

class AgWinProjPos(IAgWinProjPos, SupportsDeleteCallback):
    """Projected window position result."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgWinProjPos."""
        SupportsDeleteCallback.__init__(self)
        IAgWinProjPos.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgWinProjPos._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgWinProjPos, [IAgWinProjPos])

agcls.AgClassCatalog.add_catalog_entry((5214780816983359777, 2472702336144982961), AgWinProjPos)
agcls.AgTypeNameMap["AgWinProjPos"] = AgWinProjPos

class AgDrawElemLine(IAgDrawElemLine, SupportsDeleteCallback):
    """Defines a line in window coordinates."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDrawElemLine."""
        SupportsDeleteCallback.__init__(self)
        IAgDrawElemLine.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDrawElemLine._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDrawElemLine, [IAgDrawElemLine])

agcls.AgClassCatalog.add_catalog_entry((5698625807246192592, 13092199471832302782), AgDrawElemLine)
agcls.AgTypeNameMap["AgDrawElemLine"] = AgDrawElemLine

class AgSTKXSSLCertificateErrorEventArgs(IAgSTKXSSLCertificateErrorEventArgs, SupportsDeleteCallback):
    """Provides information about an SSL certificate that is expired or invalid."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgSTKXSSLCertificateErrorEventArgs."""
        SupportsDeleteCallback.__init__(self)
        IAgSTKXSSLCertificateErrorEventArgs.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgSTKXSSLCertificateErrorEventArgs._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgSTKXSSLCertificateErrorEventArgs, [IAgSTKXSSLCertificateErrorEventArgs])

agcls.AgClassCatalog.add_catalog_entry((5554115527393925356, 13023286019988610437), AgSTKXSSLCertificateErrorEventArgs)
agcls.AgTypeNameMap["AgSTKXSSLCertificateErrorEventArgs"] = AgSTKXSSLCertificateErrorEventArgs

class AgSTKXConControlQuitReceivedEventArgs(IAgSTKXConControlQuitReceivedEventArgs, SupportsDeleteCallback):
    """Arguments for the OnConControlQuitReceived event."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgSTKXConControlQuitReceivedEventArgs."""
        SupportsDeleteCallback.__init__(self)
        IAgSTKXConControlQuitReceivedEventArgs.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgSTKXConControlQuitReceivedEventArgs._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgSTKXConControlQuitReceivedEventArgs, [IAgSTKXConControlQuitReceivedEventArgs])

agcls.AgClassCatalog.add_catalog_entry((5130572763297124902, 5647256661091814069), AgSTKXConControlQuitReceivedEventArgs)
agcls.AgTypeNameMap["AgSTKXConControlQuitReceivedEventArgs"] = AgSTKXConControlQuitReceivedEventArgs


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
