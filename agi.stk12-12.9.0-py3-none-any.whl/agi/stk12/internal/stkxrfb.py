################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["IAgRemoteFrameBuffer", "IAgRemoteFrameBufferHost"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class IAgRemoteFrameBufferHost(object):
    """Called by engine to request operations from the host using the remote frame buffer."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _Refresh_method_offset = 1
    _metadata = {
        "iid_data" : (4933363163864868357, 6362292819724085430),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgRemoteFrameBufferHost."""
        initialize_from_source_object(self, sourceObject, IAgRemoteFrameBufferHost)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgRemoteFrameBufferHost)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgRemoteFrameBufferHost, None)
    
    _Refresh_metadata = { "offset" : _Refresh_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Refresh(self) -> None:
        """Request a new frame to be displayed."""
        return self._intf.invoke(IAgRemoteFrameBufferHost._metadata, IAgRemoteFrameBufferHost._Refresh_metadata, )


agcls.AgClassCatalog.add_catalog_entry((4933363163864868357, 6362292819724085430), IAgRemoteFrameBufferHost)
agcls.AgTypeNameMap["IAgRemoteFrameBufferHost"] = IAgRemoteFrameBufferHost

class IAgRemoteFrameBuffer(object):
    """Expose the control as a remote frame buffer."""

    _num_methods = 15
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _SnapToRBGRaster_method_offset = 1
    _SetToOffScreenRendering_method_offset = 2
    _NotifyResize_method_offset = 3
    _NotifyLButtonUp_method_offset = 4
    _NotifyRButtonUp_method_offset = 5
    _NotifyMButtonUp_method_offset = 6
    _NotifyLButtonDown_method_offset = 7
    _NotifyRButtonDown_method_offset = 8
    _NotifyMButtonDown_method_offset = 9
    _NotifyMouseMove_method_offset = 10
    _NotifyMouseWheel_method_offset = 11
    _SetHost_method_offset = 12
    _RenderToDirectXTexture_method_offset = 13
    _SetToDirectXRendering_method_offset = 14
    _UpdateDirectXRenderingTexture_method_offset = 15
    _metadata = {
        "iid_data" : (4781006033999273496, 11877164716837129142),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgRemoteFrameBuffer."""
        initialize_from_source_object(self, sourceObject, IAgRemoteFrameBuffer)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgRemoteFrameBuffer)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgRemoteFrameBuffer, None)
    
    _SnapToRBGRaster_metadata = { "offset" : _SnapToRBGRaster_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.PVOID_arg,) }
    def SnapToRBGRaster(self, rbgRasterPtr:agcom.PVOID) -> None:
        """Capture the current scene to a raster."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._SnapToRBGRaster_metadata, rbgRasterPtr)

    _SetToOffScreenRendering_metadata = { "offset" : _SetToOffScreenRendering_method_offset,
            "arg_types" : (agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg,) }
    def SetToOffScreenRendering(self, initialWidth:int, initialHeight:int) -> None:
        """Switch to offscreen rendering."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._SetToOffScreenRendering_metadata, initialWidth, initialHeight)

    _NotifyResize_metadata = { "offset" : _NotifyResize_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg,) }
    def NotifyResize(self, left:int, top:int, width:int, height:int) -> None:
        """Notifies that a resize event occurred."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._NotifyResize_metadata, left, top, width, height)

    _NotifyLButtonUp_metadata = { "offset" : _NotifyLButtonUp_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg,) }
    def NotifyLButtonUp(self, x:int, y:int, keyState:int) -> None:
        """Notifies that a mouse left button up event occurred."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._NotifyLButtonUp_metadata, x, y, keyState)

    _NotifyRButtonUp_metadata = { "offset" : _NotifyRButtonUp_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg,) }
    def NotifyRButtonUp(self, x:int, y:int, keyState:int) -> None:
        """Notifies that a mouse right button up event occurred."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._NotifyRButtonUp_metadata, x, y, keyState)

    _NotifyMButtonUp_metadata = { "offset" : _NotifyMButtonUp_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg,) }
    def NotifyMButtonUp(self, x:int, y:int, keyState:int) -> None:
        """Notifies that a mouse middle button up event occurred."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._NotifyMButtonUp_metadata, x, y, keyState)

    _NotifyLButtonDown_metadata = { "offset" : _NotifyLButtonDown_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg,) }
    def NotifyLButtonDown(self, x:int, y:int, keyState:int) -> None:
        """Notifies that a mouse left button down event occurred."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._NotifyLButtonDown_metadata, x, y, keyState)

    _NotifyRButtonDown_metadata = { "offset" : _NotifyRButtonDown_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg,) }
    def NotifyRButtonDown(self, x:int, y:int, keyState:int) -> None:
        """Notifies that a mouse right button down event occurred."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._NotifyRButtonDown_metadata, x, y, keyState)

    _NotifyMButtonDown_metadata = { "offset" : _NotifyMButtonDown_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg,) }
    def NotifyMButtonDown(self, x:int, y:int, keyState:int) -> None:
        """Notifies that a mouse middle button down event occurred."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._NotifyMButtonDown_metadata, x, y, keyState)

    _NotifyMouseMove_metadata = { "offset" : _NotifyMouseMove_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg,) }
    def NotifyMouseMove(self, x:int, y:int, buttons:int, keyState:int) -> None:
        """Notifies that a mouse move event occurred."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._NotifyMouseMove_metadata, x, y, buttons, keyState)

    _NotifyMouseWheel_metadata = { "offset" : _NotifyMouseWheel_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.INT, agcom.INT,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.INT_arg,) }
    def NotifyMouseWheel(self, x:int, y:int, steps:int, keyState:int) -> None:
        """Notifies that a mouse wheel event occurred."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._NotifyMouseWheel_metadata, x, y, steps, keyState)

    _SetHost_metadata = { "offset" : _SetHost_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgRemoteFrameBufferHost"),) }
    def SetHost(self, pHost:"IAgRemoteFrameBufferHost") -> None:
        """Sets the host using this remote frame buffer."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._SetHost_metadata, pHost)

    _RenderToDirectXTexture_metadata = { "offset" : _RenderToDirectXTexture_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RenderToDirectXTexture(self) -> None:
        """Render to the DirectX texture configured by SetToDirectXRendering()."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._RenderToDirectXTexture_metadata, )

    _SetToDirectXRendering_metadata = { "offset" : _SetToDirectXRendering_method_offset,
            "arg_types" : (agcom.INT, agcom.INT, agcom.PVOID, agcom.PVOID, agcom.PVOID, agcom.PVOID,),
            "marshallers" : (agmarshall.INT_arg, agmarshall.INT_arg, agmarshall.PVOID_arg, agmarshall.PVOID_arg, agmarshall.PVOID_arg, agmarshall.PVOID_arg,) }
    def SetToDirectXRendering(self, initialWidth:int, initialHeight:int, hwnd:agcom.PVOID, directXDevice:agcom.PVOID, directXTexture:agcom.PVOID, directXSharedHandle:agcom.PVOID) -> None:
        """Switch to rendering to the specified Dirext X texture."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._SetToDirectXRendering_metadata, initialWidth, initialHeight, hwnd, directXDevice, directXTexture, directXSharedHandle)

    _UpdateDirectXRenderingTexture_metadata = { "offset" : _UpdateDirectXRenderingTexture_method_offset,
            "arg_types" : (agcom.PVOID, agcom.PVOID,),
            "marshallers" : (agmarshall.PVOID_arg, agmarshall.PVOID_arg,) }
    def UpdateDirectXRenderingTexture(self, directXTexture:agcom.PVOID, directXSharedHandle:agcom.PVOID) -> None:
        """Update Dirext X texture (for instance after a resize)."""
        return self._intf.invoke(IAgRemoteFrameBuffer._metadata, IAgRemoteFrameBuffer._UpdateDirectXRenderingTexture_metadata, directXTexture, directXSharedHandle)


agcls.AgClassCatalog.add_catalog_entry((4781006033999273496, 11877164716837129142), IAgRemoteFrameBuffer)
agcls.AgTypeNameMap["IAgRemoteFrameBuffer"] = IAgRemoteFrameBuffer



################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
