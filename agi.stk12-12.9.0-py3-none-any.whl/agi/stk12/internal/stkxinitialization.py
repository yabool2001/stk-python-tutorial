################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgSTKXInitialize", "IAgSTKXInitialize"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from ..internal  import comutil          as agcom
from ..internal  import coclassutil      as agcls
from ..internal  import marshall         as agmarshall
from ..internal  import dataanalysisutil as agdata
from ..utilities import colors           as agcolor
from ..internal.comutil     import IUnknown, IDispatch, IPictureDisp
from ..internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from ..internal.eventutil   import *
from ..utilities.exceptions import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class IAgSTKXInitialize(object):
    """STK X Advanced Initialization Options."""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _InitializeActivationContext_method_offset = 1
    _InitializeData_method_offset = 2
    _InitializeDataEx_method_offset = 3
    _metadata = {
        "iid_data" : (5587570431076459601, 3289199399803536798),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSTKXInitialize."""
        initialize_from_source_object(self, sourceObject, IAgSTKXInitialize)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSTKXInitialize)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSTKXInitialize, None)
    
    _InitializeActivationContext_metadata = { "offset" : _InitializeActivationContext_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def InitializeActivationContext(self) -> None:
        """Initialize the activation context to be used by STK Engine based on the current activation context."""
        return self._intf.invoke(IAgSTKXInitialize._metadata, IAgSTKXInitialize._InitializeActivationContext_metadata, )

    _InitializeData_metadata = { "offset" : _InitializeData_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def InitializeData(self, installHome:str, configDirectory:str) -> None:
        """Copy the virtual registry to the Config directory and initialize it with the install home specified."""
        return self._intf.invoke(IAgSTKXInitialize._metadata, IAgSTKXInitialize._InitializeData_metadata, installHome, configDirectory)

    _InitializeDataEx_metadata = { "offset" : _InitializeDataEx_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.VARIANT_BOOL, agcom.VARIANT_BOOL, agcom.VARIANT_BOOL, agcom.VARIANT_BOOL, agcom.VARIANT_BOOL, agcom.VARIANT_BOOL, agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.VARIANT_BOOL_arg, agmarshall.VARIANT_BOOL_arg, agmarshall.VARIANT_BOOL_arg, agmarshall.VARIANT_BOOL_arg, agmarshall.VARIANT_BOOL_arg, agmarshall.VARIANT_BOOL_arg, agmarshall.VARIANT_BOOL_arg,) }
    def InitializeDataEx(self, installHome:str, configDirectory:str, bDefaults:bool, bStyles:bool, bVGT:bool, bAMM:bool, bGator:bool, bOnlineData:bool, bOnlineSGP4:bool) -> None:
        """Copy the virtual registry to the Config directory and initialize it with the install home specified, and config options."""
        return self._intf.invoke(IAgSTKXInitialize._metadata, IAgSTKXInitialize._InitializeDataEx_metadata, installHome, configDirectory, bDefaults, bStyles, bVGT, bAMM, bGator, bOnlineData, bOnlineSGP4)


agcls.AgClassCatalog.add_catalog_entry((5587570431076459601, 3289199399803536798), IAgSTKXInitialize)
agcls.AgTypeNameMap["IAgSTKXInitialize"] = IAgSTKXInitialize



class AgSTKXInitialize(IAgSTKXInitialize, SupportsDeleteCallback):
    """STK X Initialize object."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgSTKXInitialize."""
        SupportsDeleteCallback.__init__(self)
        IAgSTKXInitialize.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgSTKXInitialize._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgSTKXInitialize, [IAgSTKXInitialize])

agcls.AgClassCatalog.add_catalog_entry((5130722036779683869, 8760598985969493655), AgSTKXInitialize)
agcls.AgTypeNameMap["AgSTKXInitialize"] = AgSTKXInitialize


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
