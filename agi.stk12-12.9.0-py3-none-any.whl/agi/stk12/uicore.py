################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgEArrangeStyle", "AgEDockStyle", "AgEFloatState", "AgEWindowService", "AgEWindowState", "AgUiToolbar", "AgUiToolbarCollection", 
"AgUiWindow", "AgUiWindowGlobeObject", "AgUiWindowMapObject", "AgUiWindowsCollection", "IAgUiToolbar", "IAgUiToolbarCollection", 
"IAgUiWindow", "IAgUiWindowGlobeObject", "IAgUiWindowMapObject", "IAgUiWindowsCollection"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from .internal  import comutil          as agcom
from .internal  import coclassutil      as agcls
from .internal  import marshall         as agmarshall
from .internal  import dataanalysisutil as agdata
from .utilities import colors           as agcolor
from .internal.comutil     import IUnknown, IDispatch, IPictureDisp
from .internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from .internal.eventutil   import *
from .utilities.exceptions import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEWindowService(IntEnum):
    """Well-known types of services."""
   
    eWindowService2DWindow = 1
    """A 2D window."""
    eWindowService3DWindow = 2
    """A 3D window."""

AgEWindowService.eWindowService2DWindow.__doc__ = "A 2D window."
AgEWindowService.eWindowService3DWindow.__doc__ = "A 3D window."

agcls.AgTypeNameMap["AgEWindowService"] = AgEWindowService

class AgEWindowState(IntEnum):
    """Window states."""
   
    eWindowStateMaximized = 1
    """Window is maximized."""
    eWindowStateMinimized = 2
    """Window is minimized."""
    eWindowStateNormal = 3
    """Normal window state."""

AgEWindowState.eWindowStateMaximized.__doc__ = "Window is maximized."
AgEWindowState.eWindowStateMinimized.__doc__ = "Window is minimized."
AgEWindowState.eWindowStateNormal.__doc__ = "Normal window state."

agcls.AgTypeNameMap["AgEWindowState"] = AgEWindowState

class AgEArrangeStyle(IntEnum):
    """Window layout styles."""
   
    eArrangeStyleCascade = 1
    """Child windows are cascaded within the main window."""
    eArrangeStyleTiledHorizontal = 2
    """Child windows are tiled horizontally within the main window."""
    eArrangeStyleTiledVertical = 3
    """Child windows are tiled vertically within the main window."""

AgEArrangeStyle.eArrangeStyleCascade.__doc__ = "Child windows are cascaded within the main window."
AgEArrangeStyle.eArrangeStyleTiledHorizontal.__doc__ = "Child windows are tiled horizontally within the main window."
AgEArrangeStyle.eArrangeStyleTiledVertical.__doc__ = "Child windows are tiled vertically within the main window."

agcls.AgTypeNameMap["AgEArrangeStyle"] = AgEArrangeStyle

class AgEDockStyle(IntEnum):
    """Window docking styles."""
   
    eDockStyleIntegrated = 1
    """Child window is integrated into the main window."""
    eDockStyleDockedLeft = 2
    """Child window is docked to the left side of the within the main window."""
    eDockStyleDockedRight = 3
    """Child window is docked to the right side of the main window."""
    eDockStyleDockedTop = 4
    """Child window is docked to the top of the main window."""
    eDockStyleDockedBottom = 5
    """Child window is docked to the bottom of the main window."""
    eDockStyleFloating = 6
    """Child window is not docked or integrated."""

AgEDockStyle.eDockStyleIntegrated.__doc__ = "Child window is integrated into the main window."
AgEDockStyle.eDockStyleDockedLeft.__doc__ = "Child window is docked to the left side of the within the main window."
AgEDockStyle.eDockStyleDockedRight.__doc__ = "Child window is docked to the right side of the main window."
AgEDockStyle.eDockStyleDockedTop.__doc__ = "Child window is docked to the top of the main window."
AgEDockStyle.eDockStyleDockedBottom.__doc__ = "Child window is docked to the bottom of the main window."
AgEDockStyle.eDockStyleFloating.__doc__ = "Child window is not docked or integrated."

agcls.AgTypeNameMap["AgEDockStyle"] = AgEDockStyle

class AgEFloatState(IntEnum):
    """Floating state."""
   
    eFloatStateFloated = 1
    """The UI element is floated."""
    eFloatStateDocked = 2
    """The UI element is docked."""

AgEFloatState.eFloatStateFloated.__doc__ = "The UI element is floated."
AgEFloatState.eFloatStateDocked.__doc__ = "The UI element is docked."

agcls.AgTypeNameMap["AgEFloatState"] = AgEFloatState


class IAgUiToolbar(object):
    """Provides methods and properties to control a toolbar."""

    _num_methods = 6
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ID_method_offset = 1
    _get_Caption_method_offset = 2
    _get_Visible_method_offset = 3
    _set_Visible_method_offset = 4
    _get_FloatState_method_offset = 5
    _set_FloatState_method_offset = 6
    _metadata = {
        "iid_data" : (4815534316350549014, 8106580190020797345),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiToolbar."""
        initialize_from_source_object(self, sourceObject, IAgUiToolbar)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiToolbar)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiToolbar, None)
    
    _get_ID_metadata = { "offset" : _get_ID_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def ID(self) -> int:
        """The identity."""
        return self._intf.get_property(IAgUiToolbar._metadata, IAgUiToolbar._get_ID_metadata)

    _get_Caption_metadata = { "offset" : _get_Caption_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Caption(self) -> str:
        """The caption."""
        return self._intf.get_property(IAgUiToolbar._metadata, IAgUiToolbar._get_Caption_metadata)

    _get_Visible_metadata = { "offset" : _get_Visible_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def Visible(self) -> bool:
        """The visibility."""
        return self._intf.get_property(IAgUiToolbar._metadata, IAgUiToolbar._get_Visible_metadata)

    _set_Visible_metadata = { "offset" : _set_Visible_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @Visible.setter
    def Visible(self, newVal:bool) -> None:
        return self._intf.set_property(IAgUiToolbar._metadata, IAgUiToolbar._set_Visible_metadata, newVal)

    _get_FloatState_metadata = { "offset" : _get_FloatState_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEFloatState),) }
    @property
    def FloatState(self) -> "AgEFloatState":
        """The float state."""
        return self._intf.get_property(IAgUiToolbar._metadata, IAgUiToolbar._get_FloatState_metadata)

    _set_FloatState_metadata = { "offset" : _set_FloatState_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEFloatState),) }
    @FloatState.setter
    def FloatState(self, newVal:"AgEFloatState") -> None:
        return self._intf.set_property(IAgUiToolbar._metadata, IAgUiToolbar._set_FloatState_metadata, newVal)

    _property_names[ID] = "ID"
    _property_names[Caption] = "Caption"
    _property_names[Visible] = "Visible"
    _property_names[FloatState] = "FloatState"


agcls.AgClassCatalog.add_catalog_entry((4815534316350549014, 8106580190020797345), IAgUiToolbar)
agcls.AgTypeNameMap["IAgUiToolbar"] = IAgUiToolbar

class IAgUiToolbarCollection(object):
    """Provides methods and properties to obtain a window's toolbars."""

    _num_methods = 6
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Item_method_offset = 1
    _get_Count_method_offset = 2
    _get__NewEnum_method_offset = 3
    _GetToolbarByID_method_offset = 4
    _GetItemByIndex_method_offset = 5
    _GetItemByName_method_offset = 6
    _metadata = {
        "iid_data" : (5034548498384163675, 2931144109818226324),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiToolbarCollection."""
        initialize_from_source_object(self, sourceObject, IAgUiToolbarCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiToolbarCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiToolbarCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgUiToolbarCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgUiToolbar":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.VARIANT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, indexOrCaption:typing.Any) -> "IAgUiToolbar":
        """Retrieves a toolbar object."""
        return self._intf.invoke(IAgUiToolbarCollection._metadata, IAgUiToolbarCollection._Item_metadata, indexOrCaption, OutArg())

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns a total number of toolbars in the collection."""
        return self._intf.get_property(IAgUiToolbarCollection._metadata, IAgUiToolbarCollection._get_Count_metadata)

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Enumerates the toolbars in the collection."""
        return self._intf.get_property(IAgUiToolbarCollection._metadata, IAgUiToolbarCollection._get__NewEnum_metadata)

    _GetToolbarByID_metadata = { "offset" : _GetToolbarByID_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgInterface_out_arg,) }
    def GetToolbarByID(self, id:int) -> "IAgUiToolbar":
        """Returns a toolbar object with the specified toolbar identifier. The identifier is a unique number assigned to a toolbar object."""
        return self._intf.invoke(IAgUiToolbarCollection._metadata, IAgUiToolbarCollection._GetToolbarByID_metadata, id, OutArg())

    _GetItemByIndex_metadata = { "offset" : _GetItemByIndex_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByIndex(self, index:int) -> "IAgUiToolbar":
        """Retrieves a toolbar object based on the index in the collection."""
        return self._intf.invoke(IAgUiToolbarCollection._metadata, IAgUiToolbarCollection._GetItemByIndex_metadata, index, OutArg())

    _GetItemByName_metadata = { "offset" : _GetItemByName_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByName(self, name:str) -> "IAgUiToolbar":
        """Retrieves a toolbar object based on the name of the Toolbar in the collection."""
        return self._intf.invoke(IAgUiToolbarCollection._metadata, IAgUiToolbarCollection._GetItemByName_metadata, name, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5034548498384163675, 2931144109818226324), IAgUiToolbarCollection)
agcls.AgTypeNameMap["IAgUiToolbarCollection"] = IAgUiToolbarCollection

class IAgUiWindow(object):
    """Represents a window abstraction. Provides methods and properties to manipulate the position and the state of the window."""

    _num_methods = 24
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Caption_method_offset = 1
    _set_Caption_method_offset = 2
    _Activate_method_offset = 3
    _get_WindowState_method_offset = 4
    _set_WindowState_method_offset = 5
    _Close_method_offset = 6
    _get_Height_method_offset = 7
    _set_Height_method_offset = 8
    _get_Width_method_offset = 9
    _set_Width_method_offset = 10
    _get_Left_method_offset = 11
    _set_Left_method_offset = 12
    _get_Top_method_offset = 13
    _set_Top_method_offset = 14
    _get_DockStyle_method_offset = 15
    _set_DockStyle_method_offset = 16
    _get_NoWBClose_method_offset = 17
    _set_NoWBClose_method_offset = 18
    _get_UnPinned_method_offset = 19
    _set_UnPinned_method_offset = 20
    _get_SupportsPinning_method_offset = 21
    _get_Toolbars_method_offset = 22
    _GetServiceByName_method_offset = 23
    _GetServiceByType_method_offset = 24
    _metadata = {
        "iid_data" : (5238521222474863957, 13235753129659511978),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiWindow."""
        initialize_from_source_object(self, sourceObject, IAgUiWindow)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiWindow)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiWindow, None)
    
    _get_Caption_metadata = { "offset" : _get_Caption_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Caption(self) -> str:
        """Gets or sets the window caption. Can only be set within UI plugins for the non unique windows they own."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_Caption_metadata)

    _set_Caption_metadata = { "offset" : _set_Caption_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @Caption.setter
    def Caption(self, caption:str) -> None:
        """Gets or sets  the window caption. Can only be set within UI plugins for the non unique windows they own."""
        return self._intf.set_property(IAgUiWindow._metadata, IAgUiWindow._set_Caption_metadata, caption)

    _Activate_metadata = { "offset" : _Activate_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Activate(self) -> None:
        """Activates the window."""
        return self._intf.invoke(IAgUiWindow._metadata, IAgUiWindow._Activate_metadata, )

    _get_WindowState_metadata = { "offset" : _get_WindowState_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEWindowState),) }
    @property
    def WindowState(self) -> "AgEWindowState":
        """The window state."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_WindowState_metadata)

    _set_WindowState_metadata = { "offset" : _set_WindowState_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEWindowState),) }
    @WindowState.setter
    def WindowState(self, newVal:"AgEWindowState") -> None:
        return self._intf.set_property(IAgUiWindow._metadata, IAgUiWindow._set_WindowState_metadata, newVal)

    _Close_metadata = { "offset" : _Close_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def Close(self) -> None:
        """Closes the window."""
        return self._intf.invoke(IAgUiWindow._metadata, IAgUiWindow._Close_metadata, )

    _get_Height_metadata = { "offset" : _get_Height_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Height(self) -> int:
        """The window height."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_Height_metadata)

    _set_Height_metadata = { "offset" : _set_Height_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @Height.setter
    def Height(self, newVal:int) -> None:
        return self._intf.set_property(IAgUiWindow._metadata, IAgUiWindow._set_Height_metadata, newVal)

    _get_Width_metadata = { "offset" : _get_Width_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Width(self) -> int:
        """The window width."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_Width_metadata)

    _set_Width_metadata = { "offset" : _set_Width_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @Width.setter
    def Width(self, newVal:int) -> None:
        return self._intf.set_property(IAgUiWindow._metadata, IAgUiWindow._set_Width_metadata, newVal)

    _get_Left_metadata = { "offset" : _get_Left_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Left(self) -> int:
        """The window horizontal position."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_Left_metadata)

    _set_Left_metadata = { "offset" : _set_Left_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @Left.setter
    def Left(self, newVal:int) -> None:
        return self._intf.set_property(IAgUiWindow._metadata, IAgUiWindow._set_Left_metadata, newVal)

    _get_Top_metadata = { "offset" : _get_Top_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Top(self) -> int:
        """The window vertical position."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_Top_metadata)

    _set_Top_metadata = { "offset" : _set_Top_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @Top.setter
    def Top(self, newVal:int) -> None:
        return self._intf.set_property(IAgUiWindow._metadata, IAgUiWindow._set_Top_metadata, newVal)

    _get_DockStyle_metadata = { "offset" : _get_DockStyle_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEDockStyle),) }
    @property
    def DockStyle(self) -> "AgEDockStyle":
        """The window docking style."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_DockStyle_metadata)

    _set_DockStyle_metadata = { "offset" : _set_DockStyle_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEDockStyle),) }
    @DockStyle.setter
    def DockStyle(self, newVal:"AgEDockStyle") -> None:
        return self._intf.set_property(IAgUiWindow._metadata, IAgUiWindow._set_DockStyle_metadata, newVal)

    _get_NoWBClose_metadata = { "offset" : _get_NoWBClose_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def NoWBClose(self) -> bool:
        """Whether to close the window when the application workbook is loaded/closed."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_NoWBClose_metadata)

    _set_NoWBClose_metadata = { "offset" : _set_NoWBClose_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @NoWBClose.setter
    def NoWBClose(self, newVal:bool) -> None:
        return self._intf.set_property(IAgUiWindow._metadata, IAgUiWindow._set_NoWBClose_metadata, newVal)

    _get_UnPinned_metadata = { "offset" : _get_UnPinned_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def UnPinned(self) -> bool:
        """The window's pinned state."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_UnPinned_metadata)

    _set_UnPinned_metadata = { "offset" : _set_UnPinned_method_offset,
            "arg_types" : (agcom.VARIANT_BOOL,),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @UnPinned.setter
    def UnPinned(self, newVal:bool) -> None:
        return self._intf.set_property(IAgUiWindow._metadata, IAgUiWindow._set_UnPinned_metadata, newVal)

    _get_SupportsPinning_metadata = { "offset" : _get_SupportsPinning_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def SupportsPinning(self) -> bool:
        """Returns whether the window supports pinning."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_SupportsPinning_metadata)

    _get_Toolbars_metadata = { "offset" : _get_Toolbars_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Toolbars(self) -> "IAgUiToolbarCollection":
        """Returns the window's toolbar collection."""
        return self._intf.get_property(IAgUiWindow._metadata, IAgUiWindow._get_Toolbars_metadata)

    _GetServiceByName_metadata = { "offset" : _GetServiceByName_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetServiceByName(self, name:str) -> typing.Any:
        """Returns a service object that can be accessed at runtime. The method returns null if no service object is associated with the specified symbolic name."""
        return self._intf.invoke(IAgUiWindow._metadata, IAgUiWindow._GetServiceByName_metadata, name, OutArg())

    _GetServiceByType_metadata = { "offset" : _GetServiceByType_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEWindowService), agmarshall.AgInterface_out_arg,) }
    def GetServiceByType(self, serviceType:"AgEWindowService") -> typing.Any:
        """Returns a service object that can be accessed at runtime. The method returns null if no service object is associated with the specified service type."""
        return self._intf.invoke(IAgUiWindow._metadata, IAgUiWindow._GetServiceByType_metadata, serviceType, OutArg())

    _property_names[Caption] = "Caption"
    _property_names[WindowState] = "WindowState"
    _property_names[Height] = "Height"
    _property_names[Width] = "Width"
    _property_names[Left] = "Left"
    _property_names[Top] = "Top"
    _property_names[DockStyle] = "DockStyle"
    _property_names[NoWBClose] = "NoWBClose"
    _property_names[UnPinned] = "UnPinned"
    _property_names[SupportsPinning] = "SupportsPinning"
    _property_names[Toolbars] = "Toolbars"


agcls.AgClassCatalog.add_catalog_entry((5238521222474863957, 13235753129659511978), IAgUiWindow)
agcls.AgTypeNameMap["IAgUiWindow"] = IAgUiWindow

class IAgUiWindowsCollection(object):
    """Provides methods and properties to manage the application's windows."""

    _num_methods = 7
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Item_method_offset = 1
    _get_Count_method_offset = 2
    _Arrange_method_offset = 3
    _Add_method_offset = 4
    _get__NewEnum_method_offset = 5
    _GetItemByIndex_method_offset = 6
    _GetItemByName_method_offset = 7
    _metadata = {
        "iid_data" : (4730401565789584263, 3861368304027982243),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiWindowsCollection."""
        initialize_from_source_object(self, sourceObject, IAgUiWindowsCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiWindowsCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiWindowsCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgUiWindowsCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgUiWindow":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.VARIANT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, indexOrCaption:typing.Any) -> "IAgUiWindow":
        """Retrieves a window object."""
        return self._intf.invoke(IAgUiWindowsCollection._metadata, IAgUiWindowsCollection._Item_metadata, indexOrCaption, OutArg())

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns a total number of window objects in the collection."""
        return self._intf.get_property(IAgUiWindowsCollection._metadata, IAgUiWindowsCollection._get_Count_metadata)

    _Arrange_metadata = { "offset" : _Arrange_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEArrangeStyle),) }
    def Arrange(self, arrangeStyle:"AgEArrangeStyle") -> None:
        """Arranges the application windows using the specified style."""
        return self._intf.invoke(IAgUiWindowsCollection._metadata, IAgUiWindowsCollection._Arrange_metadata, arrangeStyle)

    _Add_metadata = { "offset" : _Add_method_offset,
            "arg_types" : (agcom.BSTR, agcom.VARIANT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.VARIANT_arg, agmarshall.AgInterface_out_arg,) }
    def Add(self, pluginID:str, initData:typing.Any) -> "IAgUiWindow":
        """Creates a new window. The bstrPluginID is a COM ProgID associated with an STK plugin."""
        return self._intf.invoke(IAgUiWindowsCollection._metadata, IAgUiWindowsCollection._Add_metadata, pluginID, initData, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Enumerates the windows in the collection."""
        return self._intf.get_property(IAgUiWindowsCollection._metadata, IAgUiWindowsCollection._get__NewEnum_metadata)

    _GetItemByIndex_metadata = { "offset" : _GetItemByIndex_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByIndex(self, index:int) -> "IAgUiWindow":
        """Retrieves a window object by index in collection."""
        return self._intf.invoke(IAgUiWindowsCollection._metadata, IAgUiWindowsCollection._GetItemByIndex_metadata, index, OutArg())

    _GetItemByName_metadata = { "offset" : _GetItemByName_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByName(self, name:str) -> "IAgUiWindow":
        """Retrieves a window object by name of window object."""
        return self._intf.invoke(IAgUiWindowsCollection._metadata, IAgUiWindowsCollection._GetItemByName_metadata, name, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((4730401565789584263, 3861368304027982243), IAgUiWindowsCollection)
agcls.AgTypeNameMap["IAgUiWindowsCollection"] = IAgUiWindowsCollection

class IAgUiWindowMapObject(object):
    """Represents a 2D (Map) window. Provides methods and properties to access the 2D window properties."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_MapID_method_offset = 1
    _metadata = {
        "iid_data" : (5665093236705462569, 949456394611833022),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiWindowMapObject."""
        initialize_from_source_object(self, sourceObject, IAgUiWindowMapObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiWindowMapObject)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiWindowMapObject, None)
    
    _get_MapID_metadata = { "offset" : _get_MapID_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def MapID(self) -> int:
        """A unique identifier associated with the window that can be used with Connect to control the 2D map."""
        return self._intf.get_property(IAgUiWindowMapObject._metadata, IAgUiWindowMapObject._get_MapID_metadata)

    _property_names[MapID] = "MapID"


agcls.AgClassCatalog.add_catalog_entry((5665093236705462569, 949456394611833022), IAgUiWindowMapObject)
agcls.AgTypeNameMap["IAgUiWindowMapObject"] = IAgUiWindowMapObject

class IAgUiWindowGlobeObject(object):
    """Represents a 3D (Globe) window. Provides methods and properties to access the 3D window properties."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_SceneID_method_offset = 1
    _metadata = {
        "iid_data" : (5014201186762943933, 15007269609063404450),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUiWindowGlobeObject."""
        initialize_from_source_object(self, sourceObject, IAgUiWindowGlobeObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUiWindowGlobeObject)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUiWindowGlobeObject, None)
    
    _get_SceneID_metadata = { "offset" : _get_SceneID_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def SceneID(self) -> int:
        """A unique identifier associated with the window that can be used with Connect to control the 3D globe."""
        return self._intf.get_property(IAgUiWindowGlobeObject._metadata, IAgUiWindowGlobeObject._get_SceneID_metadata)

    _property_names[SceneID] = "SceneID"


agcls.AgClassCatalog.add_catalog_entry((5014201186762943933, 15007269609063404450), IAgUiWindowGlobeObject)
agcls.AgTypeNameMap["IAgUiWindowGlobeObject"] = IAgUiWindowGlobeObject



class AgUiWindowsCollection(IAgUiWindowsCollection, SupportsDeleteCallback):
    """Provides methods and properties to manage the windows."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiWindowsCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgUiWindowsCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiWindowsCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiWindowsCollection, [IAgUiWindowsCollection])

agcls.AgClassCatalog.add_catalog_entry((5494012632689531786, 14643514705293336469), AgUiWindowsCollection)
agcls.AgTypeNameMap["AgUiWindowsCollection"] = AgUiWindowsCollection

class AgUiWindow(IAgUiWindow, SupportsDeleteCallback):
    """Represents a window abstraction. Provides methods and properties to manipulate the position and the state of the window."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiWindow."""
        SupportsDeleteCallback.__init__(self)
        IAgUiWindow.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiWindow._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiWindow, [IAgUiWindow])

agcls.AgClassCatalog.add_catalog_entry((4826632444527701187, 17778306301041749141), AgUiWindow)
agcls.AgTypeNameMap["AgUiWindow"] = AgUiWindow

class AgUiToolbar(IAgUiToolbar, SupportsDeleteCallback):
    """Represents a toolbar abstraction. Provides methods and properties to manipulate the position and the state of the toolbar."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiToolbar."""
        SupportsDeleteCallback.__init__(self)
        IAgUiToolbar.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiToolbar._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiToolbar, [IAgUiToolbar])

agcls.AgClassCatalog.add_catalog_entry((5472906868102444420, 13479142476234282134), AgUiToolbar)
agcls.AgTypeNameMap["AgUiToolbar"] = AgUiToolbar

class AgUiToolbarCollection(IAgUiToolbarCollection, SupportsDeleteCallback):
    """Provides methods and properties to manage the toolbars."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiToolbarCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgUiToolbarCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiToolbarCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiToolbarCollection, [IAgUiToolbarCollection])

agcls.AgClassCatalog.add_catalog_entry((5214835483446608103, 6177983444187579524), AgUiToolbarCollection)
agcls.AgTypeNameMap["AgUiToolbarCollection"] = AgUiToolbarCollection

class AgUiWindowMapObject(IAgUiWindowMapObject, SupportsDeleteCallback):
    """Provides methods and properties to manipulate the 2D map."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiWindowMapObject."""
        SupportsDeleteCallback.__init__(self)
        IAgUiWindowMapObject.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiWindowMapObject._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiWindowMapObject, [IAgUiWindowMapObject])

agcls.AgClassCatalog.add_catalog_entry((5532961742508552268, 7732337666827650452), AgUiWindowMapObject)
agcls.AgTypeNameMap["AgUiWindowMapObject"] = AgUiWindowMapObject

class AgUiWindowGlobeObject(IAgUiWindowGlobeObject, SupportsDeleteCallback):
    """Provides methods and properties to manipulate the 3D globe."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUiWindowGlobeObject."""
        SupportsDeleteCallback.__init__(self)
        IAgUiWindowGlobeObject.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUiWindowGlobeObject._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUiWindowGlobeObject, [IAgUiWindowGlobeObject])

agcls.AgClassCatalog.add_catalog_entry((5334286057966533215, 999415816428096669), AgUiWindowGlobeObject)
agcls.AgTypeNameMap["AgUiWindowGlobeObject"] = AgUiWindowGlobeObject


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
