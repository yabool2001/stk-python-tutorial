################################################################################
#          Copyright 2020-2024, Ansys Government Initiatives
################################################################################

"""Starts STK Engine and provides access to the Object Model root."""

__all__ = ["STKEngine", "STKEngineApplication", "STKEngineTimerType"]

import os
import atexit
from ctypes import byref
from enum import IntEnum
from ..internal.timerutil import *

if os.name != "nt":
    from ctypes import CFUNCTYPE, cdll
    from ctypes.util import find_library

from ..internal.comutil            import CLSCTX_INPROC_SERVER, COINIT_APARTMENTTHREADED, GUID
from ..internal.comutil            import ole32lib, CoInitializeManager, IUnknown, ObjectLifetimeManager, Succeeded
from ..internal.eventutil          import EventSubscriptionManager
from ..utilities.grpcutilities     import GrpcCallBatcher
from ..internal.stkxinitialization import IAgSTKXInitialize
from ..utilities.exceptions        import STKRuntimeError, STKInitializationError, GrpcUtilitiesException
from ..stkobjects                  import AgStkObjectRoot, AgStkObjectModelContext
from ..stkx                        import AgSTKXApplication

class STKEngineTimerType(IntEnum):
    DisableTimers     = 1
    TkinterMainloop   = 2
    InteractivePython = 3
    SigAlarm          = 4
    SigRt             = 5

class STKEngineApplication(AgSTKXApplication):
    """
    Interact with STK Engine.

    Use STKEngine.StartApplication() to obtain an initialized STKEngineApplication object.
    """
    
    def __init__(self):
        """Construct an object of type STKEngineApplication."""
        AgSTKXApplication.__init__(self)
        self.__dict__["_initialized"] = False
        self.__dict__["_grpc_exceptions"] = True

    def _private_init(self, pUnk:IUnknown, noGraphics):
        AgSTKXApplication._private_init(self, pUnk)
        if os.name!="nt":
            self._STKXInitialize()
        self._STKXInitializeTimer(noGraphics)
        self.__dict__["_initialized"] = True
        
    def __del__(self):
        """Destruct the STKEngineApplication object after all references to the object are deleted."""
        self.ShutDown()
        
    def _STKXInitialize(self):
        CLSID_AgSTKXInitialize = GUID()
        if Succeeded(ole32lib.CLSIDFromString("{3B85901D-FC82-4733-97E6-5BB25CE69379}", CLSID_AgSTKXInitialize)):
            IID_IUnknown = GUID(IUnknown._guid)
            stkxinit_unk = IUnknown()
            if Succeeded(ole32lib.CoCreateInstance(byref(CLSID_AgSTKXInitialize), None, CLSCTX_INPROC_SERVER, byref(IID_IUnknown), byref(stkxinit_unk.p))):
                stkxinit_unk.take_ownership()
                pInit = IAgSTKXInitialize()
                pInit._private_init(stkxinit_unk)
                install_dir = os.getenv("STK_INSTALL_DIR")
                if install_dir is None:
                    raise STKInitializationError("Please set a valid STK_INSTALL_DIR environment variable.")
                config_dir = os.getenv("STK_CONFIG_DIR")
                if config_dir is None:
                    raise STKInitializationError("Please set a valid STK_CONFIG_DIR environment variable.")
                pInit.InitializeData(install_dir, config_dir)
                
    @staticmethod
    def _get_signo(sigrtmin_offset):
        if os.name=="nt":
            return None
        libc = cdll.LoadLibrary(find_library("c"))
        __libc_current_sigrtmin = CFUNCTYPE(c_int)(("__libc_current_sigrtmin", libc))
        return __libc_current_sigrtmin() + sigrtmin_offset
        
    def _set_timer_type_from_env(self):
        timer_type = int(os.getenv("STK_PYTHONAPI_TIMERTYPE", "4"))
        if os.name=="nt" or timer_type == STKEngineTimerType.DisableTimers:
            self.__dict__["_timer_impl"] = NullTimer()
        elif timer_type == STKEngineTimerType.TkinterMainloop or timer_type == STKEngineTimerType.InteractivePython:
            self.__dict__["_timer_impl"] = TclTimer()
        elif timer_type == STKEngineTimerType.SigAlarm:
            self.__dict__["_timer_impl"] = SigAlarmTimer()
        elif timer_type == STKEngineTimerType.SigRt:
            sigrtmin_offset = int(os.getenv("STK_PYTHONAPI_TIMERTYPE5_SIGRTMIN_OFFSET", "0"))
            signo = STKEngineApplication._get_signo(sigrtmin_offset)
            self.__dict__["_timer_impl"] = SigRtTimer(signo)
            
    def _user_override_timer_type(self) -> bool:
        return ("STK_PYTHONAPI_TIMERTYPE" in os.environ)
                
    def _STKXInitializeTimer(self, noGraphics):
        if os.name=="nt":
            #Timers are not implemented on Windows, use a placeholder.
            self.__dict__["_timer_impl"] = NullTimer()
        elif noGraphics:
            self._set_timer_type_from_env()
        else:
            #default to Tkinter mainloop in graphics applications, but allow the user to override
            #e.g. if controls are not being used, the SigAlarm timer might be desired.
            if self._user_override_timer_type():
                self._set_timer_type_from_env()
            else:
                self.__dict__["_timer_impl"] = TclTimer()
        
    def NewObjectRoot(self) -> AgStkObjectRoot:
        """Create a new object model root for the STK Engine application."""
        if not self.__dict__["_initialized"]:
            raise STKRuntimeError("STKEngineApplication has not been properly initialized.  Use StartApplication() to obtain the STKEngineApplication object.")
        CLSID_AgStkObjectRoot = GUID()
        if Succeeded(ole32lib.CLSIDFromString("{96C1CE4E-C61D-4657-99CB-8581E12693FE}", CLSID_AgStkObjectRoot)):
            IID_IUnknown = GUID(IUnknown._guid)
            root_unk = IUnknown()
            ole32lib.CoCreateInstance(byref(CLSID_AgStkObjectRoot), None, CLSCTX_INPROC_SERVER, byref(IID_IUnknown), byref(root_unk.p))
            root_unk.take_ownership()
            root = AgStkObjectRoot()
            root._private_init(root_unk)
            return root

    def NewObjectModelContext(self) -> AgStkObjectModelContext:
        """Create a new object model context for the STK Engine application."""
        if not self.__dict__['_initialized']:
            raise STKRuntimeError('STKEngineApplication has not been properly initialized.  Use StartApplication() to obtain the STKEngineApplication object.')
        CLSID_AgStkObjectModelContext = GUID()
        if Succeeded(ole32lib.CLSIDFromString('{7A12879C-5018-4433-8415-5DB250AFBAF9}', CLSID_AgStkObjectModelContext)):
            IID_IUnknown = GUID(IUnknown._guid)
            context_unk = IUnknown()
            ole32lib.CoCreateInstance(byref(CLSID_AgStkObjectModelContext), None, CLSCTX_INPROC_SERVER, byref(IID_IUnknown), byref(context_unk.p))
            context_unk.take_ownership()
            context = AgStkObjectModelContext()
            context._private_init(context_unk)
            return context

    def SetGrpcOptions(self, options:dict) -> None:
        """
        Grpc is not available with STK Engine. Provided for parity with STK Runtime and Desktop.
        
        Available options include:
        { "raise exceptions with STK Engine" : bool }. Set to false to suppress exceptions when
        using SetGrpcOptions and NewGrpcCallBatcher with STK Engine.
        """
        if "raise exceptions with STK Engine" in options:
            self.__dict__["_grpc_exceptions"] = options["raise exceptions with STK Engine"]
        if self._grpc_exceptions:
            raise GrpcUtilitiesException("gRPC is not available with STK Engine. Disable this exception with SetGrpcOptions({\"raise exceptions with STK Engine\" : False}).")
            
    def NewGrpcCallBatcher(self, max_batch:int=None, disable_batching:bool=True) -> GrpcCallBatcher:
        """
        Grpc is not available with STK Engine. Provided for parity with STK Runtime and Desktop.
        """
        if self._grpc_exceptions:
            raise GrpcUtilitiesException("gRPC is not available with STK Engine. Disable this exception with SetGrpcOptions({\"raise exceptions with STK Engine\" : False}).")
        return GrpcCallBatcher(disable_batching=True)

    def ShutDown(self) -> None:
        """Shut down the STK Engine application."""
        if self._initialized:
            EventSubscriptionManager.UnsubscribeAll()
            self._timer_impl.terminate()
            ObjectLifetimeManager.ReleaseAll(releaseApplication=False)
            self.Terminate()
            ObjectLifetimeManager.ReleaseAll(releaseApplication=True)
            CoInitializeManager.uninitialize()
            self.__dict__["_initialized"] = False


class STKEngine(object):
    """Initialize and manage the STK Engine application."""
    
    _is_engine_running = False
            
    @staticmethod
    def _initX11(noGraphics):
        if noGraphics or os.name=="nt":
            return
        try:
            x11lib = cdll.LoadLibrary(find_library("X11"))
            XInitThreads = CFUNCTYPE(None)(("XInitThreads", x11lib))
            XInitThreads()
        except:
            raise STKRuntimeError("Failed attempting to run graphics mode without X11.")
            
    @staticmethod
    def StartApplication(noGraphics:bool=True) -> STKEngineApplication:
        """
        Initialize STK Engine in-process and return the instance.

        Must only be used once per Python process.
        """
        if STKEngine._is_engine_running:
            raise STKRuntimeError("Only one STKEngine instance is allowed per Python process.")
        CoInitializeManager.initialize()
        CLSID_AgSTKXApplication = GUID()
        if Succeeded(ole32lib.CLSIDFromString("{062AB565-B121-45B5-A9A9-B412CEFAB6A9}", CLSID_AgSTKXApplication)):
            pUnk = IUnknown()
            IID_IUnknown = GUID(IUnknown._guid)
            if Succeeded(ole32lib.CoCreateInstance(byref(CLSID_AgSTKXApplication), None, CLSCTX_INPROC_SERVER, byref(IID_IUnknown), byref(pUnk.p))):
                pUnk.take_ownership(isApplication=True)
                STKEngine._is_engine_running = True
                STKEngine._initX11(noGraphics)
                engine = STKEngineApplication()
                engine._private_init(pUnk, noGraphics)
                engine.NoGraphics = noGraphics
                atexit.register(engine.ShutDown)
                return engine
        raise STKInitializationError("Failed to create STK Engine application.  Check for successful install and registration.")
       
################################################################################
#          Copyright 2020-2024, Ansys Government Initiatives
################################################################################
