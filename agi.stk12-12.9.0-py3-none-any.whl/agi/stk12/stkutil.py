################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################ 

__all__ = ["AgCROrientationAzEl", "AgCROrientationEulerAngles", "AgCROrientationOffsetCart", "AgCROrientationQuaternion", 
"AgCROrientationYPRAngles", "AgCartesian", "AgCartesian2Vector", "AgCartesian3Vector", "AgConversionUtility", "AgCylindrical", 
"AgDate", "AgDirection", "AgDirectionEuler", "AgDirectionPR", "AgDirectionRADec", "AgDirectionXYZ", "AgDoublesCollection", 
"AgEAzElAboutBoresight", "AgECoordinateSystem", "AgEDirectionType", "AgEEulerDirectionSequence", "AgEEulerOrientationSequence", 
"AgEExecMultiCmdResultAction", "AgEFillStyle", "AgELineStyle", "AgELogMsgDispID", "AgELogMsgType", "AgEOrbitStateType", 
"AgEOrientationType", "AgEPRSequence", "AgEPositionType", "AgEPropertyInfoValueType", "AgEYPRAnglesSequence", "AgExecCmdResult", 
"AgExecMultiCmdResult", "AgGeocentric", "AgGeodetic", "AgOrientation", "AgOrientationAzEl", "AgOrientationEulerAngles", 
"AgOrientationQuaternion", "AgOrientationYPRAngles", "AgPlanetocentric", "AgPlanetodetic", "AgPosition", "AgPropertyInfo", 
"AgPropertyInfoCollection", "AgQuantity", "AgRuntimeTypeInfo", "AgSpherical", "AgUnitPrefsDim", "AgUnitPrefsDimCollection", 
"AgUnitPrefsUnit", "AgUnitPrefsUnitCollection", "IAgCartesian", "IAgCartesian2Vector", "IAgCartesian3Vector", "IAgConversionUtility", 
"IAgCylindrical", "IAgDate", "IAgDirection", "IAgDirectionEuler", "IAgDirectionPR", "IAgDirectionRADec", "IAgDirectionXYZ", 
"IAgDoublesCollection", "IAgExecCmdResult", "IAgExecMultiCmdResult", "IAgGeocentric", "IAgGeodetic", "IAgLocationData", 
"IAgOrbitState", "IAgOrientation", "IAgOrientationAzEl", "IAgOrientationEulerAngles", "IAgOrientationPositionOffset", "IAgOrientationQuaternion", 
"IAgOrientationYPRAngles", "IAgPlanetocentric", "IAgPlanetodetic", "IAgPosition", "IAgPropertyInfo", "IAgPropertyInfoCollection", 
"IAgQuantity", "IAgRuntimeTypeInfo", "IAgRuntimeTypeInfoProvider", "IAgSpherical", "IAgUnitPrefsDim", "IAgUnitPrefsDimCollection", 
"IAgUnitPrefsUnit", "IAgUnitPrefsUnitCollection"]

import typing

from ctypes   import byref, POINTER
from datetime import datetime
from enum     import IntEnum, IntFlag

from .internal  import comutil          as agcom
from .internal  import coclassutil      as agcls
from .internal  import marshall         as agmarshall
from .internal  import dataanalysisutil as agdata
from .utilities import colors           as agcolor
from .internal.comutil     import IUnknown, IDispatch, IPictureDisp
from .internal.apiutil     import (InterfaceProxy, EnumeratorProxy, OutArg, 
    initialize_from_source_object, get_interface_property, set_interface_attribute, 
    set_class_attribute, SupportsDeleteCallback)
from .internal.eventutil   import *
from .utilities.exceptions import *


def _raise_uninitialized_error(*args):
    raise STKRuntimeError("Valid STK object model classes are returned from STK methods and should not be created independently.")

class AgEPositionType(IntEnum):
    """Facility/place/target position types."""
   
    eCartesian = 0x0
    """Cartesian: position specified in terms of the X, Y and Z components of the object's position vector, where the Z-axis points to the North pole, and the X-axis crosses 0 degrees latitude/0 degrees longitude."""
    eCylindrical = 0x1
    """Cylindrical: position specified in terms of radius (polar), longitude (measured in degrees from -360.0 degrees to +360.0 degrees), and the Z component of the object's position vector."""
    eGeocentric = 0x2
    """Geocentric: position specified in terms of latitude (spherical latitude of the sub-point on the surface of the Earth), longitude and altitude."""
    eGeodetic = 0x3
    """Geodetic: position specified in terms of latitude (angle between the normal to the reference ellipsoid and the equatorial plane), longitude and altitude."""
    eSpherical = 0x4
    """Spherical: position specified in terms of latitude (spherical latitude of the sub-point on the surface of the Earth), longitude and radius (distance of the object from the center of the Earth)."""
    ePlanetocentric = 0x5
    """Planetocentric: position specified in terms of latitude (spherical latitude of the sub-point on the surface of the Earth), longitude and altitude."""
    ePlanetodetic = 0x6
    """Planetodetic: position specified in terms of latitude (angle between the normal to the reference ellipsoid and the equatorial plane), longitude and altitude."""

AgEPositionType.eCartesian.__doc__ = "Cartesian: position specified in terms of the X, Y and Z components of the object's position vector, where the Z-axis points to the North pole, and the X-axis crosses 0 degrees latitude/0 degrees longitude."
AgEPositionType.eCylindrical.__doc__ = "Cylindrical: position specified in terms of radius (polar), longitude (measured in degrees from -360.0 degrees to +360.0 degrees), and the Z component of the object's position vector."
AgEPositionType.eGeocentric.__doc__ = "Geocentric: position specified in terms of latitude (spherical latitude of the sub-point on the surface of the Earth), longitude and altitude."
AgEPositionType.eGeodetic.__doc__ = "Geodetic: position specified in terms of latitude (angle between the normal to the reference ellipsoid and the equatorial plane), longitude and altitude."
AgEPositionType.eSpherical.__doc__ = "Spherical: position specified in terms of latitude (spherical latitude of the sub-point on the surface of the Earth), longitude and radius (distance of the object from the center of the Earth)."
AgEPositionType.ePlanetocentric.__doc__ = "Planetocentric: position specified in terms of latitude (spherical latitude of the sub-point on the surface of the Earth), longitude and altitude."
AgEPositionType.ePlanetodetic.__doc__ = "Planetodetic: position specified in terms of latitude (angle between the normal to the reference ellipsoid and the equatorial plane), longitude and altitude."

agcls.AgTypeNameMap["AgEPositionType"] = AgEPositionType

class AgEEulerDirectionSequence(IntEnum):
    """Euler direction sequences."""
   
    e12 = 0
    """12 sequence."""
    e21 = 1
    """21 sequence."""
    e31 = 2
    """31 sequence."""
    e32 = 3
    """32 sequence."""

AgEEulerDirectionSequence.e12.__doc__ = "12 sequence."
AgEEulerDirectionSequence.e21.__doc__ = "21 sequence."
AgEEulerDirectionSequence.e31.__doc__ = "31 sequence."
AgEEulerDirectionSequence.e32.__doc__ = "32 sequence."

agcls.AgTypeNameMap["AgEEulerDirectionSequence"] = AgEEulerDirectionSequence

class AgEDirectionType(IntEnum):
    """Direction options for aligned and constrained vectors."""
   
    eDirEuler = 0
    """Euler B and C angles."""
    eDirPR = 1
    """Pitch and Roll angles."""
    eDirRADec = 2
    """Spherical elements: Right Ascension and Declination."""
    eDirXYZ = 3
    """Cartesian elements."""

AgEDirectionType.eDirEuler.__doc__ = "Euler B and C angles."
AgEDirectionType.eDirPR.__doc__ = "Pitch and Roll angles."
AgEDirectionType.eDirRADec.__doc__ = "Spherical elements: Right Ascension and Declination."
AgEDirectionType.eDirXYZ.__doc__ = "Cartesian elements."

agcls.AgTypeNameMap["AgEDirectionType"] = AgEDirectionType

class AgEPRSequence(IntEnum):
    """Pitch-Roll (PR) direction sequences."""
   
    ePR = 0
    """PR sequence."""

AgEPRSequence.ePR.__doc__ = "PR sequence."

agcls.AgTypeNameMap["AgEPRSequence"] = AgEPRSequence

class AgEOrientationType(IntEnum):
    """Orientation methods."""
   
    eAzEl = 0
    """AzEl (azimuth-elevation) method."""
    eEulerAngles = 1
    """Euler angles method."""
    eQuaternion = 2
    """Quaternion method."""
    eYPRAngles = 3
    """YPR (yaw-pitch-roll) method."""

AgEOrientationType.eAzEl.__doc__ = "AzEl (azimuth-elevation) method."
AgEOrientationType.eEulerAngles.__doc__ = "Euler angles method."
AgEOrientationType.eQuaternion.__doc__ = "Quaternion method."
AgEOrientationType.eYPRAngles.__doc__ = "YPR (yaw-pitch-roll) method."

agcls.AgTypeNameMap["AgEOrientationType"] = AgEOrientationType

class AgEAzElAboutBoresight(IntEnum):
    """About Boresight options for AzEl orientation method."""
   
    eAzElAboutBoresightHold = 0
    """Hold: rotation about the Y axis followed by rotation about the new X-axis."""
    eAzElAboutBoresightRotate = 1
    """Rotate: rotation about the sensor's or antenna's Z axis by the azimuth angle, followed by rotation about the new Y axis by 90 degrees minus the elevation angle."""

AgEAzElAboutBoresight.eAzElAboutBoresightHold.__doc__ = "Hold: rotation about the Y axis followed by rotation about the new X-axis."
AgEAzElAboutBoresight.eAzElAboutBoresightRotate.__doc__ = "Rotate: rotation about the sensor's or antenna's Z axis by the azimuth angle, followed by rotation about the new Y axis by 90 degrees minus the elevation angle."

agcls.AgTypeNameMap["AgEAzElAboutBoresight"] = AgEAzElAboutBoresight

class AgEEulerOrientationSequence(IntEnum):
    """Euler rotation sequence options:."""
   
    e121 = 0
    """121 rotation."""
    e123 = 1
    """123 rotation."""
    e131 = 2
    """131 rotation."""
    e132 = 3
    """132 rotation."""
    e212 = 4
    """212 rotation."""
    e213 = 5
    """213 rotation."""
    e231 = 6
    """231 rotation."""
    e232 = 7
    """232 rotation."""
    e312 = 8
    """312 rotation."""
    e313 = 9
    """313 rotation."""
    e321 = 10
    """321 rotation."""
    e323 = 11
    """323 rotation."""

AgEEulerOrientationSequence.e121.__doc__ = "121 rotation."
AgEEulerOrientationSequence.e123.__doc__ = "123 rotation."
AgEEulerOrientationSequence.e131.__doc__ = "131 rotation."
AgEEulerOrientationSequence.e132.__doc__ = "132 rotation."
AgEEulerOrientationSequence.e212.__doc__ = "212 rotation."
AgEEulerOrientationSequence.e213.__doc__ = "213 rotation."
AgEEulerOrientationSequence.e231.__doc__ = "231 rotation."
AgEEulerOrientationSequence.e232.__doc__ = "232 rotation."
AgEEulerOrientationSequence.e312.__doc__ = "312 rotation."
AgEEulerOrientationSequence.e313.__doc__ = "313 rotation."
AgEEulerOrientationSequence.e321.__doc__ = "321 rotation."
AgEEulerOrientationSequence.e323.__doc__ = "323 rotation."

agcls.AgTypeNameMap["AgEEulerOrientationSequence"] = AgEEulerOrientationSequence

class AgEYPRAnglesSequence(IntEnum):
    """Yaw-Pitch-Roll (YPR) sequences."""
   
    ePRY = 0
    """PRY sequence."""
    ePYR = 1
    """PYR sequence."""
    eRPY = 2
    """RPY sequence."""
    eRYP = 3
    """RYP sequence."""
    eYPR = 4
    """YPR sequence."""
    eYRP = 5
    """YRP sequence."""

AgEYPRAnglesSequence.ePRY.__doc__ = "PRY sequence."
AgEYPRAnglesSequence.ePYR.__doc__ = "PYR sequence."
AgEYPRAnglesSequence.eRPY.__doc__ = "RPY sequence."
AgEYPRAnglesSequence.eRYP.__doc__ = "RYP sequence."
AgEYPRAnglesSequence.eYPR.__doc__ = "YPR sequence."
AgEYPRAnglesSequence.eYRP.__doc__ = "YRP sequence."

agcls.AgTypeNameMap["AgEYPRAnglesSequence"] = AgEYPRAnglesSequence

class AgEOrbitStateType(IntEnum):
    """Coordinate types used in specifying orbit state."""
   
    eOrbitStateCartesian = 0
    """Cartesian coordinate type."""
    eOrbitStateClassical = 1
    """Classical (Keplerian) coordinate type."""
    eOrbitStateEquinoctial = 2
    """Equinoctial coordinate type."""
    eOrbitStateDelaunay = 3
    """Delaunay variables coordinate type."""
    eOrbitStateSpherical = 4
    """Spherical coordinate type."""
    eOrbitStateMixedSpherical = 5
    """Mixed spherical coordinate type."""
    eOrbitStateGeodetic = 6
    """Geodetic coordinate type."""

AgEOrbitStateType.eOrbitStateCartesian.__doc__ = "Cartesian coordinate type."
AgEOrbitStateType.eOrbitStateClassical.__doc__ = "Classical (Keplerian) coordinate type."
AgEOrbitStateType.eOrbitStateEquinoctial.__doc__ = "Equinoctial coordinate type."
AgEOrbitStateType.eOrbitStateDelaunay.__doc__ = "Delaunay variables coordinate type."
AgEOrbitStateType.eOrbitStateSpherical.__doc__ = "Spherical coordinate type."
AgEOrbitStateType.eOrbitStateMixedSpherical.__doc__ = "Mixed spherical coordinate type."
AgEOrbitStateType.eOrbitStateGeodetic.__doc__ = "Geodetic coordinate type."

agcls.AgTypeNameMap["AgEOrbitStateType"] = AgEOrbitStateType

class AgECoordinateSystem(IntEnum):
    """Earth-centered coordinate systems for defining certain propagators."""
   
    eCoordinateSystemUnknown = -1
    """Represents coordinate system not supported by the Object Model."""
    eCoordinateSystemAlignmentAtEpoch = 0
    """Alignment at Epoch: an inertial system coincident with ECF at the Coord Epoch. Often used to specify launch trajectories."""
    eCoordinateSystemB1950 = 1
    """B1950: X points toward the mean vernal equinox and Z points along the mean rotation axis of the Earth at the beginning of the Besselian year 1950 and corresponds to 31 December 1949 22:09:07.2 or JD 2433282.423."""
    eCoordinateSystemFixed = 2
    """Fixed: X is fixed at 0 deg longitude, Y is fixed at 90 deg longitude, and Z is directed toward the north pole."""
    eCoordinateSystemJ2000 = 3
    """J2000: X points toward the mean vernal equinox and Z points along the mean rotation axis of the Earth on 1 Jan 2000 at 12:00:00.00 TDB, which corresponds to JD 2451545.0 TDB."""
    eCoordinateSystemMeanOfDate = 4
    """Mean of Date: X points toward the mean vernal equinox and Z points along the mean rotation axis of the Earth at the Orbit Epoch."""
    eCoordinateSystemMeanOfEpoch = 5
    """Mean of Epoch: X points toward the mean vernal equinox and Z points along the mean rotation axis of the Earth at the Coord Epoch."""
    eCoordinateSystemTEMEOfDate = 6
    """TEME of Date: X points toward the mean vernal equinox and Z points along the true rotation axis of the Earth at the Orbit Epoch."""
    eCoordinateSystemTEMEOfEpoch = 7
    """TEME of Epoch: X points toward the mean vernal equinox and Z points along the true rotation axis of the Earth at the Coord Epoch."""
    eCoordinateSystemTrueOfDate = 8
    """True of Date: X points toward the true vernal equinox and Z points along the true rotation axis of the Earth at the Orbit Epoch."""
    eCoordinateSystemTrueOfEpoch = 9
    """True of Epoch: X points toward the true vernal equinox and Z points along the true rotation axis of the Earth at the Coord Epoch."""
    eCoordinateSystemTrueOfRefDate = 10
    """True of Ref Date: A special case of True of Epoch. Instead of the Coord Epoch, this system uses a Reference Date defined in the Integration Control page of the scenario's PODS properties."""
    eCoordinateSystemICRF = 11
    """ICRF: International Celestial Reference Frame."""
    eCoordinateSystemMeanEarth = 13
    """Mean Earth."""
    eCoordinateSystemFixedNoLibration = 14
    """uses an analytic formula not modeling lunar libration."""
    eCoordinateSystemFixedIAU2003 = 15
    """Fixed_IAU2003."""
    eCoordinateSystemPrincipalAxes421 = 16
    """PrincipalAxes_421."""
    eCoordinateSystemPrincipalAxes403 = 17
    """PrincipalAxes_403."""
    eCoordinateSystemInertial = 18
    """Inertial."""
    eCoordinateSystemJ2000Ecliptic = 19
    """The mean ecliptic system evaluated at the J2000 epoch. The mean ecliptic plane is defined as the rotation of the J2000 XY plane about the J2000 X axis by the mean obliquity defined using FK5 IAU76 theory."""
    eCoordinateSystemTrueEclipticOfDate = 21
    """The true ecliptic system, evaluated at each given time. The true ecliptic plane is defined as the rotation of the J2000 XY plane about the J2000 X axis by the true obliquity defined using FK5 IAU76 theory."""
    eCoordinateSystemPrincipalAxes430 = 22
    """PrincipalAxes_430."""
    eCoordinateSystemTrueOfDateRotating = 23
    """TrueOfDateRotating: Like the Fixed system, but ignores pole wander. The XY plane is the same as the XY plane of the TrueOfDate system, and the system rotates about the TrueOfDate Z-axis."""
    eCoordinateSystemEclipticJ2000ICRF = 24
    """EclipticJ2000ICRF: An ecliptic system that is a fixed offset of the ICRF system, found by rotating the ICRF system about its X-axis by the mean obliquity at the J2000 epoch (i.e., 84381.448 arcSecs). The ecliptic plane is the XY-plane of this system."""

AgECoordinateSystem.eCoordinateSystemUnknown.__doc__ = "Represents coordinate system not supported by the Object Model."
AgECoordinateSystem.eCoordinateSystemAlignmentAtEpoch.__doc__ = "Alignment at Epoch: an inertial system coincident with ECF at the Coord Epoch. Often used to specify launch trajectories."
AgECoordinateSystem.eCoordinateSystemB1950.__doc__ = "B1950: X points toward the mean vernal equinox and Z points along the mean rotation axis of the Earth at the beginning of the Besselian year 1950 and corresponds to 31 December 1949 22:09:07.2 or JD 2433282.423."
AgECoordinateSystem.eCoordinateSystemFixed.__doc__ = "Fixed: X is fixed at 0 deg longitude, Y is fixed at 90 deg longitude, and Z is directed toward the north pole."
AgECoordinateSystem.eCoordinateSystemJ2000.__doc__ = "J2000: X points toward the mean vernal equinox and Z points along the mean rotation axis of the Earth on 1 Jan 2000 at 12:00:00.00 TDB, which corresponds to JD 2451545.0 TDB."
AgECoordinateSystem.eCoordinateSystemMeanOfDate.__doc__ = "Mean of Date: X points toward the mean vernal equinox and Z points along the mean rotation axis of the Earth at the Orbit Epoch."
AgECoordinateSystem.eCoordinateSystemMeanOfEpoch.__doc__ = "Mean of Epoch: X points toward the mean vernal equinox and Z points along the mean rotation axis of the Earth at the Coord Epoch."
AgECoordinateSystem.eCoordinateSystemTEMEOfDate.__doc__ = "TEME of Date: X points toward the mean vernal equinox and Z points along the true rotation axis of the Earth at the Orbit Epoch."
AgECoordinateSystem.eCoordinateSystemTEMEOfEpoch.__doc__ = "TEME of Epoch: X points toward the mean vernal equinox and Z points along the true rotation axis of the Earth at the Coord Epoch."
AgECoordinateSystem.eCoordinateSystemTrueOfDate.__doc__ = "True of Date: X points toward the true vernal equinox and Z points along the true rotation axis of the Earth at the Orbit Epoch."
AgECoordinateSystem.eCoordinateSystemTrueOfEpoch.__doc__ = "True of Epoch: X points toward the true vernal equinox and Z points along the true rotation axis of the Earth at the Coord Epoch."
AgECoordinateSystem.eCoordinateSystemTrueOfRefDate.__doc__ = "True of Ref Date: A special case of True of Epoch. Instead of the Coord Epoch, this system uses a Reference Date defined in the Integration Control page of the scenario's PODS properties."
AgECoordinateSystem.eCoordinateSystemICRF.__doc__ = "ICRF: International Celestial Reference Frame."
AgECoordinateSystem.eCoordinateSystemMeanEarth.__doc__ = "Mean Earth."
AgECoordinateSystem.eCoordinateSystemFixedNoLibration.__doc__ = "uses an analytic formula not modeling lunar libration."
AgECoordinateSystem.eCoordinateSystemFixedIAU2003.__doc__ = "Fixed_IAU2003."
AgECoordinateSystem.eCoordinateSystemPrincipalAxes421.__doc__ = "PrincipalAxes_421."
AgECoordinateSystem.eCoordinateSystemPrincipalAxes403.__doc__ = "PrincipalAxes_403."
AgECoordinateSystem.eCoordinateSystemInertial.__doc__ = "Inertial."
AgECoordinateSystem.eCoordinateSystemJ2000Ecliptic.__doc__ = "The mean ecliptic system evaluated at the J2000 epoch. The mean ecliptic plane is defined as the rotation of the J2000 XY plane about the J2000 X axis by the mean obliquity defined using FK5 IAU76 theory."
AgECoordinateSystem.eCoordinateSystemTrueEclipticOfDate.__doc__ = "The true ecliptic system, evaluated at each given time. The true ecliptic plane is defined as the rotation of the J2000 XY plane about the J2000 X axis by the true obliquity defined using FK5 IAU76 theory."
AgECoordinateSystem.eCoordinateSystemPrincipalAxes430.__doc__ = "PrincipalAxes_430."
AgECoordinateSystem.eCoordinateSystemTrueOfDateRotating.__doc__ = "TrueOfDateRotating: Like the Fixed system, but ignores pole wander. The XY plane is the same as the XY plane of the TrueOfDate system, and the system rotates about the TrueOfDate Z-axis."
AgECoordinateSystem.eCoordinateSystemEclipticJ2000ICRF.__doc__ = "EclipticJ2000ICRF: An ecliptic system that is a fixed offset of the ICRF system, found by rotating the ICRF system about its X-axis by the mean obliquity at the J2000 epoch (i.e., 84381.448 arcSecs). The ecliptic plane is the XY-plane of this system."

agcls.AgTypeNameMap["AgECoordinateSystem"] = AgECoordinateSystem

class AgELogMsgType(IntEnum):
    """Log message types."""
   
    eLogMsgDebug = 0
    """Debugging message."""
    eLogMsgInfo = 1
    """Informational message."""
    eLogMsgForceInfo = 2
    """Informational message."""
    eLogMsgWarning = 3
    """Warning message."""
    eLogMsgAlarm = 4
    """Alarm message."""

AgELogMsgType.eLogMsgDebug.__doc__ = "Debugging message."
AgELogMsgType.eLogMsgInfo.__doc__ = "Informational message."
AgELogMsgType.eLogMsgForceInfo.__doc__ = "Informational message."
AgELogMsgType.eLogMsgWarning.__doc__ = "Warning message."
AgELogMsgType.eLogMsgAlarm.__doc__ = "Alarm message."

agcls.AgTypeNameMap["AgELogMsgType"] = AgELogMsgType

class AgELogMsgDispID(IntEnum):
    """Log message destination options."""
   
    eLogMsgDispAll = -1
    """STK displays the message in all the log destination."""
    eLogMsgDispDefault = 0
    """STK displays the message in the default log destination."""
    eLogMsgDispMsgWin = 1
    """STK displays the message in the message window."""
    eLogMsgDispStatusBar = 2
    """STK displays the message in the status bar."""

AgELogMsgDispID.eLogMsgDispAll.__doc__ = "STK displays the message in all the log destination."
AgELogMsgDispID.eLogMsgDispDefault.__doc__ = "STK displays the message in the default log destination."
AgELogMsgDispID.eLogMsgDispMsgWin.__doc__ = "STK displays the message in the message window."
AgELogMsgDispID.eLogMsgDispStatusBar.__doc__ = "STK displays the message in the status bar."

agcls.AgTypeNameMap["AgELogMsgDispID"] = AgELogMsgDispID

class AgELineStyle(IntEnum):
    """Line Style."""
   
    eSolid = 0
    """Specifies a solid line."""
    eDashed = 1
    """Specifies a dashed line."""
    eDotted = 2
    """Specifies a dotted line."""
    eDotDashed = 3
    """Dot-dashed line."""
    eLongDashed = 4
    """Specifies a long dashed line."""
    eDashDotDotted = 5
    """Specifies an alternating dash-dot-dot line."""
    eMDash = 6
    """Specifies a user configurable medium dashed line."""
    eLDash = 7
    """Specifies a user configurable long dashed line."""
    eSDashDot = 8
    """Specifies a user configurable small dash-dotted line."""
    eMDashDot = 9
    """Specifies a user configurable medium dash-dotted line."""
    eLDashDot = 10
    """Specifies a user configurable long dash-dotted line."""
    eMSDash = 11
    """Specifies a user configurable medium followed by small dashed line."""
    eLSDash = 12
    """Specifies a user configurable long followed by small dashed line."""
    eLMDash = 13
    """Specifies a user configurable long followed by medium dashed line."""
    eLMSDash = 14
    """Specifies a user configurable medium followed by small dashed line."""
    eDot = 15
    """Specifies a dotted line."""
    eLongDash = 16
    """Specifies a long dashed line."""
    eSDash = 17
    """Specifies an alternating dash-dot line."""

AgELineStyle.eSolid.__doc__ = "Specifies a solid line."
AgELineStyle.eDashed.__doc__ = "Specifies a dashed line."
AgELineStyle.eDotted.__doc__ = "Specifies a dotted line."
AgELineStyle.eDotDashed.__doc__ = "Dot-dashed line."
AgELineStyle.eLongDashed.__doc__ = "Specifies a long dashed line."
AgELineStyle.eDashDotDotted.__doc__ = "Specifies an alternating dash-dot-dot line."
AgELineStyle.eMDash.__doc__ = "Specifies a user configurable medium dashed line."
AgELineStyle.eLDash.__doc__ = "Specifies a user configurable long dashed line."
AgELineStyle.eSDashDot.__doc__ = "Specifies a user configurable small dash-dotted line."
AgELineStyle.eMDashDot.__doc__ = "Specifies a user configurable medium dash-dotted line."
AgELineStyle.eLDashDot.__doc__ = "Specifies a user configurable long dash-dotted line."
AgELineStyle.eMSDash.__doc__ = "Specifies a user configurable medium followed by small dashed line."
AgELineStyle.eLSDash.__doc__ = "Specifies a user configurable long followed by small dashed line."
AgELineStyle.eLMDash.__doc__ = "Specifies a user configurable long followed by medium dashed line."
AgELineStyle.eLMSDash.__doc__ = "Specifies a user configurable medium followed by small dashed line."
AgELineStyle.eDot.__doc__ = "Specifies a dotted line."
AgELineStyle.eLongDash.__doc__ = "Specifies a long dashed line."
AgELineStyle.eSDash.__doc__ = "Specifies an alternating dash-dot line."

agcls.AgTypeNameMap["AgELineStyle"] = AgELineStyle

class AgEExecMultiCmdResultAction(IntFlag):
    """Enumeration defines a set of actions when an error occurs while executing a command batch."""
   
    eContinueOnError = 0
    """Continue executing the remaining commands in the command batch."""
    eStopOnError = 1
    """Terminate the execution of the command batch but do not throw an exception."""
    eExceptionOnError = 2
    """Terminate the execution of the command batch and throw an exception."""
    eIgnoreExecCmdResult = 0x8000
    """Ignore results returned by individual commands. The option must be used in combination with other flags."""

AgEExecMultiCmdResultAction.eContinueOnError.__doc__ = "Continue executing the remaining commands in the command batch."
AgEExecMultiCmdResultAction.eStopOnError.__doc__ = "Terminate the execution of the command batch but do not throw an exception."
AgEExecMultiCmdResultAction.eExceptionOnError.__doc__ = "Terminate the execution of the command batch and throw an exception."
AgEExecMultiCmdResultAction.eIgnoreExecCmdResult.__doc__ = "Ignore results returned by individual commands. The option must be used in combination with other flags."

agcls.AgTypeNameMap["AgEExecMultiCmdResultAction"] = AgEExecMultiCmdResultAction

class AgEFillStyle(IntEnum):
    """Fill Style."""
   
    eFillStyleSolid = 0
    """Specifies a solid fill style."""
    eFillStyleHorizontalStripe = 1
    """Specifies a horizontally striped fill style."""
    eFillStyleDiagonalStripe1 = 2
    """Specifies a diagonally striped fill style."""
    eFillStyleDiagonalStripe2 = 3
    """Specifies a diagonally striped fill style."""
    eFillStyleHatch = 4
    """Specifies a hatched fill style."""
    eFillStyleDiagonalHatch = 5
    """Specifies a diagonally hatched fill style."""
    eFillStyleScreen = 6
    """Specifies a special fill style where every other pixel is drawn."""
    eFillStyleVerticalStripe = 7
    """Specifies a vertically striped fill style."""

AgEFillStyle.eFillStyleSolid.__doc__ = "Specifies a solid fill style."
AgEFillStyle.eFillStyleHorizontalStripe.__doc__ = "Specifies a horizontally striped fill style."
AgEFillStyle.eFillStyleDiagonalStripe1.__doc__ = "Specifies a diagonally striped fill style."
AgEFillStyle.eFillStyleDiagonalStripe2.__doc__ = "Specifies a diagonally striped fill style."
AgEFillStyle.eFillStyleHatch.__doc__ = "Specifies a hatched fill style."
AgEFillStyle.eFillStyleDiagonalHatch.__doc__ = "Specifies a diagonally hatched fill style."
AgEFillStyle.eFillStyleScreen.__doc__ = "Specifies a special fill style where every other pixel is drawn."
AgEFillStyle.eFillStyleVerticalStripe.__doc__ = "Specifies a vertically striped fill style."

agcls.AgTypeNameMap["AgEFillStyle"] = AgEFillStyle

class AgEPropertyInfoValueType(IntEnum):
    """The enumeration used to determine what type of property is being used."""
   
    ePropertyInfoValueTypeInt = 0
    """Property is of type int."""
    ePropertyInfoValueTypeReal = 1
    """Property is of type real."""
    ePropertyInfoValueTypeQuantity = 2
    """Property is of type IAgQuantity."""
    ePropertyInfoValueTypeDate = 3
    """Property is of type IAgDate."""
    ePropertyInfoValueTypeString = 4
    """Property is of type string."""
    ePropertyInfoValueTypeBool = 5
    """Property is of type bool."""
    ePropertyInfoValueTypeInterface = 6
    """Property is an interface."""

AgEPropertyInfoValueType.ePropertyInfoValueTypeInt.__doc__ = "Property is of type int."
AgEPropertyInfoValueType.ePropertyInfoValueTypeReal.__doc__ = "Property is of type real."
AgEPropertyInfoValueType.ePropertyInfoValueTypeQuantity.__doc__ = "Property is of type IAgQuantity."
AgEPropertyInfoValueType.ePropertyInfoValueTypeDate.__doc__ = "Property is of type IAgDate."
AgEPropertyInfoValueType.ePropertyInfoValueTypeString.__doc__ = "Property is of type string."
AgEPropertyInfoValueType.ePropertyInfoValueTypeBool.__doc__ = "Property is of type bool."
AgEPropertyInfoValueType.ePropertyInfoValueTypeInterface.__doc__ = "Property is an interface."

agcls.AgTypeNameMap["AgEPropertyInfoValueType"] = AgEPropertyInfoValueType


class IAgLocationData(object):
    """Base interface IAgLocationData. IAgPosition derives from this interface."""

    _num_methods = 0
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _metadata = {
        "iid_data" : (5292229181779320538, 5946016819874812079),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgLocationData."""
        initialize_from_source_object(self, sourceObject, IAgLocationData)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgLocationData)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgLocationData, None)
    

agcls.AgClassCatalog.add_catalog_entry((5292229181779320538, 5946016819874812079), IAgLocationData)
agcls.AgTypeNameMap["IAgLocationData"] = IAgLocationData

class IAgPosition(object):
    """IAgPosition provides access to the position of the object."""

    _num_methods = 21
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _ConvertTo_method_offset = 1
    _get_PosType_method_offset = 2
    _Assign_method_offset = 3
    _AssignGeocentric_method_offset = 4
    _AssignGeodetic_method_offset = 5
    _AssignSpherical_method_offset = 6
    _AssignCylindrical_method_offset = 7
    _AssignCartesian_method_offset = 8
    _AssignPlanetocentric_method_offset = 9
    _AssignPlanetodetic_method_offset = 10
    _QueryPlanetocentric_method_offset = 11
    _QueryPlanetodetic_method_offset = 12
    _QuerySpherical_method_offset = 13
    _QueryCylindrical_method_offset = 14
    _QueryCartesian_method_offset = 15
    _get_CentralBodyName_method_offset = 16
    _QueryPlanetocentricArray_method_offset = 17
    _QueryPlanetodeticArray_method_offset = 18
    _QuerySphericalArray_method_offset = 19
    _QueryCylindricalArray_method_offset = 20
    _QueryCartesianArray_method_offset = 21
    _metadata = {
        "iid_data" : (5449387932942688462, 15999276090360342948),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgPosition."""
        initialize_from_source_object(self, sourceObject, IAgPosition)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgPosition)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgPosition, None)
    
    _ConvertTo_metadata = { "offset" : _ConvertTo_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEPositionType), agmarshall.AgInterface_out_arg,) }
    def ConvertTo(self, type:"AgEPositionType") -> "IAgPosition":
        """Changes the position coordinates to type specified."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._ConvertTo_metadata, type, OutArg())

    _get_PosType_metadata = { "offset" : _get_PosType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEPositionType),) }
    @property
    def PosType(self) -> "AgEPositionType":
        """Gets the type of position currently being used."""
        return self._intf.get_property(IAgPosition._metadata, IAgPosition._get_PosType_metadata)

    _Assign_metadata = { "offset" : _Assign_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgPosition"),) }
    def Assign(self, pPosition:"IAgPosition") -> None:
        """Assigns the coordinates into the system."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._Assign_metadata, pPosition)

    _AssignGeocentric_metadata = { "offset" : _AssignGeocentric_method_offset,
            "arg_types" : (agcom.VARIANT, agcom.VARIANT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.DOUBLE_arg,) }
    def AssignGeocentric(self, lat:typing.Any, lon:typing.Any, alt:float) -> None:
        """Assign the position using the Geocentric representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._AssignGeocentric_metadata, lat, lon, alt)

    _AssignGeodetic_metadata = { "offset" : _AssignGeodetic_method_offset,
            "arg_types" : (agcom.VARIANT, agcom.VARIANT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.DOUBLE_arg,) }
    def AssignGeodetic(self, lat:typing.Any, lon:typing.Any, alt:float) -> None:
        """Assign the position using the Geodetic representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._AssignGeodetic_metadata, lat, lon, alt)

    _AssignSpherical_metadata = { "offset" : _AssignSpherical_method_offset,
            "arg_types" : (agcom.VARIANT, agcom.VARIANT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.DOUBLE_arg,) }
    def AssignSpherical(self, lat:typing.Any, lon:typing.Any, radius:float) -> None:
        """Assign the position using the Spherical representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._AssignSpherical_metadata, lat, lon, radius)

    _AssignCylindrical_metadata = { "offset" : _AssignCylindrical_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.VARIANT,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.VARIANT_arg,) }
    def AssignCylindrical(self, radius:float, z:float, lon:typing.Any) -> None:
        """Assign the position using the Cylindrical representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._AssignCylindrical_metadata, radius, z, lon)

    _AssignCartesian_metadata = { "offset" : _AssignCartesian_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignCartesian(self, x:float, y:float, z:float) -> None:
        """Assign the position using the Cartesian representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._AssignCartesian_metadata, x, y, z)

    _AssignPlanetocentric_metadata = { "offset" : _AssignPlanetocentric_method_offset,
            "arg_types" : (agcom.VARIANT, agcom.VARIANT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.DOUBLE_arg,) }
    def AssignPlanetocentric(self, lat:typing.Any, lon:typing.Any, alt:float) -> None:
        """Assign the position using the Planetocentric representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._AssignPlanetocentric_metadata, lat, lon, alt)

    _AssignPlanetodetic_metadata = { "offset" : _AssignPlanetodetic_method_offset,
            "arg_types" : (agcom.VARIANT, agcom.VARIANT, agcom.DOUBLE,),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.DOUBLE_arg,) }
    def AssignPlanetodetic(self, lat:typing.Any, lon:typing.Any, alt:float) -> None:
        """Assign the position using the Planetodetic representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._AssignPlanetodetic_metadata, lat, lon, alt)

    _QueryPlanetocentric_metadata = { "offset" : _QueryPlanetocentric_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT), POINTER(agcom.VARIANT), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.DOUBLE_arg,) }
    def QueryPlanetocentric(self) -> typing.Tuple[typing.Any, typing.Any, float]:
        """Get the position using the Planetocentric representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QueryPlanetocentric_metadata, OutArg(), OutArg(), OutArg())

    _QueryPlanetodetic_metadata = { "offset" : _QueryPlanetodetic_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT), POINTER(agcom.VARIANT), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.DOUBLE_arg,) }
    def QueryPlanetodetic(self) -> typing.Tuple[typing.Any, typing.Any, float]:
        """Get the position using the Planetodetic representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QueryPlanetodetic_metadata, OutArg(), OutArg(), OutArg())

    _QuerySpherical_metadata = { "offset" : _QuerySpherical_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT), POINTER(agcom.VARIANT), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.DOUBLE_arg,) }
    def QuerySpherical(self) -> typing.Tuple[typing.Any, typing.Any, float]:
        """Get the position using the Spherical representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QuerySpherical_metadata, OutArg(), OutArg(), OutArg())

    _QueryCylindrical_metadata = { "offset" : _QueryCylindrical_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.VARIANT), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.VARIANT_arg, agmarshall.DOUBLE_arg,) }
    def QueryCylindrical(self) -> typing.Tuple[float, typing.Any, float]:
        """Get the position using the Cylindrical representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QueryCylindrical_metadata, OutArg(), OutArg(), OutArg())

    _QueryCartesian_metadata = { "offset" : _QueryCartesian_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def QueryCartesian(self) -> typing.Tuple[float, float, float]:
        """Get the position using the Cartesian representation."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QueryCartesian_metadata, OutArg(), OutArg(), OutArg())

    _get_CentralBodyName_metadata = { "offset" : _get_CentralBodyName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CentralBodyName(self) -> str:
        """Gets the central body."""
        return self._intf.get_property(IAgPosition._metadata, IAgPosition._get_CentralBodyName_metadata)

    _QueryPlanetocentricArray_metadata = { "offset" : _QueryPlanetocentricArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def QueryPlanetocentricArray(self) -> list:
        """Returns the Planetocentric elements as an array."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QueryPlanetocentricArray_metadata, OutArg())

    _QueryPlanetodeticArray_metadata = { "offset" : _QueryPlanetodeticArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def QueryPlanetodeticArray(self) -> list:
        """Returns the Planetodetic elements as an array."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QueryPlanetodeticArray_metadata, OutArg())

    _QuerySphericalArray_metadata = { "offset" : _QuerySphericalArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def QuerySphericalArray(self) -> list:
        """Returns the Spherical elements as an array."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QuerySphericalArray_metadata, OutArg())

    _QueryCylindricalArray_metadata = { "offset" : _QueryCylindricalArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def QueryCylindricalArray(self) -> list:
        """Returns the Cylindrical elements as an array."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QueryCylindricalArray_metadata, OutArg())

    _QueryCartesianArray_metadata = { "offset" : _QueryCartesianArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def QueryCartesianArray(self) -> list:
        """Returns the Cartesian elements as an array."""
        return self._intf.invoke(IAgPosition._metadata, IAgPosition._QueryCartesianArray_metadata, OutArg())

    _property_names[PosType] = "PosType"
    _property_names[CentralBodyName] = "CentralBodyName"


agcls.AgClassCatalog.add_catalog_entry((5449387932942688462, 15999276090360342948), IAgPosition)
agcls.AgTypeNameMap["IAgPosition"] = IAgPosition

class IAgPlanetocentric(IAgPosition):
    """Planetocentric Position Type."""

    _num_methods = 6
    _vtable_offset = IAgPosition._vtable_offset + IAgPosition._num_methods
    _get_Lat_method_offset = 1
    _set_Lat_method_offset = 2
    _get_Lon_method_offset = 3
    _set_Lon_method_offset = 4
    _get_Alt_method_offset = 5
    _set_Alt_method_offset = 6
    _metadata = {
        "iid_data" : (5442694245436645843, 11671904789978155692),
        "vtable_reference" : IAgPosition._vtable_offset + IAgPosition._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgPlanetocentric."""
        initialize_from_source_object(self, sourceObject, IAgPlanetocentric)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgPlanetocentric)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgPlanetocentric, IAgPosition)
    
    _get_Lat_metadata = { "offset" : _get_Lat_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lat(self) -> typing.Any:
        """Uses Latitude Dimension."""
        return self._intf.get_property(IAgPlanetocentric._metadata, IAgPlanetocentric._get_Lat_metadata)

    _set_Lat_metadata = { "offset" : _set_Lat_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lat.setter
    def Lat(self, pVal:typing.Any) -> None:
        return self._intf.set_property(IAgPlanetocentric._metadata, IAgPlanetocentric._set_Lat_metadata, pVal)

    _get_Lon_metadata = { "offset" : _get_Lon_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lon(self) -> typing.Any:
        """Uses Longitude Dimension."""
        return self._intf.get_property(IAgPlanetocentric._metadata, IAgPlanetocentric._get_Lon_metadata)

    _set_Lon_metadata = { "offset" : _set_Lon_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lon.setter
    def Lon(self, pVal:typing.Any) -> None:
        return self._intf.set_property(IAgPlanetocentric._metadata, IAgPlanetocentric._set_Lon_metadata, pVal)

    _get_Alt_metadata = { "offset" : _get_Alt_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Alt(self) -> float:
        """Dimension depends on context."""
        return self._intf.get_property(IAgPlanetocentric._metadata, IAgPlanetocentric._get_Alt_metadata)

    _set_Alt_metadata = { "offset" : _set_Alt_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Alt.setter
    def Alt(self, pVal:float) -> None:
        return self._intf.set_property(IAgPlanetocentric._metadata, IAgPlanetocentric._set_Alt_metadata, pVal)

    _property_names[Lat] = "Lat"
    _property_names[Lon] = "Lon"
    _property_names[Alt] = "Alt"


agcls.AgClassCatalog.add_catalog_entry((5442694245436645843, 11671904789978155692), IAgPlanetocentric)
agcls.AgTypeNameMap["IAgPlanetocentric"] = IAgPlanetocentric

class IAgGeocentric(IAgPosition):
    """Geocentric Position Type."""

    _num_methods = 6
    _vtable_offset = IAgPosition._vtable_offset + IAgPosition._num_methods
    _get_Lat_method_offset = 1
    _set_Lat_method_offset = 2
    _get_Lon_method_offset = 3
    _set_Lon_method_offset = 4
    _get_Alt_method_offset = 5
    _set_Alt_method_offset = 6
    _metadata = {
        "iid_data" : (4985064436854354632, 18010173850499286698),
        "vtable_reference" : IAgPosition._vtable_offset + IAgPosition._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgGeocentric."""
        initialize_from_source_object(self, sourceObject, IAgGeocentric)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgGeocentric)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgGeocentric, IAgPosition)
    
    _get_Lat_metadata = { "offset" : _get_Lat_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lat(self) -> typing.Any:
        """Uses Latitude Dimension."""
        return self._intf.get_property(IAgGeocentric._metadata, IAgGeocentric._get_Lat_metadata)

    _set_Lat_metadata = { "offset" : _set_Lat_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lat.setter
    def Lat(self, pVal:typing.Any) -> None:
        return self._intf.set_property(IAgGeocentric._metadata, IAgGeocentric._set_Lat_metadata, pVal)

    _get_Lon_metadata = { "offset" : _get_Lon_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lon(self) -> typing.Any:
        """Uses Longitude Dimension."""
        return self._intf.get_property(IAgGeocentric._metadata, IAgGeocentric._get_Lon_metadata)

    _set_Lon_metadata = { "offset" : _set_Lon_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lon.setter
    def Lon(self, pVal:typing.Any) -> None:
        return self._intf.set_property(IAgGeocentric._metadata, IAgGeocentric._set_Lon_metadata, pVal)

    _get_Alt_metadata = { "offset" : _get_Alt_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Alt(self) -> float:
        """Dimension depends on context."""
        return self._intf.get_property(IAgGeocentric._metadata, IAgGeocentric._get_Alt_metadata)

    _set_Alt_metadata = { "offset" : _set_Alt_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Alt.setter
    def Alt(self, pVal:float) -> None:
        return self._intf.set_property(IAgGeocentric._metadata, IAgGeocentric._set_Alt_metadata, pVal)

    _property_names[Lat] = "Lat"
    _property_names[Lon] = "Lon"
    _property_names[Alt] = "Alt"


agcls.AgClassCatalog.add_catalog_entry((4985064436854354632, 18010173850499286698), IAgGeocentric)
agcls.AgTypeNameMap["IAgGeocentric"] = IAgGeocentric

class IAgSpherical(IAgPosition):
    """Spherical Position Type."""

    _num_methods = 6
    _vtable_offset = IAgPosition._vtable_offset + IAgPosition._num_methods
    _get_Lat_method_offset = 1
    _set_Lat_method_offset = 2
    _get_Lon_method_offset = 3
    _set_Lon_method_offset = 4
    _get_Radius_method_offset = 5
    _set_Radius_method_offset = 6
    _metadata = {
        "iid_data" : (4855942618388446705, 316067453481966004),
        "vtable_reference" : IAgPosition._vtable_offset + IAgPosition._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgSpherical."""
        initialize_from_source_object(self, sourceObject, IAgSpherical)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgSpherical)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgSpherical, IAgPosition)
    
    _get_Lat_metadata = { "offset" : _get_Lat_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lat(self) -> typing.Any:
        """Uses Latitude Dimension."""
        return self._intf.get_property(IAgSpherical._metadata, IAgSpherical._get_Lat_metadata)

    _set_Lat_metadata = { "offset" : _set_Lat_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lat.setter
    def Lat(self, pVal:typing.Any) -> None:
        return self._intf.set_property(IAgSpherical._metadata, IAgSpherical._set_Lat_metadata, pVal)

    _get_Lon_metadata = { "offset" : _get_Lon_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lon(self) -> typing.Any:
        """Uses Longitude Dimension."""
        return self._intf.get_property(IAgSpherical._metadata, IAgSpherical._get_Lon_metadata)

    _set_Lon_metadata = { "offset" : _set_Lon_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lon.setter
    def Lon(self, pVal:typing.Any) -> None:
        return self._intf.set_property(IAgSpherical._metadata, IAgSpherical._set_Lon_metadata, pVal)

    _get_Radius_metadata = { "offset" : _get_Radius_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Radius(self) -> float:
        """Dimension depends on context."""
        return self._intf.get_property(IAgSpherical._metadata, IAgSpherical._get_Radius_metadata)

    _set_Radius_metadata = { "offset" : _set_Radius_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Radius.setter
    def Radius(self, pVal:float) -> None:
        return self._intf.set_property(IAgSpherical._metadata, IAgSpherical._set_Radius_metadata, pVal)

    _property_names[Lat] = "Lat"
    _property_names[Lon] = "Lon"
    _property_names[Radius] = "Radius"


agcls.AgClassCatalog.add_catalog_entry((4855942618388446705, 316067453481966004), IAgSpherical)
agcls.AgTypeNameMap["IAgSpherical"] = IAgSpherical

class IAgCylindrical(IAgPosition):
    """Cylindrical Position Type."""

    _num_methods = 6
    _vtable_offset = IAgPosition._vtable_offset + IAgPosition._num_methods
    _get_Radius_method_offset = 1
    _set_Radius_method_offset = 2
    _get_Z_method_offset = 3
    _set_Z_method_offset = 4
    _get_Lon_method_offset = 5
    _set_Lon_method_offset = 6
    _metadata = {
        "iid_data" : (4746503479402464409, 7300718477734136235),
        "vtable_reference" : IAgPosition._vtable_offset + IAgPosition._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCylindrical."""
        initialize_from_source_object(self, sourceObject, IAgCylindrical)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCylindrical)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCylindrical, IAgPosition)
    
    _get_Radius_metadata = { "offset" : _get_Radius_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Radius(self) -> float:
        """Dimension depends on context."""
        return self._intf.get_property(IAgCylindrical._metadata, IAgCylindrical._get_Radius_metadata)

    _set_Radius_metadata = { "offset" : _set_Radius_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Radius.setter
    def Radius(self, pVal:float) -> None:
        return self._intf.set_property(IAgCylindrical._metadata, IAgCylindrical._set_Radius_metadata, pVal)

    _get_Z_metadata = { "offset" : _get_Z_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Z(self) -> float:
        """Uses Angle Dimension."""
        return self._intf.get_property(IAgCylindrical._metadata, IAgCylindrical._get_Z_metadata)

    _set_Z_metadata = { "offset" : _set_Z_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Z.setter
    def Z(self, pVal:float) -> None:
        return self._intf.set_property(IAgCylindrical._metadata, IAgCylindrical._set_Z_metadata, pVal)

    _get_Lon_metadata = { "offset" : _get_Lon_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lon(self) -> typing.Any:
        """Dimension depends on context."""
        return self._intf.get_property(IAgCylindrical._metadata, IAgCylindrical._get_Lon_metadata)

    _set_Lon_metadata = { "offset" : _set_Lon_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lon.setter
    def Lon(self, pVal:typing.Any) -> None:
        return self._intf.set_property(IAgCylindrical._metadata, IAgCylindrical._set_Lon_metadata, pVal)

    _property_names[Radius] = "Radius"
    _property_names[Z] = "Z"
    _property_names[Lon] = "Lon"


agcls.AgClassCatalog.add_catalog_entry((4746503479402464409, 7300718477734136235), IAgCylindrical)
agcls.AgTypeNameMap["IAgCylindrical"] = IAgCylindrical

class IAgCartesian(IAgPosition):
    """IAgCartesian Interface used to access a position using Cartesian Coordinates."""

    _num_methods = 6
    _vtable_offset = IAgPosition._vtable_offset + IAgPosition._num_methods
    _get_X_method_offset = 1
    _set_X_method_offset = 2
    _get_Y_method_offset = 3
    _set_Y_method_offset = 4
    _get_Z_method_offset = 5
    _set_Z_method_offset = 6
    _metadata = {
        "iid_data" : (5065991857659686292, 12086713184993056139),
        "vtable_reference" : IAgPosition._vtable_offset + IAgPosition._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCartesian."""
        initialize_from_source_object(self, sourceObject, IAgCartesian)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCartesian)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCartesian, IAgPosition)
    
    _get_X_metadata = { "offset" : _get_X_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def X(self) -> float:
        """Dimension depends on context."""
        return self._intf.get_property(IAgCartesian._metadata, IAgCartesian._get_X_metadata)

    _set_X_metadata = { "offset" : _set_X_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @X.setter
    def X(self, pVal:float) -> None:
        return self._intf.set_property(IAgCartesian._metadata, IAgCartesian._set_X_metadata, pVal)

    _get_Y_metadata = { "offset" : _get_Y_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Y(self) -> float:
        """Dimension depends on context."""
        return self._intf.get_property(IAgCartesian._metadata, IAgCartesian._get_Y_metadata)

    _set_Y_metadata = { "offset" : _set_Y_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Y.setter
    def Y(self, pVal:float) -> None:
        return self._intf.set_property(IAgCartesian._metadata, IAgCartesian._set_Y_metadata, pVal)

    _get_Z_metadata = { "offset" : _get_Z_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Z(self) -> float:
        """Dimension depends on context."""
        return self._intf.get_property(IAgCartesian._metadata, IAgCartesian._get_Z_metadata)

    _set_Z_metadata = { "offset" : _set_Z_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Z.setter
    def Z(self, pVal:float) -> None:
        return self._intf.set_property(IAgCartesian._metadata, IAgCartesian._set_Z_metadata, pVal)

    _property_names[X] = "X"
    _property_names[Y] = "Y"
    _property_names[Z] = "Z"


agcls.AgClassCatalog.add_catalog_entry((5065991857659686292, 12086713184993056139), IAgCartesian)
agcls.AgTypeNameMap["IAgCartesian"] = IAgCartesian

class IAgGeodetic(IAgPosition):
    """IAgGeodetic sets the position using Geodetic properties."""

    _num_methods = 6
    _vtable_offset = IAgPosition._vtable_offset + IAgPosition._num_methods
    _get_Lat_method_offset = 1
    _set_Lat_method_offset = 2
    _get_Lon_method_offset = 3
    _set_Lon_method_offset = 4
    _get_Alt_method_offset = 5
    _set_Alt_method_offset = 6
    _metadata = {
        "iid_data" : (5247476704113537579, 10282454301074575279),
        "vtable_reference" : IAgPosition._vtable_offset + IAgPosition._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgGeodetic."""
        initialize_from_source_object(self, sourceObject, IAgGeodetic)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgGeodetic)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgGeodetic, IAgPosition)
    
    _get_Lat_metadata = { "offset" : _get_Lat_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lat(self) -> typing.Any:
        """Latitude. Uses Latitude Dimension."""
        return self._intf.get_property(IAgGeodetic._metadata, IAgGeodetic._get_Lat_metadata)

    _set_Lat_metadata = { "offset" : _set_Lat_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lat.setter
    def Lat(self, pLat:typing.Any) -> None:
        return self._intf.set_property(IAgGeodetic._metadata, IAgGeodetic._set_Lat_metadata, pLat)

    _get_Lon_metadata = { "offset" : _get_Lon_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lon(self) -> typing.Any:
        """Longitude. Uses Longitude Dimension."""
        return self._intf.get_property(IAgGeodetic._metadata, IAgGeodetic._get_Lon_metadata)

    _set_Lon_metadata = { "offset" : _set_Lon_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lon.setter
    def Lon(self, pLon:typing.Any) -> None:
        return self._intf.set_property(IAgGeodetic._metadata, IAgGeodetic._set_Lon_metadata, pLon)

    _get_Alt_metadata = { "offset" : _get_Alt_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Alt(self) -> float:
        """Altitude. Dimension depends on context."""
        return self._intf.get_property(IAgGeodetic._metadata, IAgGeodetic._get_Alt_metadata)

    _set_Alt_metadata = { "offset" : _set_Alt_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Alt.setter
    def Alt(self, pAlt:float) -> None:
        return self._intf.set_property(IAgGeodetic._metadata, IAgGeodetic._set_Alt_metadata, pAlt)

    _property_names[Lat] = "Lat"
    _property_names[Lon] = "Lon"
    _property_names[Alt] = "Alt"


agcls.AgClassCatalog.add_catalog_entry((5247476704113537579, 10282454301074575279), IAgGeodetic)
agcls.AgTypeNameMap["IAgGeodetic"] = IAgGeodetic

class IAgPlanetodetic(IAgPosition):
    """IAgPlanetodetic sets the position using Planetodetic properties."""

    _num_methods = 6
    _vtable_offset = IAgPosition._vtable_offset + IAgPosition._num_methods
    _get_Lat_method_offset = 1
    _set_Lat_method_offset = 2
    _get_Lon_method_offset = 3
    _set_Lon_method_offset = 4
    _get_Alt_method_offset = 5
    _set_Alt_method_offset = 6
    _metadata = {
        "iid_data" : (4681345680163832497, 5523404160351816630),
        "vtable_reference" : IAgPosition._vtable_offset + IAgPosition._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgPlanetodetic."""
        initialize_from_source_object(self, sourceObject, IAgPlanetodetic)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgPlanetodetic)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgPlanetodetic, IAgPosition)
    
    _get_Lat_metadata = { "offset" : _get_Lat_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lat(self) -> typing.Any:
        """Latitude. Uses Latitude Dimension."""
        return self._intf.get_property(IAgPlanetodetic._metadata, IAgPlanetodetic._get_Lat_metadata)

    _set_Lat_metadata = { "offset" : _set_Lat_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lat.setter
    def Lat(self, pLat:typing.Any) -> None:
        return self._intf.set_property(IAgPlanetodetic._metadata, IAgPlanetodetic._set_Lat_metadata, pLat)

    _get_Lon_metadata = { "offset" : _get_Lon_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Lon(self) -> typing.Any:
        """Longitude. Uses Longitude Dimension."""
        return self._intf.get_property(IAgPlanetodetic._metadata, IAgPlanetodetic._get_Lon_metadata)

    _set_Lon_metadata = { "offset" : _set_Lon_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Lon.setter
    def Lon(self, pLon:typing.Any) -> None:
        return self._intf.set_property(IAgPlanetodetic._metadata, IAgPlanetodetic._set_Lon_metadata, pLon)

    _get_Alt_metadata = { "offset" : _get_Alt_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Alt(self) -> float:
        """Altitude. Dimension depends on context."""
        return self._intf.get_property(IAgPlanetodetic._metadata, IAgPlanetodetic._get_Alt_metadata)

    _set_Alt_metadata = { "offset" : _set_Alt_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Alt.setter
    def Alt(self, pAlt:float) -> None:
        return self._intf.set_property(IAgPlanetodetic._metadata, IAgPlanetodetic._set_Alt_metadata, pAlt)

    _property_names[Lat] = "Lat"
    _property_names[Lon] = "Lon"
    _property_names[Alt] = "Alt"


agcls.AgClassCatalog.add_catalog_entry((4681345680163832497, 5523404160351816630), IAgPlanetodetic)
agcls.AgTypeNameMap["IAgPlanetodetic"] = IAgPlanetodetic

class IAgDirection(object):
    """Interface to set and retrieve direction options for aligned and constrained vectors."""

    _num_methods = 15
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _ConvertTo_method_offset = 1
    _get_DirectionType_method_offset = 2
    _Assign_method_offset = 3
    _AssignEuler_method_offset = 4
    _AssignPR_method_offset = 5
    _AssignRADec_method_offset = 6
    _AssignXYZ_method_offset = 7
    _QueryEuler_method_offset = 8
    _QueryPR_method_offset = 9
    _QueryRADec_method_offset = 10
    _QueryXYZ_method_offset = 11
    _QueryEulerArray_method_offset = 12
    _QueryPRArray_method_offset = 13
    _QueryRADecArray_method_offset = 14
    _QueryXYZArray_method_offset = 15
    _metadata = {
        "iid_data" : (4989224318937616506, 6269745591008380041),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDirection."""
        initialize_from_source_object(self, sourceObject, IAgDirection)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDirection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDirection, None)
    
    _ConvertTo_metadata = { "offset" : _ConvertTo_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEDirectionType), agmarshall.AgInterface_out_arg,) }
    def ConvertTo(self, type:"AgEDirectionType") -> "IAgDirection":
        """Changes the direction to the type specified."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._ConvertTo_metadata, type, OutArg())

    _get_DirectionType_metadata = { "offset" : _get_DirectionType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEDirectionType),) }
    @property
    def DirectionType(self) -> "AgEDirectionType":
        """Returns the type of direction currently being used."""
        return self._intf.get_property(IAgDirection._metadata, IAgDirection._get_DirectionType_metadata)

    _Assign_metadata = { "offset" : _Assign_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgDirection"),) }
    def Assign(self, pDirection:"IAgDirection") -> None:
        """Assign a new direction."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._Assign_metadata, pDirection)

    _AssignEuler_metadata = { "offset" : _AssignEuler_method_offset,
            "arg_types" : (agcom.VARIANT, agcom.VARIANT, agcom.LONG,),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.AgEnum_arg(AgEEulerDirectionSequence),) }
    def AssignEuler(self, b:typing.Any, c:typing.Any, sequence:"AgEEulerDirectionSequence") -> None:
        """Set direction using the Euler representation. Params B and C use Angle Dimension."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._AssignEuler_metadata, b, c, sequence)

    _AssignPR_metadata = { "offset" : _AssignPR_method_offset,
            "arg_types" : (agcom.VARIANT, agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg,) }
    def AssignPR(self, pitch:typing.Any, roll:typing.Any) -> None:
        """Set direction using the Pitch Roll representation. Pitch and Roll use Angle Dimension."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._AssignPR_metadata, pitch, roll)

    _AssignRADec_metadata = { "offset" : _AssignRADec_method_offset,
            "arg_types" : (agcom.VARIANT, agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg,) }
    def AssignRADec(self, ra:typing.Any, dec:typing.Any) -> None:
        """Set direction using the Right Ascension and Declination representation. Param Dec uses Latitude. Param RA uses Longitude."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._AssignRADec_metadata, ra, dec)

    _AssignXYZ_metadata = { "offset" : _AssignXYZ_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignXYZ(self, x:float, y:float, z:float) -> None:
        """Set direction using the Cartesian representation. Params X, Y and Z are dimensionless."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._AssignXYZ_metadata, x, y, z)

    _QueryEuler_metadata = { "offset" : _QueryEuler_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.VARIANT), POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerDirectionSequence), agmarshall.VARIANT_arg, agmarshall.VARIANT_arg,) }
    def QueryEuler(self, sequence:"AgEEulerDirectionSequence") -> typing.Tuple[typing.Any, typing.Any]:
        """Get direction using the Euler representation. Params B and C use Angle Dimension."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._QueryEuler_metadata, sequence, OutArg(), OutArg())

    _QueryPR_metadata = { "offset" : _QueryPR_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.VARIANT), POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEPRSequence), agmarshall.VARIANT_arg, agmarshall.VARIANT_arg,) }
    def QueryPR(self, sequence:"AgEPRSequence") -> typing.Tuple[typing.Any, typing.Any]:
        """Get direction using the Pitch Roll representation. Pitch and Roll use Angle Dimension."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._QueryPR_metadata, sequence, OutArg(), OutArg())

    _QueryRADec_metadata = { "offset" : _QueryRADec_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT), POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg,) }
    def QueryRADec(self) -> typing.Tuple[typing.Any, typing.Any]:
        """Get direction using the Right Ascension and Declination representation. Param Dec uses Latitude. Param RA uses Longitude."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._QueryRADec_metadata, OutArg(), OutArg())

    _QueryXYZ_metadata = { "offset" : _QueryXYZ_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def QueryXYZ(self) -> typing.Tuple[float, float, float]:
        """Get direction using the Cartesian representation. Params X, Y and Z are dimensionless."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._QueryXYZ_metadata, OutArg(), OutArg(), OutArg())

    _QueryEulerArray_metadata = { "offset" : _QueryEulerArray_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerDirectionSequence), agmarshall.LPSAFEARRAY_arg,) }
    def QueryEulerArray(self, sequence:"AgEEulerDirectionSequence") -> list:
        """Returns the Euler elements in an array."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._QueryEulerArray_metadata, sequence, OutArg())

    _QueryPRArray_metadata = { "offset" : _QueryPRArray_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEPRSequence), agmarshall.LPSAFEARRAY_arg,) }
    def QueryPRArray(self, sequence:"AgEPRSequence") -> list:
        """Returns the PR elements in an array."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._QueryPRArray_metadata, sequence, OutArg())

    _QueryRADecArray_metadata = { "offset" : _QueryRADecArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def QueryRADecArray(self) -> list:
        """Returns the RADec elements in an array."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._QueryRADecArray_metadata, OutArg())

    _QueryXYZArray_metadata = { "offset" : _QueryXYZArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def QueryXYZArray(self) -> list:
        """Returns the XYZ elements in an array."""
        return self._intf.invoke(IAgDirection._metadata, IAgDirection._QueryXYZArray_metadata, OutArg())

    _property_names[DirectionType] = "DirectionType"


agcls.AgClassCatalog.add_catalog_entry((4989224318937616506, 6269745591008380041), IAgDirection)
agcls.AgTypeNameMap["IAgDirection"] = IAgDirection

class IAgDirectionEuler(IAgDirection):
    """Interface for Euler direction sequence."""

    _num_methods = 6
    _vtable_offset = IAgDirection._vtable_offset + IAgDirection._num_methods
    _get_B_method_offset = 1
    _set_B_method_offset = 2
    _get_C_method_offset = 3
    _set_C_method_offset = 4
    _get_Sequence_method_offset = 5
    _set_Sequence_method_offset = 6
    _metadata = {
        "iid_data" : (5130852120085250360, 13058025655636170127),
        "vtable_reference" : IAgDirection._vtable_offset + IAgDirection._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDirectionEuler."""
        initialize_from_source_object(self, sourceObject, IAgDirectionEuler)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDirection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDirectionEuler)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDirectionEuler, IAgDirection)
    
    _get_B_metadata = { "offset" : _get_B_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def B(self) -> typing.Any:
        """Euler B angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgDirectionEuler._metadata, IAgDirectionEuler._get_B_metadata)

    _set_B_metadata = { "offset" : _set_B_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @B.setter
    def B(self, va:typing.Any) -> None:
        return self._intf.set_property(IAgDirectionEuler._metadata, IAgDirectionEuler._set_B_metadata, va)

    _get_C_metadata = { "offset" : _get_C_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def C(self) -> typing.Any:
        """Euler C angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgDirectionEuler._metadata, IAgDirectionEuler._get_C_metadata)

    _set_C_metadata = { "offset" : _set_C_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @C.setter
    def C(self, vb:typing.Any) -> None:
        return self._intf.set_property(IAgDirectionEuler._metadata, IAgDirectionEuler._set_C_metadata, vb)

    _get_Sequence_metadata = { "offset" : _get_Sequence_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerDirectionSequence),) }
    @property
    def Sequence(self) -> "AgEEulerDirectionSequence":
        """Euler direction sequence.  Must be set before B,C values. Otherwise the B,C values will converted to the Sequence specified."""
        return self._intf.get_property(IAgDirectionEuler._metadata, IAgDirectionEuler._get_Sequence_metadata)

    _set_Sequence_metadata = { "offset" : _set_Sequence_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerDirectionSequence),) }
    @Sequence.setter
    def Sequence(self, sequence:"AgEEulerDirectionSequence") -> None:
        return self._intf.set_property(IAgDirectionEuler._metadata, IAgDirectionEuler._set_Sequence_metadata, sequence)

    _property_names[B] = "B"
    _property_names[C] = "C"
    _property_names[Sequence] = "Sequence"


agcls.AgClassCatalog.add_catalog_entry((5130852120085250360, 13058025655636170127), IAgDirectionEuler)
agcls.AgTypeNameMap["IAgDirectionEuler"] = IAgDirectionEuler

class IAgDirectionPR(IAgDirection):
    """Interface for Pitch-Roll (PR) direction sequence."""

    _num_methods = 6
    _vtable_offset = IAgDirection._vtable_offset + IAgDirection._num_methods
    _get_Pitch_method_offset = 1
    _set_Pitch_method_offset = 2
    _get_Roll_method_offset = 3
    _set_Roll_method_offset = 4
    _get_Sequence_method_offset = 5
    _set_Sequence_method_offset = 6
    _metadata = {
        "iid_data" : (5481773091912686577, 1023308621448571275),
        "vtable_reference" : IAgDirection._vtable_offset + IAgDirection._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDirectionPR."""
        initialize_from_source_object(self, sourceObject, IAgDirectionPR)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDirection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDirectionPR)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDirectionPR, IAgDirection)
    
    _get_Pitch_metadata = { "offset" : _get_Pitch_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Pitch(self) -> typing.Any:
        """Pitch angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgDirectionPR._metadata, IAgDirectionPR._get_Pitch_metadata)

    _set_Pitch_metadata = { "offset" : _set_Pitch_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Pitch.setter
    def Pitch(self, vPitch:typing.Any) -> None:
        return self._intf.set_property(IAgDirectionPR._metadata, IAgDirectionPR._set_Pitch_metadata, vPitch)

    _get_Roll_metadata = { "offset" : _get_Roll_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Roll(self) -> typing.Any:
        """Roll angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgDirectionPR._metadata, IAgDirectionPR._get_Roll_metadata)

    _set_Roll_metadata = { "offset" : _set_Roll_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Roll.setter
    def Roll(self, vRoll:typing.Any) -> None:
        return self._intf.set_property(IAgDirectionPR._metadata, IAgDirectionPR._set_Roll_metadata, vRoll)

    _get_Sequence_metadata = { "offset" : _get_Sequence_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEPRSequence),) }
    @property
    def Sequence(self) -> "AgEPRSequence":
        """PR direction sequence. Must be set before Pitch,Roll values. Otherwise the current Pitch,Roll values will be converted to the Sequence specified."""
        return self._intf.get_property(IAgDirectionPR._metadata, IAgDirectionPR._get_Sequence_metadata)

    _set_Sequence_metadata = { "offset" : _set_Sequence_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEPRSequence),) }
    @Sequence.setter
    def Sequence(self, sequence:"AgEPRSequence") -> None:
        return self._intf.set_property(IAgDirectionPR._metadata, IAgDirectionPR._set_Sequence_metadata, sequence)

    _property_names[Pitch] = "Pitch"
    _property_names[Roll] = "Roll"
    _property_names[Sequence] = "Sequence"


agcls.AgClassCatalog.add_catalog_entry((5481773091912686577, 1023308621448571275), IAgDirectionPR)
agcls.AgTypeNameMap["IAgDirectionPR"] = IAgDirectionPR

class IAgDirectionRADec(IAgDirection):
    """Interface for Spherical direction (Right Ascension and Declination)."""

    _num_methods = 6
    _vtable_offset = IAgDirection._vtable_offset + IAgDirection._num_methods
    _get_Dec_method_offset = 1
    _set_Dec_method_offset = 2
    _get_RA_method_offset = 3
    _set_RA_method_offset = 4
    _get_Magnitude_method_offset = 5
    _set_Magnitude_method_offset = 6
    _metadata = {
        "iid_data" : (5701254258584839559, 16705505474005351321),
        "vtable_reference" : IAgDirection._vtable_offset + IAgDirection._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDirectionRADec."""
        initialize_from_source_object(self, sourceObject, IAgDirectionRADec)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDirection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDirectionRADec)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDirectionRADec, IAgDirection)
    
    _get_Dec_metadata = { "offset" : _get_Dec_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Dec(self) -> typing.Any:
        """Declination: angle above the x-y plane. Uses Latitude Dimension."""
        return self._intf.get_property(IAgDirectionRADec._metadata, IAgDirectionRADec._get_Dec_metadata)

    _set_Dec_metadata = { "offset" : _set_Dec_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Dec.setter
    def Dec(self, vLat:typing.Any) -> None:
        return self._intf.set_property(IAgDirectionRADec._metadata, IAgDirectionRADec._set_Dec_metadata, vLat)

    _get_RA_metadata = { "offset" : _get_RA_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def RA(self) -> typing.Any:
        """Right Ascension: angle in x-y plane from x towards y. Uses Longitude Dimension."""
        return self._intf.get_property(IAgDirectionRADec._metadata, IAgDirectionRADec._get_RA_metadata)

    _set_RA_metadata = { "offset" : _set_RA_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @RA.setter
    def RA(self, vLon:typing.Any) -> None:
        return self._intf.set_property(IAgDirectionRADec._metadata, IAgDirectionRADec._set_RA_metadata, vLon)

    _get_Magnitude_metadata = { "offset" : _get_Magnitude_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Magnitude(self) -> float:
        """A unitless value that represents magnitude."""
        return self._intf.get_property(IAgDirectionRADec._metadata, IAgDirectionRADec._get_Magnitude_metadata)

    _set_Magnitude_metadata = { "offset" : _set_Magnitude_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Magnitude.setter
    def Magnitude(self, magnitude:float) -> None:
        return self._intf.set_property(IAgDirectionRADec._metadata, IAgDirectionRADec._set_Magnitude_metadata, magnitude)

    _property_names[Dec] = "Dec"
    _property_names[RA] = "RA"
    _property_names[Magnitude] = "Magnitude"


agcls.AgClassCatalog.add_catalog_entry((5701254258584839559, 16705505474005351321), IAgDirectionRADec)
agcls.AgTypeNameMap["IAgDirectionRADec"] = IAgDirectionRADec

class IAgDirectionXYZ(IAgDirection):
    """Interface for Cartesian direction."""

    _num_methods = 6
    _vtable_offset = IAgDirection._vtable_offset + IAgDirection._num_methods
    _get_X_method_offset = 1
    _set_X_method_offset = 2
    _get_Y_method_offset = 3
    _set_Y_method_offset = 4
    _get_Z_method_offset = 5
    _set_Z_method_offset = 6
    _metadata = {
        "iid_data" : (5701669700070119970, 11855669950262444683),
        "vtable_reference" : IAgDirection._vtable_offset + IAgDirection._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDirectionXYZ."""
        initialize_from_source_object(self, sourceObject, IAgDirectionXYZ)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDirection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDirectionXYZ)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDirectionXYZ, IAgDirection)
    
    _get_X_metadata = { "offset" : _get_X_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def X(self) -> float:
        """X component. Dimensionless."""
        return self._intf.get_property(IAgDirectionXYZ._metadata, IAgDirectionXYZ._get_X_metadata)

    _set_X_metadata = { "offset" : _set_X_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @X.setter
    def X(self, vx:float) -> None:
        return self._intf.set_property(IAgDirectionXYZ._metadata, IAgDirectionXYZ._set_X_metadata, vx)

    _get_Y_metadata = { "offset" : _get_Y_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Y(self) -> float:
        """Y component. Dimensionless."""
        return self._intf.get_property(IAgDirectionXYZ._metadata, IAgDirectionXYZ._get_Y_metadata)

    _set_Y_metadata = { "offset" : _set_Y_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Y.setter
    def Y(self, vy:float) -> None:
        return self._intf.set_property(IAgDirectionXYZ._metadata, IAgDirectionXYZ._set_Y_metadata, vy)

    _get_Z_metadata = { "offset" : _get_Z_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Z(self) -> float:
        """Z component. Dimensionless."""
        return self._intf.get_property(IAgDirectionXYZ._metadata, IAgDirectionXYZ._get_Z_metadata)

    _set_Z_metadata = { "offset" : _set_Z_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Z.setter
    def Z(self, vz:float) -> None:
        return self._intf.set_property(IAgDirectionXYZ._metadata, IAgDirectionXYZ._set_Z_metadata, vz)

    _property_names[X] = "X"
    _property_names[Y] = "Y"
    _property_names[Z] = "Z"


agcls.AgClassCatalog.add_catalog_entry((5701669700070119970, 11855669950262444683), IAgDirectionXYZ)
agcls.AgTypeNameMap["IAgDirectionXYZ"] = IAgDirectionXYZ

class IAgCartesian3Vector(object):
    """Represents a cartesian 3-D vector."""

    _num_methods = 9
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_X_method_offset = 1
    _set_X_method_offset = 2
    _get_Y_method_offset = 3
    _set_Y_method_offset = 4
    _get_Z_method_offset = 5
    _set_Z_method_offset = 6
    _Get_method_offset = 7
    _Set_method_offset = 8
    _ToArray_method_offset = 9
    _metadata = {
        "iid_data" : (4689779903308240950, 14404026751257344151),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCartesian3Vector."""
        initialize_from_source_object(self, sourceObject, IAgCartesian3Vector)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCartesian3Vector)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCartesian3Vector, None)
    
    _get_X_metadata = { "offset" : _get_X_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def X(self) -> float:
        """X coordinate."""
        return self._intf.get_property(IAgCartesian3Vector._metadata, IAgCartesian3Vector._get_X_metadata)

    _set_X_metadata = { "offset" : _set_X_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @X.setter
    def X(self, x:float) -> None:
        return self._intf.set_property(IAgCartesian3Vector._metadata, IAgCartesian3Vector._set_X_metadata, x)

    _get_Y_metadata = { "offset" : _get_Y_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Y(self) -> float:
        """Y coordinate."""
        return self._intf.get_property(IAgCartesian3Vector._metadata, IAgCartesian3Vector._get_Y_metadata)

    _set_Y_metadata = { "offset" : _set_Y_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Y.setter
    def Y(self, y:float) -> None:
        return self._intf.set_property(IAgCartesian3Vector._metadata, IAgCartesian3Vector._set_Y_metadata, y)

    _get_Z_metadata = { "offset" : _get_Z_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Z(self) -> float:
        """Z coordinate."""
        return self._intf.get_property(IAgCartesian3Vector._metadata, IAgCartesian3Vector._get_Z_metadata)

    _set_Z_metadata = { "offset" : _set_Z_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Z.setter
    def Z(self, z:float) -> None:
        return self._intf.set_property(IAgCartesian3Vector._metadata, IAgCartesian3Vector._set_Z_metadata, z)

    _Get_metadata = { "offset" : _Get_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def Get(self) -> typing.Tuple[float, float, float]:
        """Returns cartesian vector."""
        return self._intf.invoke(IAgCartesian3Vector._metadata, IAgCartesian3Vector._Get_metadata, OutArg(), OutArg(), OutArg())

    _Set_metadata = { "offset" : _Set_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def Set(self, x:float, y:float, z:float) -> None:
        """Sets cartesian vector."""
        return self._intf.invoke(IAgCartesian3Vector._metadata, IAgCartesian3Vector._Set_metadata, x, y, z)

    _ToArray_metadata = { "offset" : _ToArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def ToArray(self) -> list:
        """Returns coordinates as an array."""
        return self._intf.invoke(IAgCartesian3Vector._metadata, IAgCartesian3Vector._ToArray_metadata, OutArg())

    _property_names[X] = "X"
    _property_names[Y] = "Y"
    _property_names[Z] = "Z"


agcls.AgClassCatalog.add_catalog_entry((4689779903308240950, 14404026751257344151), IAgCartesian3Vector)
agcls.AgTypeNameMap["IAgCartesian3Vector"] = IAgCartesian3Vector

class IAgOrientation(object):
    """Interface to set and retrieve the orientation method."""

    _num_methods = 15
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _ConvertTo_method_offset = 1
    _get_OrientationType_method_offset = 2
    _Assign_method_offset = 3
    _AssignAzEl_method_offset = 4
    _AssignEulerAngles_method_offset = 5
    _AssignQuaternion_method_offset = 6
    _AssignYPRAngles_method_offset = 7
    _QueryAzEl_method_offset = 8
    _QueryEulerAngles_method_offset = 9
    _QueryQuaternion_method_offset = 10
    _QueryYPRAngles_method_offset = 11
    _QueryAzElArray_method_offset = 12
    _QueryEulerAnglesArray_method_offset = 13
    _QueryQuaternionArray_method_offset = 14
    _QueryYPRAnglesArray_method_offset = 15
    _metadata = {
        "iid_data" : (4942731207787353951, 2364797108030602640),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgOrientation."""
        initialize_from_source_object(self, sourceObject, IAgOrientation)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgOrientation)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgOrientation, None)
    
    _ConvertTo_metadata = { "offset" : _ConvertTo_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEOrientationType), agmarshall.AgInterface_out_arg,) }
    def ConvertTo(self, type:"AgEOrientationType") -> "IAgOrientation":
        """Change the orientation method to the type specified."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._ConvertTo_metadata, type, OutArg())

    _get_OrientationType_metadata = { "offset" : _get_OrientationType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEOrientationType),) }
    @property
    def OrientationType(self) -> "AgEOrientationType":
        """Returns the orientation method currently being used."""
        return self._intf.get_property(IAgOrientation._metadata, IAgOrientation._get_OrientationType_metadata)

    _Assign_metadata = { "offset" : _Assign_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgOrientation"),) }
    def Assign(self, pOrientation:"IAgOrientation") -> None:
        """Assign a new orientation method."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._Assign_metadata, pOrientation)

    _AssignAzEl_metadata = { "offset" : _AssignAzEl_method_offset,
            "arg_types" : (agcom.VARIANT, agcom.VARIANT, agcom.LONG,),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.AgEnum_arg(AgEAzElAboutBoresight),) }
    def AssignAzEl(self, azimuth:typing.Any, elevation:typing.Any, aboutBoresight:"AgEAzElAboutBoresight") -> None:
        """Set orientation using the AzEl representation."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._AssignAzEl_metadata, azimuth, elevation, aboutBoresight)

    _AssignEulerAngles_metadata = { "offset" : _AssignEulerAngles_method_offset,
            "arg_types" : (agcom.LONG, agcom.VARIANT, agcom.VARIANT, agcom.VARIANT,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerOrientationSequence), agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.VARIANT_arg,) }
    def AssignEulerAngles(self, sequence:"AgEEulerOrientationSequence", a:typing.Any, b:typing.Any, c:typing.Any) -> None:
        """Set orientation using the Euler angles representation."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._AssignEulerAngles_metadata, sequence, a, b, c)

    _AssignQuaternion_metadata = { "offset" : _AssignQuaternion_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignQuaternion(self, qx:float, qy:float, qz:float, qs:float) -> None:
        """Set orientation using the Quaternion representation."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._AssignQuaternion_metadata, qx, qy, qz, qs)

    _AssignYPRAngles_metadata = { "offset" : _AssignYPRAngles_method_offset,
            "arg_types" : (agcom.LONG, agcom.VARIANT, agcom.VARIANT, agcom.VARIANT,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEYPRAnglesSequence), agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.VARIANT_arg,) }
    def AssignYPRAngles(self, sequence:"AgEYPRAnglesSequence", yaw:typing.Any, pitch:typing.Any, roll:typing.Any) -> None:
        """Set orientation using the YPR angles representation."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._AssignYPRAngles_metadata, sequence, yaw, pitch, roll)

    _QueryAzEl_metadata = { "offset" : _QueryAzEl_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT), POINTER(agcom.VARIANT), POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.AgEnum_arg(AgEAzElAboutBoresight),) }
    def QueryAzEl(self) -> typing.Tuple[typing.Any, typing.Any, AgEAzElAboutBoresight]:
        """Get orientation using the AzEl representation."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._QueryAzEl_metadata, OutArg(), OutArg(), OutArg())

    _QueryEulerAngles_metadata = { "offset" : _QueryEulerAngles_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.VARIANT), POINTER(agcom.VARIANT), POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerOrientationSequence), agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.VARIANT_arg,) }
    def QueryEulerAngles(self, sequence:"AgEEulerOrientationSequence") -> typing.Tuple[typing.Any, typing.Any, typing.Any]:
        """Get orientation using the Euler angles representation."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._QueryEulerAngles_metadata, sequence, OutArg(), OutArg(), OutArg())

    _QueryQuaternion_metadata = { "offset" : _QueryQuaternion_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def QueryQuaternion(self) -> typing.Tuple[float, float, float, float]:
        """Get orientation using the Quaternion representation."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._QueryQuaternion_metadata, OutArg(), OutArg(), OutArg(), OutArg())

    _QueryYPRAngles_metadata = { "offset" : _QueryYPRAngles_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.VARIANT), POINTER(agcom.VARIANT), POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEYPRAnglesSequence), agmarshall.VARIANT_arg, agmarshall.VARIANT_arg, agmarshall.VARIANT_arg,) }
    def QueryYPRAngles(self, sequence:"AgEYPRAnglesSequence") -> typing.Tuple[typing.Any, typing.Any, typing.Any]:
        """Get orientation using the YPR angles representation."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._QueryYPRAngles_metadata, sequence, OutArg(), OutArg(), OutArg())

    _QueryAzElArray_metadata = { "offset" : _QueryAzElArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def QueryAzElArray(self) -> list:
        """Returns the AzEl elements as an array."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._QueryAzElArray_metadata, OutArg())

    _QueryEulerAnglesArray_metadata = { "offset" : _QueryEulerAnglesArray_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerOrientationSequence), agmarshall.LPSAFEARRAY_arg,) }
    def QueryEulerAnglesArray(self, sequence:"AgEEulerOrientationSequence") -> list:
        """Returns the Euler elements as an array."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._QueryEulerAnglesArray_metadata, sequence, OutArg())

    _QueryQuaternionArray_metadata = { "offset" : _QueryQuaternionArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def QueryQuaternionArray(self) -> list:
        """Returns the Quaternion elements as an array."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._QueryQuaternionArray_metadata, OutArg())

    _QueryYPRAnglesArray_metadata = { "offset" : _QueryYPRAnglesArray_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEYPRAnglesSequence), agmarshall.LPSAFEARRAY_arg,) }
    def QueryYPRAnglesArray(self, sequence:"AgEYPRAnglesSequence") -> list:
        """Returns the YPR Angles elements as an array."""
        return self._intf.invoke(IAgOrientation._metadata, IAgOrientation._QueryYPRAnglesArray_metadata, sequence, OutArg())

    _property_names[OrientationType] = "OrientationType"


agcls.AgClassCatalog.add_catalog_entry((4942731207787353951, 2364797108030602640), IAgOrientation)
agcls.AgTypeNameMap["IAgOrientation"] = IAgOrientation

class IAgOrientationAzEl(IAgOrientation):
    """Interface for AzEl orientation method."""

    _num_methods = 6
    _vtable_offset = IAgOrientation._vtable_offset + IAgOrientation._num_methods
    _get_Azimuth_method_offset = 1
    _set_Azimuth_method_offset = 2
    _get_Elevation_method_offset = 3
    _set_Elevation_method_offset = 4
    _get_AboutBoresight_method_offset = 5
    _set_AboutBoresight_method_offset = 6
    _metadata = {
        "iid_data" : (5238647887040814461, 18345805215225203352),
        "vtable_reference" : IAgOrientation._vtable_offset + IAgOrientation._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgOrientationAzEl."""
        initialize_from_source_object(self, sourceObject, IAgOrientationAzEl)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgOrientationAzEl)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgOrientationAzEl, IAgOrientation)
    
    _get_Azimuth_metadata = { "offset" : _get_Azimuth_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Azimuth(self) -> typing.Any:
        """Measured in the XY plane of the parent reference frame about its Z axis in the right-handed sense for both vehicle-based sensors and facility-based sensors. Uses Angle Dimension."""
        return self._intf.get_property(IAgOrientationAzEl._metadata, IAgOrientationAzEl._get_Azimuth_metadata)

    _set_Azimuth_metadata = { "offset" : _set_Azimuth_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Azimuth.setter
    def Azimuth(self, vAzimuth:typing.Any) -> None:
        return self._intf.set_property(IAgOrientationAzEl._metadata, IAgOrientationAzEl._set_Azimuth_metadata, vAzimuth)

    _get_Elevation_metadata = { "offset" : _get_Elevation_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Elevation(self) -> typing.Any:
        """Defined as the angle between the XY plane of the parent reference frame and the sensor or antenna boresight measured toward the positive Z axis. Uses Angle Dimension."""
        return self._intf.get_property(IAgOrientationAzEl._metadata, IAgOrientationAzEl._get_Elevation_metadata)

    _set_Elevation_metadata = { "offset" : _set_Elevation_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Elevation.setter
    def Elevation(self, vElevation:typing.Any) -> None:
        return self._intf.set_property(IAgOrientationAzEl._metadata, IAgOrientationAzEl._set_Elevation_metadata, vElevation)

    _get_AboutBoresight_metadata = { "offset" : _get_AboutBoresight_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAzElAboutBoresight),) }
    @property
    def AboutBoresight(self) -> "AgEAzElAboutBoresight":
        """Determines orientation of the X and Y axes with respect to the parent's reference frame."""
        return self._intf.get_property(IAgOrientationAzEl._metadata, IAgOrientationAzEl._get_AboutBoresight_metadata)

    _set_AboutBoresight_metadata = { "offset" : _set_AboutBoresight_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEAzElAboutBoresight),) }
    @AboutBoresight.setter
    def AboutBoresight(self, aboutBoresight:"AgEAzElAboutBoresight") -> None:
        return self._intf.set_property(IAgOrientationAzEl._metadata, IAgOrientationAzEl._set_AboutBoresight_metadata, aboutBoresight)

    _property_names[Azimuth] = "Azimuth"
    _property_names[Elevation] = "Elevation"
    _property_names[AboutBoresight] = "AboutBoresight"


agcls.AgClassCatalog.add_catalog_entry((5238647887040814461, 18345805215225203352), IAgOrientationAzEl)
agcls.AgTypeNameMap["IAgOrientationAzEl"] = IAgOrientationAzEl

class IAgOrientationEulerAngles(IAgOrientation):
    """Interface for Euler Angles orientation method."""

    _num_methods = 8
    _vtable_offset = IAgOrientation._vtable_offset + IAgOrientation._num_methods
    _get_Sequence_method_offset = 1
    _set_Sequence_method_offset = 2
    _get_A_method_offset = 3
    _set_A_method_offset = 4
    _get_B_method_offset = 5
    _set_B_method_offset = 6
    _get_C_method_offset = 7
    _set_C_method_offset = 8
    _metadata = {
        "iid_data" : (4660640816984016865, 13688688469838857641),
        "vtable_reference" : IAgOrientation._vtable_offset + IAgOrientation._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgOrientationEulerAngles."""
        initialize_from_source_object(self, sourceObject, IAgOrientationEulerAngles)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgOrientationEulerAngles)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgOrientationEulerAngles, IAgOrientation)
    
    _get_Sequence_metadata = { "offset" : _get_Sequence_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerOrientationSequence),) }
    @property
    def Sequence(self) -> "AgEEulerOrientationSequence":
        """Euler rotation sequence. Must be set before A,B,C values. Otherwise the current A,B,C values will be converted to the Sequence specified."""
        return self._intf.get_property(IAgOrientationEulerAngles._metadata, IAgOrientationEulerAngles._get_Sequence_metadata)

    _set_Sequence_metadata = { "offset" : _set_Sequence_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEEulerOrientationSequence),) }
    @Sequence.setter
    def Sequence(self, ppVal:"AgEEulerOrientationSequence") -> None:
        return self._intf.set_property(IAgOrientationEulerAngles._metadata, IAgOrientationEulerAngles._set_Sequence_metadata, ppVal)

    _get_A_metadata = { "offset" : _get_A_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def A(self) -> typing.Any:
        """Euler A angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgOrientationEulerAngles._metadata, IAgOrientationEulerAngles._get_A_metadata)

    _set_A_metadata = { "offset" : _set_A_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @A.setter
    def A(self, va:typing.Any) -> None:
        return self._intf.set_property(IAgOrientationEulerAngles._metadata, IAgOrientationEulerAngles._set_A_metadata, va)

    _get_B_metadata = { "offset" : _get_B_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def B(self) -> typing.Any:
        """Euler b angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgOrientationEulerAngles._metadata, IAgOrientationEulerAngles._get_B_metadata)

    _set_B_metadata = { "offset" : _set_B_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @B.setter
    def B(self, vb:typing.Any) -> None:
        return self._intf.set_property(IAgOrientationEulerAngles._metadata, IAgOrientationEulerAngles._set_B_metadata, vb)

    _get_C_metadata = { "offset" : _get_C_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def C(self) -> typing.Any:
        """Euler C angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgOrientationEulerAngles._metadata, IAgOrientationEulerAngles._get_C_metadata)

    _set_C_metadata = { "offset" : _set_C_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @C.setter
    def C(self, vc:typing.Any) -> None:
        return self._intf.set_property(IAgOrientationEulerAngles._metadata, IAgOrientationEulerAngles._set_C_metadata, vc)

    _property_names[Sequence] = "Sequence"
    _property_names[A] = "A"
    _property_names[B] = "B"
    _property_names[C] = "C"


agcls.AgClassCatalog.add_catalog_entry((4660640816984016865, 13688688469838857641), IAgOrientationEulerAngles)
agcls.AgTypeNameMap["IAgOrientationEulerAngles"] = IAgOrientationEulerAngles

class IAgOrientationQuaternion(IAgOrientation):
    """Quaternion representing orientation between two sets of axes."""

    _num_methods = 8
    _vtable_offset = IAgOrientation._vtable_offset + IAgOrientation._num_methods
    _get_QX_method_offset = 1
    _set_QX_method_offset = 2
    _get_QY_method_offset = 3
    _set_QY_method_offset = 4
    _get_QZ_method_offset = 5
    _set_QZ_method_offset = 6
    _get_QS_method_offset = 7
    _set_QS_method_offset = 8
    _metadata = {
        "iid_data" : (5570827236088458332, 138389395716207516),
        "vtable_reference" : IAgOrientation._vtable_offset + IAgOrientation._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgOrientationQuaternion."""
        initialize_from_source_object(self, sourceObject, IAgOrientationQuaternion)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgOrientationQuaternion)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgOrientationQuaternion, IAgOrientation)
    
    _get_QX_metadata = { "offset" : _get_QX_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def QX(self) -> float:
        """Gets or sets the first element of the vector component of the quaternion. This quaternion is from the reference axes to the body frame; if n and A are the axis and angle of rotation, respectively, then QX = nx sin(A/2). Dimensionless."""
        return self._intf.get_property(IAgOrientationQuaternion._metadata, IAgOrientationQuaternion._get_QX_metadata)

    _set_QX_metadata = { "offset" : _set_QX_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @QX.setter
    def QX(self, vQX:float) -> None:
        return self._intf.set_property(IAgOrientationQuaternion._metadata, IAgOrientationQuaternion._set_QX_metadata, vQX)

    _get_QY_metadata = { "offset" : _get_QY_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def QY(self) -> float:
        """Gets or sets the second element of the vector component of the quaternion. This quaternion is from the reference axes to the body frame; if n and A are the axis and angle of rotation, respectively, then QY = ny sin(A/2). Dimensionless."""
        return self._intf.get_property(IAgOrientationQuaternion._metadata, IAgOrientationQuaternion._get_QY_metadata)

    _set_QY_metadata = { "offset" : _set_QY_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @QY.setter
    def QY(self, vQY:float) -> None:
        return self._intf.set_property(IAgOrientationQuaternion._metadata, IAgOrientationQuaternion._set_QY_metadata, vQY)

    _get_QZ_metadata = { "offset" : _get_QZ_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def QZ(self) -> float:
        """Gets or sets the third element of the vector component of the quaternion. This quaternion is from the reference axes to the body frame; if n and A are the axis and angle of rotation, respectively, then QZ = nz sin(A/2). Dimensionless."""
        return self._intf.get_property(IAgOrientationQuaternion._metadata, IAgOrientationQuaternion._get_QZ_metadata)

    _set_QZ_metadata = { "offset" : _set_QZ_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @QZ.setter
    def QZ(self, vQZ:float) -> None:
        return self._intf.set_property(IAgOrientationQuaternion._metadata, IAgOrientationQuaternion._set_QZ_metadata, vQZ)

    _get_QS_metadata = { "offset" : _get_QS_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def QS(self) -> float:
        """Gets or sets the scalar component of the quaternion. This quaternion is from the reference axes to the body frame; if n and A are the axis and angle of rotation, respectively, then QS = cos(A/2). Dimensionless."""
        return self._intf.get_property(IAgOrientationQuaternion._metadata, IAgOrientationQuaternion._get_QS_metadata)

    _set_QS_metadata = { "offset" : _set_QS_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @QS.setter
    def QS(self, vQS:float) -> None:
        return self._intf.set_property(IAgOrientationQuaternion._metadata, IAgOrientationQuaternion._set_QS_metadata, vQS)

    _property_names[QX] = "QX"
    _property_names[QY] = "QY"
    _property_names[QZ] = "QZ"
    _property_names[QS] = "QS"


agcls.AgClassCatalog.add_catalog_entry((5570827236088458332, 138389395716207516), IAgOrientationQuaternion)
agcls.AgTypeNameMap["IAgOrientationQuaternion"] = IAgOrientationQuaternion

class IAgOrientationYPRAngles(IAgOrientation):
    """Interface for Yaw-Pitch Roll (YPR) Angles orientation system."""

    _num_methods = 8
    _vtable_offset = IAgOrientation._vtable_offset + IAgOrientation._num_methods
    _get_Sequence_method_offset = 1
    _set_Sequence_method_offset = 2
    _get_Yaw_method_offset = 3
    _set_Yaw_method_offset = 4
    _get_Pitch_method_offset = 5
    _set_Pitch_method_offset = 6
    _get_Roll_method_offset = 7
    _set_Roll_method_offset = 8
    _metadata = {
        "iid_data" : (4754929399406122077, 1946068441090675372),
        "vtable_reference" : IAgOrientation._vtable_offset + IAgOrientation._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgOrientationYPRAngles."""
        initialize_from_source_object(self, sourceObject, IAgOrientationYPRAngles)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgOrientationYPRAngles)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgOrientationYPRAngles, IAgOrientation)
    
    _get_Sequence_metadata = { "offset" : _get_Sequence_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEYPRAnglesSequence),) }
    @property
    def Sequence(self) -> "AgEYPRAnglesSequence":
        """YPR sequence. Must be set before Yaw,Pitch,Roll values. Otherwise the current Yaw,Pitch,Roll values will be converted to the Sequence specified."""
        return self._intf.get_property(IAgOrientationYPRAngles._metadata, IAgOrientationYPRAngles._get_Sequence_metadata)

    _set_Sequence_metadata = { "offset" : _set_Sequence_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.AgEnum_arg(AgEYPRAnglesSequence),) }
    @Sequence.setter
    def Sequence(self, sequence:"AgEYPRAnglesSequence") -> None:
        return self._intf.set_property(IAgOrientationYPRAngles._metadata, IAgOrientationYPRAngles._set_Sequence_metadata, sequence)

    _get_Yaw_metadata = { "offset" : _get_Yaw_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Yaw(self) -> typing.Any:
        """Yaw angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgOrientationYPRAngles._metadata, IAgOrientationYPRAngles._get_Yaw_metadata)

    _set_Yaw_metadata = { "offset" : _set_Yaw_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Yaw.setter
    def Yaw(self, vYaw:typing.Any) -> None:
        return self._intf.set_property(IAgOrientationYPRAngles._metadata, IAgOrientationYPRAngles._set_Yaw_metadata, vYaw)

    _get_Pitch_metadata = { "offset" : _get_Pitch_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Pitch(self) -> typing.Any:
        """Pitch angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgOrientationYPRAngles._metadata, IAgOrientationYPRAngles._get_Pitch_metadata)

    _set_Pitch_metadata = { "offset" : _set_Pitch_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Pitch.setter
    def Pitch(self, vPitch:typing.Any) -> None:
        return self._intf.set_property(IAgOrientationYPRAngles._metadata, IAgOrientationYPRAngles._set_Pitch_metadata, vPitch)

    _get_Roll_metadata = { "offset" : _get_Roll_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Roll(self) -> typing.Any:
        """Roll angle. Uses Angle Dimension."""
        return self._intf.get_property(IAgOrientationYPRAngles._metadata, IAgOrientationYPRAngles._get_Roll_metadata)

    _set_Roll_metadata = { "offset" : _set_Roll_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Roll.setter
    def Roll(self, vRoll:typing.Any) -> None:
        return self._intf.set_property(IAgOrientationYPRAngles._metadata, IAgOrientationYPRAngles._set_Roll_metadata, vRoll)

    _property_names[Sequence] = "Sequence"
    _property_names[Yaw] = "Yaw"
    _property_names[Pitch] = "Pitch"
    _property_names[Roll] = "Roll"


agcls.AgClassCatalog.add_catalog_entry((4754929399406122077, 1946068441090675372), IAgOrientationYPRAngles)
agcls.AgTypeNameMap["IAgOrientationYPRAngles"] = IAgOrientationYPRAngles

class IAgOrientationPositionOffset(object):
    """Interface for defining the orientation origin position offset relative to the parent object."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_PositionOffset_method_offset = 1
    _metadata = {
        "iid_data" : (5470278826130565228, 13133202882000034710),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgOrientationPositionOffset."""
        initialize_from_source_object(self, sourceObject, IAgOrientationPositionOffset)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgOrientationPositionOffset)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgOrientationPositionOffset, None)
    
    _get_PositionOffset_metadata = { "offset" : _get_PositionOffset_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def PositionOffset(self) -> "IAgCartesian3Vector":
        """Gets or sets the position offset cartesian vector."""
        return self._intf.get_property(IAgOrientationPositionOffset._metadata, IAgOrientationPositionOffset._get_PositionOffset_metadata)

    _property_names[PositionOffset] = "PositionOffset"


agcls.AgClassCatalog.add_catalog_entry((5470278826130565228, 13133202882000034710), IAgOrientationPositionOffset)
agcls.AgTypeNameMap["IAgOrientationPositionOffset"] = IAgOrientationPositionOffset

class IAgOrbitState(object):
    """Interface to set and retrieve the coordinate type used to specify the orbit state."""

    _num_methods = 13
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _ConvertTo_method_offset = 1
    _get_OrbitStateType_method_offset = 2
    _Assign_method_offset = 3
    _AssignClassical_method_offset = 4
    _AssignCartesian_method_offset = 5
    _AssignGeodetic_method_offset = 6
    _AssignEquinoctialPosigrade_method_offset = 7
    _AssignEquinoctialRetrograde_method_offset = 8
    _AssignMixedSpherical_method_offset = 9
    _AssignSpherical_method_offset = 10
    _get_CentralBodyName_method_offset = 11
    _get_Epoch_method_offset = 12
    _set_Epoch_method_offset = 13
    _metadata = {
        "iid_data" : (4786190356090989266, 14434973523195079339),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgOrbitState."""
        initialize_from_source_object(self, sourceObject, IAgOrbitState)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgOrbitState)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgOrbitState, None)
    
    _ConvertTo_metadata = { "offset" : _ConvertTo_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEOrbitStateType), agmarshall.AgInterface_out_arg,) }
    def ConvertTo(self, type:"AgEOrbitStateType") -> "IAgOrbitState":
        """Changes the coordinate type to the type specified."""
        return self._intf.invoke(IAgOrbitState._metadata, IAgOrbitState._ConvertTo_metadata, type, OutArg())

    _get_OrbitStateType_metadata = { "offset" : _get_OrbitStateType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEOrbitStateType),) }
    @property
    def OrbitStateType(self) -> "AgEOrbitStateType":
        """Returns the coordinate type currently being used."""
        return self._intf.get_property(IAgOrbitState._metadata, IAgOrbitState._get_OrbitStateType_metadata)

    _Assign_metadata = { "offset" : _Assign_method_offset,
            "arg_types" : (agcom.PVOID,),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgOrbitState"),) }
    def Assign(self, pOrbitState:"IAgOrbitState") -> None:
        """Assign a new coordinate type."""
        return self._intf.invoke(IAgOrbitState._metadata, IAgOrbitState._Assign_metadata, pOrbitState)

    _AssignClassical_metadata = { "offset" : _AssignClassical_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECoordinateSystem), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignClassical(self, eCoordinateSystem:"AgECoordinateSystem", semiMajorAxis:float, eccentricity:float, inclination:float, argOfPerigee:float, rAAN:float, meanAnomaly:float) -> None:
        """Assign a new orbit state using Classical representation."""
        return self._intf.invoke(IAgOrbitState._metadata, IAgOrbitState._AssignClassical_metadata, eCoordinateSystem, semiMajorAxis, eccentricity, inclination, argOfPerigee, rAAN, meanAnomaly)

    _AssignCartesian_metadata = { "offset" : _AssignCartesian_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECoordinateSystem), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignCartesian(self, eCoordinateSystem:"AgECoordinateSystem", xPosition:float, yPosition:float, zPosition:float, xVelocity:float, yVelocity:float, zVelocity:float) -> None:
        """Assign a new orbit state using Cartesian representation."""
        return self._intf.invoke(IAgOrbitState._metadata, IAgOrbitState._AssignCartesian_metadata, eCoordinateSystem, xPosition, yPosition, zPosition, xVelocity, yVelocity, zVelocity)

    _AssignGeodetic_metadata = { "offset" : _AssignGeodetic_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECoordinateSystem), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignGeodetic(self, eCoordinateSystem:"AgECoordinateSystem", latitude:float, longitude:float, altitude:float, latitudeRate:float, longitudeRate:float, altitudeRate:float) -> None:
        """Assign a new orbit state using Geodetic representation."""
        return self._intf.invoke(IAgOrbitState._metadata, IAgOrbitState._AssignGeodetic_metadata, eCoordinateSystem, latitude, longitude, altitude, latitudeRate, longitudeRate, altitudeRate)

    _AssignEquinoctialPosigrade_metadata = { "offset" : _AssignEquinoctialPosigrade_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECoordinateSystem), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignEquinoctialPosigrade(self, eCoordinateSystem:"AgECoordinateSystem", semiMajorAxis:float, h:float, k:float, p:float, q:float, meanLon:float) -> None:
        """Assign a new orbit state using Equinoctial representation."""
        return self._intf.invoke(IAgOrbitState._metadata, IAgOrbitState._AssignEquinoctialPosigrade_metadata, eCoordinateSystem, semiMajorAxis, h, k, p, q, meanLon)

    _AssignEquinoctialRetrograde_metadata = { "offset" : _AssignEquinoctialRetrograde_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECoordinateSystem), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignEquinoctialRetrograde(self, eCoordinateSystem:"AgECoordinateSystem", semiMajorAxis:float, h:float, k:float, p:float, q:float, meanLon:float) -> None:
        """Assign a new orbit state using Equinoctial representation."""
        return self._intf.invoke(IAgOrbitState._metadata, IAgOrbitState._AssignEquinoctialRetrograde_metadata, eCoordinateSystem, semiMajorAxis, h, k, p, q, meanLon)

    _AssignMixedSpherical_metadata = { "offset" : _AssignMixedSpherical_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECoordinateSystem), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignMixedSpherical(self, eCoordinateSystem:"AgECoordinateSystem", latitude:float, longitude:float, altitude:float, horFlightPathAngle:float, flightPathAzimuth:float, velocity:float) -> None:
        """Assign a new orbit state using Mixed Spherical representation."""
        return self._intf.invoke(IAgOrbitState._metadata, IAgOrbitState._AssignMixedSpherical_metadata, eCoordinateSystem, latitude, longitude, altitude, horFlightPathAngle, flightPathAzimuth, velocity)

    _AssignSpherical_metadata = { "offset" : _AssignSpherical_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.AgEnum_arg(AgECoordinateSystem), agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def AssignSpherical(self, eCoordinateSystem:"AgECoordinateSystem", rightAscension:float, declination:float, radius:float, horFlightPathAngle:float, flightPathAzimuth:float, velocity:float) -> None:
        """Assign a new orbit state using Spherical representation."""
        return self._intf.invoke(IAgOrbitState._metadata, IAgOrbitState._AssignSpherical_metadata, eCoordinateSystem, rightAscension, declination, radius, horFlightPathAngle, flightPathAzimuth, velocity)

    _get_CentralBodyName_metadata = { "offset" : _get_CentralBodyName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def CentralBodyName(self) -> str:
        """Gets the central body."""
        return self._intf.get_property(IAgOrbitState._metadata, IAgOrbitState._get_CentralBodyName_metadata)

    _get_Epoch_metadata = { "offset" : _get_Epoch_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Epoch(self) -> typing.Any:
        """Gets or sets the state epoch."""
        return self._intf.get_property(IAgOrbitState._metadata, IAgOrbitState._get_Epoch_metadata)

    _set_Epoch_metadata = { "offset" : _set_Epoch_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @Epoch.setter
    def Epoch(self, epoch:typing.Any) -> None:
        return self._intf.set_property(IAgOrbitState._metadata, IAgOrbitState._set_Epoch_metadata, epoch)

    _property_names[OrbitStateType] = "OrbitStateType"
    _property_names[CentralBodyName] = "CentralBodyName"
    _property_names[Epoch] = "Epoch"


agcls.AgClassCatalog.add_catalog_entry((4786190356090989266, 14434973523195079339), IAgOrbitState)
agcls.AgTypeNameMap["IAgOrbitState"] = IAgOrbitState

class IAgCartesian2Vector(object):
    """Represents a cartesian 2-D vector."""

    _num_methods = 7
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_X_method_offset = 1
    _set_X_method_offset = 2
    _get_Y_method_offset = 3
    _set_Y_method_offset = 4
    _Get_method_offset = 5
    _Set_method_offset = 6
    _ToArray_method_offset = 7
    _metadata = {
        "iid_data" : (5417927181131422679, 3111395435573516163),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgCartesian2Vector."""
        initialize_from_source_object(self, sourceObject, IAgCartesian2Vector)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgCartesian2Vector)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgCartesian2Vector, None)
    
    _get_X_metadata = { "offset" : _get_X_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def X(self) -> float:
        """X coordinate."""
        return self._intf.get_property(IAgCartesian2Vector._metadata, IAgCartesian2Vector._get_X_metadata)

    _set_X_metadata = { "offset" : _set_X_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @X.setter
    def X(self, x:float) -> None:
        return self._intf.set_property(IAgCartesian2Vector._metadata, IAgCartesian2Vector._set_X_metadata, x)

    _get_Y_metadata = { "offset" : _get_Y_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Y(self) -> float:
        """Y coordinate."""
        return self._intf.get_property(IAgCartesian2Vector._metadata, IAgCartesian2Vector._get_Y_metadata)

    _set_Y_metadata = { "offset" : _set_Y_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Y.setter
    def Y(self, y:float) -> None:
        return self._intf.set_property(IAgCartesian2Vector._metadata, IAgCartesian2Vector._set_Y_metadata, y)

    _Get_metadata = { "offset" : _Get_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE), POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def Get(self) -> typing.Tuple[float, float]:
        """Returns cartesian vector."""
        return self._intf.invoke(IAgCartesian2Vector._metadata, IAgCartesian2Vector._Get_metadata, OutArg(), OutArg())

    _Set_metadata = { "offset" : _Set_method_offset,
            "arg_types" : (agcom.DOUBLE, agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def Set(self, x:float, y:float) -> None:
        """Sets cartesian vector."""
        return self._intf.invoke(IAgCartesian2Vector._metadata, IAgCartesian2Vector._Set_metadata, x, y)

    _ToArray_metadata = { "offset" : _ToArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def ToArray(self) -> list:
        """Returns coordinates as an array."""
        return self._intf.invoke(IAgCartesian2Vector._metadata, IAgCartesian2Vector._ToArray_metadata, OutArg())

    _property_names[X] = "X"
    _property_names[Y] = "Y"


agcls.AgClassCatalog.add_catalog_entry((5417927181131422679, 3111395435573516163), IAgCartesian2Vector)
agcls.AgTypeNameMap["IAgCartesian2Vector"] = IAgCartesian2Vector

class IAgUnitPrefsDim(object):
    """Provides info on a Dimension from the global unit table."""

    _num_methods = 5
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Id_method_offset = 1
    _get_Name_method_offset = 2
    _get_AvailableUnits_method_offset = 3
    _get_CurrentUnit_method_offset = 4
    _SetCurrentUnit_method_offset = 5
    _metadata = {
        "iid_data" : (5032801830880833533, 18057669493672743825),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUnitPrefsDim."""
        initialize_from_source_object(self, sourceObject, IAgUnitPrefsDim)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUnitPrefsDim)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUnitPrefsDim, None)
    
    _get_Id_metadata = { "offset" : _get_Id_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Id(self) -> int:
        """Returns the ID of the dimension."""
        return self._intf.get_property(IAgUnitPrefsDim._metadata, IAgUnitPrefsDim._get_Id_metadata)

    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Returns the current Dimension's full name."""
        return self._intf.get_property(IAgUnitPrefsDim._metadata, IAgUnitPrefsDim._get_Name_metadata)

    _get_AvailableUnits_metadata = { "offset" : _get_AvailableUnits_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def AvailableUnits(self) -> "IAgUnitPrefsUnitCollection":
        """Returns collection of Units."""
        return self._intf.get_property(IAgUnitPrefsDim._metadata, IAgUnitPrefsDim._get_AvailableUnits_metadata)

    _get_CurrentUnit_metadata = { "offset" : _get_CurrentUnit_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def CurrentUnit(self) -> "IAgUnitPrefsUnit":
        """Returns the current unit for this dimension."""
        return self._intf.get_property(IAgUnitPrefsDim._metadata, IAgUnitPrefsDim._get_CurrentUnit_metadata)

    _SetCurrentUnit_metadata = { "offset" : _SetCurrentUnit_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def SetCurrentUnit(self, unitAbbrv:str) -> None:
        """Sets the Unit for this simple dimension."""
        return self._intf.invoke(IAgUnitPrefsDim._metadata, IAgUnitPrefsDim._SetCurrentUnit_metadata, unitAbbrv)

    _property_names[Id] = "Id"
    _property_names[Name] = "Name"
    _property_names[AvailableUnits] = "AvailableUnits"
    _property_names[CurrentUnit] = "CurrentUnit"


agcls.AgClassCatalog.add_catalog_entry((5032801830880833533, 18057669493672743825), IAgUnitPrefsDim)
agcls.AgTypeNameMap["IAgUnitPrefsDim"] = IAgUnitPrefsDim

class IAgPropertyInfo(object):
    """Property information."""

    _num_methods = 8
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Name_method_offset = 1
    _get_PropertyType_method_offset = 2
    _GetValue_method_offset = 3
    _SetValue_method_offset = 4
    _get_HasMin_method_offset = 5
    _get_HasMax_method_offset = 6
    _get_Min_method_offset = 7
    _get_Max_method_offset = 8
    _metadata = {
        "iid_data" : (5736951962975636299, 3080140686805457046),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgPropertyInfo."""
        initialize_from_source_object(self, sourceObject, IAgPropertyInfo)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgPropertyInfo)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgPropertyInfo, None)
    
    _get_Name_metadata = { "offset" : _get_Name_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Name(self) -> str:
        """Get the name of the property."""
        return self._intf.get_property(IAgPropertyInfo._metadata, IAgPropertyInfo._get_Name_metadata)

    _get_PropertyType_metadata = { "offset" : _get_PropertyType_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEPropertyInfoValueType),) }
    @property
    def PropertyType(self) -> "AgEPropertyInfoValueType":
        """Get the type of property."""
        return self._intf.get_property(IAgPropertyInfo._metadata, IAgPropertyInfo._get_PropertyType_metadata)

    _GetValue_metadata = { "offset" : _GetValue_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    def GetValue(self) -> typing.Any:
        """Get the value of the property. Use PropertyType to determine the type to cast to."""
        return self._intf.invoke(IAgPropertyInfo._metadata, IAgPropertyInfo._GetValue_metadata, OutArg())

    _SetValue_metadata = { "offset" : _SetValue_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    def SetValue(self, propertyInfo:typing.Any) -> None:
        """Set the value of the property. Use PropertyType to determine the type to cast to."""
        return self._intf.invoke(IAgPropertyInfo._metadata, IAgPropertyInfo._SetValue_metadata, propertyInfo)

    _get_HasMin_metadata = { "offset" : _get_HasMin_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def HasMin(self) -> bool:
        """Determine if the property has a minimum value."""
        return self._intf.get_property(IAgPropertyInfo._metadata, IAgPropertyInfo._get_HasMin_metadata)

    _get_HasMax_metadata = { "offset" : _get_HasMax_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def HasMax(self) -> bool:
        """Determine if the property has a maximum value."""
        return self._intf.get_property(IAgPropertyInfo._metadata, IAgPropertyInfo._get_HasMax_metadata)

    _get_Min_metadata = { "offset" : _get_Min_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Min(self) -> typing.Any:
        """Get the minimum value of this property. Use PropertyType to determine the type to cast to."""
        return self._intf.get_property(IAgPropertyInfo._metadata, IAgPropertyInfo._get_Min_metadata)

    _get_Max_metadata = { "offset" : _get_Max_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def Max(self) -> typing.Any:
        """Get the maximum value of this property. Use PropertyType to determine the type to cast to."""
        return self._intf.get_property(IAgPropertyInfo._metadata, IAgPropertyInfo._get_Max_metadata)

    _property_names[Name] = "Name"
    _property_names[PropertyType] = "PropertyType"
    _property_names[HasMin] = "HasMin"
    _property_names[HasMax] = "HasMax"
    _property_names[Min] = "Min"
    _property_names[Max] = "Max"


agcls.AgClassCatalog.add_catalog_entry((5736951962975636299, 3080140686805457046), IAgPropertyInfo)
agcls.AgTypeNameMap["IAgPropertyInfo"] = IAgPropertyInfo

class IAgPropertyInfoCollection(object):
    """The collection of properties."""

    _num_methods = 5
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Item_method_offset = 1
    _get__NewEnum_method_offset = 2
    _get_Count_method_offset = 3
    _GetItemByIndex_method_offset = 4
    _GetItemByName_method_offset = 5
    _metadata = {
        "iid_data" : (5399003801100116608, 9751059917458695069),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgPropertyInfoCollection."""
        initialize_from_source_object(self, sourceObject, IAgPropertyInfoCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgPropertyInfoCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgPropertyInfoCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgPropertyInfoCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgPropertyInfo":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.VARIANT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, indexOrName:typing.Any) -> "IAgPropertyInfo":
        """Allows the user to iterate through the properties."""
        return self._intf.invoke(IAgPropertyInfoCollection._metadata, IAgPropertyInfoCollection._Item_metadata, indexOrName, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Enumerates through the properties."""
        return self._intf.get_property(IAgPropertyInfoCollection._metadata, IAgPropertyInfoCollection._get__NewEnum_metadata)

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Get the number of properties available."""
        return self._intf.get_property(IAgPropertyInfoCollection._metadata, IAgPropertyInfoCollection._get_Count_metadata)

    _GetItemByIndex_metadata = { "offset" : _GetItemByIndex_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByIndex(self, index:int) -> "IAgPropertyInfo":
        """Retrieves a property from the collection by index."""
        return self._intf.invoke(IAgPropertyInfoCollection._metadata, IAgPropertyInfoCollection._GetItemByIndex_metadata, index, OutArg())

    _GetItemByName_metadata = { "offset" : _GetItemByName_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByName(self, name:str) -> "IAgPropertyInfo":
        """Retrieves a property from the collection by name."""
        return self._intf.invoke(IAgPropertyInfoCollection._metadata, IAgPropertyInfoCollection._GetItemByName_metadata, name, OutArg())

    __getitem__ = Item


    _property_names[_NewEnum] = "_NewEnum"
    _property_names[Count] = "Count"


agcls.AgClassCatalog.add_catalog_entry((5399003801100116608, 9751059917458695069), IAgPropertyInfoCollection)
agcls.AgTypeNameMap["IAgPropertyInfoCollection"] = IAgPropertyInfoCollection

class IAgRuntimeTypeInfo(object):
    """Interface used to retrieve the properties at runtime."""

    _num_methods = 4
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Properties_method_offset = 1
    _get_IsCollection_method_offset = 2
    _get_Count_method_offset = 3
    _GetItem_method_offset = 4
    _metadata = {
        "iid_data" : (4697700289115359020, 4542123673636119719),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgRuntimeTypeInfo."""
        initialize_from_source_object(self, sourceObject, IAgRuntimeTypeInfo)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgRuntimeTypeInfo)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgRuntimeTypeInfo, None)
    
    _get_Properties_metadata = { "offset" : _get_Properties_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Properties(self) -> "IAgPropertyInfoCollection":
        """Get the collection of properties."""
        return self._intf.get_property(IAgRuntimeTypeInfo._metadata, IAgRuntimeTypeInfo._get_Properties_metadata)

    _get_IsCollection_metadata = { "offset" : _get_IsCollection_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsCollection(self) -> bool:
        """Determines if the interface is a collection."""
        return self._intf.get_property(IAgRuntimeTypeInfo._metadata, IAgRuntimeTypeInfo._get_IsCollection_metadata)

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """If the interface is a collection, returns the collection count."""
        return self._intf.get_property(IAgRuntimeTypeInfo._metadata, IAgRuntimeTypeInfo._get_Count_metadata)

    _GetItem_metadata = { "offset" : _GetItem_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgInterface_out_arg,) }
    def GetItem(self, index:int) -> "IAgPropertyInfo":
        """Returns the property of the collection at the given index."""
        return self._intf.invoke(IAgRuntimeTypeInfo._metadata, IAgRuntimeTypeInfo._GetItem_metadata, index, OutArg())

    _property_names[Properties] = "Properties"
    _property_names[IsCollection] = "IsCollection"
    _property_names[Count] = "Count"


agcls.AgClassCatalog.add_catalog_entry((4697700289115359020, 4542123673636119719), IAgRuntimeTypeInfo)
agcls.AgTypeNameMap["IAgRuntimeTypeInfo"] = IAgRuntimeTypeInfo

class IAgRuntimeTypeInfoProvider(object):
    """Access point for IAgRuntimeTypeInfo."""

    _num_methods = 1
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_ProvideRuntimeTypeInfo_method_offset = 1
    _metadata = {
        "iid_data" : (4856983295523357109, 1229146414855014286),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgRuntimeTypeInfoProvider."""
        initialize_from_source_object(self, sourceObject, IAgRuntimeTypeInfoProvider)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgRuntimeTypeInfoProvider)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgRuntimeTypeInfoProvider, None)
    
    _get_ProvideRuntimeTypeInfo_metadata = { "offset" : _get_ProvideRuntimeTypeInfo_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def ProvideRuntimeTypeInfo(self) -> "IAgRuntimeTypeInfo":
        """Returns the IAgRuntimeTypeInfo interface to access properties at runtime."""
        return self._intf.get_property(IAgRuntimeTypeInfoProvider._metadata, IAgRuntimeTypeInfoProvider._get_ProvideRuntimeTypeInfo_metadata)

    _property_names[ProvideRuntimeTypeInfo] = "ProvideRuntimeTypeInfo"


agcls.AgClassCatalog.add_catalog_entry((4856983295523357109, 1229146414855014286), IAgRuntimeTypeInfoProvider)
agcls.AgTypeNameMap["IAgRuntimeTypeInfoProvider"] = IAgRuntimeTypeInfoProvider

class IAgExecCmdResult(object):
    """Collection of strings returned by the ExecuteCommand."""

    _num_methods = 5
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _Range_method_offset = 4
    _get_IsSucceeded_method_offset = 5
    _metadata = {
        "iid_data" : (5532952564068017084, 6961682191463635117),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgExecCmdResult."""
        initialize_from_source_object(self, sourceObject, IAgExecCmdResult)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgExecCmdResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgExecCmdResult, None)
    def __iter__(self):
        """Create an iterator for the IAgExecCmdResult object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> str:
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Number of elements contained in the collection."""
        return self._intf.get_property(IAgExecCmdResult._metadata, IAgExecCmdResult._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.BSTR_arg,) }
    def Item(self, index:int) -> str:
        """Gets the element at the specified index (0-based)."""
        return self._intf.invoke(IAgExecCmdResult._metadata, IAgExecCmdResult._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an object that can be used to iterate through all the strings in the collection."""
        return self._intf.get_property(IAgExecCmdResult._metadata, IAgExecCmdResult._get__NewEnum_metadata)

    _Range_metadata = { "offset" : _Range_method_offset,
            "arg_types" : (agcom.LONG, agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.LONG_arg, agmarshall.LPSAFEARRAY_arg,) }
    def Range(self, startIndex:int, stopIndex:int) -> list:
        """Return the elements within the specified range."""
        return self._intf.invoke(IAgExecCmdResult._metadata, IAgExecCmdResult._Range_metadata, startIndex, stopIndex, OutArg())

    _get_IsSucceeded_metadata = { "offset" : _get_IsSucceeded_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT_BOOL),),
            "marshallers" : (agmarshall.VARIANT_BOOL_arg,) }
    @property
    def IsSucceeded(self) -> bool:
        """Indicates whether the object contains valid results."""
        return self._intf.get_property(IAgExecCmdResult._metadata, IAgExecCmdResult._get_IsSucceeded_metadata)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"
    _property_names[IsSucceeded] = "IsSucceeded"


agcls.AgClassCatalog.add_catalog_entry((5532952564068017084, 6961682191463635117), IAgExecCmdResult)
agcls.AgTypeNameMap["IAgExecCmdResult"] = IAgExecCmdResult

class IAgExecMultiCmdResult(object):
    """Collection of objects returned by the ExecuteMultipleCommands."""

    _num_methods = 3
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _get_Count_method_offset = 1
    _Item_method_offset = 2
    _get__NewEnum_method_offset = 3
    _metadata = {
        "iid_data" : (5271171048043179548, 17166981793534785703),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgExecMultiCmdResult."""
        initialize_from_source_object(self, sourceObject, IAgExecMultiCmdResult)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgExecMultiCmdResult)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgExecMultiCmdResult, None)
    def __iter__(self):
        """Create an iterator for the IAgExecMultiCmdResult object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgExecCmdResult":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Number of elements contained in the collection."""
        return self._intf.get_property(IAgExecMultiCmdResult._metadata, IAgExecMultiCmdResult._get_Count_metadata)

    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, index:int) -> "IAgExecCmdResult":
        """Gets the element at the specified index (0-based)."""
        return self._intf.invoke(IAgExecMultiCmdResult._metadata, IAgExecMultiCmdResult._Item_metadata, index, OutArg())

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an object that can be used to iterate through all the objects in the collection."""
        return self._intf.get_property(IAgExecMultiCmdResult._metadata, IAgExecMultiCmdResult._get__NewEnum_metadata)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5271171048043179548, 17166981793534785703), IAgExecMultiCmdResult)
agcls.AgTypeNameMap["IAgExecMultiCmdResult"] = IAgExecMultiCmdResult

class IAgUnitPrefsUnit(object):
    """Provides info about a unit."""

    _num_methods = 4
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_FullName_method_offset = 1
    _get_Abbrv_method_offset = 2
    _get_Id_method_offset = 3
    _get_Dimension_method_offset = 4
    _metadata = {
        "iid_data" : (5635454554877079377, 14141992965915125166),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUnitPrefsUnit."""
        initialize_from_source_object(self, sourceObject, IAgUnitPrefsUnit)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUnitPrefsUnit)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUnitPrefsUnit, None)
    
    _get_FullName_metadata = { "offset" : _get_FullName_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def FullName(self) -> str:
        """Returns the fullname of the unit."""
        return self._intf.get_property(IAgUnitPrefsUnit._metadata, IAgUnitPrefsUnit._get_FullName_metadata)

    _get_Abbrv_metadata = { "offset" : _get_Abbrv_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Abbrv(self) -> str:
        """Returns the abbreviation of the unit."""
        return self._intf.get_property(IAgUnitPrefsUnit._metadata, IAgUnitPrefsUnit._get_Abbrv_metadata)

    _get_Id_metadata = { "offset" : _get_Id_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Id(self) -> int:
        """Returns the ID of the unit."""
        return self._intf.get_property(IAgUnitPrefsUnit._metadata, IAgUnitPrefsUnit._get_Id_metadata)

    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    @property
    def Dimension(self) -> "IAgUnitPrefsDim":
        """Returns the Dimension for this unit."""
        return self._intf.get_property(IAgUnitPrefsUnit._metadata, IAgUnitPrefsUnit._get_Dimension_metadata)

    _property_names[FullName] = "FullName"
    _property_names[Abbrv] = "Abbrv"
    _property_names[Id] = "Id"
    _property_names[Dimension] = "Dimension"


agcls.AgClassCatalog.add_catalog_entry((5635454554877079377, 14141992965915125166), IAgUnitPrefsUnit)
agcls.AgTypeNameMap["IAgUnitPrefsUnit"] = IAgUnitPrefsUnit

class IAgUnitPrefsUnitCollection(object):
    """Provides access to the Unit collection."""

    _num_methods = 5
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Item_method_offset = 1
    _get_Count_method_offset = 2
    _get__NewEnum_method_offset = 3
    _GetItemByIndex_method_offset = 4
    _GetItemByName_method_offset = 5
    _metadata = {
        "iid_data" : (5470923714325537781, 12978283017277731717),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUnitPrefsUnitCollection."""
        initialize_from_source_object(self, sourceObject, IAgUnitPrefsUnitCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUnitPrefsUnitCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUnitPrefsUnitCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgUnitPrefsUnitCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgUnitPrefsUnit":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.VARIANT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, indexOrName:typing.Any) -> "IAgUnitPrefsUnit":
        """Returns the specific item in the collection given a unit identifier or an index."""
        return self._intf.invoke(IAgUnitPrefsUnitCollection._metadata, IAgUnitPrefsUnitCollection._Item_metadata, indexOrName, OutArg())

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of items in the collection."""
        return self._intf.get_property(IAgUnitPrefsUnitCollection._metadata, IAgUnitPrefsUnitCollection._get_Count_metadata)

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns an enumeration of AgUnitPrefsUnit."""
        return self._intf.get_property(IAgUnitPrefsUnitCollection._metadata, IAgUnitPrefsUnitCollection._get__NewEnum_metadata)

    _GetItemByIndex_metadata = { "offset" : _GetItemByIndex_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByIndex(self, index:int) -> "IAgUnitPrefsUnit":
        """Retrieves a unit from the collection by index."""
        return self._intf.invoke(IAgUnitPrefsUnitCollection._metadata, IAgUnitPrefsUnitCollection._GetItemByIndex_metadata, index, OutArg())

    _GetItemByName_metadata = { "offset" : _GetItemByName_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByName(self, name:str) -> "IAgUnitPrefsUnit":
        """Retrieves a unit from the collection by name."""
        return self._intf.invoke(IAgUnitPrefsUnitCollection._metadata, IAgUnitPrefsUnitCollection._GetItemByName_metadata, name, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((5470923714325537781, 12978283017277731717), IAgUnitPrefsUnitCollection)
agcls.AgTypeNameMap["IAgUnitPrefsUnitCollection"] = IAgUnitPrefsUnitCollection

class IAgUnitPrefsDimCollection(object):
    """Provides accesses to the global unit table."""

    _num_methods = 12
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Item_method_offset = 1
    _get_Count_method_offset = 2
    _SetCurrentUnit_method_offset = 3
    _GetCurrentUnitAbbrv_method_offset = 4
    _get_MissionElapsedTime_method_offset = 5
    _set_MissionElapsedTime_method_offset = 6
    _get_JulianDateOffset_method_offset = 7
    _set_JulianDateOffset_method_offset = 8
    _get__NewEnum_method_offset = 9
    _ResetUnits_method_offset = 10
    _GetItemByIndex_method_offset = 11
    _GetItemByName_method_offset = 12
    _metadata = {
        "iid_data" : (4785890395549473833, 4361686517023815598),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgUnitPrefsDimCollection."""
        initialize_from_source_object(self, sourceObject, IAgUnitPrefsDimCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgUnitPrefsDimCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgUnitPrefsDimCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgUnitPrefsDimCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> "IAgUnitPrefsDim":
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.VARIANT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.AgInterface_out_arg,) }
    def Item(self, indexOrName:typing.Any) -> "IAgUnitPrefsDim":
        """Returns an IAgUnitPrefsDim given a Dimension name or an index."""
        return self._intf.invoke(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._Item_metadata, indexOrName, OutArg())

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of items in the collection."""
        return self._intf.get_property(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._get_Count_metadata)

    _SetCurrentUnit_metadata = { "offset" : _SetCurrentUnit_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def SetCurrentUnit(self, dimension:str, unitAbbrv:str) -> None:
        """Returns the Current unit for a Dimension."""
        return self._intf.invoke(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._SetCurrentUnit_metadata, dimension, unitAbbrv)

    _GetCurrentUnitAbbrv_metadata = { "offset" : _GetCurrentUnitAbbrv_method_offset,
            "arg_types" : (agcom.VARIANT, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.VARIANT_arg, agmarshall.BSTR_arg,) }
    def GetCurrentUnitAbbrv(self, indexOrDimName:typing.Any) -> str:
        """Returns the Current Unit for a Dimension."""
        return self._intf.invoke(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._GetCurrentUnitAbbrv_metadata, indexOrDimName, OutArg())

    _get_MissionElapsedTime_metadata = { "offset" : _get_MissionElapsedTime_method_offset,
            "arg_types" : (POINTER(agcom.VARIANT),),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @property
    def MissionElapsedTime(self) -> typing.Any:
        """The MissionElapsedTime."""
        return self._intf.get_property(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._get_MissionElapsedTime_metadata)

    _set_MissionElapsedTime_metadata = { "offset" : _set_MissionElapsedTime_method_offset,
            "arg_types" : (agcom.VARIANT,),
            "marshallers" : (agmarshall.VARIANT_arg,) }
    @MissionElapsedTime.setter
    def MissionElapsedTime(self, pMisElapTime:typing.Any) -> None:
        return self._intf.set_property(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._set_MissionElapsedTime_metadata, pMisElapTime)

    _get_JulianDateOffset_metadata = { "offset" : _get_JulianDateOffset_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def JulianDateOffset(self) -> float:
        """The JulianDateOffset."""
        return self._intf.get_property(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._get_JulianDateOffset_metadata)

    _set_JulianDateOffset_metadata = { "offset" : _set_JulianDateOffset_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @JulianDateOffset.setter
    def JulianDateOffset(self, pJDateOffset:float) -> None:
        return self._intf.set_property(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._set_JulianDateOffset_metadata, pJDateOffset)

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns a collection of IAgUnitPrefsDim."""
        return self._intf.get_property(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._get__NewEnum_metadata)

    _ResetUnits_metadata = { "offset" : _ResetUnits_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def ResetUnits(self) -> None:
        """Resets the unitpreferences to the Default units."""
        return self._intf.invoke(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._ResetUnits_metadata, )

    _GetItemByIndex_metadata = { "offset" : _GetItemByIndex_method_offset,
            "arg_types" : (agcom.INT, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.INT_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByIndex(self, index:int) -> "IAgUnitPrefsDim":
        """Retrieves a dimension from the collection by index."""
        return self._intf.invoke(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._GetItemByIndex_metadata, index, OutArg())

    _GetItemByName_metadata = { "offset" : _GetItemByName_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def GetItemByName(self, name:str) -> "IAgUnitPrefsDim":
        """Retrieves a dimension from the collection by name."""
        return self._intf.invoke(IAgUnitPrefsDimCollection._metadata, IAgUnitPrefsDimCollection._GetItemByName_metadata, name, OutArg())

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[MissionElapsedTime] = "MissionElapsedTime"
    _property_names[JulianDateOffset] = "JulianDateOffset"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((4785890395549473833, 4361686517023815598), IAgUnitPrefsDimCollection)
agcls.AgTypeNameMap["IAgUnitPrefsDimCollection"] = IAgUnitPrefsDimCollection

class IAgQuantity(object):
    """Provides helper methods for a quantity."""

    _num_methods = 9
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _get_Dimension_method_offset = 1
    _get_Unit_method_offset = 2
    _ConvertToUnit_method_offset = 3
    _get_Value_method_offset = 4
    _set_Value_method_offset = 5
    _Add_method_offset = 6
    _Subtract_method_offset = 7
    _MultiplyQty_method_offset = 8
    _DivideQty_method_offset = 9
    _metadata = {
        "iid_data" : (4847092431830365084, 7729483638506016434),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgQuantity."""
        initialize_from_source_object(self, sourceObject, IAgQuantity)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgQuantity)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgQuantity, None)
    
    _get_Dimension_metadata = { "offset" : _get_Dimension_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Dimension(self) -> str:
        """Gets the name of the dimension."""
        return self._intf.get_property(IAgQuantity._metadata, IAgQuantity._get_Dimension_metadata)

    _get_Unit_metadata = { "offset" : _get_Unit_method_offset,
            "arg_types" : (POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg,) }
    @property
    def Unit(self) -> str:
        """Get the current Unit abbreviation."""
        return self._intf.get_property(IAgQuantity._metadata, IAgQuantity._get_Unit_metadata)

    _ConvertToUnit_metadata = { "offset" : _ConvertToUnit_method_offset,
            "arg_types" : (agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg,) }
    def ConvertToUnit(self, unitAbbrv:str) -> None:
        """Changes the value in this quantity to the specified unit."""
        return self._intf.invoke(IAgQuantity._metadata, IAgQuantity._ConvertToUnit_metadata, unitAbbrv)

    _get_Value_metadata = { "offset" : _get_Value_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def Value(self) -> float:
        """Gets or sets the current value."""
        return self._intf.get_property(IAgQuantity._metadata, IAgQuantity._get_Value_metadata)

    _set_Value_metadata = { "offset" : _set_Value_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @Value.setter
    def Value(self, value:float) -> None:
        return self._intf.set_property(IAgQuantity._metadata, IAgQuantity._set_Value_metadata, value)

    _Add_metadata = { "offset" : _Add_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgQuantity"), agmarshall.AgInterface_out_arg,) }
    def Add(self, quantity:"IAgQuantity") -> "IAgQuantity":
        """Adds the value from the IAgQuantity interface to this interface. Returns a new IAgQuantity. The dimensions must be similar."""
        return self._intf.invoke(IAgQuantity._metadata, IAgQuantity._Add_metadata, quantity, OutArg())

    _Subtract_metadata = { "offset" : _Subtract_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgQuantity"), agmarshall.AgInterface_out_arg,) }
    def Subtract(self, quantity:"IAgQuantity") -> "IAgQuantity":
        """Subtracts the value from the IAgQuantity interface to this interface. Returns a new IAgQuantity. The dimensions must be similar."""
        return self._intf.invoke(IAgQuantity._metadata, IAgQuantity._Subtract_metadata, quantity, OutArg())

    _MultiplyQty_metadata = { "offset" : _MultiplyQty_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgQuantity"), agmarshall.AgInterface_out_arg,) }
    def MultiplyQty(self, quantity:"IAgQuantity") -> "IAgQuantity":
        """Multiplies the value from the IAgQuantity interface to this interface. Returns a new IAgQuantity. The dimensions must be similar."""
        return self._intf.invoke(IAgQuantity._metadata, IAgQuantity._MultiplyQty_metadata, quantity, OutArg())

    _DivideQty_metadata = { "offset" : _DivideQty_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgQuantity"), agmarshall.AgInterface_out_arg,) }
    def DivideQty(self, quantity:"IAgQuantity") -> "IAgQuantity":
        """Divides the value from the IAgQuantity interface to this interface. The dimensions must be similar."""
        return self._intf.invoke(IAgQuantity._metadata, IAgQuantity._DivideQty_metadata, quantity, OutArg())

    _property_names[Dimension] = "Dimension"
    _property_names[Unit] = "Unit"
    _property_names[Value] = "Value"


agcls.AgClassCatalog.add_catalog_entry((4847092431830365084, 7729483638506016434), IAgQuantity)
agcls.AgTypeNameMap["IAgQuantity"] = IAgQuantity

class IAgDate(object):
    """Provides helper methods for a date."""

    _num_methods = 15
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _Format_method_offset = 1
    _SetDate_method_offset = 2
    _get_OLEDate_method_offset = 3
    _set_OLEDate_method_offset = 4
    _get_WholeDays_method_offset = 5
    _set_WholeDays_method_offset = 6
    _get_SecIntoDay_method_offset = 7
    _set_SecIntoDay_method_offset = 8
    _get_WholeDaysUTC_method_offset = 9
    _set_WholeDaysUTC_method_offset = 10
    _get_SecIntoDayUTC_method_offset = 11
    _set_SecIntoDayUTC_method_offset = 12
    _Add_method_offset = 13
    _Subtract_method_offset = 14
    _Span_method_offset = 15
    _metadata = {
        "iid_data" : (4839709052320147977, 10626775382734749074),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDate."""
        initialize_from_source_object(self, sourceObject, IAgDate)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDate)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDate, None)
    
    _Format_metadata = { "offset" : _Format_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def Format(self, unit:str) -> str:
        """Returns the value of the date given the unit."""
        return self._intf.invoke(IAgDate._metadata, IAgDate._Format_metadata, unit, OutArg())

    _SetDate_metadata = { "offset" : _SetDate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR,),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def SetDate(self, unit:str, value:str) -> None:
        """Sets this date with the given date value and unit type."""
        return self._intf.invoke(IAgDate._metadata, IAgDate._SetDate_metadata, unit, value)

    _get_OLEDate_metadata = { "offset" : _get_OLEDate_method_offset,
            "arg_types" : (POINTER(agcom.DATE),),
            "marshallers" : (agmarshall.DATE_arg,) }
    @property
    def OLEDate(self) -> datetime:
        """Gets or sets the current time in OLE DATE Format."""
        return self._intf.get_property(IAgDate._metadata, IAgDate._get_OLEDate_metadata)

    _set_OLEDate_metadata = { "offset" : _set_OLEDate_method_offset,
            "arg_types" : (agcom.DATE,),
            "marshallers" : (agmarshall.DATE_arg,) }
    @OLEDate.setter
    def OLEDate(self, inVal:datetime) -> None:
        return self._intf.set_property(IAgDate._metadata, IAgDate._set_OLEDate_metadata, inVal)

    _get_WholeDays_metadata = { "offset" : _get_WholeDays_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def WholeDays(self) -> int:
        """Gets or sets the Julian Day Number of the date of interest."""
        return self._intf.get_property(IAgDate._metadata, IAgDate._get_WholeDays_metadata)

    _set_WholeDays_metadata = { "offset" : _set_WholeDays_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @WholeDays.setter
    def WholeDays(self, wholeDays:int) -> None:
        return self._intf.set_property(IAgDate._metadata, IAgDate._set_WholeDays_metadata, wholeDays)

    _get_SecIntoDay_metadata = { "offset" : _get_SecIntoDay_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SecIntoDay(self) -> float:
        """Contains values between 0.0 and 86400 with the exception of when the date is inside a leap second in which case the SecIntoDay can become as large as 86401.0."""
        return self._intf.get_property(IAgDate._metadata, IAgDate._get_SecIntoDay_metadata)

    _set_SecIntoDay_metadata = { "offset" : _set_SecIntoDay_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @SecIntoDay.setter
    def SecIntoDay(self, secIntoDay:float) -> None:
        return self._intf.set_property(IAgDate._metadata, IAgDate._set_SecIntoDay_metadata, secIntoDay)

    _get_WholeDaysUTC_metadata = { "offset" : _get_WholeDaysUTC_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def WholeDaysUTC(self) -> int:
        """Gets or sets the UTC Day Number of the date of interest."""
        return self._intf.get_property(IAgDate._metadata, IAgDate._get_WholeDaysUTC_metadata)

    _set_WholeDaysUTC_metadata = { "offset" : _set_WholeDaysUTC_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    @WholeDaysUTC.setter
    def WholeDaysUTC(self, wholeDays:int) -> None:
        return self._intf.set_property(IAgDate._metadata, IAgDate._set_WholeDaysUTC_metadata, wholeDays)

    _get_SecIntoDayUTC_metadata = { "offset" : _get_SecIntoDayUTC_method_offset,
            "arg_types" : (POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @property
    def SecIntoDayUTC(self) -> float:
        """Contains values between 0.0 and 86400 with the exception of when the date is inside a leap second in which case the SecIntoDay can become as large as 86401.0."""
        return self._intf.get_property(IAgDate._metadata, IAgDate._get_SecIntoDayUTC_metadata)

    _set_SecIntoDayUTC_metadata = { "offset" : _set_SecIntoDayUTC_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    @SecIntoDayUTC.setter
    def SecIntoDayUTC(self, secIntoDay:float) -> None:
        return self._intf.set_property(IAgDate._metadata, IAgDate._set_SecIntoDayUTC_metadata, secIntoDay)

    _Add_metadata = { "offset" : _Add_method_offset,
            "arg_types" : (agcom.BSTR, agcom.DOUBLE, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.AgInterface_out_arg,) }
    def Add(self, unit:str, value:float) -> "IAgDate":
        """Adds the value in the given unit and returns a new date interface."""
        return self._intf.invoke(IAgDate._metadata, IAgDate._Add_metadata, unit, value, OutArg())

    _Subtract_metadata = { "offset" : _Subtract_method_offset,
            "arg_types" : (agcom.BSTR, agcom.DOUBLE, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.AgInterface_out_arg,) }
    def Subtract(self, unit:str, value:float) -> "IAgDate":
        """Subtracts the value in the given unit and returns a new date interface."""
        return self._intf.invoke(IAgDate._metadata, IAgDate._Subtract_metadata, unit, value, OutArg())

    _Span_metadata = { "offset" : _Span_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgDate"), agmarshall.AgInterface_out_arg,) }
    def Span(self, date:"IAgDate") -> "IAgQuantity":
        """Subtracts the value from the IAgDate interface and returns an IAgQuantity."""
        return self._intf.invoke(IAgDate._metadata, IAgDate._Span_metadata, date, OutArg())

    _property_names[OLEDate] = "OLEDate"
    _property_names[WholeDays] = "WholeDays"
    _property_names[SecIntoDay] = "SecIntoDay"
    _property_names[WholeDaysUTC] = "WholeDaysUTC"
    _property_names[SecIntoDayUTC] = "SecIntoDayUTC"


agcls.AgClassCatalog.add_catalog_entry((4839709052320147977, 10626775382734749074), IAgDate)
agcls.AgTypeNameMap["IAgDate"] = IAgDate

class IAgConversionUtility(object):
    """Provides conversion utilities."""

    _num_methods = 18
    _vtable_offset = IUnknown._vtable_offset + IUnknown._num_methods
    _ConvertQuantity_method_offset = 1
    _ConvertDate_method_offset = 2
    _ConvertQuantityArray_method_offset = 3
    _ConvertDateArray_method_offset = 4
    _NewQuantity_method_offset = 5
    _NewDate_method_offset = 6
    _NewPositionOnEarth_method_offset = 7
    _ConvertPositionArray_method_offset = 8
    _NewDirection_method_offset = 9
    _NewOrientation_method_offset = 10
    _NewOrbitStateOnEarth_method_offset = 11
    _NewPositionOnCB_method_offset = 12
    _NewOrbitStateOnCB_method_offset = 13
    _QueryDirectionCosineMatrix_method_offset = 14
    _QueryDirectionCosineMatrixArray_method_offset = 15
    _NewCartesian3Vector_method_offset = 16
    _NewCartesian3VectorFromDirection_method_offset = 17
    _NewCartesian3VectorFromPosition_method_offset = 18
    _metadata = {
        "iid_data" : (5269429572990182626, 2030319770630291336),
        "vtable_reference" : IUnknown._vtable_offset + IUnknown._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgConversionUtility."""
        initialize_from_source_object(self, sourceObject, IAgConversionUtility)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgConversionUtility)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgConversionUtility, None)
    
    _ConvertQuantity_metadata = { "offset" : _ConvertQuantity_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, agcom.DOUBLE, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.DOUBLE_arg,) }
    def ConvertQuantity(self, dimensionName:str, fromUnit:str, toUnit:str, fromValue:float) -> float:
        """Converts the specified quantity value from a given unit to another unit."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._ConvertQuantity_metadata, dimensionName, fromUnit, toUnit, fromValue, OutArg())

    _ConvertDate_metadata = { "offset" : _ConvertDate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.BSTR),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg,) }
    def ConvertDate(self, fromUnit:str, toUnit:str, fromValue:str) -> str:
        """Converts the specified date from a given unit to another unit."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._ConvertDate_metadata, fromUnit, toUnit, fromValue, OutArg())

    _ConvertQuantityArray_metadata = { "offset" : _ConvertQuantityArray_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.BSTR, POINTER(agcom.LPSAFEARRAY), POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LPSAFEARRAY_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertQuantityArray(self, dimensionName:str, fromUnit:str, toUnit:str, quantityValues:list) -> list:
        """Converts the specified quantity values from a given unit to another unit."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._ConvertQuantityArray_metadata, dimensionName, fromUnit, toUnit, quantityValues, OutArg())

    _ConvertDateArray_metadata = { "offset" : _ConvertDateArray_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.LPSAFEARRAY), POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.LPSAFEARRAY_arg, agmarshall.LPSAFEARRAY_arg,) }
    def ConvertDateArray(self, fromUnit:str, toUnit:str, fromValues:list) -> list:
        """Converts the specified dates from a given unit to another unit."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._ConvertDateArray_metadata, fromUnit, toUnit, fromValues, OutArg())

    _NewQuantity_metadata = { "offset" : _NewQuantity_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, agcom.DOUBLE, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.DOUBLE_arg, agmarshall.AgInterface_out_arg,) }
    def NewQuantity(self, dimension:str, unitAbbrv:str, value:float) -> "IAgQuantity":
        """Creates an IAgQuantity interface with the given dimension, unit and value."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewQuantity_metadata, dimension, unitAbbrv, value, OutArg())

    _NewDate_metadata = { "offset" : _NewDate_method_offset,
            "arg_types" : (agcom.BSTR, agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def NewDate(self, unitAbbrv:str, value:str) -> "IAgDate":
        """Creates an IAgDate interface with the given unit and value."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewDate_metadata, unitAbbrv, value, OutArg())

    _NewPositionOnEarth_metadata = { "offset" : _NewPositionOnEarth_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def NewPositionOnEarth(self) -> "IAgPosition":
        """Creates an IAgPosition interface with earth as its central body."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewPositionOnEarth_metadata, OutArg())

    _ConvertPositionArray_metadata = { "offset" : _ConvertPositionArray_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.LPSAFEARRAY), agcom.LONG, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgEnum_arg(AgEPositionType), agmarshall.LPSAFEARRAY_arg, agmarshall.AgEnum_arg(AgEPositionType), agmarshall.LPSAFEARRAY_arg,) }
    def ConvertPositionArray(self, positionType:"AgEPositionType", positionArray:list, convertTo:"AgEPositionType") -> list:
        """Converts the specified position values from a given position type to another position type."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._ConvertPositionArray_metadata, positionType, positionArray, convertTo, OutArg())

    _NewDirection_metadata = { "offset" : _NewDirection_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def NewDirection(self) -> "IAgDirection":
        """Creates an IAgDirection interface."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewDirection_metadata, OutArg())

    _NewOrientation_metadata = { "offset" : _NewOrientation_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def NewOrientation(self) -> "IAgOrientation":
        """Creates an IAgOrientation interface."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewOrientation_metadata, OutArg())

    _NewOrbitStateOnEarth_metadata = { "offset" : _NewOrbitStateOnEarth_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def NewOrbitStateOnEarth(self) -> "IAgOrbitState":
        """Creates an IAgOrbitState interface with earth as its central body."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewOrbitStateOnEarth_metadata, OutArg())

    _NewPositionOnCB_metadata = { "offset" : _NewPositionOnCB_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def NewPositionOnCB(self, centralBodyName:str) -> "IAgPosition":
        """Creates an IAgPosition interface using the supplied central body."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewPositionOnCB_metadata, centralBodyName, OutArg())

    _NewOrbitStateOnCB_metadata = { "offset" : _NewOrbitStateOnCB_method_offset,
            "arg_types" : (agcom.BSTR, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.BSTR_arg, agmarshall.AgInterface_out_arg,) }
    def NewOrbitStateOnCB(self, centralBodyName:str) -> "IAgOrbitState":
        """Creates an IAgOrbitState interface using the supplied central body."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewOrbitStateOnCB_metadata, centralBodyName, OutArg())

    _QueryDirectionCosineMatrix_metadata = { "offset" : _QueryDirectionCosineMatrix_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID), POINTER(agcom.PVOID), POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgOrientation"), agmarshall.AgInterface_out_arg, agmarshall.AgInterface_out_arg, agmarshall.AgInterface_out_arg,) }
    def QueryDirectionCosineMatrix(self, inputOrientation:"IAgOrientation") -> typing.Tuple[IAgCartesian3Vector, IAgCartesian3Vector, IAgCartesian3Vector]:
        """Returns a Direction Cosine Matrix (DCM)."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._QueryDirectionCosineMatrix_metadata, inputOrientation, OutArg(), OutArg(), OutArg())

    _QueryDirectionCosineMatrixArray_metadata = { "offset" : _QueryDirectionCosineMatrixArray_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgOrientation"), agmarshall.LPSAFEARRAY_arg,) }
    def QueryDirectionCosineMatrixArray(self, inputOrientation:"IAgOrientation") -> list:
        """Returns a Direction Cosine Matrix (DCM) as an array."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._QueryDirectionCosineMatrixArray_metadata, inputOrientation, OutArg())

    _NewCartesian3Vector_metadata = { "offset" : _NewCartesian3Vector_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_out_arg,) }
    def NewCartesian3Vector(self) -> "IAgCartesian3Vector":
        """Creates a cartesian vector."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewCartesian3Vector_metadata, OutArg())

    _NewCartesian3VectorFromDirection_metadata = { "offset" : _NewCartesian3VectorFromDirection_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgDirection"), agmarshall.AgInterface_out_arg,) }
    def NewCartesian3VectorFromDirection(self, inputDirection:"IAgDirection") -> "IAgCartesian3Vector":
        """Converts the direction to cartesian vector."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewCartesian3VectorFromDirection_metadata, inputDirection, OutArg())

    _NewCartesian3VectorFromPosition_metadata = { "offset" : _NewCartesian3VectorFromPosition_method_offset,
            "arg_types" : (agcom.PVOID, POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.AgInterface_in_arg("IAgPosition"), agmarshall.AgInterface_out_arg,) }
    def NewCartesian3VectorFromPosition(self, inputPosition:"IAgPosition") -> "IAgCartesian3Vector":
        """Converts the position to cartesian vector."""
        return self._intf.invoke(IAgConversionUtility._metadata, IAgConversionUtility._NewCartesian3VectorFromPosition_metadata, inputPosition, OutArg())


agcls.AgClassCatalog.add_catalog_entry((5269429572990182626, 2030319770630291336), IAgConversionUtility)
agcls.AgTypeNameMap["IAgConversionUtility"] = IAgConversionUtility

class IAgDoublesCollection(object):
    """Represents a collection of doubles."""

    _num_methods = 8
    _vtable_offset = IDispatch._vtable_offset + IDispatch._num_methods
    _Item_method_offset = 1
    _get_Count_method_offset = 2
    _get__NewEnum_method_offset = 3
    _Add_method_offset = 4
    _RemoveAt_method_offset = 5
    _RemoveAll_method_offset = 6
    _ToArray_method_offset = 7
    _SetAt_method_offset = 8
    _metadata = {
        "iid_data" : (4956705744396413812, 13718121738100352392),
        "vtable_reference" : IDispatch._vtable_offset + IDispatch._num_methods - 1,
    }
    _property_names = {}
    def __init__(self, sourceObject=None):
        """Construct an object of type IAgDoublesCollection."""
        initialize_from_source_object(self, sourceObject, IAgDoublesCollection)
        self.__dict__["_enumerator"] = None
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def _get_property(self, attrname):
        return get_interface_property(attrname, IAgDoublesCollection)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_interface_attribute(self, attrname, value, IAgDoublesCollection, None)
    def __iter__(self):
        """Create an iterator for the IAgDoublesCollection object."""
        self.__dict__["_enumerator"] = self._NewEnum
        self._enumerator.reset()
        return self
    def __next__(self) -> float:
        """Return the next element in the collection."""
        if self._enumerator is None:
            raise StopIteration
        nextval = self._enumerator.next()
        if nextval is None:
            raise StopIteration
        return nextval
    
    _Item_metadata = { "offset" : _Item_method_offset,
            "arg_types" : (agcom.LONG, POINTER(agcom.DOUBLE),),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.DOUBLE_arg,) }
    def Item(self, index:int) -> float:
        """Returns a double at a specified position."""
        return self._intf.invoke(IAgDoublesCollection._metadata, IAgDoublesCollection._Item_metadata, index, OutArg())

    _get_Count_metadata = { "offset" : _get_Count_method_offset,
            "arg_types" : (POINTER(agcom.LONG),),
            "marshallers" : (agmarshall.LONG_arg,) }
    @property
    def Count(self) -> int:
        """Returns the number of items in the collection."""
        return self._intf.get_property(IAgDoublesCollection._metadata, IAgDoublesCollection._get_Count_metadata)

    _get__NewEnum_metadata = { "offset" : _get__NewEnum_method_offset,
            "arg_types" : (POINTER(agcom.PVOID),),
            "marshallers" : (agmarshall.IEnumVARIANT_arg,) }
    @property
    def _NewEnum(self) -> EnumeratorProxy:
        """Returns a collection enumerator."""
        return self._intf.get_property(IAgDoublesCollection._metadata, IAgDoublesCollection._get__NewEnum_metadata)

    _Add_metadata = { "offset" : _Add_method_offset,
            "arg_types" : (agcom.DOUBLE,),
            "marshallers" : (agmarshall.DOUBLE_arg,) }
    def Add(self, value:float) -> None:
        """Add a value to the collection of doubles."""
        return self._intf.invoke(IAgDoublesCollection._metadata, IAgDoublesCollection._Add_metadata, value)

    _RemoveAt_metadata = { "offset" : _RemoveAt_method_offset,
            "arg_types" : (agcom.LONG,),
            "marshallers" : (agmarshall.LONG_arg,) }
    def RemoveAt(self, index:int) -> None:
        """Remove an element from the collection at a specified position."""
        return self._intf.invoke(IAgDoublesCollection._metadata, IAgDoublesCollection._RemoveAt_metadata, index)

    _RemoveAll_metadata = { "offset" : _RemoveAll_method_offset,
            "arg_types" : (),
            "marshallers" : () }
    def RemoveAll(self) -> None:
        """Clears the collection."""
        return self._intf.invoke(IAgDoublesCollection._metadata, IAgDoublesCollection._RemoveAll_metadata, )

    _ToArray_metadata = { "offset" : _ToArray_method_offset,
            "arg_types" : (POINTER(agcom.LPSAFEARRAY),),
            "marshallers" : (agmarshall.LPSAFEARRAY_arg,) }
    def ToArray(self) -> list:
        """Returns an array of the elements in the collection."""
        return self._intf.invoke(IAgDoublesCollection._metadata, IAgDoublesCollection._ToArray_metadata, OutArg())

    _SetAt_metadata = { "offset" : _SetAt_method_offset,
            "arg_types" : (agcom.LONG, agcom.DOUBLE,),
            "marshallers" : (agmarshall.LONG_arg, agmarshall.DOUBLE_arg,) }
    def SetAt(self, index:int, value:float) -> None:
        """Updates an element in the collection at a specified position."""
        return self._intf.invoke(IAgDoublesCollection._metadata, IAgDoublesCollection._SetAt_metadata, index, value)

    __getitem__ = Item


    _property_names[Count] = "Count"
    _property_names[_NewEnum] = "_NewEnum"


agcls.AgClassCatalog.add_catalog_entry((4956705744396413812, 13718121738100352392), IAgDoublesCollection)
agcls.AgTypeNameMap["IAgDoublesCollection"] = IAgDoublesCollection



class AgExecCmdResult(IAgExecCmdResult, SupportsDeleteCallback):
    """Collection of strings returned by the ExecuteCommand."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgExecCmdResult."""
        SupportsDeleteCallback.__init__(self)
        IAgExecCmdResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgExecCmdResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgExecCmdResult, [IAgExecCmdResult])

agcls.AgClassCatalog.add_catalog_entry((5578266293439448088, 16187374167037800079), AgExecCmdResult)
agcls.AgTypeNameMap["AgExecCmdResult"] = AgExecCmdResult

class AgExecMultiCmdResult(IAgExecMultiCmdResult, SupportsDeleteCallback):
    """Collection of objects returned by the ExecuteMultipleCommands."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgExecMultiCmdResult."""
        SupportsDeleteCallback.__init__(self)
        IAgExecMultiCmdResult.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgExecMultiCmdResult._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgExecMultiCmdResult, [IAgExecMultiCmdResult])

agcls.AgClassCatalog.add_catalog_entry((5597408360176953121, 16609041734428668607), AgExecMultiCmdResult)
agcls.AgTypeNameMap["AgExecMultiCmdResult"] = AgExecMultiCmdResult

class AgUnitPrefsUnit(IAgUnitPrefsUnit, SupportsDeleteCallback):
    """Object that contains info on the unit."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUnitPrefsUnit."""
        SupportsDeleteCallback.__init__(self)
        IAgUnitPrefsUnit.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUnitPrefsUnit._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUnitPrefsUnit, [IAgUnitPrefsUnit])

agcls.AgClassCatalog.add_catalog_entry((5140380005508462669, 10852272987728314258), AgUnitPrefsUnit)
agcls.AgTypeNameMap["AgUnitPrefsUnit"] = AgUnitPrefsUnit

class AgUnitPrefsUnitCollection(IAgUnitPrefsUnitCollection, SupportsDeleteCallback):
    """Object that contains a collection of IAgUnitPrefsUnit."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUnitPrefsUnitCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgUnitPrefsUnitCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUnitPrefsUnitCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUnitPrefsUnitCollection, [IAgUnitPrefsUnitCollection])

agcls.AgClassCatalog.add_catalog_entry((4997790097000541348, 8910467701735531661), AgUnitPrefsUnitCollection)
agcls.AgTypeNameMap["AgUnitPrefsUnitCollection"] = AgUnitPrefsUnitCollection

class AgUnitPrefsDim(IAgUnitPrefsDim, SupportsDeleteCallback):
    """Object that contains info on the Dimension."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUnitPrefsDim."""
        SupportsDeleteCallback.__init__(self)
        IAgUnitPrefsDim.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUnitPrefsDim._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUnitPrefsDim, [IAgUnitPrefsDim])

agcls.AgClassCatalog.add_catalog_entry((5271764906473484718, 16965070245430951351), AgUnitPrefsDim)
agcls.AgTypeNameMap["AgUnitPrefsDim"] = AgUnitPrefsDim

class AgUnitPrefsDimCollection(IAgUnitPrefsDimCollection, SupportsDeleteCallback):
    """Object that contains a collection of dimensions."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgUnitPrefsDimCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgUnitPrefsDimCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgUnitPrefsDimCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgUnitPrefsDimCollection, [IAgUnitPrefsDimCollection])

agcls.AgClassCatalog.add_catalog_entry((5428558532974093061, 4002212422146042015), AgUnitPrefsDimCollection)
agcls.AgTypeNameMap["AgUnitPrefsDimCollection"] = AgUnitPrefsDimCollection

class AgConversionUtility(IAgConversionUtility, SupportsDeleteCallback):
    """Object that contains a unit conversion utility."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgConversionUtility."""
        SupportsDeleteCallback.__init__(self)
        IAgConversionUtility.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgConversionUtility._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgConversionUtility, [IAgConversionUtility])

agcls.AgClassCatalog.add_catalog_entry((5181743311813148101, 15770197442584964502), AgConversionUtility)
agcls.AgTypeNameMap["AgConversionUtility"] = AgConversionUtility

class AgQuantity(IAgQuantity, SupportsDeleteCallback):
    """Object that contains a quantity."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgQuantity."""
        SupportsDeleteCallback.__init__(self)
        IAgQuantity.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgQuantity._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgQuantity, [IAgQuantity])

agcls.AgClassCatalog.add_catalog_entry((5675535125497015062, 16555349346851492745), AgQuantity)
agcls.AgTypeNameMap["AgQuantity"] = AgQuantity

class AgDate(IAgDate, SupportsDeleteCallback):
    """Object that contains a date."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDate."""
        SupportsDeleteCallback.__init__(self)
        IAgDate.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDate._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDate, [IAgDate])

agcls.AgClassCatalog.add_catalog_entry((5102923649362142973, 17408233547208630458), AgDate)
agcls.AgTypeNameMap["AgDate"] = AgDate

class AgPosition(IAgLocationData, IAgPosition, SupportsDeleteCallback):
    """The Position class."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgPosition."""
        SupportsDeleteCallback.__init__(self)
        IAgLocationData.__init__(self, sourceObject)
        IAgPosition.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgLocationData._private_init(self, intf)
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgPosition, [IAgLocationData, IAgPosition])

agcls.AgClassCatalog.add_catalog_entry((4783790566498273220, 15051755396967356547), AgPosition)
agcls.AgTypeNameMap["AgPosition"] = AgPosition

class AgCartesian(IAgCartesian, IAgPosition, SupportsDeleteCallback):
    """Class used to access a position using Cartesian Coordinates."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCartesian."""
        SupportsDeleteCallback.__init__(self)
        IAgCartesian.__init__(self, sourceObject)
        IAgPosition.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCartesian._private_init(self, intf)
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCartesian, [IAgCartesian, IAgPosition])

agcls.AgClassCatalog.add_catalog_entry((4886785515660981294, 13482715367352507267), AgCartesian)
agcls.AgTypeNameMap["AgCartesian"] = AgCartesian

class AgGeodetic(IAgGeodetic, IAgPosition, SupportsDeleteCallback):
    """Class defining Geodetic position."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgGeodetic."""
        SupportsDeleteCallback.__init__(self)
        IAgGeodetic.__init__(self, sourceObject)
        IAgPosition.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgGeodetic._private_init(self, intf)
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgGeodetic, [IAgGeodetic, IAgPosition])

agcls.AgClassCatalog.add_catalog_entry((5002206469410366585, 7585413342857336456), AgGeodetic)
agcls.AgTypeNameMap["AgGeodetic"] = AgGeodetic

class AgGeocentric(IAgGeocentric, IAgPosition, SupportsDeleteCallback):
    """Class defining Geocentric position."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgGeocentric."""
        SupportsDeleteCallback.__init__(self)
        IAgGeocentric.__init__(self, sourceObject)
        IAgPosition.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgGeocentric._private_init(self, intf)
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgGeocentric, [IAgGeocentric, IAgPosition])

agcls.AgClassCatalog.add_catalog_entry((5536768708250821380, 6212014438723660453), AgGeocentric)
agcls.AgTypeNameMap["AgGeocentric"] = AgGeocentric

class AgPlanetodetic(IAgPlanetodetic, IAgPosition, SupportsDeleteCallback):
    """Class defining Planetodetic position."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgPlanetodetic."""
        SupportsDeleteCallback.__init__(self)
        IAgPlanetodetic.__init__(self, sourceObject)
        IAgPosition.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPlanetodetic._private_init(self, intf)
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgPlanetodetic, [IAgPlanetodetic, IAgPosition])

agcls.AgClassCatalog.add_catalog_entry((4865275958093293023, 17880122858575839921), AgPlanetodetic)
agcls.AgTypeNameMap["AgPlanetodetic"] = AgPlanetodetic

class AgPlanetocentric(IAgPlanetocentric, IAgPosition, SupportsDeleteCallback):
    """Class defining Planetocentric position."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgPlanetocentric."""
        SupportsDeleteCallback.__init__(self)
        IAgPlanetocentric.__init__(self, sourceObject)
        IAgPosition.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPlanetocentric._private_init(self, intf)
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgPlanetocentric, [IAgPlanetocentric, IAgPosition])

agcls.AgClassCatalog.add_catalog_entry((4774131885783686972, 215975021935693194), AgPlanetocentric)
agcls.AgTypeNameMap["AgPlanetocentric"] = AgPlanetocentric

class AgSpherical(IAgSpherical, IAgPosition, SupportsDeleteCallback):
    """Class defining spherical position."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgSpherical."""
        SupportsDeleteCallback.__init__(self)
        IAgSpherical.__init__(self, sourceObject)
        IAgPosition.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgSpherical._private_init(self, intf)
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgSpherical, [IAgSpherical, IAgPosition])

agcls.AgClassCatalog.add_catalog_entry((5092243929735143340, 16629405832577163939), AgSpherical)
agcls.AgTypeNameMap["AgSpherical"] = AgSpherical

class AgCylindrical(IAgCylindrical, IAgPosition, SupportsDeleteCallback):
    """Class defining cylindrical position."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCylindrical."""
        SupportsDeleteCallback.__init__(self)
        IAgCylindrical.__init__(self, sourceObject)
        IAgPosition.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCylindrical._private_init(self, intf)
        IAgPosition._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCylindrical, [IAgCylindrical, IAgPosition])

agcls.AgClassCatalog.add_catalog_entry((5727435697763876994, 5872019145677976212), AgCylindrical)
agcls.AgTypeNameMap["AgCylindrical"] = AgCylindrical

class AgDirection(IAgDirection, SupportsDeleteCallback):
    """Class defining direction options for aligned and constrained vectors."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDirection."""
        SupportsDeleteCallback.__init__(self)
        IAgDirection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDirection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDirection, [IAgDirection])

agcls.AgClassCatalog.add_catalog_entry((4972622844825001264, 259476629588993709), AgDirection)
agcls.AgTypeNameMap["AgDirection"] = AgDirection

class AgDirectionEuler(IAgDirectionEuler, IAgDirection, SupportsDeleteCallback):
    """Euler direction sequence."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDirectionEuler."""
        SupportsDeleteCallback.__init__(self)
        IAgDirectionEuler.__init__(self, sourceObject)
        IAgDirection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDirectionEuler._private_init(self, intf)
        IAgDirection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDirectionEuler, [IAgDirectionEuler, IAgDirection])

agcls.AgClassCatalog.add_catalog_entry((5743426898815331373, 1690930472100015514), AgDirectionEuler)
agcls.AgTypeNameMap["AgDirectionEuler"] = AgDirectionEuler

class AgDirectionPR(IAgDirectionPR, IAgDirection, SupportsDeleteCallback):
    """Pitch-Roll (PR) direction sequence."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDirectionPR."""
        SupportsDeleteCallback.__init__(self)
        IAgDirectionPR.__init__(self, sourceObject)
        IAgDirection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDirectionPR._private_init(self, intf)
        IAgDirection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDirectionPR, [IAgDirectionPR, IAgDirection])

agcls.AgClassCatalog.add_catalog_entry((4912859073423007117, 12018351089291632522), AgDirectionPR)
agcls.AgTypeNameMap["AgDirectionPR"] = AgDirectionPR

class AgDirectionRADec(IAgDirectionRADec, IAgDirection, SupportsDeleteCallback):
    """Spherical direction (Right Ascension and Declination)."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDirectionRADec."""
        SupportsDeleteCallback.__init__(self)
        IAgDirectionRADec.__init__(self, sourceObject)
        IAgDirection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDirectionRADec._private_init(self, intf)
        IAgDirection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDirectionRADec, [IAgDirectionRADec, IAgDirection])

agcls.AgClassCatalog.add_catalog_entry((4755265490592473487, 7365114835293023376), AgDirectionRADec)
agcls.AgTypeNameMap["AgDirectionRADec"] = AgDirectionRADec

class AgDirectionXYZ(IAgDirectionXYZ, IAgDirection, SupportsDeleteCallback):
    """Cartesian direction."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDirectionXYZ."""
        SupportsDeleteCallback.__init__(self)
        IAgDirectionXYZ.__init__(self, sourceObject)
        IAgDirection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDirectionXYZ._private_init(self, intf)
        IAgDirection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDirectionXYZ, [IAgDirectionXYZ, IAgDirection])

agcls.AgClassCatalog.add_catalog_entry((5084327274554819417, 10955510114470564541), AgDirectionXYZ)
agcls.AgTypeNameMap["AgDirectionXYZ"] = AgDirectionXYZ

class AgOrientation(IAgOrientation, SupportsDeleteCallback):
    """Class defining the orientation of an orbit."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgOrientation."""
        SupportsDeleteCallback.__init__(self)
        IAgOrientation.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgOrientation, [IAgOrientation])

agcls.AgClassCatalog.add_catalog_entry((5094091112665004814, 12552931884794694536), AgOrientation)
agcls.AgTypeNameMap["AgOrientation"] = AgOrientation

class AgOrientationAzEl(IAgOrientationAzEl, IAgOrientation, SupportsDeleteCallback):
    """AzEl orientation method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgOrientationAzEl."""
        SupportsDeleteCallback.__init__(self)
        IAgOrientationAzEl.__init__(self, sourceObject)
        IAgOrientation.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientationAzEl._private_init(self, intf)
        IAgOrientation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgOrientationAzEl, [IAgOrientationAzEl, IAgOrientation])

agcls.AgClassCatalog.add_catalog_entry((5436578645205542340, 2051705821180885412), AgOrientationAzEl)
agcls.AgTypeNameMap["AgOrientationAzEl"] = AgOrientationAzEl

class AgOrientationEulerAngles(IAgOrientationEulerAngles, IAgOrientation, SupportsDeleteCallback):
    """Euler Angles orientation method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgOrientationEulerAngles."""
        SupportsDeleteCallback.__init__(self)
        IAgOrientationEulerAngles.__init__(self, sourceObject)
        IAgOrientation.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientationEulerAngles._private_init(self, intf)
        IAgOrientation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgOrientationEulerAngles, [IAgOrientationEulerAngles, IAgOrientation])

agcls.AgClassCatalog.add_catalog_entry((5485499845388799498, 4642618011140109457), AgOrientationEulerAngles)
agcls.AgTypeNameMap["AgOrientationEulerAngles"] = AgOrientationEulerAngles

class AgOrientationQuaternion(IAgOrientationQuaternion, IAgOrientation, SupportsDeleteCallback):
    """Quaternion orientation method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgOrientationQuaternion."""
        SupportsDeleteCallback.__init__(self)
        IAgOrientationQuaternion.__init__(self, sourceObject)
        IAgOrientation.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientationQuaternion._private_init(self, intf)
        IAgOrientation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgOrientationQuaternion, [IAgOrientationQuaternion, IAgOrientation])

agcls.AgClassCatalog.add_catalog_entry((5478004044167740338, 15661663069987288478), AgOrientationQuaternion)
agcls.AgTypeNameMap["AgOrientationQuaternion"] = AgOrientationQuaternion

class AgOrientationYPRAngles(IAgOrientationYPRAngles, IAgOrientation, SupportsDeleteCallback):
    """Yaw-Pitch Roll (YPR) Angles orientation system."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgOrientationYPRAngles."""
        SupportsDeleteCallback.__init__(self)
        IAgOrientationYPRAngles.__init__(self, sourceObject)
        IAgOrientation.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientationYPRAngles._private_init(self, intf)
        IAgOrientation._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgOrientationYPRAngles, [IAgOrientationYPRAngles, IAgOrientation])

agcls.AgClassCatalog.add_catalog_entry((5216062330205998232, 2431040311449851776), AgOrientationYPRAngles)
agcls.AgTypeNameMap["AgOrientationYPRAngles"] = AgOrientationYPRAngles

class AgDoublesCollection(IAgDoublesCollection, SupportsDeleteCallback):
    """A collection of doubles."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgDoublesCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgDoublesCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgDoublesCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgDoublesCollection, [IAgDoublesCollection])

agcls.AgClassCatalog.add_catalog_entry((4961001141423142595, 1632769765904225949), AgDoublesCollection)
agcls.AgTypeNameMap["AgDoublesCollection"] = AgDoublesCollection

class AgCartesian3Vector(IAgCartesian3Vector, SupportsDeleteCallback):
    """A 3-D cartesian vector."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCartesian3Vector."""
        SupportsDeleteCallback.__init__(self)
        IAgCartesian3Vector.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCartesian3Vector._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCartesian3Vector, [IAgCartesian3Vector])

agcls.AgClassCatalog.add_catalog_entry((5016372381064673909, 162334041874476445), AgCartesian3Vector)
agcls.AgTypeNameMap["AgCartesian3Vector"] = AgCartesian3Vector

class AgCartesian2Vector(IAgCartesian2Vector, SupportsDeleteCallback):
    """A 2-D cartesian vector."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCartesian2Vector."""
        SupportsDeleteCallback.__init__(self)
        IAgCartesian2Vector.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCartesian2Vector._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCartesian2Vector, [IAgCartesian2Vector])

agcls.AgClassCatalog.add_catalog_entry((4694100951548749791, 16355409252312132778), AgCartesian2Vector)
agcls.AgTypeNameMap["AgCartesian2Vector"] = AgCartesian2Vector

class AgPropertyInfo(IAgPropertyInfo, SupportsDeleteCallback):
    """Property Information coclass."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgPropertyInfo."""
        SupportsDeleteCallback.__init__(self)
        IAgPropertyInfo.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPropertyInfo._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgPropertyInfo, [IAgPropertyInfo])

agcls.AgClassCatalog.add_catalog_entry((5286236984342840384, 14433295702405332392), AgPropertyInfo)
agcls.AgTypeNameMap["AgPropertyInfo"] = AgPropertyInfo

class AgPropertyInfoCollection(IAgPropertyInfoCollection, SupportsDeleteCallback):
    """Property Information Collection coclass."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgPropertyInfoCollection."""
        SupportsDeleteCallback.__init__(self)
        IAgPropertyInfoCollection.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgPropertyInfoCollection._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgPropertyInfoCollection, [IAgPropertyInfoCollection])

agcls.AgClassCatalog.add_catalog_entry((5266200912497155233, 9631256143026290573), AgPropertyInfoCollection)
agcls.AgTypeNameMap["AgPropertyInfoCollection"] = AgPropertyInfoCollection

class AgRuntimeTypeInfo(IAgRuntimeTypeInfo, SupportsDeleteCallback):
    """Runtime Type info coclass."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgRuntimeTypeInfo."""
        SupportsDeleteCallback.__init__(self)
        IAgRuntimeTypeInfo.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgRuntimeTypeInfo._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgRuntimeTypeInfo, [IAgRuntimeTypeInfo])

agcls.AgClassCatalog.add_catalog_entry((5310750197822733971, 15113477984957915526), AgRuntimeTypeInfo)
agcls.AgTypeNameMap["AgRuntimeTypeInfo"] = AgRuntimeTypeInfo

class AgCROrientationAzEl(IAgOrientationAzEl, IAgOrientation, IAgOrientationPositionOffset, SupportsDeleteCallback):
    """AzEl orientation method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCROrientationAzEl."""
        SupportsDeleteCallback.__init__(self)
        IAgOrientationAzEl.__init__(self, sourceObject)
        IAgOrientation.__init__(self, sourceObject)
        IAgOrientationPositionOffset.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientationAzEl._private_init(self, intf)
        IAgOrientation._private_init(self, intf)
        IAgOrientationPositionOffset._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCROrientationAzEl, [IAgOrientationAzEl, IAgOrientation, IAgOrientationPositionOffset])

agcls.AgClassCatalog.add_catalog_entry((5629425498071360462, 13472887956028455354), AgCROrientationAzEl)
agcls.AgTypeNameMap["AgCROrientationAzEl"] = AgCROrientationAzEl

class AgCROrientationEulerAngles(IAgOrientationEulerAngles, IAgOrientation, IAgOrientationPositionOffset, SupportsDeleteCallback):
    """Euler Angles orientation method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCROrientationEulerAngles."""
        SupportsDeleteCallback.__init__(self)
        IAgOrientationEulerAngles.__init__(self, sourceObject)
        IAgOrientation.__init__(self, sourceObject)
        IAgOrientationPositionOffset.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientationEulerAngles._private_init(self, intf)
        IAgOrientation._private_init(self, intf)
        IAgOrientationPositionOffset._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCROrientationEulerAngles, [IAgOrientationEulerAngles, IAgOrientation, IAgOrientationPositionOffset])

agcls.AgClassCatalog.add_catalog_entry((4840627131925552121, 3902022524010776716), AgCROrientationEulerAngles)
agcls.AgTypeNameMap["AgCROrientationEulerAngles"] = AgCROrientationEulerAngles

class AgCROrientationQuaternion(IAgOrientationQuaternion, IAgOrientation, IAgOrientationPositionOffset, SupportsDeleteCallback):
    """Quaternion orientation method."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCROrientationQuaternion."""
        SupportsDeleteCallback.__init__(self)
        IAgOrientationQuaternion.__init__(self, sourceObject)
        IAgOrientation.__init__(self, sourceObject)
        IAgOrientationPositionOffset.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientationQuaternion._private_init(self, intf)
        IAgOrientation._private_init(self, intf)
        IAgOrientationPositionOffset._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCROrientationQuaternion, [IAgOrientationQuaternion, IAgOrientation, IAgOrientationPositionOffset])

agcls.AgClassCatalog.add_catalog_entry((4916724588521169912, 1914183132378344616), AgCROrientationQuaternion)
agcls.AgTypeNameMap["AgCROrientationQuaternion"] = AgCROrientationQuaternion

class AgCROrientationYPRAngles(IAgOrientationYPRAngles, IAgOrientation, IAgOrientationPositionOffset, SupportsDeleteCallback):
    """Yaw-Pitch Roll (YPR) Angles orientation system."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCROrientationYPRAngles."""
        SupportsDeleteCallback.__init__(self)
        IAgOrientationYPRAngles.__init__(self, sourceObject)
        IAgOrientation.__init__(self, sourceObject)
        IAgOrientationPositionOffset.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgOrientationYPRAngles._private_init(self, intf)
        IAgOrientation._private_init(self, intf)
        IAgOrientationPositionOffset._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCROrientationYPRAngles, [IAgOrientationYPRAngles, IAgOrientation, IAgOrientationPositionOffset])

agcls.AgClassCatalog.add_catalog_entry((5537483897697766249, 8061659922439947453), AgCROrientationYPRAngles)
agcls.AgTypeNameMap["AgCROrientationYPRAngles"] = AgCROrientationYPRAngles

class AgCROrientationOffsetCart(IAgCartesian3Vector, SupportsDeleteCallback):
    """Orientation offset cartesian."""

    def __init__(self, sourceObject=None):
        """Construct an object of type AgCROrientationOffsetCart."""
        SupportsDeleteCallback.__init__(self)
        IAgCartesian3Vector.__init__(self, sourceObject)
    def _private_init(self, intf:InterfaceProxy):
        self.__dict__["_intf"] = intf
        IAgCartesian3Vector._private_init(self, intf)
    def __eq__(self, other):
        """Check equality of the underlying STK references."""
        return agcls.compare_com_objects(self, other)
    def __setattr__(self, attrname, value):
        """Attempt to assign an attribute."""
        set_class_attribute(self, attrname, value, AgCROrientationOffsetCart, [IAgCartesian3Vector])

agcls.AgClassCatalog.add_catalog_entry((5639253642343045290, 17032588021575169672), AgCROrientationOffsetCart)
agcls.AgTypeNameMap["AgCROrientationOffsetCart"] = AgCROrientationOffsetCart


################################################################################
#          Copyright 2020-2023, Ansys Government Initiatives
################################################################################
